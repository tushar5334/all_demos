//import './utils';

/* import substractval, { square, add } from './utils'

import isSenior, {isAdult, canDrink} from './person';

console.log('square', square(4));

console.log('add', add(4, 4));

console.log('substractval', substractval(100, 8));




console.log('isAdult', isAdult(21));

console.log('canDrink', canDrink(4));

console.log('isSenior', isSenior(66));

console.log('app is running!!!');
 */

/* import validator from 'validator';

const isEmail = validator.isEmail('test@test.com');
console.log(isEmail); */

import React from 'react';
import ReactDOM from 'react-dom';


const template = <p>Testing Using Babel</p>;
//const template = React.createElement('p', {}, 'Testing 123');
ReactDOM.render(template, document.getElementById('app'));
