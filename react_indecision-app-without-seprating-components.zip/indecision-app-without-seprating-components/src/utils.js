//named export
/* const square = (x)=>x*x;

const add = (a, b)=>a+b;

export { square, add } */

//inline named export

/* export const square = (x)=>x*x;

export const add = (a, b)=>a+b; */


// Default Export

/* const square = (x)=>x*x;

const add = (a, b)=>a+b;

const substractval = (a, b)=>a-b;

export { square, add, substractval as default } */

// Default Export inline

export const square = (x)=>x*x;

export const add = (a, b)=>a+b;

const substractval = (a, b)=>a-b;

//export default (a, b)=>a-b;

export default substractval;

