/* const obj = {
    name:'Tushar',
    getName() {
        return this.name;
    }
} */
//console.log(obj.getName());
/* const getName = obj.getName;
console.log(getName()); */

/* const getName = obj.getName.bind(obj);
console.log(getName()); */


class IndecisionApp extends React.Component {
    constructor(props) {
        super(props)
        this.handleRemoveRemoveAll = this.handleRemoveRemoveAll.bind(this);
        this.handlePick = this.handlePick.bind(this);
        this.handleAddOption = this.handleAddOption.bind(this);
        this.handleDeleteOption = this.handleDeleteOption.bind(this);
        this.state = {
            options: props.options
        };

    }

    componentDidMount() {
        try {
            const json = localStorage.getItem('options');
            const options = JSON.parse(json);
            this.setState(()=>({options}));
            console.log('FetchData...!');
        } catch (error) {
            
        }
        
    }

    componentDidUpdate(prevProps, prevState) {
        if(prevState.options.length !== this.state.options.length) {
            const json = JSON.stringify(this.state.options);
            localStorage.setItem('options', json);
            console.log('SavingData...!');
        }
    }

    componentWillUnmount() {
        console.log('Leaving Component...!');
    }

    handleRemoveRemoveAll() {

        //simplify code
        this.setState(() => ({ options: [] })); // you can return any object in arrow function this.setState(() => ({}))
        /* this.setState(()=>{
            return {
                options:[]
            }
        }) */
    }


    handlePick() {
        const randomNumber = Math.floor(Math.random() * this.state.options.length);
        const option = this.state.options[randomNumber];
        alert(option);
    }

    handleAddOption(option) {
        if (!option) {
            return 'Enter valid value to add item.';
        } else if (this.state.options.indexOf(option) >-1) {
            return 'This option already exists';
        }
        //simplify code
        this.setState((prevState) => ({ options: prevState.options.concat(option)}));
        /* this.setState((prevState)=>{
            return {
                options: prevState.options.concat(option)
            }
        }) */
    }

    handleDeleteOption(optionToRemove) {
        this.setState((prevState)=>{
            return {
                options: prevState.options.filter((option)=>{
                    return optionToRemove !== option
                })
            }
        })
    }
    render() {
        //const title = 'Indecision App';
        const sub_title = '!!Indecision App Sub Title';
        //const options = ['Thing one', 'Thing two', 'Thing four'];
        return(
            <div>
                {/* <Header title="Test Title"/> */}
                {/* <Header title={title} sub_title={sub_title} /> //with props title */}
                <Header sub_title={sub_title} /> {/* remove props title so it can take default title from Header.defaultProps object */}
                <Action hasOptions={this.state.options.length > 0 ? true : false} handlePick={this.handlePick}/>
                <Options options={this.state.options} handleRemove={this.handleRemoveRemoveAll} handleDeleteOption={this.handleDeleteOption} />
                <AddOption handleAddOption={this.handleAddOption}/>
            </div>
        );
    }
}

// Default props for class component
IndecisionApp.defaultProps = {
    options: []//['option 1', 'option 2']
};

//stateless functional component
const Header = (props)=>{
    return (
        <div>
            <h1>
                {props.title}
            </h1>
            <h1>
                {props.sub_title}
            </h1>
        </div>
    );
}

//Setup default props value for stateless functional component
Header.defaultProps = {
    title:'Default Title'
};


// class base component
// class Header extends React.Component {
//     render() {
//         //console.log(this.props);
//         return (
//             <div>
//                 <h1>
//                     {this.props.title}
//                 </h1>
//                 <h1>
//                     {this.props.sub_title}
//                 </h1>
//             </div>
//         );
//     }
// }

//stateless functional component
const Action = (props)=>{
    return (
        <div>
            <button onClick={props.handlePick} disabled={!props.hasOptions}>What Should I Do?</button>
        </div>
    );
}

// class base component
// class Action extends React.Component {
//     /* handleClick() {
//         alert('handl click');
//     } */
//     render() {
//         return (
//             <div>
//                 <button onClick={this.props.handlePick} disabled={!this.props.hasOptions}>What Should I Do?</button>
//             </div>
//         );
//     }

// }

//stateless functional component
const Options = (props)=>{
    return (
        <div>
            {/* <button onClick={handleRemoveAll}>Remove All</button> */}
            <button onClick={props.handleRemove}>Remove All</button>
            {/* props.options.length */}
            {props.options.length===0 && <p>Please add an option to get started!</p>}
            {
                /* props.options.map((option) => <p key={option}>{option}</p>) */
                props.options.map((option) =>(
                    <Option key={option}
                    optionText={option}
                        handleDeleteOption={props.handleDeleteOption} />
                    )
                )
            }
            {/* <Option /> */}
        </div>
    );
}
// class base component
// class Options extends React.Component {
//     /* constructor(props) {
//         super(props);
//         this.handleRemoveAll = this.handleRemoveAll.bind(this);
//     }

//     handleRemoveAll() {
//         console.log(this.props.options);
//     } */
//     render() {
//         return (
//             <div>
//                 {/* <button onClick={this.handleRemoveAll}>Remove All</button> */}
//                 <button onClick={this.props.handleRemove}>Remove All</button>
//                 {/* this.props.options.length */}
//                 {
//                     /* this.props.options.map((option) => <p key={option}>{option}</p>) */
//                     this.props.options.map((option) => <Option key={option} optionText={option} />)
//                 }
//                 {/* <Option /> */}
//             </div>
//         );
//     }
// }

//stateless functional component
const Option = (props) => {
    return (
        <div>
            <p style={{ color: "red" }}>{props.optionText}</p>
            <button onClick={(e)=>{
                props.handleDeleteOption(props.optionText);
            }}>
            Remove</button>
        </div>
    );
}


// class base component
// class Option extends React.Component {
//     render() {
//         return(
//             <div>
//                 <p style={{ color: "red" }}>{this.props.optionText}</p>
//             </div>
//         );
//     }
// }

class AddOption extends React.Component {
    constructor(props) {
        super(props)
        this.handleAddOptionLocal = this.handleAddOptionLocal.bind(this);
        this.state = {
            error:undefined
        }
    }
    handleAddOptionLocal(e) {
        e.preventDefault();
        const option = e.target.elements.option.value.trim();
        const error = this.props.handleAddOption(option);
        //simplify code
        this.setState(() => ({ error }));
        /* this.setState(()=> {
            return { error };
        }) */

        if(!error) {
            e.target.elements.option.value = "";
        }

    }
    render() {
        return (
            <div>
                {this.state.error && <p>{this.state.error}</p>}
                <form onSubmit={this.handleAddOptionLocal}>
                    <input type="text" name="option" />
                    <button>Add Option</button>
                </form>
            </div>
        );
    }
}

// const JSX = (
//     <div>
//         {/*<h1>Title</h1>*/}
//         <Header />
//         <Action />
//         <Options />
//         <AddOption />
//     </div>
// );

//ReactDOM.render(JSX, document.getElementById('app'));

//ReactDOM.render(<IndecisionApp options={['1','2']}/>, document.getElementById('app')); //class with default props
ReactDOM.render(<IndecisionApp />, document.getElementById('app'));