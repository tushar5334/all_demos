console.log('app.js is running!')
//var template = <h1>Indecision App</h1>;
/* var template = React.createElement("p", {
    id: "someid"
}, "This is JSX Example!"); */
const app = {
    title: 'Indecision App!',
    subTitle: 'This is some text',
    options: []
};
const appName = 'Indecision App!';
const appText = 'This is some text';

const onFormSubmit = (e) => {
    e.preventDefault();
    const option = e.target.elements.option.value;
    if (option) {
        app.options.push(option);
        e.target.elements.option.value = "";
    }
    renderIndecisionApp();
}

const onRemoveAll = () => {
    app.options = [];
    renderIndecisionApp();
}

const onMakeDecision = () => {
    const randomNumber = Math.floor(Math.random() * app.options.length);
    const option = app.options[randomNumber];
    alert(option);
}

const numbers = [10, 11, 22];
const renderIndecisionApp = () => {
    const template = (
        /* <div>
            <h1>Indecision App</h1>
            <p>This is some text</p>
            { [11,12,13,'Mango', undefined, null, true] }
            {[<p key="A">A</p>, <p key="B">B</p>, <p key="C">C</p>]}
            <ol>
                <li>Item 1</li>
                <li>Item 2</li>
            </ol>
        </div> */
        <div>
            <h1>{app.title}</h1>
            {app.subTitle && <p>{app.subTitle}</p>}
            <p>{app.options.length > 0 ? 'Here are your options' : 'No options'}</p>
            <button disabled={app.options.length > 0 ? false : true} onClick={onMakeDecision}>What should i do?</button>
            <button onClick={onRemoveAll}>Remove All</button>
            { numbers.map((number) => {
                return <p key={number}>Number: {number * 2}</p>;
            })}
            <ol>
                {app.options.map((option) => <li key={option}>{option}</li>)}
            </ol>
            <form onSubmit={onFormSubmit}>
                <input type="text" name="option" />
                <button>Add Option</button>
            </form>
        </div>
    );
    ReactDOM.render(template, appRoot);
}
const appRoot = document.getElementById('app');


renderIndecisionApp();


