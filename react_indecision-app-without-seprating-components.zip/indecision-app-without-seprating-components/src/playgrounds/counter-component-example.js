class Counter extends React.Component {

    constructor(props) {
        super(props)
        this.handleAdd = this.handleAdd.bind(this);
        this.handleMinus = this.handleMinus.bind(this);
        this.handleReset = this.handleReset.bind(this);
        this.state = {
            count: props.count,
            name:'Tushar'
        };
    }
    componentDidMount() {
        const countString = localStorage.getItem('count');
        const count = parseInt(countString, 10);
        if(!isNaN(count)) {
            this.setState(()=>({count}))
        }
    }
    componentDidUpdate(prevProps, prevState) {
        if(prevState.count !== this.state.count) {
            localStorage.setItem('count',this.state.count)
        }
    }

    handleAdd() {
        this.setState((prevState)=>{
            return {
                count: prevState.count + 1,
                name:'Dhaval'
            };
        });
    }

    handleMinus() {
        this.setState((prevState)=>{
            return {
                count: prevState.count - 1
            }
        })
    }

    handleReset() {

        this.setState(()=>{
            return {
                count: this.props.count,
                name:'Tushar'
            }
        });

        /* this.setState((prevState)=>
        {
            return { count: prevState.count + 1}
        }); */


        /* don`t use below code */
        /* this.setState({
            count:0
        });

        this.setState({
            count: this.state.count + 1
        }); */



    }

    render() {
        return (
            <div>
                <h1>Name: {this.state.name}</h1>
                <h1>Counter: {this.state.count}</h1>
                <button onClick={this.handleAdd}>+1</button>
                <button onClick={this.handleMinus}>-1</button>
                <button onClick={this.handleReset}>Reset</button>
            </div>
        );
    }

}

Counter.defaultProps = {
    count:0
};

//ReactDOM.render(<Counter count={-10}/>, document.getElementById('app')); with default props value
ReactDOM.render(<Counter/>, document.getElementById('app'));