// eslint-disable-next-line import/prefer-default-export
export const Attributes = {
  COLOR: 'Colors',
  ARRAY: 'Array',
  TOGGLE: 'Toggle',
};
