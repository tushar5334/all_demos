<template>
  <div style="width: 100%;">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'OrderView',
};
</script>

<style>

</style>
