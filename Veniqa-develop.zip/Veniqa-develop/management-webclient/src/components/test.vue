<template>
  <div>
    <ul>
      <li>I want to be single</li>
    </ul>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  },
};
</script>

<style>
</style>
