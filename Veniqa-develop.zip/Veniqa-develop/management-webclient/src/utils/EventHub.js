import Vue from 'vue';

// eslint-disable-next-line import/prefer-default-export
export const eventHub = new Vue();
