module.exports = {
  singleQuote: true,
  semi: true,
  printWidth: 120,
  proseWrap: 'always'
};
