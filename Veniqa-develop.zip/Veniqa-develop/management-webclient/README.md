## Veniqa Management Webclient

For Documentation, Refer to [Wiki](https://github.com/Viveckh/Veniqa/wiki).