import ProxyUrl from './ProxyUrls';

export const SilentUrls = [ProxyUrl.isSessionActive];

export default SilentUrls;
