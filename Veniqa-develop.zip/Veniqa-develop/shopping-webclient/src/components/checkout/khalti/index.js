import Khalti from './KhaltiEntry.vue';

export {
  // eslint-disable-next-line import/prefer-default-export
  Khalti,
};
