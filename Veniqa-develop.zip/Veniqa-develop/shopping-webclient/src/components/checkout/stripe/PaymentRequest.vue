<template>
  <div>
    <div id="payment-request-button"></div>

  </div>
</template>

<script>
export default {

};
</script>

<style>

</style>
