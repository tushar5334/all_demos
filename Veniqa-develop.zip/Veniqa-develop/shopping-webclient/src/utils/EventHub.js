/* eslint-disable import/prefer-default-export */
import Vue from 'vue';

export const eventHub = new Vue();
