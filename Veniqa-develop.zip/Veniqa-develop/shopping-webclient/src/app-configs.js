export default {
  analyticsId: 'UA-157968226-3'
};
