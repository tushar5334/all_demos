## Veniqa Management Server

For Documentation, Refer to [Wiki](https://github.com/Viveckh/Veniqa/wiki).