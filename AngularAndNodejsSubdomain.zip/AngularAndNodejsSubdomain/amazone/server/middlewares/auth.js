const jwt = require('jsonwebtoken')
const config = require('../config')

const auth = async (req, res, next)=>{
	try {
		const token = req.header('Authorization').replace('Bearer ','')
		const decode = jwt.verify(token, config.secret)
		console.log(decode)
		if(!decode) {
			throw new Error()
		}
		req.decode = decode
		next()

	} catch (e) {
		res.status(403).send({
            success: false,
            message: 'Authentication Failed!'
        })
	}
}

module.exports = auth