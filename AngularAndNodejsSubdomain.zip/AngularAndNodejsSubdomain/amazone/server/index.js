const express = require('express')
const bodyParser = require('body-parser')
const morgan = require('morgan')
const mongoose = require('mongoose')
const cors = require('cors')
const config = require('./config')
const path = require('path')
const app = express()
const userRoutes = require('./routes/accounts')
const categoryRoutes = require('./routes/main')
const sellerRoutes = require('./routes/seller')

const staticDirPath = path.join(__dirname, './public')
app.use(express.static(staticDirPath))
mongoose.connect(config.database,{
	useNewUrlParser:true,
	useCreateIndex:true,
	useFindAndModify: false,
	useUnifiedTopology: true
},(error)=>{
	if(error){
		console.log(error)
	} else {
		console.log('Connected to the database successfully!')
	}

})
//app.use(express.json())
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended:false }))
app.use(morgan('dev'))
app.use(cors())

//category Routes
app.use('/api', categoryRoutes)

//seller Routes
app.use('/api/seller', sellerRoutes)

//User Routes
app.use('/api/accounts', userRoutes)
/*app.get('/',(req, res, next)=>{
	res.json({name:"Tushar Patil"})
})*/

app.listen(config.port,()=>{

	console.log('server listening on port :'+config.port)
})