const express = require('express')
const Category = require('../models/category')
const router = new express.Router()
router.route('/categories')
.get( async (req, res, next)=>{
	try {
		const categories = await Category.find({})
		if(!categories) {
			return res.status(404).send({success:false, message:'Categories not found!'})
		}

		res.send({success:true, message:'Categories found successfully!', categories})

	} catch(e) {
		res.status(500).send({success:false, message:'Something went wrong'})
	}
})
.post( async (req, res, next)=>{
	try {
		let category = new Category()
		category.name = req.body.name
		category.save()
		res.send({success:true, message:'Category added successfully!'})
	} catch(e) {
		res.status(400).send({success:false, message:'Something went wrong'})
	}
})

module.exports = router
