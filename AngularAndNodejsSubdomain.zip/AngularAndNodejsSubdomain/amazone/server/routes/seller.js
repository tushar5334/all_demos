const express = require('express')
const Product = require('../models/product')
const faker = require('faker')
//const aws = require('aws-sdk')
const multer = require('multer')
//const multerS3 = require('multer-s3')
const auth = require('./../middlewares/auth')

const router = new express.Router()
/* const s3 = new aws.S3({
	accessKeyId: "AKIAIBR5G5OP47EVSYJA",
	secretAccessKey: "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"
}); */

const upload = multer({
	dest:'avtars',
	limits: {
		fileSize: 1000000
	},
	fileFilter(req, file, cb) {
		if (!file.originalname.match(/\.(jpg|jpeg|png)$/)) {
			cb(new Error('Please upload valid image file'))
		}

		cb(undefined, true)
	}
})
/* const upload = multer({
	storage:multerS3({
		s3:s3,
		bucket: 'amazonowebapplication',
		metadata: function(req, file, cb) {
			cb(null, {fieldName:file.fieldname})
		},
		key: function(req, file, cb) {
			cb(null, Date.now().toString())
		},
	})
}) */
router.post('/test',  (req, res) => {
	console.log(req.body)
})
router.get('/faker/test', (req, res) => {
	for(i=1;i<=20;i++) {
		const randNumber = Math.floor(Math.random() * (10 - 1 + 1)) + 1;
		let product = new Product()
		product.owner = "5e5e33bd1c7c3c3d3c8db13b";
		product.category = "5e70b53563a7204e3bffd11e";
		product.title = faker.commerce.productName();
		product.price = faker.commerce.price();
		product.description = faker.lorem.words();
		//product.image = req.file.location;
		product.image = "http://localhost:3030/products/" + randNumber + ".jpg";
		product.save();
	}
	res.send({ success: true, message: 'Product added successfully!' })
})
router.route('/products')
.get(auth, async (req, res, next)=>{
	try {
		const products = await Product.find({
			owner: req.decode.user._id
		})
		.populate('owner')
		.populate('category')
		.exec()
		if (!products) {
			return res.status(404).send({ success: false, message: 'Products not found!' })
		}
		res.send({ success: true, message: 'Product found successfully!', products })
	} catch (e) {
		res.status(500).send({ success: false, message: 'Something went wrong' })
	}
})
//.post([auth, upload.single('product_picture')], async (req, res, next) => {
	.post([auth, upload.single('product_picture')], async (req, res, next)=>{
		//console.log('S3 Upload',req.file);
		/* console.log('S3 Upload',upload)*/
		//console.log('Request Params', req.body)
		const randNumber = Math.floor(Math.random() * (10 - 1 + 1)) + 1;
	try {
		let product = new Product()
		product.owner = req.decode.user._id;
        product.category = req.body.categoryId;
        product.title = req.body.title;
        product.price = req.body.price;
        product.description = req.body.description;
        //product.image = req.file.location;
		product.image = "http://localhost:3030/products/" + randNumber+".jpg";
        product.save();
		res.send({success:true, message:'Product added successfully!'})
	} catch(e) {

		res.status(400).send({success:false, message:'Something went wrong'})
	}

})


module.exports = router
