import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  sampleModelArray:Array<any> =[];
  selectedSampleModelArray:Array<any> =[{name:"Ram"},{name:"BalRam"}];
  title = 'app';
  constructor() { }
  ngOnInit() {
  	this.selectedSampleModelArray.forEach((value : any, key: any) => {
  		this.sampleModelArray.push({name:value.name});
	});
  }

  add(){
  	this.sampleModelArray.push({name:""});
  }

  remove(i){
  	if(this.sampleModelArray.length > 0){
  		this.sampleModelArray.splice(i, 1);
  	}
  }
  submit(){
  	console.log(JSON.stringify(this.sampleModelArray));
  }
}
