import { TestBed, async, fakeAsync, ComponentFixture } from '@angular/core/testing';
import { AppComponent } from './app.component';
import { By } from '@angular/platform-browser';
describe('AppComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        AppComponent
      ],
    }).compileComponents();
  }));
  it('should create the app', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  }));
  it(`should have as title 'app'`, async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app.title).toEqual('app');
  }));
  it('should render title in a h1 tag', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('h1').textContent).toContain('Welcome to app');
  }));

  it('should render title in a <a> tag', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    //fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;

    // with id selector
    //expect(compiled.querySelector('#tour').textContent).toContain('Tour of Heroes');
    // with css selector
    //expect(compiled.querySelector('.cli').textContent).toContain('CLI Documentation');

    const El = fixture.debugElement.query(By.css('#tour'));
    //expect(El.nativeElement.textContent).toContain('Tour of Heroes');
    expect(El.nativeElement.textContent).toEqual('Tour of Heroes');
  }));

  it('should trigger a buttons click event 1', () => {
    const fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      let comp = fixture.componentInstance;
      spyOn(comp, 'onSelect');
      let el = fixture.debugElement.query(By.css('button')).nativeElement.click();
      expect(comp.onSelect).toHaveBeenCalled();
    });
  });

  it('should trigger a buttons click event 2', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    //fixture.detectChanges();
    const component = fixture.componentInstance;
    spyOn(component, 'onSelect');

    //let button = fixture.debugElement.nativeElement.querySelector('button');
    let button = fixture.debugElement.query(By.css('button')).nativeElement;
    button.click();

    fixture.whenStable().then(() => {
      expect(component.onSelect).toHaveBeenCalled();
    });
  }));

it('should trigger a buttons click event 3', fakeAsync( () => {
    const fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
    const component = fixture.componentInstance;
    spyOn(component, 'onSelect'); //method attached to the click.
    let btn = fixture.debugElement.query(By.css('button'));
    btn.triggerEventHandler('click', null);
    fixture.detectChanges();
    expect(component.onSelect).toHaveBeenCalled();
}));

});
