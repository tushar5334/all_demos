import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Lazy2RoutingModule } from './/lazy2-routing.module';

@NgModule({
  imports: [
    CommonModule,
    Lazy2RoutingModule
  ],
  declarations: []
})
export class Lazy2Module { }
