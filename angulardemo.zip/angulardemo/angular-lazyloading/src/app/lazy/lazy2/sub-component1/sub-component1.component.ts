import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub-component1',
  templateUrl: './sub-component1.component.html',
  styleUrls: ['./sub-component1.component.css']
})
export class SubComponent1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
