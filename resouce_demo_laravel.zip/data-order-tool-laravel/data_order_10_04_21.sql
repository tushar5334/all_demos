-- Adminer 4.7.8 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `do_migrations`;
CREATE TABLE `do_migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `do_pages`;
CREATE TABLE `do_pages` (
  `page_id` char(36) NOT NULL,
  `title` varchar(765) DEFAULT NULL,
  `meta_title` varchar(765) DEFAULT NULL,
  `meta_keywords` varchar(765) DEFAULT NULL,
  `description` text,
  `meta_description` text,
  `name` varchar(1000) DEFAULT NULL,
  `page_slug` varchar(1000) DEFAULT NULL,
  `is_static` tinyint(2) DEFAULT NULL COMMENT '0-Static, 1-Dynamic',
  `status` tinyint(4) DEFAULT '1' COMMENT '0-InActive, 1-Active',
  `created_by` char(36) NOT NULL,
  `updated_by` char(36) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`page_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `do_pages` (`page_id`, `title`, `meta_title`, `meta_keywords`, `description`, `meta_description`, `name`, `page_slug`, `is_static`, `status`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
('0ae148f2-8af6-4445-9661-34ac3d62bd80',	'Ipsam placeat in si',	'Illum sint deserunt',	'Officiis rerum sint',	'Aut deserunt deserun',	NULL,	'Keegan Chavez',	'keegan_chavez',	0,	1,	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'2021-03-13 10:29:30',	'2021-03-12 10:33:24',	NULL),
('162006b6-7fcd-47a8-82e4-0503a58c6f37',	'dd',	'sdfsdf',	'sdfsdf',	'<p><img alt=\"\" src=\"http://data-order-tool-laravel.local/images/ckeditor/download_1616066560.png\" style=\"height:225px; width:225px\" />hhghasgfhsgdf hhsbfgsf ghsgfhdfhjsdf</p>',	NULL,	'dfsdfasd',	'dfsdfasd',	1,	1,	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'2021-03-18 11:15:23',	'2021-03-18 11:22:54',	NULL),
('2b12436b-40b4-4168-821d-ae597c2085a2',	'Do ipsum eveniet an',	'Voluptate eligendi u',	'Ullamco quae iure id',	'<p>In aut ut accusantiu</p>',	'hell\r\nr u there',	'Upton Leblanc',	'upton_leblanc',	0,	1,	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'2021-03-10 10:29:37',	'2021-03-18 12:11:42',	NULL),
('90dd641b-3826-4eea-ab65-351a484b6e27',	'Quos quis duis bland',	'Cumque commodo corpo',	'Quibusdam nostrum vo',	'Autem blanditiis inc',	NULL,	'Selma Wheeler',	'selma_wheeler',	1,	1,	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'2021-03-12 10:29:21',	'2021-03-12 10:33:24',	NULL),
('bae95bb5-2c56-49d9-bb6f-66e59cdeb839',	'Occaecat occaecat im',	'Laborum Quis incidu',	'Incidunt vel et fug',	'Quis culpa laborum',	NULL,	'Guy Williamson',	'guy_williamson',	0,	0,	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'2021-03-11 10:29:53',	'2021-03-17 10:09:24',	NULL),
('c5171211-6988-4ad6-9b73-9afc64a5dd71',	'Amet commodo odio f mic',	'Beatae eum est est',	'Nobis vero sequi del',	'Ipsum nemo quidem fu',	NULL,	'Alec Chandler',	'alec_chandler',	0,	1,	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'2021-03-18 07:57:29',	'2021-03-18 07:57:29',	NULL),
('cca179ff-14e4-4a2e-8bd4-1979ad7ec345',	'Officiis velit libe',	'Qui sit iste nemo ul',	'Anim aut sit natus',	'Esse aute nostrud mfhfghfgh\r\nd\r\ngdfgdfgdf\r\ndfgdsfgsdfg\r\ndfgsdfgdf\r\ngdfgsdfgdf',	NULL,	'Idona Owen',	'idona_owen',	1,	0,	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'2021-03-12 10:29:45',	'2021-03-17 10:09:22',	NULL),
('e376001f-566c-4790-9834-7c1f73050fb9',	'Ea vitae mollit ipsu',	'In sit autem cillum',	'Voluptas accusantium',	'Non non duis odio la',	NULL,	'Yael Kaufman',	'yael_kaufman',	1,	1,	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'2021-03-10 09:51:24',	'2021-03-12 10:33:24',	NULL),
('e90fc5c0-f2cc-4033-95dd-b082c9381cef',	'dssf',	'sdfsdf',	'sdfsd',	'fdsfsd\r\nsadfsdf\r\nsaddasdsdasdsd sadsdsadsfsdf\r\nsdasfdsfdfadfd\r\nsfsdfsdfd \r\nfsdfffasdfadfdssdfsadf\r\ndsfdsafdfdf sdfsdfdfd \r\nsdfsdfadsfd',	NULL,	'dsfsdf',	'dsfsdf',	0,	1,	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'2021-03-12 07:06:55',	'2021-03-12 10:33:24',	NULL),
('f59037f9-5ace-490d-a11a-0ea4b7dcbec4',	'Quo non recusandae',	'Dolores delectus si',	'Proident magni quae',	'Fuga Tempora ad qui',	NULL,	'Lydia Adams',	'lydia_adams',	1,	1,	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'2021-03-12 10:29:58',	'2021-03-12 10:33:24',	NULL),
('fd8b3e6f-9488-4b5d-b134-71b17744f092',	'qwwr',	'qerewr',	'ewrewr',	'54645634563456345645',	NULL,	'mansi435345',	'mansi435345',	1,	1,	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'2021-03-12 09:28:46',	'2021-03-12 09:49:03',	NULL);

DROP TABLE IF EXISTS `do_users`;
CREATE TABLE `do_users` (
  `user_id` char(36) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `user_type` enum('SuperAdmin','User') NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT ' 1=active, 0=deactive 	',
  `profile_picture` varchar(255) DEFAULT NULL,
  `token` varchar(100) DEFAULT NULL,
  `remember_token` text,
  `created_by` varchar(100) DEFAULT NULL,
  `updated_by` varchar(100) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `do_users` (`user_id`, `name`, `email`, `user_type`, `password`, `status`, `profile_picture`, `token`, `remember_token`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
('1af1f3c6-fca5-4f09-b560-d68622430963',	'Nita Francis',	'fohy@mailinator.com',	'User',	'$2y$10$NxWMF7CpMTtdfaR7Nr9zku2QlrZguQNkYPbQ7LqcWUFtr3DcVOnJu',	1,	NULL,	NULL,	NULL,	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'2021-02-26 07:15:09',	'2021-03-09 05:58:39',	NULL),
('2f32303c-6e6c-44d2-bdac-01b32063f250',	'Cally Fletcher',	'cehotugeza@mailinator.com',	'User',	'$2y$10$Ym3x62gAG8/iHB5ql.I/yuMIIGnbnnfBfJ6ZuvlrgO1E46y7qAfo2',	1,	NULL,	NULL,	NULL,	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'2021-02-26 07:14:48',	'2021-03-09 05:58:39',	NULL),
('41a7de3e-746a-4aae-b566-67b05e94a4db',	'Bo Landry',	'suniwybu@mailinator.com',	'User',	'$2y$10$dQrLCwjifFkkEocAULD68.b2FLC832FhAJBLYU7zJ2KAV/MHxZmSa',	1,	NULL,	NULL,	NULL,	NULL,	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'2021-02-24 10:12:11',	'2021-03-09 05:58:39',	NULL),
('4f9a4456-516e-46cb-9935-b2bcdc9c32b5',	'Emmanuel Page',	'catugyno@mailinator.com',	'User',	'$2y$10$1oFu4/u6g4fF6BuzRy5fUeQEvnfyFQyF4ArcNdTrDj8F0gbULOMa.',	1,	NULL,	NULL,	NULL,	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'2021-02-26 07:17:56',	'2021-03-04 05:42:38',	NULL),
('7a37f6be-62c9-4fc4-b593-ee012e7ca854',	'Zena Buchanan',	'jizy@mailinator.com',	'SuperAdmin',	'$2y$10$2TUX17y8Pm6T2eE4ibhZzO6b32RCFAWkjIsovvPnulgOCKZqcGPNG',	1,	NULL,	NULL,	NULL,	NULL,	NULL,	'2021-02-26 10:51:17',	'2021-03-09 05:58:39',	NULL),
('8ea060b1-ffb1-4642-8342-999896a0c85a',	'Kalia Allen',	'kihe@mailinator.com',	'User',	'$2y$10$.fEjK8mzfOP8IgrR9Qp0yuNE9Nz4H5/mEsdKvtbX3rlVd62X51mZC',	1,	NULL,	NULL,	NULL,	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'2021-03-09 05:43:57',	'2021-03-09 05:58:39',	NULL),
('92d21e0c-5fdf-4952-8d38-f88c89ed7920',	'Hope Oneill',	'lulutar@mailinator.com',	'User',	'$2y$10$WI3Xr9kf9K/H2YO2usbDjOhYsD9Nod0dDUL6n5v5BGsvJahMlqKSK',	1,	'gJI3f9aiXG1QGjyidBtXEw3pVRcd4hhaoxzU0uMD.png',	NULL,	NULL,	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'2021-02-26 11:36:16',	'2021-03-09 05:58:39',	NULL),
('9b135c95-db4c-4256-8413-0a33f5ab45ac',	'tushar patil',	'tushar.patil@txtech.co',	'SuperAdmin',	'$2y$10$j5f0lveXnkMtgX7j3RQS7uvzg6kA.1RixtS3qyzjDCgT4hw2qDOv6',	1,	'',	'TQkvAN2enRNNaRpeEWn5j1nFokCo7b',	'c6iz0u480ocxngtIlnMljWFS2lePX6KjRsjV8bVhXiD40xKrCr5jXNHRWEtN',	NULL,	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'2021-02-24 06:05:56',	'2021-03-09 06:38:00',	NULL),
('a9980ad4-75c7-11eb-a3c6-8cdcd4472809',	'mansi patel',	'mansi.barochiya@txtech.co',	'User',	'$2y$10$evtnpbAutliL.wTTIZrD3erOZREXdSnnK8ENzoj49/bTUijpVI.dO',	1,	NULL,	NULL,	'SuyEP0Q8ewCQA3AZOEEXKAK3YX1cgjYrytEaognuM1VaDJRkY0LikHOTaZ8P',	NULL,	NULL,	'2021-02-23 16:39:56',	'2021-03-09 05:58:39',	NULL),
('d348aa0b-dedf-48ba-8e6a-e06a284528a5',	'Byron Simon',	'bemahav@mailinator.com',	'SuperAdmin',	'$2y$10$KSac8AU/7NQTWSKxKNeTc..6BHhMRec.Das0DNcWagTALfHCpZoIK',	1,	NULL,	NULL,	NULL,	NULL,	NULL,	'2021-03-09 07:37:50',	'2021-03-09 07:37:50',	NULL),
('e44002e5-08c8-4342-8823-e367c25a3fe1',	'mansisdasda',	'mansi@gmail.com',	'User',	'$2y$10$my/VgCME9MkSX8OlqcmewuBvVxHcqvgRZG.iM6nYNhW3hRguzHd1e',	1,	'9GOjITr91XDXn2VpHNZvgEhTibxP9o8eWrbB8qe9.png',	NULL,	NULL,	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'2021-02-26 05:38:29',	'2021-03-09 05:58:39',	NULL),
('fe1362b7-ebd5-4f99-8c17-61c4485fd43f',	'khushbu lakhataria',	'khushboo@gmail.com',	'User',	'$2y$10$c9HqgMMwn4KuZCK3miR9jOWuVoTeM3gKI3Mn71y6ieNuLiTUgVWZe',	1,	NULL,	NULL,	NULL,	NULL,	NULL,	'2021-02-24 09:35:32',	'2021-03-09 05:58:39',	NULL);

-- 2021-04-12 08:12:13
