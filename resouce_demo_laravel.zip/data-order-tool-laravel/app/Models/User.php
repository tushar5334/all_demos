<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\ColumnFillable;
use Illuminate\Support\Str;
use App\Libraries\General;

use Config;
use Auth;

class User extends Authenticatable
{
    use HasFactory, Notifiable;
    use SoftDeletes;
    use ColumnFillable;
    protected $table = 'users';
    protected $primaryKey = 'user_id';
    public $incrementing = false;
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    /* protected $fillable = [
        'name',
        'email',
        'password',
    ];
 */
    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];
    protected static function boot()
    {
        parent::boot();

        User::creating(function ($model) {
            $model->setUserId();
        });
    }
    

    public function setUserId()
    {
        $this->attributes['user_id'] = Str::uuid();
    }
    public static function createUpdateUser($request, $old_profile_pic = ''){
        //echo '<pre>';print_r($request->imgdel);echo'</pre>';exit;
        if ($request->file('profile_picture')){
            // Upload Image
            $fileData = General::storagefileupload('user_images', $request->file('profile_picture'), $old_profile_pic);
            $input = $request->except(['profile_picture', 'user_id', 'confirm_password', '_method', '_token']);
            $input['profile_picture'] = $fileData;
        }else{
            if($request->imgdel == 1){
                 $fileData = General::storagefileupload('user_images','', $old_profile_pic);
            }
            $input = $request->except(['user_id', 'confirm_password', 'profile_picture', '_method', '_token']);
        }
        $user = User::updateOrCreate(
            ['user_id' => $request->user_id],
            $input
        );
        return $user;
    }
}
