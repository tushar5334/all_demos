<?php namespace App\Libraries;

/*array(
	'to' => array(
	    array(
	        'email'=>'ashwin@transaction.partners',
	        'display_name'=>'Ashwin'
	    )
	),
	'cc' => array(
	    array(
	        'email'=>'ashwin@transaction.partners',
	        'display_name'=>'Ashwin'
	    )
	),
	'bcc' => array(
	    array(
	        'email'=>'ashwin@transaction.partners',
	        'display_name'=>'Ashwin'
	    )
	)
)*/


use Mail;
use Illuminate\Support\Facades\Config;
use App\Libraries\CustomErrorHandler;
use App\Libraries\General;

class Emailsend  {

	public static $sendMailLocal = [
	 	
		[
			'email'=>'mansi.barochiya@txtech.co',
			'display_name'=>'Data Order'
		]
	];

	public static $localAdminEmail = [
		[
			'email'=>'mansi.barochiya@txtech.co',
			'display_name'=>'Q5 | ActivityQ'
		]
	];

	public static $developmentSendMail = [
		[
			'email'=>'ajay@txtech.co',
			'display_name'=>'Q5 | ActivityQ'
		],
		[
			'email'=>'hardik@txtech.co',
			'display_name'=>'Q5 | ActivityQ'
		]
	];

	public static $developmentAdminEmail = [
		[
			'email'=>'ajay@txtech.co',
			'display_name'=>'Ajay Khunti'
		],
		[
			'email'=>'tushar.patil@txtech.co',
			'display_name'=>'Tushar Patil'
		]
	];

	public static $productionAdminEmail = [
		[
			'email'=>'hardik@txtech.co',
			'display_name'=>'Q5 | ActivityQ'
		],
		[
			'email'=>'ajay@txtech.co',
			'display_name'=>'Q5 | ActivityQ'
		]
	];

	public static $developerErrorLogEmail = [
		/* [
			'email'=>'ranjit.bhalgariya@txtech.co',
			'display_name'=>'Q5 | ActivityQ'
		],
		[
			'email'=>'tushar.patil@txtech.co',
			'display_name'=>'Q5 | ActivityQ'
		] */
	];

	public static function sendEmail($mails = array(), $subject, $templates, $data=array(), $filePath='', $attachFileName='') {
		

		// Development
		if(getenv('APP_ENV')=='development') {
			$mails['to'] = (isset($mails['to']) && count($mails['to']) > 0) ? self::$developmentSendMail : [];
			$mails['cc'] = (isset($mails['cc']) && count($mails['cc']) > 0) ? self::$developmentSendMail : [];
			$mails['bcc'] = (isset($mails['bcc']) && count($mails['bcc']) > 0) ? self::$developmentSendMail : [];
			$mails['bcc'] = array_merge($mails['bcc'], self::$developmentAdminEmail);

		// Production
		} else if(getenv('APP_ENV')=='production') {
			if(isset($mails['bcc']) && count($mails['bcc']) > 0) {
				$mails['bcc'] = array_merge($mails['bcc'], self::$productionAdminEmail);
			} else {
				$mails['bcc'] = self::$productionAdminEmail;
			}

		// Local
		} else if(getenv('APP_ENV')!='production') {
			$mails['to'] = (isset($mails['to']) && count($mails['to']) > 0) ? self::$sendMailLocal : [];
			$mails['cc'] = (isset($mails['cc']) && count($mails['cc']) > 0) ? self::$sendMailLocal : [];
			$mails['bcc'] = (isset($mails['bcc']) && count($mails['bcc']) > 0) ? self::$sendMailLocal : [];
			$mails['bcc'] = array_merge($mails['bcc'], self::$localAdminEmail);
		}

		try {
			Mail::send($templates, $data, function($message)use ($mails, $subject, $filePath, $attachFileName)
			{
				$mailto = (isset($mails['to']) && count($mails['to']) > 0) ? $mails['to'] : [];
				$mailcc = (isset($mails['cc']) && count($mails['cc']) > 0) ? $mails['cc'] : [];
				$mailbcc = (isset($mails['bcc']) && count($mails['bcc']) > 0) ? $mails['bcc'] : [];
				$message = $message->subject($subject);
				foreach ($mailto as $key => $value) {
					$display_name = (isset($value['display_name']) && !empty($value['display_name'])) ? $value['display_name'] : getenv('DEFAULT_COMPANY_NAME');
					$message = $message->to($value['email'], $display_name);
				}
				foreach ($mailcc as $key => $value) {
					$display_name = (isset($value['display_name']) && !empty($value['display_name'])) ? $value['display_name'] : getenv('DEFAULT_COMPANY_NAME');
					$message = $message->cc($value['email'], $display_name);
				}

				foreach ($mailbcc as $key => $value) {
					$display_name = (isset($value['display_name']) && !empty($value['display_name'])) ? $value['display_name'] : getenv('DEFAULT_COMPANY_NAME');
					$message = $message->bcc($value['email'], $display_name);
				}
				if($filePath) {
					$message->attach($filePath, ['as' => $attachFileName]);
				}
			});

			return true;

		} catch(\Exception $e) {

			// $errorMsg = trim($e->getMessage());
			// if($e->getFile()){
			// 	$errorMsg.= "<br />ERROR FILE : ".$e->getFile();
			// }
			// if($e->getLine()){
			// 	$errorMsg.= "<br />ERROR LINE NO : ".$e->getLine();
			// }

			//CustomErrorHandler::APIServiceLog($e,'Email Send Error');
			return [
				'success'   => false,
				'message'   => 'SOMETHING_WENT_WRONG'
			];
		}
	}


	public static function sendEmailToDeveloper($mails = array(), $subject, $templates, $data=array(), $filePath='', $attachFileName='') {
		
		$mails['to'] = self::$developerErrorLogEmail;	
		try {
			Mail::send($templates, $data, function($message)use ($mails, $subject, $filePath, $attachFileName)
			{
				$mailto = (isset($mails['to']) && count($mails['to']) > 0) ? $mails['to'] : [];				
				$message = $message->subject($subject);
				foreach ($mailto as $key => $value) {
					$display_name = (isset($value['display_name']) && !empty($value['display_name'])) ? $value['display_name'] : getenv('DEFAULT_COMPANY_NAME');
					$message = $message->to($value['email'], $display_name);
				}
				if($filePath) {
					$message->attach($filePath, ['as' => $attachFileName]);
				}
			});
			return true;

		} catch(\Exception $e) {			
			//CustomErrorHandler::APIServiceLog($e,'Email Send Error');
			return [
				'success'   => false,
				'message'   => 'SOMETHING_WENT_WRONG'
			];
		}
	}

	public static $setEmailForSite = array(
		'contact_us' => array(
			'to' => array(
				array(
					'email'=> 'ashwin.vadgama@txtech.co',
					'display_name'=> 'Admin'
				)
			),
        /*'bcc' => array(
            array(
                'email'=>'ashwin@transaction.partners',
                'display_name'=>'Ashwin'
            ),
            array(
                'email'=>'ajay@transaction.partners',
                'display_name'=>'Ajay'
            )
        )*/
    )
	);
}
