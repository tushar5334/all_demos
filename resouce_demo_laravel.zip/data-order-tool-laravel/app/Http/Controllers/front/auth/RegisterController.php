<?php

namespace App\Http\Controllers\front\auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Http\Requests\Front\Auth\RegisterRequest;

use App\Models\User;

use Auth;
use Lang;
use DB;
use App\Libraries\GUID;

class RegisterController extends Controller
{

	public function __construct(){
        $this->middleware('guest')->except('logout');
    }

    public function showSignupForm(){    	
        return view('front.auth.register');
    }

    public function processSignup(RegisterRequest $request){
    	$requestData = $request->all();    	
    	DB::beginTransaction();
    	try {    		
    		User::create($requestData);
    		DB::commit();
    		return redirect()->route('login')->with('success', 'Register Successfully.');
    	} catch (\Exception $e) {
    		DB::rollback();
            // CustomErrorHandler::APIServiceLog($e->getMessage(), "CategoryController: store");
    		return back()->with('error', 'Something Went Wrong.');
    	}
    }
}
