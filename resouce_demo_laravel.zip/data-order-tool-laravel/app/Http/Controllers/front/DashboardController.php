<?php

/**
 * @uses Dashboard Controller
 * @author Ranjitsinh Bhalgariya <ranjit.bhalgariya@txtech.com>
 * @return
 */
namespace App\Http\Controllers\front;

use App\Http\Controllers\Controller;
use App\Libraries\General;
use Illuminate\Http\Request;
use Auth;

use Illuminate\Http\Response;
use Illuminate\Support\Facades\Input;

use DB;

class DashboardController extends Controller
{
    public function __construct()
    {
        
    }
    
    /**
     * Get count of completed and open campaign and campaign list for display dashboard
     *
     * @return Array Response
     */
    public function DisplayDashboard()
    { 
      return \View::make('front.dashboard');
    }
}
?>