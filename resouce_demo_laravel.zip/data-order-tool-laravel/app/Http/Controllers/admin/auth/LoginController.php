<?php

namespace App\Http\Controllers\admin\auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use App\Http\Requests\Admin\Auth\LoginRequest;

use Illuminate\Http\Request;
use Redirect;
use Validator;
use App\Libraries\CustomErrorHandler;
use App\Models\User;
use Hash;
use Auth;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */


    /**
     * Where to redirect users after login.
     *
     * @var string
     */

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest:admin')->except('adminPostLogout');
    }

    /**
     * Display Login password form
     *
     * @return \Illuminate\Http\Response
     */
    public function showLoginForm()
    {
        if (Auth::guard('admin')->check()) {
            return redirect()->intended(route('admin.dashboard'));
        } else {
            return \View::make('admin.auth.login');
        }
    }
    public function postLogin(LoginRequest $request)
    {
        $postData = $request->all();
        /*try {*/
                $remember_me  = ( !empty( $request->remember_me ) )? TRUE : FALSE;
                
                // create our user data for the authentication
                $userdata = array(
                    'email' => $postData['email'],
                    'password' => $postData['password'],
                    'status' => 1,
                    'user_type' => "SuperAdmin",
                );
                // attempt to do the login
                if (Auth::guard('admin')->attempt($userdata, $remember_me)) {
                    return redirect()->route('admin.dashboard');
                } else {
                    return back()->with('error', 'Email address or password is not valid.');
                }
       /* } catch (\Exception $e) {
            //CustomErrorHandler::APIServiceLog($e->getMessage(), "LoginController: postLogin");
            return back()->with('error', 'Something Went Wrong.');
        }*/

    }
    public function adminPostLogout()
    {
        Auth::guard('admin')->logout();
        return redirect(route('admin.login'));
    }


}
