<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Yajra\DataTables\DataTablesServiceProvider;
use Yajra\DataTables\DataTables;
use App\Http\Requests\Admin\PageRequest;
use Carbon\Carbon;

use App\Exports\CmsReportExport;

use DB;
use Validator;
use Redirect;
use Excel;
use App\Models\Page;

class PageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
      
        if($request->ajax()){
            $db_prefix = getenv('DB_PREFIX');
            $masterList = Page::select(
                '*',
                DB::RAW('DATE_FORMAT(created_at, "%d-%m-%Y") as createdAt'),
                DB::RAW('IF('.$db_prefix.'pages.is_static="1", "Dynamic", "Static") as is_static')
            );
            if(!empty($request->get('startDate')) && !empty($request->get('endDate')))
            { 
                $endDate = Carbon::createFromFormat('d/m/Y',$request->get('endDate'))->format('Y-m-d');
                $startDate = Carbon::createFromFormat('d/m/Y',$request->get('startDate'))->format('Y-m-d');
                $masterList->whereBetween(DB::RAW('DATE_FORMAT(created_at, "%Y-%m-%d")'),[$startDate,$endDate]);
            }
            if(!empty($request->get('startDate')) && empty($request->get('endDate')))
            {
                $startDate = Carbon::createFromFormat('d/m/Y',$request->get('startDate'))->format('Y-m-d');
                $masterList->whereDate('created_at','>=',$startDate);
            }
            if(!empty($request->get('endDate')) && empty($request->get('startDate')))
            {
                $endDate = Carbon::createFromFormat('d/m/Y',$request->get('endDate'))->format('Y-m-d');
                $masterList ->whereDate('created_at','<=',$endDate);
            }
            $masterList->WHERENULL('deleted_at');
            $masterList = $masterList;
           return Datatables::of($masterList)
            ->editColumn('description', function ($masterList) {
                if(isset($masterList->description) && $masterList->description !=""){
                    return html_entity_decode(strip_tags($masterList->description));
                }else{
                    return '';
                }
            })
            ->filterColumn('createdAt', function($query, $keyword) use ($masterList) {
                $query->whereRaw('DATE_FORMAT(created_at, "%d-%m-%Y") LIKE ?', ["%{$keyword}%"]);
            })
            ->filterColumn('is_static', function($query, $keyword) use ($masterList,$db_prefix) {
                $query->whereRaw('IF('.$db_prefix.'pages.is_static="1", "Dynamic", "Static") LIKE ?', ["%{$keyword}%"]);
            })
            ->make(true);
        }
        return view('admin.page.pagelist');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.page.pageadd');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(PageRequest $request)
    {
        $requestData = $request->all();
        $authId = Auth::guard('admin')->id();
        DB::beginTransaction();
        try {  
            Page::create($requestData);
            DB::commit();
            return redirect()->route('page.index')->with('success', 'Page Added Successfully.');
        } catch (\Exception $e) {
            DB::rollback();
            return back()->with('error', 'Something Went Wrong.');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Page $page)
    {
       $retData = array(
            'data' => $page
        ); 
        return view('admin.page.pageadd',$retData);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(PageRequest $request, $pageid)
    {
        $requestData = $request->all();
        $authId = Auth::id();
        DB::beginTransaction();
       /*  try { */
            $user = Page::updateOrCreate(
                ['page_id' => $request->page_id],
                $requestData
            );
            DB::commit();
            return redirect()->route('page.index')->with('success', 'Page Update Successfully.');
       /*  } catch (\Exception $e) {
            DB::rollback();
            //CustomErrorHandler::APIServiceLog($e->getMessage(), "PageController: update");
            return back()->with('error', 'Something Went Wrong.');
        } */
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        DB::beginTransaction();
        try {
            Page::destroy($id);
            DB::commit();
            return response()->json([
                'success' => true,
                'message'   => 'Page deleted successfully.'
            ], 200);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json([
                'success' => false,
                'message'   => 'Something Went Wrong.'
            ], 200);
        }
    }
    public function ActiveDeactiveStatus(Request $request){
        $postData = $request->all();
        DB::beginTransaction();
        try {
            $pageObj = Page::findOrFail($postData['id']);
            if($pageObj->status == 1){
                $page = Page::updateOrCreate(
                    ['page_id' => $postData['id']],
                    ['status'=> 0]
                );
            }
            if($pageObj->status == 0){
                $page = Page::updateOrCreate(
                    ['page_id' => $postData['id']],
                    ['status'=> 1]
                );
            }
            DB::commit();
            return response()->json([
                'success' => true,
                'message'   => 'Status Update successfully.'
            ], 200);    
        } catch (\Exception $e) {
            DB::rollback();
            //CustomErrorHandler::APIServiceLog($e, "UserController: destroy");
            return response()->json([
                'success' => false,
                'message'   => 'Something Went Wrong.'
            ], 200);
        }
    }
    public function multipleActiveStatus(Request $request){
        $postData = $request->all();
        DB::beginTransaction();
        try {
            if($postData['status'] == "active"){
                Page::whereIn('page_id',$postData['id'])->update(['status'=> 1]);
                $success = true;
                $msg = "Status Update Successfully.";
            }elseif($postData['status'] == "dective"){
                Page::whereIn('page_id',$postData['id'])->update(['status'=> 0]);
                $success = true;
                $msg = "Status Update Successfully.";
            }else{
                $success = false;
                $msg = "Something Went Wrong.";
            }
            DB::commit();
            return response()->json([
                'success' => $success,
                'message'   => $msg
            ], 200);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json([
                'success' => false,
                'message'   => 'Something Went Wrong.'
            ], 200);
        }
    }
    public function multipleDelete(Request $request){
       $postData = $request->all();
        DB::beginTransaction();
        try {
            Page::whereIn('page_id',$postData['id'])->delete();
            DB::commit();
            return response()->json([
                'success' => true,
                'message'   => 'Page deleted successfully.'
            ], 200);
        } catch (\Exception $e) {
            DB::rollback();
            //CustomErrorHandler::APIServiceLog($e, "UserController: destroy");
            return response()->json([
                'success' => false,
                'message'   => 'Something Went Wrong.'
            ], 200);
        }
    }
    public function ExportPage(Request $request){
        $requestData = $request->all();
        //echo '<pre>';print_r($requestData);echo'</pre>';exit;                     
        $now = Carbon::now()->format('Y-m-d-H-i-s');
        
        $fileName = "cms-export-".$now;

        return Excel::download(new CmsReportExport($requestData), $fileName.'.csv');
    }

        
}
