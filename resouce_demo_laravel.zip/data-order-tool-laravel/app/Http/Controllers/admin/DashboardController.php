<?php

/**
 * @uses Dashboard Controller
 * @author Ranjitsinh Bhalgariya <ranjit.bhalgariya@txtech.com>
 * @return
 */
namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Libraries\General;
use Illuminate\Http\Request;
use Auth;

//use Illuminate\Http\Response;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Response;


use DB;
use File;

class DashboardController extends Controller
{
    public function __construct()
    {
        
    }
    
    /**
     * Get count of completed and open campaign and campaign list for display dashboard
     *
     * @return Array Response
     */
   
    public function DisplayDashboard()
    { 
      
      return \View::make('admin.dashboard');
    }
    public function displayUserImage($foldername, $filename){
        $path = storage_path('app/public/'.$foldername.'/' . $filename);
        if (!File::exists($path)) {
            $path = public_path('images/avatar5.png');
        }
        $file = File::get($path);
        $type = File::mimeType($path);
        $response = Response::make($file, 200);
        $response->header("Content-Type", $type);
        return $response;
    }  
}
?>