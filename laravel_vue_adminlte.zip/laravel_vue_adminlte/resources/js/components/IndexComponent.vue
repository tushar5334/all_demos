<template>
    <!-- // load content before login -->
    <div v-if="!this.$store.state.isLoggedIn">
        <!-- route outlet -->
        <router-view></router-view>
        <!-- set progressbar -->
        <vue-progress-bar></vue-progress-bar>
    </div>
    <!-- // load content after login -->
    <div class="hold-transition sidebar-mini" v-else>
        <div class="wrapper">
                <!-- Navbar start -->
                <header-component></header-component>
                <!-- Navbar end -->
                <!-- Main Sidebar Container start -->
                    <left-menu></left-menu>
                <!-- Main Sidebar Container end -->

                <!-- Content Wrapper. Contains page content -->
                <div class="content-wrapper">
                    <!-- Main content -->
                    <div class="content">
                    <div class="container-fluid">
                        <div class="row">
                            <!-- route outlet -->
                            <!-- component matched by the route will render here -->
                            <router-view></router-view>
                        </div>
                        <!-- /.row -->
                    </div><!-- /.container-fluid -->
                    </div>
                    <!-- /.content -->
                </div>
                <!-- /.content-wrapper -->
                <!-- Main Footer start -->
                <footer-component></footer-component>
                <!-- Main Footer end-->

                <!-- set progressbar -->
                <vue-progress-bar></vue-progress-bar>
        </div>
    </div>

</template>
<script>
import * as auth from './../services/AuthService'
  export default {
    name:'Index',
    data() {
      return {
        //
      }
    },
    components: {
        //
    },
    beforeCreate: function() {
      // check for auto login
      auth.autoLogin()

    }
  }
</script>
