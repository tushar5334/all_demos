<?php
use App\User;
use App\Post;
use App\Country;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

// one to one relation (hasone)
Route::get('/user/{user_id}/post', function ($user_id) {
	$user = User::find($user_id);
    return view('orm',['post_with_user'=>$user]);
});

// one to one relation (belongesto)
Route::get('/post/{post_id}/user', function ($post_id) {
	$post = Post::find($post_id);
    return view('orm',['user_with_post'=>$post]);
});

// one to many relation (hasMany)
Route::get('/posts/{user_id}', function ($user_id) {
	$user = User::find($user_id);
    return view('orm',['user_with_many_post'=>$user]);
});

// many to many relation (belongsToMany)
Route::get('/user/{user_id}/roles', function ($user_id) {
	$user = User::find($user_id);
    return view('orm',['user_with_roles'=>$user]);
});

// has many through relation (hasManyThrough)
Route::get('/user/country/{country_id}/', function ($country_id) {
	$country = Country::find($country_id);
    return view('orm',['post_contry_user'=>$country]);
});
