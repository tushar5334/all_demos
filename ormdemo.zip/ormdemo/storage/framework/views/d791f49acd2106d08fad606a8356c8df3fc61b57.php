<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">


            <div class="content">
                <?php if(!empty($post_with_user)): ?>
                <h3>One To One Relationship (hasOne)</h3>
                <div class="links">
                    <li><?php echo e($post_with_user->name); ?> : <?php echo e($post_with_user->post->title); ?></li>
                </div>
                <?php endif; ?>
            </div>
            <div class="content">
                <?php if(!empty($user_with_post)): ?>
                <h3>One To One Relationship (belongsTo)</h3>
                <div class="links">
                    <li><?php echo e($user_with_post->user->name); ?> : <?php echo e($user_with_post->title); ?></li>
                </div>
                <?php endif; ?>
            </div>
            <div class="content">
                <?php if(!empty($user_with_many_post)): ?>
                <h3>One To Many Relationship (hasMany)</h3>
                <?php echo e($user_with_many_post); ?>

                <div class="links">
                    <?php if(!empty($user_with_many_post->posts)): ?>
                        <?php $__currentLoopData = $user_with_many_post->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($user_with_many_post->name); ?> : <?php echo e($post->title); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>

            <div class="content">
                <?php if(!empty($user_with_roles)): ?>
                <h3>Many To Many Relationship (belongsToMany)</h3>
                    <?php echo e($user_with_roles); ?>

                    <?php echo e($user_with_roles->roles); ?>

                    <div class="links">
                            <?php if(!empty($user_with_roles->roles)): ?>
                                <?php $__currentLoopData = $user_with_roles->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($user_with_roles->name); ?> : <?php echo e($role->name); ?> :Pivot Table User ID:<?php echo e($role->pivot->user_id); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            <div class="content">
                <?php if(!empty($post_contry_user)): ?>
                <h3>Many To Many Relationship (hasManyThrough)</h3>
                    <?php echo e($post_contry_user); ?>

                    <?php echo e($post_contry_user->posts); ?>

                    <div class="links">
                            <?php if(!empty($post_contry_user->posts)): ?>
                                <?php $__currentLoopData = $post_contry_user->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($post->title); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </body>
</html>
<?php /**PATH /var/www/html/ormdemo/resources/views/orm.blade.php ENDPATH**/ ?>