<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">


            <div class="content">
                @if(!empty($post_with_user))
                <h3>One To One Relationship (hasOne)</h3>
                <div class="links">
                    <li>{{$post_with_user->name}} : {{$post_with_user->post->title}}</li>
                </div>
                @endif
            </div>
            <div class="content">
                @if(!empty($user_with_post))
                <h3>One To One Relationship (belongsTo)</h3>
                <div class="links">
                    <li>{{$user_with_post->user->name}} : {{$user_with_post->title}}</li>
                </div>
                @endif
            </div>
            <div class="content">
                @if(!empty($user_with_many_post))
                <h3>One To Many Relationship (hasMany)</h3>
                {{$user_with_many_post}}
                <div class="links">
                    @if(!empty($user_with_many_post->posts))
                        @foreach($user_with_many_post->posts as $post)
                        <li>{{$user_with_many_post->name}} : {{$post->title}}</li>
                        @endforeach
                    @endif
                </div>
                @endif
            </div>

            <div class="content">
                @if(!empty($user_with_roles))
                <h3>Many To Many Relationship (belongsToMany)</h3>
                    {{$user_with_roles}}
                    {{$user_with_roles->roles}}
                    <div class="links">
                            @if(!empty($user_with_roles->roles))
                                @foreach($user_with_roles->roles as $role)
                                <li>{{$user_with_roles->name}} : {{$role->name}} :Pivot Table User ID:{{$role->pivot->user_id}}</li>
                                @endforeach
                            @endif
                    </div>
                @endif
            </div>

            <div class="content">
                @if(!empty($post_contry_user))
                <h3>Many To Many Relationship (hasManyThrough)</h3>
                    {{$post_contry_user}}
                    {{$post_contry_user->posts}}
                    <div class="links">
                            @if(!empty($post_contry_user->posts))
                                @foreach($post_contry_user->posts as $post)
                                <li>{{$post->title}}</li>
                                @endforeach
                            @endif
                    </div>
                @endif
            </div>
        </div>
    </body>
</html>
