<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;

use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Auth;

use Illuminate\Http\Request;
use Yajra\DataTables\DataTablesServiceProvider;
use Yajra\DataTables\DataTables;
use App\Http\Requests\Admin\UserRequest;
use App\Libraries\General;

use App\Exports\UserReportExport;

use DB;
use Validator;
use Redirect;
use Hash;
use App\Models\User;
use Carbon\Carbon;
use Excel;


class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if($request->ajax()){

            $userList = User::select('*',DB::RAW('DATE_FORMAT(created_at, "%d-%m-%Y") as createdAt'));
            if(!empty($request->get('startDate')) && !empty($request->get('endDate')))
            { 
                $endDate = Carbon::createFromFormat('d/m/Y',$request->get('endDate'))->format('Y-m-d');
                $startDate = Carbon::createFromFormat('d/m/Y',$request->get('startDate'))->format('Y-m-d');
                $userList->whereBetween(DB::RAW('DATE_FORMAT(created_at, "%Y-%m-%d")'),[$startDate,$endDate]);
            }
            if(!empty($request->get('startDate')) && empty($request->get('endDate')))
            {
                $startDate = Carbon::createFromFormat('d/m/Y',$request->get('startDate'))->format('Y-m-d');
                $userList->whereDate('created_at','>=',$startDate);
            }
            if(!empty($request->get('endDate')) && empty($request->get('startDate')))
            {
                $endDate = Carbon::createFromFormat('d/m/Y',$request->get('endDate'))->format('Y-m-d');
                $userList ->whereDate('created_at','<=',$endDate);
            }
            $userList->where('user_type',"User");
            $userList = $userList;
            return Datatables::of($userList)
            ->filterColumn('createdAt', function($query, $keyword) use ($userList) {
                $query->whereRaw('DATE_FORMAT(created_at, "%d-%m-%Y") LIKE ?', ["%{$keyword}%"]);
            })
            ->make(true);
       }
       return view('admin.user.userlist');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.user.useradd');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(UserRequest $request)
    {
        $authId = Auth::guard('admin')->id();
        DB::beginTransaction();
        //echo '<pre>';print_r($authId);echo'</pre>';exit;
       try {  
            $user = User::createUpdateUser($request);
            if($user){
                DB::commit();
                return redirect()->route('user.index')->with('success', 'User Added Successfully.');
            }
        } catch (\Exception $e) {
            DB::rollback();
            //CustomErrorHandler::APIServiceLog($e, "UserController: store");
            return back()->with('error', 'Something Went Wrong.');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(User $user)
    {
        $retData = array(
            'data' => $user
        );
        return view('admin.user.useradd',$retData);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UserRequest $request, $id)
    {
        $authId = Auth::guard('admin')->id();
        DB::beginTransaction();
        try {
            $userObj = User::findOrFail($id);
            if($userObj){
                $user =  User::createUpdateUser($request,$userObj->profile_picture);
                if($user){
                    DB::commit();
                    return redirect()->route('user.index')->with('success', 'User Updated Successfully.');
                }
            }          
        } catch (\Exception $e) {
            DB::rollback();
            CustomErrorHandler::APIServiceLog($e, "UserController: update");
            return back()->with('error', 'Something Went Wrong.');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
         DB::beginTransaction();
        try {
            echo '<pre>';print_r($id);echo'</pre>';exit;
            //User::destroy($id);
            DB::commit();
            return response()->json([
                'success' => true,
                'message'   => 'User deleted successfully.'
            ], 200);
        } catch (\Exception $e) {
            DB::rollback();
            //CustomErrorHandler::APIServiceLog($e, "UserController: destroy");
            return response()->json([
                'success' => false,
                'message'   => 'Something Went Wrong.'
            ], 200);
        }
    }
    public function multipleDelete(Request $request){
       $postData = $request->all();
        DB::beginTransaction();
        try {
            User::whereIn('user_id',$postData['id'])->delete();
            DB::commit();
            return response()->json([
                'success' => true,
                'message'   => 'User deleted successfully.'
            ], 200);
        } catch (\Exception $e) {
            DB::rollback();
            //CustomErrorHandler::APIServiceLog($e, "UserController: destroy");
            return response()->json([
                'success' => false,
                'message'   => 'Something Went Wrong.'
            ], 200);
        }
    }
    public function multipleActiveStatus(Request $request){
        $postData = $request->all();
        DB::beginTransaction();
        try {
            if($postData['status'] == "active"){
                User::whereIn('user_id',$postData['id'])->update(['status'=> 1]);
                $success = true;
                $msg = "Status Update Successfully.";
            }elseif($postData['status'] == "dective"){
                User::whereIn('user_id',$postData['id'])->update(['status'=> 0]);
                $success = true;
                $msg = "Status Update Successfully.";
            }else{
                $success = false;
                $msg = "Something Went Wrong.";
            }
            DB::commit();
            return response()->json([
                'success' => $success,
                'message'   => $msg
            ], 200);
        } catch (\Exception $e) {
            DB::rollback();
            //CustomErrorHandler::APIServiceLog($e, "UserController: destroy");
            return response()->json([
                'success' => false,
                'message'   => 'Something Went Wrong.'
            ], 200);
        }
    }
    public function ActiveDeactiveStatus(Request $request){
        $postData = $request->all();
        DB::beginTransaction();
        try {
            $userObj = User::findOrFail($postData['id']);
            if($userObj->status == 1){
                $user = User::updateOrCreate(
                    ['user_id' => $postData['id']],
                    ['status'=> 0]
                );
            }
            if($userObj->status == 0){
                $user = User::updateOrCreate(
                    ['user_id' => $postData['id']],
                    ['status'=> 1]
                );
            }
            DB::commit();
            return response()->json([
                'success' => true,
                'message'   => 'Status Update successfully.'
            ], 200);    
        } catch (\Exception $e) {
            DB::rollback();
            //CustomErrorHandler::APIServiceLog($e, "UserController: destroy");
            return response()->json([
                'success' => false,
                'message'   => 'Something Went Wrong.'
            ], 200);
        }
    }
    public function ExportUser(Request $request){
        $requestData = $request->all();
        //echo '<pre>';print_r($requestData);echo'</pre>';exit;                     
        $now = Carbon::now()->format('Y-m-d-H-i-s');
        
        $fileName = "user-export-".$now;

        return Excel::download(new UserReportExport($requestData), $fileName.'.csv');
    }
}
