<?php

namespace App\Http\Controllers\front\auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use App\Http\Requests\Front\Auth\LoginRequest;

use Illuminate\Http\Request;
use Redirect;
use Validator;
use App\Libraries\CustomErrorHandler;
use App\Models\User;
use Hash;
use Auth;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */


    /**
     * Where to redirect users after login.
     *
     * @var string
     */

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('frontPostLogout');
    }

    /**
     * Display Login password form
     *
     * @return \Illuminate\Http\Response
     */
    public function showLoginForm()
    {
            return \View::make('front.auth.login');
    }
    public function postLogin(LoginRequest $request)
    {
        $postData = $request->all();
        try {
                $remember_me  = ( !empty( $request->remember_me ) )? TRUE : FALSE;
                
                // create our user data for the authentication
                $userdata = array(
                    'email' => $postData['email'],
                    'password' => $postData['password'],
                    'status' => 1,
                    'user_type' => "User",
                );
                // attempt to do the login
                if (Auth::attempt($userdata, $remember_me)) {
                    return redirect(route('front.dashboard'));
                } else {
                    return back()->with('error', 'Email address or password is not valid.');
                }
        } catch (\Exception $e) {
            //CustomErrorHandler::APIServiceLog($e->getMessage(), "LoginController: postLogin");
            return back()->with('error', 'Something Went Wrong.');
        }

    }
    public function frontPostLogout()
    {
        Auth::logout();
        return redirect(route('login'));
    }


}
