<?php

namespace App\Http\Controllers\front\auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Http\Request;
use Auth;
use Redirect;
use Validator;
use App\Models\User;
use Hash;
use App\Libraries\Emailsend;
use App\Libraries\CustomErrorHandler;
use App\Http\Requests\Front\Auth\ResetPasswordRequest;

class ResetPasswordController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset requests
    | and uses a simple trait to include this behavior. You're free to
    | explore this trait and override any methods you wish to tweak.
    |
    */
    public function __construct()
    {
        $this->middleware('guest');
    }
    /**
     * Display Reset password form
     *
     * @param  Token  $token
     * @return \Illuminate\Http\Response
     */
    public function showResetPasswordForm($token)
    {
        
        return \View::make('front.auth.reset-password')->with('token', $token);
    }

    /**
     * Submit Reset password form
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  Token  $token
     * @return \Illuminate\Http\Response
     */
    public function postResetPassword(ResetPasswordRequest $request, $token)
    {

        $postData = $request->all();
        try {
            $userData = User::WHERE('token', $postData['token'])->first();
            if(isset($userData) && !empty($userData)) {
                if (isset($postData['password']) && $postData['password']) {
                    $userData->password = Hash::make($postData['password']);
                }
                $userData->token = NULL;
                $userData->save();

                $mailTo['to'] = array(
                    array(
                        'email'=>$userData->email,
                        'display_name'=>$userData->name
                    )
                );
                $data = array(
                    'siteurl' => getenv('APP_URL'),
                    'mailcontent' => array(
                        'name'=> $userData->name,
                        'login_url'=> route('login'),
                        'message'=> 'Password has been reseted sucessfully.',
                    )
                );
                $mailSubject = 'Reset Password - '.getenv("PROJECT_NAME");
                $sendMail = Emailsend::sendEmail($mailTo, $mailSubject, 'front.email_template.update-password', $data);

                if($sendMail){
                    return redirect(route('login'))->with('success', 'Password has been reseted sucessfully!');
                } else {
                    return back()->with('error', 'Password has been reseted sucessfully!');
                    
                }
            } else {
                return back()->with('error', 'Email not found!');
            }   
        } catch (\Exception $e) {
            //CustomErrorHandler::APIServiceLog($e, "ResetPasswordController: postResetPassword");
            return back()->with('error', 'Something Went Wrong.');
        }

    }
}
