<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\WithHeadings;

use App\Models\Page;
use Carbon\Carbon;
use DB;

class CmsReportExport implements FromCollection, WithHeadings
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function __construct($requestData){        
        $this->requestData = $requestData;        
    }

    use Exportable;

   public function collection()
    {   
         $db_prefix = getenv('DB_PREFIX');
        $pageData = Page::select(
            'title',
            'meta_title',
            'meta_keywords',
            'description',
            'name',
            DB::RAW('IF('.$db_prefix.'pages.is_static="1", "Dynamic", "static") as is_static'),
            DB::RAW('DATE_FORMAT(created_at, "%d-%m-%Y") as createdAt'),
        );
      if(!empty($this->requestData['startDate']) && !empty($this->requestData['endDate']))
        {
            $endDate = Carbon::createFromFormat('d/m/Y',$this->requestData['endDate'])->format('Y-m-d');
            $startDate = Carbon::createFromFormat('d/m/Y',$this->requestData['startDate'])->format('Y-m-d');
            $pageData->whereBetween(DB::RAW('DATE_FORMAT(created_at, "%Y-%m-%d")'),[$startDate,$endDate]);
        }
        if(!empty($this->requestData['startDate']) && empty($this->requestData['endDate']))
        {
            $startDate = Carbon::createFromFormat('d/m/Y',$this->requestData['startDate'])->format('Y-m-d');
            $pageData ->whereDate('created_at','>=',$startDate);
        }
        if(!empty($this->requestData['endDate']) && empty($this->requestData['startDate']))
        {
            $endDate = Carbon::createFromFormat('d/m/Y',$this->requestData['endDate'])->format('Y-m-d');
            $pageData ->whereDate('created_at','<=',$endDate);
        }
          if(!empty($this->requestData['searchData']))
        {
            $keyword = $this->requestData['searchData'];
            $pageData->where(function ($query) use ($keyword,$db_prefix) {
                $query->where('title', 'like', '%'.$keyword.'%');
                if (str_contains("dynamic", strtolower($keyword))) {
                    $query->orwhere('is_static',1);
                }
                if (str_contains("static", strtolower($keyword))) {
                    $query->orwhere('is_static',0);
                }
                $query->orWhere('meta_title', 'like', '%'.$keyword.'%');
                $query->orWhere('meta_keywords', 'like', '%'.$keyword.'%');
                $query->orWhere('description', 'like', '%'.$keyword.'%');
                $query->orWhere('name', 'like', '%'.$keyword.'%');
                $query->orWhere(DB::raw('DATE_FORMAT(created_at, "%d-%m-%Y")'), 'like' ,'%'.$keyword.'%' );
            });
        }
        $pageData = $pageData->get();
        return $pageData;
    }
    public function headings(): array{
        return['Title','Meta Title','Meta Keywords','Description','Name','Page Type','Created At'];
    }
}
