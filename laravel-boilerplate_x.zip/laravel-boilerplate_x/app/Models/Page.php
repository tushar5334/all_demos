<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\ColumnFillable;
use Illuminate\Support\Str;
use App\Libraries\General;

use Config;
use Auth;

class Page extends Authenticatable
{
    use HasFactory, Notifiable;
    use SoftDeletes;
    use ColumnFillable;
    protected $table = 'pages';
    protected $primaryKey = 'page_id';
    public $incrementing = false;
    
    protected static function boot()
    {
        parent::boot();
        Page::creating(function ($model) {
            $model->setPageId();
        });
    }
    

    public function setPageId()
    {
        $this->attributes['page_id'] = Str::uuid();
    }
}
