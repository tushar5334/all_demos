-- Adminer 4.7.8 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `lb_migrations`;
CREATE TABLE `lb_migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `lb_pages`;
CREATE TABLE `lb_pages` (
  `page_id` char(36) NOT NULL,
  `title` varchar(765) DEFAULT NULL,
  `meta_title` varchar(765) DEFAULT NULL,
  `meta_keywords` varchar(765) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `name` varchar(1000) DEFAULT NULL,
  `page_slug` varchar(1000) DEFAULT NULL,
  `is_static` tinyint(2) DEFAULT NULL COMMENT '0-Static, 1-Dynamic',
  `status` tinyint(4) DEFAULT 1 COMMENT '0-InActive, 1-Active',
  `created_by` char(36) NOT NULL,
  `updated_by` char(36) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`page_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `lb_users`;
CREATE TABLE `lb_users` (
  `user_id` char(36) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `user_type` enum('SuperAdmin','User') NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1 COMMENT ' 1=active, 0=deactive 	',
  `profile_picture` varchar(255) DEFAULT NULL,
  `token` varchar(100) DEFAULT NULL,
  `remember_token` text DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `updated_by` varchar(100) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `lb_users` (`user_id`, `name`, `email`, `user_type`, `password`, `status`, `profile_picture`, `token`, `remember_token`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
('9b135c95-db4c-4256-8413-0a33f5ab45ac',	'tushar patil',	'tushar5334@gmail.com',	'SuperAdmin',	'$2y$10$rnElpwawFYWieHaZ9IW4ouqSmWnxt.v1nY6oSt9MohqIpW/O7tF1e',	1,	'',	'TQkvAN2enRNNaRpeEWn5j1nFokCo7b',	'OZx5iOc2yjxY2vw2UJKfmXS9eV9z7eVoBuULaKlCCKlnFTayglJEaOOvpfnv',	NULL,	'9b135c95-db4c-4256-8413-0a33f5ab45ac',	'2021-02-24 06:05:56',	'2021-03-09 06:38:00',	NULL);

-- 2021-07-02 04:44:26
