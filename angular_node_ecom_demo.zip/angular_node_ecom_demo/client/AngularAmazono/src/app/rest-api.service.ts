import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, throwError, of } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class RestApiService {

  constructor(private http: HttpClient) { }

  getHeaders() {
    const token = localStorage.getItem('token')
    return token ? new HttpHeaders().set('Authorization', `Bearer ${token}`) : null;
  }

  get(link:string) {
  	return this.http.get<any>(link, { headers:this.getHeaders() })
    .pipe(
      retry(1), // retry a failed request up to 3 times
      catchError(this.handleError) // then handle the error
    );
  }

  post(link:string, reqbody:any) {
     return this.http.post<any>(link, reqbody, { headers:this.getHeaders() })
    .pipe(
      catchError(this.handleError)
    );

  }


  private handleError(error: HttpErrorResponse) {
    console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    // return an observable with a user-facing error message
    //return throwError('Something bad happened; please try again later.');
    return throwError(error.error.message);
  };
}
