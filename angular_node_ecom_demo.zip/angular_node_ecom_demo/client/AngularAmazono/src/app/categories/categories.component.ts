import { Component, OnInit } from '@angular/core';

import { DataService } from '../data.service';
import { RestApiService } from '../rest-api.service';
@Component({
  selector: 'app-categories',
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.scss']
})
export class CategoriesComponent implements OnInit {
  categories:any;
  btnDisabled = false;
  newCategory='';
  constructor(private data: DataService, private rest: RestApiService) { }

  ngOnInit() {
    this.loadCategories();
  }
  loadCategories() {
    this.rest.get('http://localhost:3030/api/categories')
      .subscribe((data: any) => {
        if (data['success']) {
          this.categories = data['categories'];
        } else {
          this.data.error(data['message']);
        }
      }, (error: any) => {
        this.data.error(error);
      });
  }


  addCategory() {
    this.btnDisabled = true;
    this.rest.post('http://localhost:3030/api/categories', {name:this.newCategory})
      .subscribe((data: any) => {
        if (data['success']) {
          this.data.success(data['message']);
          this.newCategory='';
          this.loadCategories();
        } else {
          this.data.error(data['message']);
        }
      }, (error: any) => {
        this.data.error(error);
      });
    this.btnDisabled = false;
  }

}
