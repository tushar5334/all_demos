import { Component, OnInit } from '@angular/core';

import { DataService } from '../data.service';
import { RestApiService } from '../rest-api.service';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss']
})
export class SettingsComponent implements OnInit {

	btnDisabled = false;
	currentSettings: any;

  constructor(private data: DataService, private rest: RestApiService) { }

  ngOnInit() {
    try {
      if (!this.data.user) {
      	this.data.getProfile();
      }
      this.currentSettings = Object.assign({
      newPwd: '',
      pwdConfirm: ''
      }, this.data.user)
    } catch (error) {
      this.data.error(error);
    }

  }


  validate(settings) {
    if (settings['name']) {
      if (settings['email']) {
        if (settings['newPwd']) {
          if (settings['pwdConfirm']) {
            if (settings['newPwd'] === settings['pwdConfirm']) {
              return true;
            } else {
              this.data.error('Password do not match!');
            }
          } else {
            this.data.error('Please enter confirmation password!');
          }
        } else {
          if (!settings['pwdConfirm']) {
            return true;
          } else {
            this.data.error('Please enter new password!');
          }
        }
      } else {
        this.data.error('Please enter your email!');
      }
    } else {
      this.data.error('Please enter your name!');
    }
  }

update() {
  this.btnDisabled = true;
  if (this.validate(this.currentSettings)){
  		this.rest.post('http://localhost:3030/api/accounts/profile', this.currentSettings)
  		.subscribe((data: any) => {
          if (data['success']) {
              this.data.getProfile();
              this.data.success(data['message']);
          } else {
              this.data.error(data['message']);
          }
		},(error: any) => {
      			this.data.error(error);
		});
  }

  this.btnDisabled = false;
}

}
