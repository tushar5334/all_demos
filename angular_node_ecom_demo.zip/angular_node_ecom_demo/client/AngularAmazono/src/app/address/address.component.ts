import { Component, OnInit } from '@angular/core';

import { DataService } from '../data.service';
import { RestApiService } from '../rest-api.service';
@Component({
  selector: 'app-address',
  templateUrl: './address.component.html',
  styleUrls: ['./address.component.scss']
})
export class AddressComponent implements OnInit {
	btnDisabled =  false;
	currentAddress: any;

  constructor(private data: DataService, private rest: RestApiService) { }

  ngOnInit() {
	this.rest.get('http://localhost:3030/api/accounts/address')
		.subscribe((data: any) => {
	  if (data['success']) {
	      if (JSON.stringify(data['address']) === '{}' && this.data.message === ''){
              this.data.warning('You have not entered your shipping address. Please enter your shipping address!');
          }

          this.currentAddress = data['address'];
	  } else {
	      this.data.error(data['message']);
	  }
	},(error: any) => {
				this.data.error(error);
	});
  }

  updateAddress(){
	this.btnDisabled = true;
		this.rest.post('http://localhost:3030/api/accounts/address', this.currentAddress)
			.subscribe((data: any) => {
	      if (data['success']) {
	          this.data.getProfile();
	          this.data.success(data['message']);
	      } else {
	          this.data.error(data['message']);
	      }
		},(error: any) => {
	  			this.data.error(error);
		});


	this.btnDisabled = false;
  }

}
