import { Component, OnInit } from '@angular/core';
import { RestApiService } from '../rest-api.service';
import { DataService } from '../data.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
	loginModel:any = {
		name:'',
	    email:'',
	    password:'',
	    password1:'',
	    isSeller:false,
	}

	btnDisabled = false;
  constructor(private router: Router, private data: DataService, private rest: RestApiService) { }

  ngOnInit() {
  }

  validate(){
      if(this.loginModel.email){
          if(this.loginModel.password){
              return true;
          } else {
              this.data.error('Password is not entered!');
          }
      } else {
          this.data.error('Email is not entered!');
      }
  }

  login() {
	this.btnDisabled = true;
  	if (this.validate()){
  		this.rest.post('http://localhost:3030/api/accounts/login', this.loginModel)
  		.subscribe((data: any) => {
          if (data['success']) {
              localStorage.setItem('token', data['token']);
              this.data.getProfile();
              this.router.navigate(['/']);
          } else {
              this.data.error(data['message']);
          }
			},(error: any) => {
      			this.data.error(error);
			});
  }

  this.btnDisabled = false;
}

}
