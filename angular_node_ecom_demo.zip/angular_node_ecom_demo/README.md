# angular_node_ecom_demo
mkdir server

1) npm init
2) 	package name: (server) 
	version: (1.0.0) 
	description: amazone clone app backend as a node
	entry point: (index.js) server.js
	test command: 
	git repository: 
	keywords: 
	author: 
	license: (ISC) 

3) npm install nodemon --save -dev
4) npm install express body-parser morgan mongoose --save

