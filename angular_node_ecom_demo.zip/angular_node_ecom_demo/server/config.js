module.exports = {
	//database:'mongodb+srv://tushar1987:@komal1987@cluster0-grchq.mongodb.net/amazonewebapp?retryWrites=true&w=majority',    //Will use for production Url
	database:'mongodb://localhost:27017/amazonewebapp',
	port:3030,
	secret:'amazonewebapp1987'
}