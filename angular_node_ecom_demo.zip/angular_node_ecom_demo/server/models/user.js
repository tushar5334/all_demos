const mongoose = require('mongoose')
const Schema = mongoose.Schema
const bcrypt = require('bcrypt')
const crypto = require('crypto')

const UserSchema = new Schema({
	email:{ type:String, unique:true, lowercase:true },
	name:String,
	password:String,
	picture:String,
	isSeller:{ type:Boolean, default:false },
	address: {
		addr1:String,
		addr2:String,
		city:String,
		state:String,
		country:String,
		postalCode:String,
	},
	created:{ type:Date, default:Date.now }
})

UserSchema.pre('save', async function(next) {
	user = this

	if(user.isModified('password')){
		user.password = await bcrypt.hash(user.password, 8)
	}
	next()
})

UserSchema.methods.comparePassword = async function(password) {

	const isMatchPassword = await bcrypt.compare(password, this.password)
	return isMatchPassword
}

UserSchema.methods.gravatar = function(size) {

	if(!this.size){
		size = 200
	}

	if(!this.email) {
		return 'https://gravatar.com/avatar/?s' + size + '&d=retro'
	} else {
		var md5 = crypto.createHash('md5').update(this.email).digest('hex')
		return 'https://gravatar.com/avatar/' + md5 + '?s' + size + '&d=retro'
	}
}

UserSchema.methods.toJSON= function () {

	const user = this
	const userObject = user.toObject()
	delete userObject.password
	delete userObject.tokens
	return userObject

}

const User = mongoose.model('User', UserSchema)
module.exports = User