const express = require('express')
const jwt = require('jsonwebtoken')
const User = require('../models/user')
const config = require('./../config')
const auth = require('./../middlewares/auth')
const router = new express.Router()

router.post('/signup', async (req, res, next)=>{
	let user = new User()

	user.name = req.body.name
	user.email = req.body.email
	user.password = req.body.password
	user.picture = await user.gravatar()
	user.isSeller = req.body.isSeller

	const isUserExist = await User.findOne({email:req.body.email})

	if(isUserExist) {
		res.status(400).send({success:false, message:'Account with this user already exist!'})
	} else {
		user.save()
		const token = jwt.sign({user}, config.secret, {expiresIn:'7d'})
		res.status(201).send({success:true, message:'Token generated successfuly!', token:token})
	}
})

router.post('/login', async (req, res, next)=>{
	try {
		const user = await User.findOne({email:req.body.email})
		if(!user) {
			res.status(404).send({success:false, message:'Authentication failed!User not found'})
		} else if(user) {
			const isMatchPassword = await user.comparePassword(req.body.password)
			if(!isMatchPassword) {
				res.status(404).send({success:false, message:'Authentication failed!Password not found'})
			} else {
				const token = jwt.sign({user}, config.secret, {expiresIn:'7d'})
				res.status(201).send({success:true, message:'Token generated successfuly!', token})
			}
		}

	} catch(e) {
		res.status(400).send({success:false, message:'Something went wrong'})
	}

})

router.route('/profile')
.get(auth, async (req, res, next)=>{
	try {
		const _id = req.decode.user._id
		const user = await User.findById(_id)
		if(!user) {
			return res.status(404).send({success:false, message:'User not found!'})
		}

		res.send({success:true, message:'User found successfully!', user})

	} catch(e) {
		res.status(500).send({success:false, message:'Something went wrong'})
	}
})
.post(auth, async (req, res, next)=>{
	try {
		const _id = req.decode.user._id
		const user = await User.findById(_id)

		if(!user) {

			return res.status(404).send({success:false, message:'User not found!'})
		}

		if(req.body.name){
			user.name = req.body.name
		}
		if(req.body.email){
			user.email = req.body.email
		}
		if(req.body.password){
			user.password = req.body.password
		}

		user.isSeller = req.body.isSeller
		user.save()
		res.send({success:true, message:'User profile edited successfully!'})

	} catch(e) {
		res.status(400).send({success:false, message:'Something went wrong'})
	}
})

router.route('/address')
.get(auth, async (req, res, next)=>{
	try {
		const _id = req.decode.user._id
		const user = await User.findById(_id)
		if(!user) {
			return res.status(404).send({success:false, message:'User not found!'})
		}

		res.send({success:true, message:'User found successfully!', address:user.address})

	} catch(e) {
		res.status(500).send({success:false, message:'Something went wrong'})
	}
})
.post(auth, async (req, res, next)=>{
	try {
		const _id = req.decode.user._id
		const user = await User.findById(_id)

		if(!user) {

			return res.status(404).send({success:false, message:'User not found!'})
		}

		if(req.body.addr1){
			user.address.addr1 = req.body.addr1
		}
		if(req.body.addr2){
			user.address.addr2 = req.body.addr2
		}
		if(req.body.city){
			user.address.city = req.body.city
		}
		if(req.body.state){
			user.address.state = req.body.state
		}
		if(req.body.country){
			user.address.country = req.body.country
		}
		if(req.body.postalCode){
			user.address.postalCode = req.body.postalCode
		}

		user.save()
		res.send({success:true, message:'User address edited successfully!'})

	} catch(e) {
		res.status(400).send({success:false, message:'Something went wrong'})
	}
})

module.exports = router
