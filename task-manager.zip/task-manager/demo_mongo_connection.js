/*const mongodb = require('mongodb')
const MongoClient = mongodb.MongoClient
const objectID = mongodb.objectID*/

const {MongoClient, ObjectID} = require('mongodb')

const dbConnectionUrl = 'mongodb://127.0.0.1:27017'
const databaseName = 'task-manager'

const id = new ObjectID()

//console.log(id.toHexString())

MongoClient.connect(dbConnectionUrl, {useNewUrlParser:true,useCreateIndex: true,useFindAndModify:true},(error,client)=>{
	if(error){
		return console.log('unable to connect to database')
	}

	console.log('connected correctly!')

	const db = client.db(databaseName)

	/*db.collection('users').insertOne({
		name:'Tushar',
		age:32
	},(error, result)=>{
		if(error){
			return console.log('Unable to insert record!')
		}

		console.log(result.ops)

	})*/

	/*db.collection('users').insertOne({
		_id:id,
		name:'John',
		age:32
	},(error, result)=>{
		if(error){
			return console.log('Unable to insert record!')
		}

		console.log(result.ops)

	})*/



	/*db.collection('users').insertMany([{
		name:'K1',
		age:29
	},
	{
		name:'K2',
		age:25
	}],(error, result)=>{
		if(error){
			return console.log('Unable to insert record!')
		}
		console.log(result.ops)

	})*/


	/*db.collection('users').findOne({age:25},(error, user)=>{
		console.log(user)
	})*/

	/*db.collection('users').findOne({name:'K2',age:25},(error, user)=>{
		console.log(user)
	})*/

	/*db.collection('users').findOne({_id:new ObjectID('5df8a9bb2ce7421c406f9b42')},(error, user)=>{
		console.log(user)
	})*/

	/*db.collection('users').find({age:25}).toArray((error, users)=>{
		console.log(users);
	})

	db.collection('users').find({age:25}).count((error, count)=>{
		console.log(count);
	})*/


	/*db.collection('tasks').insertMany([{
		description:'Clean the house',
		completed:true
	},
	{
		description:'Renew inspection',
		completed:false
	},
	{
		description:'Pot plants',
		completed:true
	}
	],(error, result)=>{
		if(error){
			return console.log('Unable to insert record!')
		}
		console.log(result.ops)

	})*/

	/*db.collection('tasks').findOne({_id:new ObjectID("5df386c49bbc594afc2e71b0")}, (error, task)=>{
		console.log(task);
	})

	db.collection('tasks').find({completed:true}).toArray((error, tasks)=>{
		console.log(tasks);
	})*/

	/*db.collection('users').updateOne({_id:new ObjectID("5df3851307d3d14a6c01074a")},
	{
		$set:{
			name:"Ajay"
		},
		$inc:{
			age:2
		}
	}).then((result)=>{
		console.log(result);
	}).catch((error)=>{
		console.log(error);
	})*/

	/*db.collection('tasks').updateMany(
		{completed:true},
		{
			$set:{
				completed:false
			}
		}
	).then((result)=>{
		console.log(result.modifiedCount)
	}).catch((error)=>{
		console.log(error)
	})*/

	/*db.collection('users').deleteMany({age:29})
	.then((result)=>{
		console.log(result)
	})
	.catch((error)=>{
		console.log(error)
	})*/

	db.collection('users').deleteOne({name:'John'})
	.then((result)=>{
		console.log(result)
	})
	.catch((error)=>{
		console.log(error)
	})
})