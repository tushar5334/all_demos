/*test('Hello World',()=>{

})


test('This should fail',()=>{
	throw new Error('Failed')
})*/

const { calculateTip, fehranheitToCelsius, celsiusToFehranheit, add } = require('../src/math')

test('calculate total with tip', ()=>{

	const total = calculateTip(10,0.3)

	/*if(total !==13) {
		throw new Error('Total tip should be 13.Got '+total)
	}*/

	expect(total).toBe(13)

})

test('calculate total without tip', ()=>{

	const total = calculateTip(10)

	expect(total).toBe(13)

})

test('calculate fehranheit to celsius',()=>{

	const tempInCelsius = fehranheitToCelsius(32)
	expect(tempInCelsius).toBe(0)

})

test('calculate celsius to fehranheit',()=>{

	const tempInFehranheit = celsiusToFehranheit(0)
	expect(tempInFehranheit).toBe(32)

})

test('Async test demo', (done)=>{
	setTimeout(()=>{
		expect(5).toBe(5)
		done()
	},2000)
	/*expect(5).toBe(5)*/
})

test('Async Add demo promise', (done)=>{

	add(5,5).then((sum)=>{
		expect(sum).toBe(10)
		done()
	})

})

test('Async Add demo async/await', async (done)=>{

	const sum = await add(5,5)

	expect(sum).toBe(10)
	done()
})