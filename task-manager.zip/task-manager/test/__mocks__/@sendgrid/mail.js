module.exports = {
	setApiKey() {

	},
	send() {

	}
}