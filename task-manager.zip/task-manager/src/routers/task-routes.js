const express = require('express')
const Task = require('../models/task')
const Auth = require('../middleware/auth')
const router = new express.Router()

router.post('/tasks', Auth, async (req, res)=>{
	//console.log(req.body)
	try {
		//const taskObj = new Task(req.body)
		const taskObj = new Task({
			...req.body,
			owner:req.user._id
		})
		//const tasks = await taskObj.save()
		await taskObj.save()
		res.status(201).send(taskObj)
	} catch (e) {
		res.status(400).send(e)
	}
})

///tasks?completed=true
//tasks?page_no=1
//tasks?sortBy=createdAt:asc
router.get('/tasks', Auth, async (req,res)=>{
	const match = {}
	const sort = {}
	const totalRecordPerPage = 10
	//const pageNo = (req.query.page_no && parseInt(req.query.page_no) > 0) ? totalRecordPerPage*parseInt(req.query.page_no) : 0;
	const pageNo = (req.query.page_no) ? totalRecordPerPage*(parseInt(req.query.page_no)-1) : 0;
	//console.log(pageNo)

	if(req.query.completed){
		match.completed = req.query.completed ==='true'
	}

	if(req.query.sortBy){
		const parts = req.query.sortBy.split(':')
		sort[parts[0]] = parts[1]==='desc' ? -1 : 1;
	}

	try {
		/*const tasks = await Task.find({owner:req.user._id})
		res.send(tasks)*/
		//await req.user.populate('mytasks').execPopulate()
		/*await req.user.populate({
			path:'mytasks',
			match:{
				completed:false
			}
		}).execPopulate()*/

		await req.user.populate({
			path:'mytasks',
			match,
			options:{
				limit:parseInt(totalRecordPerPage),
				skip:parseInt(pageNo),
				sort
				/*sort:{
				//createdAt:1 //createdAt = field name, 1 for asc order
				//createdAt:-1 //createdAt = field name, -1 for desc order
				}*/
			}

		}).execPopulate()
		res.send(req.user.mytasks)

	} catch(e) {
		res.status(500).send(e)
	}
})

router.get('/tasks/:taskid', Auth, async (req,res)=>{

	try {
		const _id = req.params.taskid
		//const task = await Task.findById(_id)

		const task = await Task.findOne({_id, owner:req.user._id})

		if(!task) {
			res.status(404).send()
		}
		res.send(task)
	} catch(e) {
		res.status(500).send(e)
	}
})


router.patch('/tasks/:taskid', Auth, async (req, res)=>{
	const updates = Object.keys(req.body)
	const allowedFiledsToUpdate = ['completed', 'description']
	const isValidOperation = updates.every((update)=> allowedFiledsToUpdate.includes(update))
	if(!isValidOperation) {
		return res.status(400).send({'error':'Invalid Updates'})
	}
	try {

		const task = await Task.findOne({_id:req.params.taskid, owner:req.user._id} )
		//const task = await Task.findById(req.params.taskid)
		//const task = await Task.findByIdAndUpdate(req.params.taskid, req.body , {new:true, runValidators:true})

		if(!task){
			res.status(404).send()
		}
		updates.forEach((update)=>task[update]=req.body[update])
		await task.save()
		res.send(task)
	} catch(e) {
		res.status(400).send(e)
	}
})

router.delete('/tasks/:taskid', Auth, async (req, res)=>{

	try {
		//const task = await Task.findByIdAndDelete(req.params.taskid)
		const task = await Task.findOneAndDelete({_id:req.params.taskid, owner:req.user._id})
		if(!task) {
			return res.status(404).send()
		}
		res.send(task)
	} catch(e) {
		res.status(500).send(e)
	}

})

module.exports = router