const express = require('express')
const User = require('../models/user')
const Auth = require('../middleware/auth')
const {sendWelcomeEmail, sendCancelationEmail} = require('../emails/account')
const multer = require('multer')
const path = require('path');
const router = new express.Router()

//upload file as buffer start
const upload = multer({
	//dest:'avtars',
	limits:{
		fileSize:1000000
	},
	fileFilter(req, file, cb){
		if(!file.originalname.match(/\.(jpg|jpeg|png)$/)){
			cb(new Error('Please upload valid image file'))
		}
		cb(undefined, true)
	}
})
//upload file as buffer end

//Upload file physically code start

const storage = multer.diskStorage({
	destination: (req, file, cb) => {
        cb(null,'avtars');
    },
    
    filename: function (req, file, cb) { 
	if(!file.originalname.match(/\.(jpg|jpeg|png)$/)){
		cb(new Error('Please upload valid image file'))
	}

	let customeFileName = Date.now()
             + path.extname(file.originalname);
    cb(undefined , customeFileName);   
   }
})

const uploadAsFile = multer({ storage: storage, limits:{
	fileSize:1000000
}});

//Upload file physically code end

router.post('/users',async (req, res)=>{
	try {
		const userObj = new User(req.body)
		await userObj.save()
		sendWelcomeEmail(userObj.emial, userObj.name)
		const token = await userObj.generateAuthToken()
		res.status(201).send({user:userObj,token})
		//res.status(201).send('User Added Sucessfully')
	} catch(e) {
		res.status(400).send(e)
	}
})

router.post('/users/login', async(req, res)=>{
	try {
		const user = await User.findByCredentials(req.body.email, req.body.password)
		const token = await user.generateAuthToken()
		console.log(user)
		console.log(token)
		//res.send({user:user.getPublicProfile(),token})
		res.send({user,token})
	} catch(e) {
		res.status(400).send(e)
	}
})

router.get('/users', Auth, async (req,res)=>{
	try {
		const users = await User.find({})
		res.send(users)
	} catch (e) {
		res.status(500).send(e)
	}
})

router.get('/users/me', Auth, async (req,res)=>{
	try {
		res.send(req.user)
	} catch (e) {
		res.status(500).send()
	}
})

//router.post('/users/me/avtar', Auth, uploadAsFile.single('user_avtar'), async(req,res)=>{
router.post('/users/me/avtar', Auth, upload.single('user_avtar'), async(req,res)=>{
/*	console.log(req.file);
	return false;*/
	req.user.avtar=req.file.buffer
	await req.user.save()
	//console.log('avtar')

	res.send()
	/*try {
		res.send(req.user)
	} catch (e) {
		res.status(500).send()
	}*/
},(error, req, res, next)=>{
	res.status(400).send({error:error.message})
})

router.delete('/users/me/avtar', Auth, async (req, res)=>{
	req.user.avtar=undefined
	await req.user.save()
	res.send()
})

router.post('/users/logout', Auth, async(req, res)=>{
	try {

		req.user.tokens=req.user.tokens.filter((token)=>{
			return token.token!=req.token
		})

		await req.user.save()
		res.send()

	} catch(e) {
		res.status(500).send(e)
	}
})

router.post('/users/logoutAll', Auth, async(req, res)=>{
	try {
		req.user.tokens=[]
		await req.user.save()
		res.send()
	} catch(e) {
		res.status(500).send(e)
	}
})

router.get('/users/:userid', Auth, async (req,res)=>{
	try {
		const _id = req.params.userid
		const user = await User.findById(_id)
		if(!user) {
			return res.status(404).send()
		}

		res.send(user)

	} catch(e) {
		res.status(500).send(e)
	}
})


router.patch('/users/me', Auth, async (req, res)=>{
		const updates = Object.keys(req.body)
		const allowedFiledsToUpdate = ['name','email','password','age']

		/*const isValidOperation = updates.every((update)=>{return allowedFiledsToUpdate.includes(update)
		})*/
		const isValidOperation = updates.every((update)=> allowedFiledsToUpdate.includes(update))
		if(!isValidOperation) {
			return res.status(400).send({'error':'Invalid Updates'})
		}
	try {

		updates.forEach((update)=>req.user[update]=req.body[update])
		await req.user.save()
		res.send(req.user)
	} catch(e) {
		res.status(400).send(e)
	}
})

router.patch('/users/:userid', Auth, async (req, res)=>{
		const updates = Object.keys(req.body)
		const allowedFiledsToUpdate = ['name','email','password','age']

		/*const isValidOperation = updates.every((update)=>{return allowedFiledsToUpdate.includes(update)
		})*/
		const isValidOperation = updates.every((update)=> allowedFiledsToUpdate.includes(update))
		if(!isValidOperation) {
			return res.status(400).send({'error':'Invalid Updates'})
		}
	try {

		const user = await User.findById(req.params.userid)
		//const user = await User.findByIdAndUpdate(req.params.userid, req.body , {new:true, runValidators:true})

		updates.forEach((update)=>user[update]=req.body[update])
		await user.save()
		if(!user){
			return res.status(404).send()
		}
		res.send(user)
	} catch(e) {
		res.status(400).send(e)
	}
})

router.delete('/users/me', Auth, async (req, res)=>{
	try {
		await req.user.remove()
		sendCancelationEmail(req.user.emial, req.user.name)
		res.send(req.user)
	} catch(e) {
		res.status(500).send(e)
	}
})

router.delete('/users/:userid', Auth, async (req, res)=>{
	try {
		var user = await User.findByIdAndDelete(req.params.userid)
		if(!user) {
			return res.status(404).send()
		}
		res.send(user)
	} catch(e) {
		res.status(500).send(e)
	}
})

router.get('/users/:userid/avtar', async (req,res)=>{
	try {
		const _id = req.params.userid
		const user = await User.findById(_id)
		console.log(user);
		if(!user || !user.avtar) {
			throw new Error()
		}

		res.set('Content-Type','image/jpg')
		res.send(user.avtar)
		//http://localhost:3000/users/5e252b43d3fecf118e966408/avtar
		//<img src="http://localhost:3000/users/5e252b43d3fecf118e966408/avtar">
	} catch(e) {
		res.status(404).send(e)
	}
})
module.exports = router