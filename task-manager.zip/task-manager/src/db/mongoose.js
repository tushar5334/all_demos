const mongoose = require('mongoose')
mongoose.connect(process.env.MONGODB_CONNECTION_URL,{
	useNewUrlParser:true,
	useCreateIndex:true,
	useFindAndModify: false
})

/*const User = mongoose.model('User',{
	name:{
		type:String
	},
	age:{
		type:Number
	}
})

const userObj = new User({
	name:'Tushar',
	age:20
})

userObj.save()
.then((result)=>{
	console.log('Result!',result)
}).catch((error)=>{
	console.log('Error!',error)
})*/


/*const User = mongoose.model('User',{
	name:{
		type:String,
		required:true,
		//required:[true, 'Why no bacon?'],
		trim:true,
	},
	age:{
		type:Number,
		default:0,
		validate(value){
			if(value < 0){
				throw new Error('Age must be positive number!')
			}
		}
	},
	email:{
		type:String,
		required:true,
		validate(value){
			if(!validator.isEmail(value)){
				throw new Error('Email is invalid')
			}
		}

	}
})

const userObj = new User({
	name:'Gale',
	//age:20,
	email:'tushar@jini.guru'
})

userObj.save()
.then((result)=>{
	console.log('Result!',result)
}).catch((error)=>{
	console.log('Error!',error)
})*/

/*const Task = mongoose.model('Task',{
	description:{
		type:String
	},
	completed:{
		type:Boolean
	}
})

const taskObj = new Task({
	description:'Store data in database',
	completed:true
})

taskObj.save()
.then((result)=>{
	console.log(result)
})
.catch((error)=>{
	console.log('Error',error)
})*/

/*const Task = mongoose.model('Task',{
	description:{
		type:String,
		required:true,
		trim:true,
		//lowercase:true
	},
	completed:{
		type:Boolean,
		default:true
	}
})

const taskObj = new Task({
	description:'Test Description',
})

taskObj.save()
.then((result)=>{
	console.log(result)
})
.catch((error)=>{
	console.log('Error',error)
})*/