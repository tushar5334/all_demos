const express = require('express')
require('./db/mongoose')
//Routes
const userRoutes = require('./routers/user-routes')
const taskRoutes = require('./routers/task-routes')

const app = express()

const port = process.env.PORT

app.use(express.json())

/*app.use((req, res, next)=>{
	if(req.method === 'GET'){
		res.send('GET request are disabled!')
	} else {
		next()
	}
})*/

/*app.use((req, res, next)=>{
		res.status(503).send('Site is down.Check back soon!')
})*/

//Register Routes
/*app.use(userRoutes)
app.use(taskRoutes)*/
app.use([userRoutes,taskRoutes])

/*const jwt = require('jsonwebtoken')
const generateToken = async ()=>{
	//jwt.sign(detail passed as token, 'secret key', 'value of expiration of token "0 or 0 seconds" for infinite validity, numeric value consider im mili second, 1 hour, 1h, 1 day, 1d ,1 week, 1 month, 1 second')
	const token = await jwt.sign({_id:"9913093603"}, 'mysecret', {expiresIn:"1 weeks"})
	console.log('token',token)

	const data = await jwt.verify(token, 'mysecret')

	console.log(data)
}

generateToken()*/


/*const bcrypt = require('bcryptjs')

const password = 'Tushar1987'

const myHashPassword = async (password)=>{

	const hashPassword = await bcrypt.hash(password, 8)
	console.log(hashPassword)

	const isPasswordMatch = await bcrypt.compare('tushar1987', hashPassword)
	console.log(isPasswordMatch)
}

myHashPassword(password)*/

/*const pet = {
	name:'Tushar'
}

pet.toJSON = function(){
	// console.log(this)
	// return this

	// return {}
}*/


//console.log(JSON.stringify(pet))

/*const Task = require('./models/task')
const User = require('./models/user')

const main = async ()=> {

	// const task = await Task.findById('5e1c61f8d0f4cc4eaa8e9bb5')
	// await task.populate('owner').execPopulate()
	//console.log(task.owner);
	//console.log(task.owner);

	//const user = await User.findById('5e1c5ff7df399f4d89f88cdc')
	//await user.populate('mytasks').execPopulate()
	//console.log(user);
	//console.log(user.mytasks);
}

main()*/

const multer = require('multer')
const upload = multer({
	dest:'images',
	limits: {
		fileSize:1000000
	},
	/*fileFilter(req, file, cb) {

		if(!file.originalname.endsWith('.pdf')){
			return cb(new Error('File must be a pdf'))
		}

		cb(undefined, true)
	}*/

	fileFilter(req, file, cb) {

		if(!file.originalname.match(/\.(doc|docx)$/)){
			return cb(new Error('Please upload word document'))
		}

		cb(undefined, true)
	}
})

const errorMiddleWare = (req, res, next)=>{

	throw new Error("from my error middleware")

}

/*app.post('/upload', errorMiddleWare, (req, res)=>{
	res.send()
},(error, req, res, next)=>{
	res.status(400).send({error:error.message})
})*/

app.post('/upload', upload.single('upload_image'), (req, res)=>{
	res.send()
},(error, req, res, next)=>{
	res.status(400).send({error:error.message})
})

app.listen(port, ()=>{
	console.log('server is running on port :'+port)
})

