const express = require('express')
require('./db/mongoose')
User = require('./models/user')
Task = require('./models/task')

const app = express()

const port = process.env.PORT || 3000

app.use(express.json())

/*app.post('/users',(req, res)=>{
	const userObj = new User(req.body)
	userObj.save()
	.then((result)=>{
		res.status(201)
		res.send('User Added Sucessfully')
	})
	.catch((e)=>{
		res.status(400).send(e)
	})
})*/

app.post('/users',async (req, res)=>{
	try {
		const userObj = new User(req.body)
		await userObj.save()
		res.status(201).send('User Added Sucessfully')
	} catch(e) {
		res.status(400).send(e)
	}
})

/*app.get('/users',(req,res)=>{
	User.find({}).
	then((result)=>{
		res.send(result)
	})
	.catch((e)=>{
		res.status(500).send(e)
	})

})*/

app.get('/users', async (req,res)=>{
	try {
		const users = await User.find({})
		res.send(users)
	} catch (e) {
		res.status(500).send(e)
	}
})

/*app.get('/users/:userid',(req,res)=>{
	const _id = req.params.userid
	User.findById(_id)
	.then((user)=>{
		if(!user){
			return res.status(404).send()
		}
		res.send(user)
	})
	.catch((e)=>{
		res.status(500).send(e)
	})

})*/

app.get('/users/:userid',async (req,res)=>{
	try {
		const _id = req.params.userid
		const user = await User.findById(_id)
		if(!user) {
			return res.status(404).send()
		}

		res.send(user)

	} catch(e) {
		res.status(500).send(e)
	}
})

app.patch('/users/:userid', async (req, res)=>{
		const updates = Object.keys(req.body)
		const allowedFiledsToUpdate = ['name','email','password','age']

		/*const isValidOperation = updates.every((update)=>{return allowedFiledsToUpdate.includes(update)
		})*/
		const isValidOperation = updates.every((update)=> allowedFiledsToUpdate.includes(update))
		if(!isValidOperation) {
			return res.status(400).send({'error':'Invalid Updates'})
		}
	try {


		const user = await User.findByIdAndUpdate(req.params.userid, req.body , {new:true, runValidators:true})
		if(!user){
			return res.status(404).send()
		}
		res.send(user)
	} catch(e) {
		res.status(400).send(e)
	}
})

app.delete('/users/:userid', async (req, res)=>{
	try {
		var user = await User.findByIdAndDelete(req.params.userid)
		if(!user) {
			return res.status(404).send()
		}
		res.send(user)
	} catch(e) {
		res.status(500).send(e)
	}
})

/*app.post('/tasks',(req, res)=>{
	console.log(req.body)
	const taskObj = new Task(req.body)
	taskObj.save()
	.then((result)=>{
		res.status(201).send('Task Added Sucessfully')
	})
	.catch((e)=>{
		res.status(400).send(e)
	})
})*/

app.post('/tasks', async (req, res)=>{
	//console.log(req.body)
	try {
		const taskObj = new Task(req.body)
		const tasks = await taskObj.save()
		res.status(201).send('Task Added Sucessfully')
	} catch (e) {
		res.status(400).send(e)
	}
})

/*app.get('/tasks',(req,res)=>{
	Task.find({}).
	then((result)=>{
		res.send(result)
	})
	.catch((e)=>{
		res.status(500).send(e)
	})

})*/


app.get('/tasks', async (req,res)=>{

	try {
		const tasks = await Task.find({})
		res.send(tasks)
	} catch(e) {
		res.status(500).send(e)
	}
})

/*app.get('/tasks/:taskid',(req,res)=>{
	const _id = req.params.taskid
	Task.findById(_id)
	.then((task)=>{
		if(!task){
			return res.status(400).send()
		}
		res.send(task)
	})
	.catch((e)=>{
		res.status(500).send(e)
	})
})
*/

app.get('/tasks/:taskid', async (req,res)=>{

	try {
		const _id = req.params.taskid
		const task = await Task.findById(_id)
		if(!task) {
			res.status(404).send()
		}
		res.send(task)
	} catch(e) {
		res.status(500).send(e)
	}
})


app.patch('/tasks/:taskid', async (req, res)=>{
	const updates = Object.keys(req.body)
	const allowedFiledsToUpdate = ['completed', 'description']
	const isValidOperation = updates.every((update)=> allowedFiledsToUpdate.includes(update))
	if(!isValidOperation) {
		return res.status(400).send({'error':'Invalid Updates'})
	}
	try {
		const task = await Task.findByIdAndUpdate(req.params.taskid, req.body , {new:true, runValidators:true})
		if(!task){
			res.status(404).send()
		}
		res.send(task)
	} catch(e) {
		res.status(400).send(e)
	}
})

app.delete('/tasks/:taskid', async (req, res)=>{

	try {
		var task = await Task.findByIdAndDelete(req.params.taskid)
		if(!task) {
			return res.status(404).send()
		}
		res.send(task)
	} catch(e) {
		res.status(500).send(e)
	}

})

app.listen(port, ()=>{
	console.log('server is running on port :'+port)
})