<div class="company">
@php
$companyArrayLength = 1;					
@endphp	
@if(!empty($data->investors))
  @php
  	// echo "<pre>";
  	// print_r($data->investors->toArray());
  	// echo "</pre>";
  	// exit;
  	$companyData = $data->investors;
    $companyObj = $companyData;
    $companyArrayLength = count($companyData) > 0 ? count($companyData) : 1;
  @endphp
@else 
  @if(old('company'))
    @foreach(old('company') as $key => $val)
      @php
      $companyArrayLength = count($val);break;
      @endphp
    @endforeach
  @endif
@endif
<input type="hidden" name="hid_company_length" id="hid_company_length" value="{{$companyArrayLength}}">
@for($i=0;$i<$companyArrayLength;$i++)
@php $showIndex = $i+1; @endphp
<div class="company_input addmore_input-row">
  <div class="row">
    <div class="col-sm-3">                                        
      <div class="form-group">
      <label class="bmd-label-floating"> Company Name<span class="text-danger">*</span></label>
      <input type="text" id="company_name_{{$showIndex}}" name="company[company_name][]" class="form-control {{$errors->has('company.company_name.'.$i) ? 'is-invalid' : ''}}" value="{{old('company.company_name.'.$i,isset($companyData[$i]->company->company_name) ? $companyData[$i]->company->company_name : '')}}">                                           
      @if ($errors->has('company.company_name.'.$i)) <p class="help-block text-danger">{{ $errors->first('company.company_name.'.$i) }}</p> @endif
      </div>
    </div>
    <div class="col-sm-4">  
      <div class="form-group">
      <label class="bmd-label-floating"> Linkedin Url <span class="text-danger">*</span></label>
      <input type="text" id="linkedin_url_{{$showIndex}}" name="company[linkedin_url][]" class="form-control {{$errors->has('company.linkedin_url.'.$i) ? 'is-invalid' : ''}}" value="{{old('company.linkedin_url.'.$i,isset($companyData[$i]->company->linkedin_url) ? $companyData[$i]->company->linkedin_url : '')}}">                                           
      @if ($errors->has('company.linkedin_url.'.$i)) <p class="help-block text-danger">{{ $errors->first('company.linkedin_url.'.$i) }}</p> @endif
      </div>
    </div>
    <div class="col-sm-4">  
      <div class="form-group">
      <label class="bmd-label-floating"> Website Url </label>
      <input type="text" id="company_website_{{$showIndex}}" name="company[company_website][]" class="form-control {{$errors->has('company.company_website.'.$i) ? 'is-invalid' : ''}}" value="{{old('company.company_website.'.$i,isset($companyData[$i]->company->company_website) ? $companyData[$i]->company->company_website : '')}}">                                           
      @if ($errors->has('company.company_website.'.$i)) <p class="help-block text-danger">{{ $errors->first('company.company_website.'.$i) }}</p> @endif
      </div>
    </div>
		<input type="hidden" id="hid_company_id_{{$showIndex}}" name="company[hid_company_id][]"  value="{{old('company.hid_company_id.'.$i,isset($companyData[$i]->company->company_id) ? $companyData[$i]->company->company_id : '')}}">                                           
    <div class="col-sm-1">
			<div class="form-group">
			@php
			$addBut = 'none';
			$removeBut = 'block';
			@endphp
			@if($i==$companyArrayLength-1)
			@php
			$addBut = 'block';
			$removeBut = 'none';
			@endphp
			@endif
			<label class="bmd-label-floating"></label>
      <button style="display: {{$addBut}}" type="button" class="form-control btn btn-primary but-append-company add-remove-btn mt-1" id="but_append_company_{{$showIndex}}"><i class="fas fa-plus-square fa-lg mr-2"></i> </button>
      <button style="display: {{$removeBut}};" type="button" class="form-control btn btn-danger company-remove add-remove-btn" id="but_company_remove_{{$showIndex}}"><i class="fas fa-trash fa-lg mr-2"></i></button>
			</div>
    </div>
  </div>
</div>
@endfor
</div>
<script type="text/javascript">
	$( document ).ready(function() {
		var regex = /^(.+?)(\d+)$/i;		
		var cloneIndex = $(".company_input").length + 1;				
		console.log(cloneIndex);
		$(document).on('click','.but-append-company',function(){
			$(".company_input:last").clone()
			.appendTo(".company")			
			.find("*")
			.each(function() {

				var id = this.id || "";				
				var match = id.match(regex) || [];				
				if (match.length == 3) {					
					this.id = match[1] + (cloneIndex);
					$('#'+this.id).val(null);
				}

				var label = $(this).closest('label').attr('for') || "";					
				var matchLabel = label.match(regex) || [];				
				if (matchLabel.length == 3) {					
					$(this).closest('label').attr('for',matchLabel[1] + (cloneIndex));
				}

				var labelHtml = $(this).closest('label').html() || "";
				var matchLabelHtml = labelHtml.match(regex) || [];				
				if (matchLabelHtml.length == 3) {					
					$(this).closest('label').html(matchLabelHtml[1] + (cloneIndex));
				}
			});
			$('#but_company_remove_'+(cloneIndex-1)).show();
			$('#but_append_company_'+(cloneIndex-1)).hide();
			$('#hid_company_length').val(cloneIndex);
			cloneIndex++;
		});

		$(document).on('click', ".company-remove", function () {			
			$(this).closest('.company_input').remove();
			cloneIndex--;			
			$(".company > .company_input").each(function( index, element ) {				
				$(this).find("*").each(function() {
					var newIndex = index+1;

					var id = this.id || "";				
					var match = id.match(regex) || [];				
					if (match.length == 3) {
						this.id = match[1] + (newIndex);
					}

					var label = $(this).closest('label').attr('for') || "";					
					var matchLabel = label.match(regex) || [];				
					if (matchLabel.length == 3) {					
						$(this).closest('label').attr('for',matchLabel[1] + (newIndex));
					}

					var labelHtml = $(this).closest('label').html() || "";
					var matchLabelHtml = labelHtml.match(regex) || [];				
					if (matchLabelHtml.length == 3) {					
						$(this).closest('label').html(matchLabelHtml[1] + (newIndex));
					}
				});
			});			
			$('#hid_company_length').val(cloneIndex-1);					
		});		
	});
</script>