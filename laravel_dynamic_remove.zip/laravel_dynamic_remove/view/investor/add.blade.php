@extends('admin.common.layout')
@section('content')

<!-- Content Header (Page header) -->
<div class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
            <h1 class="m-0 text-dark">Transaction Management</h1>
         </div><!-- /.col -->
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li class="breadcrumb-item"><a href="/admin">Home</a></li>
               <li class="breadcrumb-item active">Transaction</li>
               <li class="breadcrumb-item active">Transaction Add/Edit</li>
            </ol>
         </div><!-- /.col -->
      </div><!-- /.row -->
   </div><!-- /.container-fluid -->
</div>

<!-- Main content -->
<!-- Main content -->
<section class="content">   
   <div class="container-fluid">
      <form id="investorForm" action="{{ !empty($data->company_id) ? route('investor.update', $data) : route('investor.store') }}" method="POST" enctype="multipart/form-data">
         {{ !empty($data->company_id) ? method_field('PUT') :  method_field('POST') }}
         {{-- @csrf --}}
         <input type="hidden" name="_token" value="{{ csrf_token() }}"> 
         <input type="hidden" id="company_id" name="company_id" value="{{ isset($data) ? $data->company_id : '' }}">
         <div class="row">
            <div class="col-md-12">
               <div class="card card-parimary">
                  <div class="card-header">
                     <h3 class="card-title">{{ isset($data->company_id) ? 'Edit' : 'Add' }} Investor</h3>
                  </div>
                  <div class="card-body">
                     <div class="row">
                        <div class="col-sm">
                           <div class="form-group">
                              <label>Investor Name <span class="text-danger">*</span></label>
                              <input type="text" class="form-control {{$errors->has('company_name') ? 'is-invalid' : ''}}" id="company_name" placeholder="Enter Investor Name" name="company_name"  value="{{isset($data->company_name) ? $data->company_name : old('company_name')}}" autocomplete="off">
                              @if ($errors->has('company_name'))
                              <div class="invalid-feedback">
                                 <i class="fa fa-times-circle-o"></i> {{ $errors->first('company_name') }}
                              </div>
                              @endif
                           </div>
                           <div class="form-group">
                              <label>Linkedin Url <span class="text-danger">*</span></label>
                              <input type="text" class="form-control {{$errors->has('linkedin_url') ? 'is-invalid' : ''}}" id="linkedin_url" placeholder="Enter Linkedin Url" name="linkedin_url"  value="{{isset($data->linkedin_url) ? $data->linkedin_url : old('linkedin_url')}}" autocomplete="off">
                              @if ($errors->has('linkedin_url'))
                              <div class="invalid-feedback">
                                 <i class="fa fa-times-circle-o"></i> {{ $errors->first('linkedin_url') }}
                              </div>
                              @endif
                           </div>
                           <div class="form-group">
                              <label>Website Url <span class="text-danger">*</span></label>
                              <input type="text" class="form-control {{$errors->has('company_website') ? 'is-invalid' : ''}}" id="company_website" placeholder="Enter Website Url" name="company_website"  value="{{isset($data->company_website) ? $data->company_website : old('company_website')}}" autocomplete="off">
                              @if ($errors->has('company_website'))
                              <div class="invalid-feedback">
                                 <i class="fa fa-times-circle-o"></i> {{ $errors->first('company_website') }}
                              </div>
                              @endif
                           </div>
                        </div>
                     </div>
                     @include('admin.investor.company_clone')
                  </div>
               </div>
            </div>
         </div>
         <div class="row">
            <div class="col-md-12 mb-3">
               <button type="submit" class="btn btn-primary">Submit</button>&nbsp;
               <a href="{{ route('investor.index') }}" class="btn btn-danger">Cancel</a>
            </div>
         </div>
      </form>
   </div>
</section>
<!-- /.content -->

<script type="text/javascript">
   $( document ).ready(function() {
      // $('.datepicker').datepicker({
      //   autoclose: true,
      //   format: 'dd/mm/yyyy',
      //   todayHighlight: true,
      //   orientation: 'bottom'
      // });
      //  $("#TransactionForm").validate({
      //    rules: {
      //       company_name: {
      //          required: true,
      //       },
      //    },
      //    messages: {
      //       company_name: {
      //          required: 'Comapny Name field is required',
      //       },
      //    },
      // });
   });
</script>
@stop
