@extends('admin.common.layout')
@section('content')
<!-- Content Header (Page header) -->
<div class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
            <h1 class="m-0 text-dark">Transaction Management</h1>
         </div><!-- /.col -->
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li class="breadcrumb-item"><a href="/admin">Home</a></li>
               <li class="breadcrumb-item active">Transaction</li>
               <li class="breadcrumb-item active">Transaction list</li>
            </ol>
         </div><!-- /.col -->
      </div><!-- /.row -->
   </div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->

<!-- Main content -->
<section class="content">
   <div class="row">
      <div class="col-12">
         <div class="card card-outline card-primary">
            <div class="card-header">
               <h3 class="card-title float-none float-sm-left mb-3">Transaction List</h3>
            </div>

            <!-- /.card-header -->            
            <div class="card-body">
               <div class="table-overflow">
                  <table id="investorDatatable" style="width: 100%;" class="table table-bordered table-striped display responsive">
                     <thead>
                        <tr>
                           <th scope="col">#</th>
                           <th scope="col">Company Name</th>
                           <th scope="col">Linkedin Url</th>                      
                           <th scope="col">Company Website</th>
                           <th scope="col">Action</th>
                        </tr>
                     </thead>
                     <tbody>             
                     </tbody>
                     <tfoot>

                     </tfoot>             
                  </table>
               </div>

            </div>
            <!-- /.card-body -->
         </div>
         <!-- /.card -->
      </div>
      <!-- /.col -->
   </div>
   <!-- /.row -->
</section>
<!-- /.content -->

<script>
   $(function () {
      var dataTable = $('#investorDatatable').DataTable({
         processing: false,
         serverSide: true,          
         info: false,
         lengthChange: false,
         responsive: true,
         language: {
            emptyTable: "No Investor Found"
         },
         ajax: {
            url: "{{route('investor.index')}}"
         },
         order:[[ 1, "asc" ]],          
         columns: [
         {
            sTitle: "#",
            data: "company_id",
            name: "company_id",
            orderable: false,
            render: function(data, type, row, meta) {                  
               var pageinfo = dataTable.page.info();
               var currentpage = (pageinfo.page) * pageinfo.length;
               var display_number = (meta.row + 1) + currentpage;
               return display_number;
            }
         },         
         {
            data: "company_name",
            name: "company_name",
            orderable: true,
            searchable: true,            
         },
         {
            data: "linkedin_url",
            name: "linkedin_url",
            orderable: true,
            searchable: true,            
         },
         {
            data: "company_website",
            name: "company_website",
            orderable: true,
            searchable: true,            
         },         
         {
            data: "action",
            name: "action",
            orderable: false,
            searchable: false,
            render: function(data, type, row, meta) { 
                var edit_url = '{{ route("investor.edit", ":company_id") }}';
                edit_url = edit_url.replace(':company_id', row.company_id);
                var str = "";
                str += '<div class="btn-group">';
                 /* if(row.status == 1){
                  str += '<a title="Status" id="'+row.company_id+'" class="btn btn-success status_active" href="javascript:;" data-id="'+row.company_id+'"><i class="fas fa-check-circle"></i></a>';
                }else{
                  str += '<a title="Status" id="'+row.company_id+'" class="btn btn-default status_active" href="javascript:;" data-id="'+row.company_id+'"><i class="fas fa-ban"></i></a>';
                } */
                str+= '<a title="Edit" id="'+row.company_id+'" class="btn btn-warning edit_icon icon user-edit" href="'+edit_url+'"><i class="fas fa-edit"></i></a>';
                /* str += '<a title="Delete" id="'+row.company_id+'" class="btn btn-danger delete_icon icon delete_record" data-tooltip="Delete" href="javascript:;" data-id="'+row.company_id+'" data-toggle="modal" data-target="#modal-sm-'+row.company_id+'"><i class="fas fa-trash"></i></a>' */
                str += '</div>';
                return str;
              }
         }
         ],
         fnRowCallback: function( nRow, aData, iDisplayIndex ) {           
            return nRow;
         },
         fnDrawCallback: function( oSettings ) {            
            $('.delete_record').on( 'click', function (e) {
               let delId = $(this).attr("data-id");
               let url = "investor/"+delId;
               self.confirmDelete(delId, url, dataTable);                                                 
            });
            $('a.toggleButton').on( 'click', function (e) {
               let reqId = this.dataset.id;
               let content = this.dataset.content;
               $('#showrequest_'+reqId).toggle();
               $('#hiderequest_'+reqId).toggle();
            });

            $('a.responseToggle').on( 'click', function (e) {
               let reqId = this.dataset.id;
               let content = this.dataset.content;
               $('#responseShowRequest_'+reqId).toggle();
               $('#responseHideRequest_'+reqId).toggle();
            });
         },
         createdRow: function( row, data, dataIndex ) {
            $( row ).find('td:eq(0)')
            .attr('data-title', '#');
            $( row ).find('td:eq(1)')
            .attr('data-title', 'Banner Title');
            $( row ).find('td:eq(2)')
            .attr('data-title', 'Banner Description');
            $( row ).find('td:eq(3)')
            .attr('data-title', 'Status');
            $( row ).find('td:eq(4)')
            .attr('data-title', 'Action');            
         }
      });
   });
</script>

@stop