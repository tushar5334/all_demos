<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Jenssegers\Mongodb\Eloquent\Model as Eloquent;
use Pimlie\DataTables\Traits\MongodbDataTableTrait;
use Jenssegers\Mongodb\Eloquent\SoftDeletes;
use Illuminate\Support\Str;
use Auth;

class CompanyInvestor extends Eloquent
{
   use MongodbDataTableTrait,SoftDeletes;   
    protected $collection = 'company_investor';
    protected $primaryKey = 'company_investor_id';

    protected $fillable = [
        'company_investor_id',
        'company_id',
        'investor_id',
        'status',
        'deleted_at',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    protected static function boot(){
        parent::boot();
        CompanyInvestor::creating(function ($model) {
            $model->setCompanyInvestorId();
        });
    }
    

    public function setCompanyInvestorId(){
        $this->attributes['company_investor_id'] = (string) Str::uuid();
    }

    public function company(){
        return $this->hasOne('App\CompanyMaster','company_id','company_id');
    }

    public static function insertORUpdateCompanyInvestorList($investorId="",$hidCompanyLength="",$companyArray=[]){
    	$userId = Auth::guard('admin')->user()->user_id;
    	if(!empty($companyArray)){
    		$companyIdArray = [];
            $companyInvestorObj = self::WHERE('investor_id',$investorId)->forceDelete();                
	        for($i=0;$i<$hidCompanyLength;$i++){
	        	$comName = $companyArray['company_name'][$i];	        	
	        	$linUrl = $companyArray['linkedin_url'][$i];	        	
	        	$hidCompanyId = $companyArray['hid_company_id'][$i];	        	
	        	$company_website = $companyArray['company_website'][$i];	        	
	        	$companyMasterObj = CompanyMaster::where('company_id',$hidCompanyId)->first();
	        	if(!$companyMasterObj){
	        		$companyMasterObj = new CompanyMaster();
	        	}

                //$companyMasterObj = new CompanyMaster();
        		$companyMasterObj->company_name = $comName;
        		$companyMasterObj->linkedin_url = $linUrl;
                $companyMasterObj->company_website = $company_website;
                $companyMasterObj->project_id="00000000-0000-0000-0000-000000000001";
               $companyMasterObj->input_source="dealportal";
               $companyMasterObj->is_linkedin_scraped=false;
               $companyMasterObj->deleted_at = null;
               $companyMasterObj->status = true;
               $companyMasterObj->is_investor = 0;
               $companyMasterObj->created_by = $userId;
               $companyMasterObj->deleted_by =null;
               $companyMasterObj->updated_by = $userId;
        		$companyMasterObj->save();	        	
        		
                $companyInvestorObj = new self();	        	
	        	$companyInvestorObj->investor_id = $investorId;
	        	$companyInvestorObj->company_id = $companyMasterObj->company_id;	        	
	        	$companyInvestorObj->save();
            }            
         //    if(!empty($companyIdArray)){
	        // 	self::whereNotIn('company_investor_id', $companyIdArray)->where('investor_id', $investorId)->delete();
	        // }
    	} else if(empty($companyArray)) {
            // self::where('investor_id', $investorId)->delete();
        }
    }
}
