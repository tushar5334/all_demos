<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\Admin\InvestorRequest;

use App\CompanyMaster;
use App\CompanyInvestor;

use DB;
use DataTables;
use Pimlie\DataTables\MongodbDataTable;

class InvestorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request){
       if($request->ajax()){
            $masterList = CompanyMaster::select(
            '*'
        );
        $masterList = $masterList->where('is_investor',1);
        return Datatables::of($masterList)
        ->make(true);
        }
        return View('admin.investor.list');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(){
        return view('admin.investor.add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(InvestorRequest $request){    
        $requestData = $request->all();            
        // try {
            $requestData['is_investor'] = 1;
            // $companyMasterObj = CompanyMaster::where('company_name',trim($requestData['company_name']))->first();            
            // if($companyMasterObj){
            //     $requestData['company_id'] = $companyMasterObj->company_id;
            //     $companyMasterObj->update($requestData);                
            // } else {
            //     $companyMasterObj = CompanyMaster::create($requestData);
            // }
            //$requestData['company_id'] = "1";
            $companyMasterObj = CompanyMaster::create($requestData);
            $requestData['investor_id'] = $companyMasterObj->company_id;
            if(isset($requestData) && !empty($requestData)){
                CompanyInvestor::insertORUpdateCompanyInvestorList($requestData['investor_id'],$requestData['hid_company_length'],$requestData['company']);
            }
           
            return redirect()->route('investor.index')->with('success', 'Investor Added Successfully.');
        // } catch (\Exception $e) {
            
        //     return back()->with('error', 'Something Went Wrong.');
        // } 
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request, $id){                
        $companyMasterObj = CompanyMaster::findOrFail($id);        
        $retData = array(            
            'data' => $companyMasterObj,            
        );
        return view('admin.investor.add',$retData);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(InvestorRequest $request, $id){
        $requestData = $request->all();        
       
        try {
            $companyMasterObj = CompanyMaster::findOrFail($id);
            $companyMasterObj->update($requestData);
            if(isset($companyMasterObj) && !empty($companyMasterObj)){
                CompanyInvestor::insertORUpdateCompanyInvestorList($companyMasterObj->company_id,$requestData['hid_company_length'],$requestData['company']);
            }
           
            return redirect()->route('investor.index')->with('success', 'Investor Updated Successfully.');        
        } catch (\Exception $e) {
                        
            return back()->with('error', 'Something Went Wrong.');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id){        
       
        try {
            //CompanyMaster::destroy($id);

            CompanyInvestor::where('investor_id',$id)->forceDelete();
           
            return response()->json([
                'success' => true,
                'message'   => 'Investor deleted successfully.'
            ], 200);
        } catch (\Exception $e) {
                        
            return response()->json([
                'success' => false,
                'message'   => 'Something Went Wrong.'
            ], 200);
        }
    }
}
