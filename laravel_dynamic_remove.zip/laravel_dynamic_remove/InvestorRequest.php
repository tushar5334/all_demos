<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class InvestorRequest extends FormRequest
{
    public function authorize(){
        return true;
    }
    
    public function rules()
    {
        $appendRules = [];
        if(!empty($this->company)){
            for ($i = 0; $i < $this->hid_company_length; $i++) {                
                $appendRules['company.company_name.'.$i] = 'required|unique:company_master,company_name,'.$this->company['hid_company_id'][$i].',company_id,deleted_at,NULL';                
                //$appendRules['company.company_name.'.$i] = 'nullable|unique:company_master,company_name,'.$this->company['hid_company_id'][$i].',company_id,deleted_at,NULL';                
            }
        }
        return [
            'company_name' => 'required|unique:company_master,company_name,'.$this->company_id.',company_id,deleted_at,NULL',
            'linkedin_url' => 'required',
            'company_website' => 'required',
            //'company.company_name.*' => 'required',           
            //'company.linkedin_url.*' => 'nullable|url',
            //'company.company_website.*' => 'nullable|url'
        ]+$appendRules;
    }
    public function messages(){
        return [
            'company_name.required' => 'The company name field is required.',
            'company_name.unique' => 'The company name has already been taken.',
            //'linkedin_url.url' => 'Enter valid url formate.',
            //'company_website.url' => 'Enter valid url formate.',
            'company.company_name.*.required' => 'The company name field is required.',
            'company.company_name.*.unique' => 'The company name has already been taken.',
            'company.linkedin_url.*.required' => 'The linkedin url field is required.',
            //'company.linkedin_url.*.url' => 'Enter valid url formate.',
            //'company.company_website.*.url' => 'Enter valid url formate.',
        ];
    }
    
    protected function getValidatorInstance(){
        $data = $this->all();
        $validator = parent::getValidatorInstance();
        $validator->after(function ($validator) {
            $data = $this->all();
            if($data['company_id'] == ""){
                $data['project_id']="00000000-0000-0000-0000-000000000001";
                $data['input_source']="dealportal";
                $data['is_linkedin_scraped']=false;
                $data['deleted_at'] = null;
                $data['status'] = true;
                $data['created_by'] ="00000000-0000-0000-0000-000000000001";
                $data['deleted_by'] =null;
            }
            $data['updated_by'] ="00000000-0000-0000-0000-000000000001";
            $this->getInputSource()->replace($data);
        });
        return $validator;
    }
}
