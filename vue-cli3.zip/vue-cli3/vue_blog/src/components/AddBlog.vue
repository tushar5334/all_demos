<template>
  <div id="add-blog">
  <h1>Add A Blog Post</h1>
    <form v-if="!submitted">
      <label>Blog Title:</label>
      <input type="text" name="title" v-model.lazy="blog.title" required>
      <label>Blog Content:</label>
      <textarea name="content" v-model.lazy="blog.content"></textarea>
      <div id="checkboxes">
        <label for="Jeans">Jeans</label>
        <input type="checkbox" name="categories" id="Jeans" value="Jeans" v-model="blog.categories">
        <label for="Shirt">Shirt</label>
        <input type="checkbox" name="categories" id="Shirt" value="Shirt" v-model="blog.categories">
        <label for="T-Shirt">T-Shirt</label>
        <input type="checkbox" name="categories" id="T-Shirt" value="T-Shirt" v-model="blog.categories">
        <label for="Boxer">Boxer</label>
        <input type="checkbox" name="categories" id="Boxer" value="Boxer" v-model="blog.categories">
      </div>
      <select v-model="blog.author">
        <option v-for="authorDetail in blog.authorsList" v-bind:value="authorDetail.autherName">
          {{authorDetail.bookTitle}}
        </option>
      </select>
      <button v-on:click.prevent="save">Save</button>
    </form>
    <h3 v-if="submitted">Post has beed added sucessfully!</h3>
    <div id="preview">
      <h3>Preview Blog</h3>
      <p>Blog Title: {{blog.title}}</p>
      <p>Blog Content:</p>
      <p>{{blog.content}}</p>
      <ul>
        <li v-for="category in blog.categories">
          {{ category }}
        </li>
      </ul>
      <p>Author: {{ blog.author }}</p>
    </div>
  </div>

</template>

<script>
export default {
  name: 'AddBlog',
  data() {
    return {
      blog:{
        title:'',
        content:'',
        categories:[],
        author:"",
        authorsList:[{autherName:"Amish",bookTitle:"Shiva Trilogy"},{autherName:"Chetan",bookTitle:"Revolution 2020"}],
      },
      submitted:false
    }
  },

  methods:{
    save() {
      axios.post(`https://jsonplaceholder.typicode.com/posts`, 
      {
      "userId": 1,
      "title": this.blog.title,
      "body": this.blog.content
      })
      .then((res)=>{
        console.log(res)
        this.submitted=true;
      })
        //
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
#add-blog *{
    box-sizing: border-box;
}
#add-blog{
    margin: 20px auto;
    max-width: 500px;
}
label{
    display: block;
    margin: 20px 0 10px;
}
input[type="text"], textarea{
    display: block;
    width: 100%;
    padding: 8px;
}
#preview{
    padding: 10px 20px;
    border: 1px dotted #ccc;
    margin: 30px 0;
}
h3{
    margin-top: 10px;
}
#checkboxes input{
    display: inline-block;
    margin-right: 10px;
}
#checkboxes label{
    display: inline-block;
}
</style>
