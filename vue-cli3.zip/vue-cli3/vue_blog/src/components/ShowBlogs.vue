<template>
  <div v-theme:column="'wide'" id="show-blogs">
  <h1>Show Blogs</h1>
  <input type="text" name="search" v-model="search">
  <!-- custome directive with value =>v-theme="'narrow'" -->
  <!-- custome directive with argument and value =>v-theme:column="'narrow'" -->
    <div v-for="blog in filterBlogs" class="single-blog">
    <!-- custome directive without argument and value => v-rainbow -->
      <h3 v-rainbow>{{ blog.title | upper-case }}</h3>
      <article>{{ blog.body | snippest }}</article>
    </div>
  </div>

</template>

<script>
import searchMixin from '../mixins/searchMixin'
export default {
  name: 'ShowBlogs',
  data() {
    return {
      blogs:[],
      search:''
    }
  },

  methods:{

  },

  created() {
    //http://dummy.restapiexample.com/api/v1/employees
    axios.get(`https://jsonplaceholder.typicode.com/posts`)
      .then((res)=>{
        console.log(res)
        this.blogs=res.data.slice(0,10)
      })
  },

  computed: {
    /*filterBlogs() {
      return this.blogs.filter((blog)=>{
        return blog.title.match(this.search)
      })
    }*/
  },

  //local filters
  filters: {
    //First way to define filter
    /*'upper-case':(value)=>{
      return value.toUpperCase();
    }*/ 

    // Second way to define filter
      /*upperCase(value){
        return value.toUpperCase();
      } */

      upperCase:(value)=>{
        return value.toUpperCase();
      } 

  },

  //local directives
  directives:{
    'rainbow':{
      bind(el, binding, vnode) {
        el.style.color = '#'+Math.random().toString().slice(2,8)
      }
    }
  },
  mixins:[searchMixin]
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
#show-blogs{
    max-width: 800px;
    margin: 0px auto;
}
.single-blog{
    padding: 20px;
    margin: 20px 0;
    box-sizing: border-box;
    background: #eee;
}
</style>
