<template>
  <div v-theme:column="'wide'" id="single-blog">
  <h1>Single Blog</h1>
  <!-- custome directive with value =>v-theme="'narrow'" -->
  <!-- custome directive with argument and value =>v-theme:column="'narrow'" -->
    <div class="single-blog">
    <!-- custome directive without argument and value => v-rainbow -->
      <h3>{{ blog.title | upper-case }}</h3>
      <article>{{ blog.body | snippest }}</article>
    </div>
  </div>

</template>

<script>
export default {
  name: 'SingleBlog',
  data() {
    return {
      id:this.$route.params.id,
      blog:{}
    }
  },

  methods:{

  },

  created() {
    //http://dummy.restapiexample.com/api/v1/employees
    axios.get('http://jsonplaceholder.typicode.com/posts/' + this.id).then((res)=>{
     console.log(res);
    this.blog = res.data;
    console.log(this.blog);
    });
  },

  //local filters
  filters: {
    //First way to define filter
    /*'upper-case':(value)=>{
      return value.toUpperCase();
    }*/ 

    // Second way to define filter
      /*upperCase(value){
        return value.toUpperCase();
      } */

      upperCase:(value)=>{
        if(value){
          return value.toUpperCase();
        }
      } 

  },
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
#single-blog{
    max-width: 800px;
    margin: 0px auto;
}
.single-blog{
    padding: 20px;
    margin: 20px 0;
    box-sizing: border-box;
    background: #eee;
}
</style>
