<template>
  <div class="home">
    <img alt="Vue logo" src="../assets/logo.png">
    <h1>Welcome to home page</h1>
    <!-- <show-blogs/>
    <br>
    <list-blogs/>
    <br>
    <add-blog/> -->
  </div>
</template>

<script>
// @ is an alias to /src
import AddBlog from '@/components/AddBlog.vue'
import ShowBlogs from '@/components/ShowBlogs.vue'
import ListBlogs from '@/components/ListBlogs.vue'
export default {
  name: 'Home',
  components: {
    'add-blog':AddBlog,
    'show-blogs':ShowBlogs,
    'list-blogs':ListBlogs
  }
}
</script>
<style scoped lang="scss">
.home img {
	display: block;
	margin-left: auto;
	margin-right: auto;
}
</style>
