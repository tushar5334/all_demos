<template>
  <div id="app">
    <div id="nav">
      <router-link to="/">Home</router-link> |
      <router-link to="/about">About</router-link> |
      <router-link to="/dynamic-component">Dynamic Component</router-link>
    </div>
    <router-view/>

    <h1>{{title}}</h1>

    <!-- Slot is used to display content between dynamic tag start -->
    <form-helper>
      <h2>I am slot h2 </h2>
      <p slot="p1">I am slot p1 </p>
      <p slot="p2">I am slot p2 </p>
      <p slot="p3">{{title}} </p>

      <br>

      <div slot="form-header">
        <h3>This is the title of form</h3>
        <p>Information about the form</p>
      </div>

      <div slot="form-fields">
        <input type="text" name="userName">
        <input type="password" name="password">
        
      </div>

      <div slot="form-controls">
        <button v-on:click="saveData">submit</button>
      </div>

    </form-helper>
    <!-- Slot is used to display content between dynamic tag end -->

    <!-- pass data from parent to child using v-bind:title="premitiveTitle" and get data from child to parent using v-on:changeTilteEmitter="updateTitle($event)" -->
    <app-header v-bind:title="premitiveTitle" v-on:changeTilteEmitter="updateTitle($event)"></app-header>
    <Ninja v-bind:ninjaList="ninjas" v-bind:userList="users"></Ninja>
    <br>
    <!-- <Ninja v-bind:ninjaList="ninjas" v-bind:userList="users"></Ninja> -->

    <app-footer v-bind:title="premitiveTitle"></app-footer>
  </div>
</template>
<script>
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import Ninja from '@/components/Ninja'
import FormHelper from '@/components/FormHelper'
export default {
  name: 'AppVue',
  components: {
    'app-header':Header,
    'app-footer':Footer,
    Ninja,
    'form-helper':FormHelper
  },

  data() {
    return {
      title:'I am root component!',
      ninjas: [
                {name: 'Ryu', speciality: 'Vue Components', show: false},
                {name: 'Crystal', speciality: 'HTML Wizardry', show: false},
                {name: 'Hitoshi', speciality: 'Click Events', show: false},
                {name: 'Tango', speciality: 'Conditionals', show: false},
                {name: 'Kami', speciality: 'Webpack', show: false},
                {name: 'Yoshi', speciality: 'Data Diggin', show: false}
            ],
      users: ['Tushar', 'Dhaval'],
      premitiveTitle:"Vue"
    }
  },
  methods: {
    updateTitle(newTitle) {
      this.premitiveTitle = newTitle;
    },
    saveData() {
      alert('FormHelper submitted')
    }
  }
}

</script>
<style lang="scss">
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

#nav {
  padding: 30px;

  a {
    font-weight: bold;
    color: #2c3e50;

    &.router-link-exact-active {
      color: #42b983;
    }
  }
}
</style>
