<template>
  <footer>
      <p>{{ copyright }} {{ title }}</p>
      <p class="subp">{{ copyright }} {{ title1 }}</p>
  </footer>
</template>

<script>
import { bus } from '../main'
export default {
  name: 'FooterComponent',
  props: {
    title:{
      type:String
    }
  },
  data() {
    return {
      copyright: 'Copyright 2017',
      title1: 'sub footer'
    }
  },
  created() {
    bus.$on('changeFooterSubTilte', (data)=>{
      this.title1 = data;
    })
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
  footer{
    background: #222;
    padding: 6px;
  }
  p{
          color: lightgreen;
          text-align: center;
  }
  .subp{
          color: red;
          text-align: center;
  }
</style>
