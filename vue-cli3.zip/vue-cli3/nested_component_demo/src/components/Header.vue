<template>
  <header>
      <!-- <h1 v-on:click="changeTitle" title="click me">{{ title }}</h1>
      <p>String ,Boolean and Number Are Premitive types.When you do some thing this variable it will specific to that components variable only it will not update same name variable in other component</p> -->
      <h1 v-on:click="changeTitleByEventEmitter" title="click me">{{ title }}</h1>
      <h2 v-on:click="changeTitleByEventBus" title="click me">{{ title1 }}</h2>
  </header>
</template>

<script>
import { bus } from '../main'
export default {
  name: 'HeaderComponent',
  props: {
    title:{
      type:String
    }
  },

  data() {
    return{
            title1: 'Sub Header'
        }
  },
  methods:{
    changeTitle() {
      this.title = "Vue Wizards"
    },
    //child to parent communication
    changeTitleByEventEmitter() {
      this.$emit("changeTilteEmitter","Vue Wizards")
    },
    //non relational component //We will change title of footer directly from here
    changeTitleByEventBus() {
      this.title1 = "Sub Vue Wizards";
      bus.$emit("changeFooterSubTilte","Sub Vue Wizards")
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
  header{
    background: lightgreen;
    padding: 10px;
  }
  h1{
      color: #222;
      text-align: center;
  }
  h2{
      color: red;
      text-align: center;
  }
</style>
