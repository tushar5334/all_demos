<template>
<div>
  <h1>Form One</h1>
  <br>
  <input type="text" name="userName">
  <input type="password" name="password">
  <button v-on:click="form1">Send1</button>
</div>
</template>

<script>
export default {
  name: 'FormOne',
  data() {
    return {
    }
  },
  methods: {
    form1() {
      alert('form1 submitted')
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
  
</style>
