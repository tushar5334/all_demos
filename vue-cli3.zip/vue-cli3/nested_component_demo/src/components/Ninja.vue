<template>
  <div id="ninjas">
        <p>Array and Object Are Reference types.When you do some thing this reference it will update orinal array or object
        </p>
        <br>
        <ul>
            <li v-for="ninja in ninjaList" v-on:click="ninja.show=!ninja.show">
              <h2>{{ ninja.name }}</h2>
              <h3 v-show="ninja.show">{{ ninja.speciality }}</h3>
            </li>
        </ul>
        <button v-on:click="deleteNinja">Delete Ninja</button>
        <ul>
            <li v-for="user in userList">
              <h2>{{ user }}</h2>
            </li>
        </ul>
    </div>
</template>

<script>
export default {
  name: 'NinjaComponent',
 // props:['ninjaList'],
 props: {
  ninjaList: {
    type:Array,
    required:true
  },
  userList: {
    type:Array,
    required:true
  }
 },
  data() {
    return{
           

        }
  },

  methods: {
      deleteNinja() {
        this.ninjaList.pop();
      }
  },

  //life cycle hooks

  beforeCreate() {
    //alert('beforeCreate');
  },

  created() {
    //alert('created');
  },

  beforeMount() {
    //alert('beforeMount');
  },

  mounted() {
    //alert('mounted');
  },

  beforeUpdate() {
   // alert('beforeUpdate');
  },

  updated() {
   // alert('updated');
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
  #ninjas{
    width: 100%;
    max-width: 1200px;
    margin: 40px auto;
    padding: 0 20px;
    box-sizing: border-box;
}
ul{
    display: flex;
    flex-wrap: wrap;
    list-style-type: none;
    padding: 0;
}
li{
    flex-grow: 1;
    flex-basis: 300px;
    text-align: center;
    padding: 30px;
    border: 1px solid #222;
    margin: 10px;
}
</style>
