<template>
<div>
  <h1>Form Two</h1>
  <br>
  <input type="text" name="userName">
  <input type="password" name="password">
  <button v-on:click="form2">Send2</button>
</div>
</template>

<script>
export default {
  name: 'FormTwo',
  data() {
    return {
    }
  },
  methods: {
    form2() {
      alert('form2 submitted')
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
  
</style>