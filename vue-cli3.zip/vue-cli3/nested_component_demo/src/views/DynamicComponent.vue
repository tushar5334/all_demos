<template>
  <div>
  <!-- Keep live can remain your data as it is when you click from one other  -->
  <keep-alive>	
  	<component v-bind:is="comp"></component>
  </keep-alive>
  <button v-on:click="comp='form-one'">Form1</button>
  <button v-on:click="comp='form-two'">Form2</button>
  <!-- <form-one></form-one>
  <form-two></form-two> -->
  </div>
</template>

<script>
// @ is an alias to /src
import FormOne from '@/components/FormOne.vue'
import FormTwo from '@/components/FormTwo.vue'

export default {
  name: 'DynamicComponent',
  components: {
    'form-one':FormOne,
    'form-two':FormTwo
  },
  data() {
  	return {
  		comp:"form-one"
  	}
  }
}
</script>
