<template>
  <div id="app">
    <!-- <div id="nav">
      <router-link to="/">Home</router-link> |
      <router-link to="/about">About</router-link>
    </div>
    <router-view/> -->
    <!-- <product-list-one v-bind:products="products"/>
    <product-list-two v-bind:products="products"/> -->

    <product-list-one />
    <product-list-two />
  </div>
</template>

<script>
// @ is an alias to /src
import ProductListOne from '@/components/ProductListOne.vue'
import ProductListTwo from '@/components/ProductListTwo.vue'
export default {
  name: 'App',
  components:{
    'product-list-one':ProductListOne,
    'product-list-two':ProductListTwo
  },
  data() {
    return {
      /*products: [
          {name: 'Banana Skin', price: 20},
          {name: 'Shiny Star', price: 40},
          {name: 'Green Shells', price: 60},
          {name: 'Red Shells', price: 80}
      ]*/
    }
  }
}
</script>
<style>
  body{
      font-family: Ubuntu;
      color: #555;
  }
</style>
