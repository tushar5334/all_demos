<template>
  <div id="product-list-one">
    <h1>Product List One</h1>
    <ul>
      <li v-for="product in saleProducts">
        <span class="name">{{product.name}}</span>
        <span class="price"> ${{product.price}}</span>
      </li>
    </ul>
    <!-- <button v-on:click="reducePrice(1)">Reduce Price</button> -->
    <button v-on:click="reducePriceAction(4)">Reduce Price</button>
  </div>
</template>

<script>
import {mapActions} from 'vuex';
import {mapGetters} from 'vuex';

export default {
  name: 'ProductListOne',
  computed:{
    products() {
      return this.$store.state.products;
    },
    /*saleProducts() {
     var saleProducts = this.$store.state.products.map(product=>{
        return {
          name:"**"+product.name+"**",
          price:product.price/2
        }
     })
     return saleProducts;
    }*/

    /*saleProducts() {
     return this.$store.getters.saleProducts;
    }*/
    ...mapGetters(['saleProducts'])
  },
  methods:{
    //reducePrice(amount) {
      /*this.$store.state.products.forEach(product=>{
        product.price -= 1; 
      })*/
      //this.$store.commit('reducePrice', amount)

      //this.$store.dispatch('reducePriceAction', amount)
    //}
      ...mapActions(['reducePriceAction'])
  }
  /*props:{
    products:Array
  },
  data() {
    return {

    }
  }*/
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
#product-list-one{
    background: #FFF8B1;
    box-shadow: 1px 2px 3px rgba(0,0,0,0.2);
    margin-bottom: 30px;
    padding: 10px 20px;
}
#product-list-one ul{
    padding: 0;
}
#product-list-one li{
    display: inline-block;
    margin-right: 10px;
    margin-top: 10px;
    padding: 20px;
    background: rgba(255,255,255,0.7);
}
.price{
    font-weight: bold;
    color: #E8800C;
}
</style>
