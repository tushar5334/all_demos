<template>
  <div id="app">
    <div id="nav">
      <router-link to="/">Home</router-link> |
      <router-link to="/about">About</router-link> |
      <router-link to="/dynamic-css">Dynamic CSS</router-link> |
      <router-link to="/conditions">Conditions</router-link> |
      <router-link to="/loopings">Loopings</router-link> |
      <router-link to="/punchbag-game">PuchbagGame</router-link> |
      <router-link to="/multi-vue-instance">Multiple Vue Instance</router-link> |
      <router-link to="/vue-component">Vue Component</router-link> |
      <router-link to="/refs">Refs</router-link> |
      <router-link to="/scoped-css">Scoped CSS</router-link> |
    </div>  
    <global-comp></global-comp>
    <br>
    <router-view/>

  </div>
</template>

<style lang="scss">
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

#nav {
  padding: 30px;

  a {
    font-weight: bold;
    color: #2c3e50;

    &.router-link-exact-active {
      color: #42b983;
    }
  }
}
</style>
