<template>
  <div class="home">
    <h1>Multiple Vue Instance HTML Code</h1>
    <div>
        {{htmlCode}}
    </div>
     <h1>Multiple Vue Instance JS Code</h1>
     <div>
        {{jsCode}}
    </div>
  </div>
</template>

<script>

export default {
  name: 'MultiVueInstance',
  data() {
    return {
      htmlCode:`
      <div id="vue-app-one">
            <h2>{{ title }}</h2>
            <p>{{ greet }}</p>
        </div>
        <div id="vue-app-two">
            <h2>{{ title }}</h2>
            <p>{{ greet }}</p>
            <button v-on:click="changeTitle">Change App One Title</button>
        </div>
      `,

      jsCode:`
      var one = new Vue({
        el: '#vue-app-one',
        data: {
          title: 'Vue App One'
        },
        computed: {
          greet: function(){
            return 'Hello, from app one :)';
          }
        }
    });

    var two = new Vue({
        el: '#vue-app-two',
        data: {
          title: 'Vue App Two'
        },
        computed: {
          greet: function(){
            return 'Yo dudes, this is app 2 speaking to ya';
          }
        },
        methods: {
          changeTitle: function(){
            one.title = 'Title Changed';
          }
        }
    });

    two.title = 'Changed from outside';`
    }
  },

  methods: {
    
  },

  computed:{

  }


}
</script>
