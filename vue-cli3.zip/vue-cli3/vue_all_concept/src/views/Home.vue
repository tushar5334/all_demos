<template>
  <div class="home">
    <img alt="Vue logo" src="../assets/logo.png">
    <HelloWorld1/>
    <HelloWorld msg="Welcome to Your Vue.js App"/>

    <h1>Data Binding</h1>
    <p>{{ name }}</p>
    <p>{{ greeting('Afternoon') }}</p>
    <p><a v-bind:href="website"> Attribute binding </a></p>
    <p><a :href="website"> Attribute binding shorthand</a></p>
    <p>Bind html data</p><p v-html="websiteUrl"></p>

    <br>

    <h1>Event Binding</h1>
    <button v-on:click="add(1)">Add</button> &nbsp;
    <button @click="sub(1)">Sub (Short Hand)</button>
    <button v-on:dblclick="add(10)">Increment age by 10</button> &nbsp;
    <p>{{ name }} is {{ age }} year old.</p>

    <div id="canvas" v-on:mousemove="updateXY" style="width:200px;height:200px;border:solid 1px;text-align:center"> 
     {{ x }} {{ y }}
    </div>

    <br>

    <h1>Event Modifiers</h1>
    <button v-on:click.once="add(1)">Add (will click only once using v-on:click.once="add(1)" )</button> &nbsp;
    <a v-on:click.prevent="clickme" href="http://www.google.com">Google.com (will prevent default behaviour using v-on:click.prevent="clickme" )</a>
    <p>{{ name }} is {{ age }} year old.</p>

    <br>
    <h1>Keyboard Events</h1>
    Keyup Event:<input type="text" name="hobby" v-on:keyup="myhobby" >
    <br>
    Keyup Calles when you hit enter:<input type="text" name="hobby2" v-on:keyup.enter="myhobby" >
    <br>
    Keyup Calles when you hit alt+enter:<input type="text" name="hobby3" v-on:keyup.alt.enter="myhobby" >
    <br>
    My Hobby Is {{hobby}}
    <br>
    <h1>Two-way Databinding</h1>

    Movie Name:<input type="text" name="hobby" v-model="moviename" >

    The movie name is {{moviename}}

    <br>
    <h1>Computed Properties</h1>
    <button v-on:click=a++>Add To A</button>
    <button v-on:click=b++>Add To B</button>
    <br>
    A :{{a}} === B:{{b}}
    <br>
    Added To A {{ageAddedtoA()}} == Added To B {{ageAddedtoB()}}

    <br>
    With computed Added To A {{ageAddedtoAcomp}} == Added To B {{ageAddedtoBcomp}}

  </div>
</template>

<script>
// @ is an alias to /src
import HelloWorld from '@/components/HelloWorld.vue'
import HelloWorld1 from '@/views/UseLocallyComponent.vue'
export default {
  name: 'Home',
  components: {
    HelloWorld,
    HelloWorld1
  },

  data() {
  	return {
	  	name:'Tushar',
	  	age:20,
	  	website:'http://www.google.com',
	  	websiteUrl:'<a href="http://www.google.com">google.com</a>',
      x:0,
      y:0,
      hobby:'',
      moviename:'',
      a:0,
      b:0
  	}
  },

  methods: {
  	greeting(time) {
  		return 'Good' + time + ' '+ this.name;
  	},

    add(inc) {
      this.age +=inc;
    },

    sub(dec) {
      this.age -=dec;
    },

    updateXY(event) {
      this.x = event.offsetX,
      this.y = event.offsetY
    },

    clickme() {
      alert('i am clicked')
    },

    myhobby(event) {
      this.hobby = event.target.value

    },

    ageAddedtoA() {
      console.log('adde to a')
      return this.a+this.age 
    },

    ageAddedtoB() {
      console.log('adde to b')
      return this.b+this.age 
    }
    
  },

  computed:{
    ageAddedtoAcomp() {
      console.log('adde to a comp')
      return this.a+this.age 
    },

    ageAddedtoBcomp() {
      console.log('adde to b comp')
      return this.b+this.age 
    }
  }


}
</script>
