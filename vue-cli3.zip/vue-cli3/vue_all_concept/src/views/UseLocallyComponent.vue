<template>
  <div class="home">
    <h1>I am {{text}}</h1>
  </div>
</template>

<script>

export default {
  name: 'LocalComponent',
  data() {
    return {
      text:"local Component"
    }
  },

  methods: {
    
  },

  computed:{

  }


}
</script>
