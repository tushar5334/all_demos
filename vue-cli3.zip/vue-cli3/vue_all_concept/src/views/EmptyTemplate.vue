<template>
  <div class="home">
    <h1>Data Binding</h1>
    <p>{{ name }}</p>

  </div>
</template>

<script>

export default {
  name: 'DynamicCss1',
  data() {
    return {
      name:'Tushar'
    }
  },

  methods: {
    
  },

  computed:{

  }


}
</script>
