<template>
  <div class="home">
    <h1>Loops</h1>
    <h1>Looping through lists without index</h1>
      <div v-for="character in characters">
        {{character}}
      </div>

      <h1>Looping through lists with index</h1>
      <div v-for="(character, index) in characters">
        {{index}}==> {{character}}
      </div>

      <h1>Looping through array object</h1>
      <div v-for="(detail, index) in gameLists">
        {{index}}==> {{detail.name}} == {{detail.game}}
      </div>

      <h1>Looping through array object without html element</h1>
      <template v-for="(detail, index) in gameLists">
        {{index}}==> {{detail.name}} == {{detail.game}}
      </template>

      <h1>Looping through object</h1>
      <div v-for="(value, key) in personalDetail">
        {{key}}==> {{value}}
      </div>

  </div>
</template>

<script>

export default {
  name: 'Looping',
  data() {
    return {
      characters:['Tushar', 'Dhaval', 'Maanarth'],
      gameLists:[{name:'Yuraj Sinh', game:'cricket'}, {name:'Ronaldo', game:'football'}, {name:'Sandip Singh', game:'hockey'}],
      personalDetail:{name:'Yuraj Sinh', email:'tushar5334@gmail.comp', phone:"9913093603"}
    }
  },

  methods: {
    
  },

  computed:{

  }


}
</script>
