<template>
  <div class="home">
    <h1>Conditions</h1>
    <h2>Example 1 (v-if and v-else-if)</h2>
    <button v-on:click="error=!error">v-if / v-else-if Toggle Error</button>&nbsp;
    <button v-on:click="success=!success">v-if / v-else-if Toggle Success</button>
    <p v-if="error">This is error</p>
    <p v-else-if="success">This is success :)</p>

    <h2>Example 2 (v-if and v-else)</h2>
    <button v-on:click="defaultFlag=!defaultFlag">v-if / v-elseToggle</button>
    <p v-if="defaultFlag">This is error</p>
    <p v-else>This is else</p>

    <h2>Example 3 (v-show)</h2>
    <button v-on:click="vshowFlag=!vshowFlag">v-show toggle</button>
    <p v-show="vshowFlag">This is error</p>


  </div>
</template>

<script>

export default {
  name: 'Conditions',
  data() {
    return {
      error:false,
      success:false,
      defaultFlag:false,
      vshowFlag:false
    }
  },

  methods: {
    
  },

  computed:{

  }


}
</script>
