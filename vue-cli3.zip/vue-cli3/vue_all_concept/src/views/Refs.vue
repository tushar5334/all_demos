<template>
  <div class="home">
    <h1>refs</h1>
    <input type="text" name="mob" ref="mobRef">&nbsp;
    <button v-on:click="changeTitle">Click Me To Change Title</button>
    <p>{{ title }}</p>
    <br>
    <div ref="demo_div">Hello</div>
  </div>
</template>

<script>

export default {
  name: 'Refs',
  data() {
    return {
      title:'Tushar'
    }
  },

  methods: {
    changeTitle() {
      console.log(this.$refs.demo_div.innerText)
      //console.log(this.$refs.demo_div.innerHTML)

      this.title = this.$refs.mobRef.value;
      this.$refs.demo_div.innerHTML = "Hi...";
    }
  },

  computed:{

  }


}
</script>
