<template>
  <div class="home">
    <h1>Global Component</h1>
    <p>
      Add Component in main.js file
      <br>
      import GlobalComponent from './views/UseGloballyComponent'
      <br>
      Vue.component('global-comp', GlobalComponent)
      <br>
      And Add  {{tag}}
      In any component you wish to use
    </p>
    <ul>
      <li v-for="user in Users">
        {{user}}
      </li>
    </ul>
  </div>
</template>

<script>

export default {
  name: 'GlobalComponent',
  data() {
    return {
      Users:['Tushar', 'Dhaval', 'Maanarth'],
      tag:`<global-comp></global-comp>`
    }
  },

  methods: {
    
  },

  computed:{

  }


}
</script>
