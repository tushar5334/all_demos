<template>
  <div class="home">
    <h1>Vue Component HTML Code</h1>
    <div>
        {{htmlCode}}
    </div>
     <h1>Vue Component JS Code</h1>
     <div>
        {{jsCode}}
    </div>
  </div>
</template>

<script>

export default {
  name: 'VueComponentDemo',
  data() {
    return {
      htmlCode:`
      <h1>Templates</h1>
      <div id="vue-app-one">
          <h1>Vue App One</h1>
          <greeting></greeting>
      </div>
      <div id="vue-app-two">
          <h1>Vue App Two</h1>
          <greeting></greeting>
      </div>
      `,

      jsCode:`
      Vue.component('greeting', {
          template: '<p>Hey there, I am a re-usable component</p>'
      });

      /* new Vue({
          el: '.test',
          template: '<p>I am a template</p>'
      }); */

      new Vue({
          el: '#vue-app-one'
      });

      new Vue({
          el: '#vue-app-two'
      });`
    }
  },

  methods: {
    
  },

  computed:{

  }


}
</script>
