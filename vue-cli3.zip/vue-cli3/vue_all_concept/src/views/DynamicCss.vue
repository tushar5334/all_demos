<template>
  <!-- <div class="home">
    <h1>Example 1</h1>
    <div v-on:click="availableFlag=!availableFlag" v-bind:class={available:availableFlag}>
      <span>Hello!</span>
    </div>
  </div> -->

   <div class="home">
    <h1>Example 2</h1>
    <button v-on:click="nearbyFlag=!nearbyFlag">Toggle Near By</button> &nbsp;
    <button v-on:click="availableFlag=!availableFlag">Toggle Available</button>
    <div v-bind:class="compClasses">
      <span>Hello!</span>
    </div>

  </div>
</template>

<script>

export default {
  name: 'DynamicCss1',
  data() {
    return {
      availableFlag:false,
      nearbyFlag:false
    }
  },

  methods: {
    
  },

  computed:{

    compClasses() {
      return {
        available:this.availableFlag,
        nearby:this.nearbyFlag
      }
    }

  }


}
</script>

<style lang="scss">
span {
  background:red;
  display: inline-block;
  padding: 10px;
  color: #fff;
  margin: 10px 0;
}

.available span {
  background: green
}

.nearby span:after {
  content: 'NearBy';
  margin-left:10px;
}
</style>
