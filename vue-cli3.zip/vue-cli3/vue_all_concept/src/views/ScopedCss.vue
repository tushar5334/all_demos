<template>
  <div class="home">
    <h1>Component specific css example (scoped)</h1>
    <p>{{ title }}</p>

  </div>
</template>

<script>

export default {
  name: 'ScopedCss',
  data() {
    return {
      title:'ScopedCss Tilte'
    }
  },

  methods: {
    
  },

  computed:{

  }


}
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
  p {
    color: green;
  }
</style>
