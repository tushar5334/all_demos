import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import DynamicCss1 from '../views/DynamicCss.vue'
import Conditions from '../views/Conditions.vue'
import Looping from '../views/Looping.vue'
import PunchbagGame from '../views/PunchbagGame.vue'
import MultiVueInstance from '../views/MultiVueInstance.vue'
import VueComponentDemo from '../views/VueComponentDemo.vue'
import Refs from '../views/Refs.vue'
import ScopedCss from '../views/ScopedCss.vue'
Vue.use(VueRouter)

  const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {
    path: '/dynamic-css',
    name: 'DynamicCss1',
    component: DynamicCss1
  },
  {
    path: '/conditions',
    name: 'Conditions',
    component: Conditions
  },
  {
    path: '/loopings',
    name: 'Looping',
    component: Looping
  },
  {
    path: '/punchbag-game',
    name: 'PunchbagGame',
    component: PunchbagGame
  },
  {
    path: '/multi-vue-instance',
    name: 'MultiVueInstance',
    component: MultiVueInstance
  },
  {
    path: '/vue-component',
    name: 'VueComponentDemo',
    component: VueComponentDemo
  },
  {
    path: '/refs',
    name: 'Refs',
    component: Refs
  },
  {
    path: '/scoped-css',
    name: 'ScopedCss',
    component: ScopedCss
  },
  {
    path: '/about',
    name: 'About',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
  },
  // {
  //   path: '/dynamic-css',
  //   name: 'DynamicCss1',
  //   // route level code-splitting
  //   // this generates a separate chunk (about.[hash].js) for this route
  //   // which is lazy-loaded when the route is visited.
  //   component: () => import(/* webpackChunkName: "about" */ '../views/DynamicCss.vue')
  // }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
