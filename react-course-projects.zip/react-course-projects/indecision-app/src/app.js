import React from 'react';
import ReactDOM from 'react-dom';

import IndecisionApp from './components/IndecisionApp';
//import './styles/style.css';
import 'normalize.css/normalize.css';
import './styles/style.scss';

ReactDOM.render(<IndecisionApp />, document.getElementById('app'));


// data passed with props start //

/* const Layout = (props)=> {
    return (
        <div>
            <p>Header</p>
            {props.content}
            <p>Footer</p>
        </div>
    )
}

const template = (
    <div>
        <h1>This is content</h1>
        <p>Loremipsum</p>
    </div> 
)

ReactDOM.render(<Layout content={template} />, document.getElementById('app')); */
// data passed with props end //


// data passed with props.children start //

/* const Layout = (props)=> {
    return (
        <div>
            <p>Header</p>
            {props.children}
            <p>Footer</p>
        </div>
    )
}

ReactDOM.render(
    (
    <Layout>
        <h1>This is content</h1>
        <p>Loremipsum</p>
    </Layout>
    ), document.getElementById('app')); */
// data passed with props.children end //



/* class OldSyantax {
    constructor() {
        this.name = 'Myke';
        this.getGreeting = this.getGreeting.bind(this);
    }

    getGreeting() {
        return `My name is ${this.name}`;
    }
}

const objOldSyntax = new OldSyantax();
const getOldGreeting = objOldSyntax.getGreeting;
//console.log(objOldSyntax);
console.log(getOldGreeting());


class NewSyantax {
    name = 'Jen';
    getGreeting = () => {
        return `My name is ${this.name}`;
    }
}

const objNewSyntax = new NewSyantax();
const getNewGreeting = objNewSyntax.getGreeting;
console.log(getNewGreeting()); */