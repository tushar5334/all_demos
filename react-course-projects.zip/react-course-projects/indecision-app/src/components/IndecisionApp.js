import React from 'react';
/* import components */

import AddOption from './AddOption';
import Action from './Action';
import Header from './Header';
import Options from './Options';
import OptionModal from './OptionModal';
class IndecisionApp extends React.Component {
    state = {
        //options: props.options
        options: [],
        selectedOption:undefined
    }

    handleRemoveRemoveAll = () => {
        this.setState(() => ({ options: [] }));
    }

    //simplify code
    //this.setState((prevState) => ({ options: prevState.options.concat(option)}));
    /* this.setState((prevState)=>{
        return {
            options: prevState.options.concat(option)
        }
    }) */

    handlePick = () => {
        const randomNumber = Math.floor(Math.random() * this.state.options.length);
        const option = this.state.options[randomNumber];
        /* this.setState(()=>{
            return {selectedOption:option}
        }) */
        this.setState(()=>({selectedOption:option}));
    }

    handleClearSelection = ()=>{
        this.setState(()=>({selectedOption:undefined}));
    }

    handleAddOption = (option) => {
        if (!option) {
            return 'Enter valid value to add item.';
        } else if (this.state.options.indexOf(option) >-1) {
            return 'This option already exists';
        }
        this.setState((prevState) => ({ options: prevState.options.concat(option)}));
    }

    handleDeleteOption = (optionToRemove) => {
        this.setState((prevState)=>{
            return {
                options: prevState.options.filter((option)=>{
                    return optionToRemove !== option
                })
            }
        })
    }
    /* constructor(props) {
        super(props)
        this.handleRemoveRemoveAll = this.handleRemoveRemoveAll.bind(this);
        this.handlePick = this.handlePick.bind(this);
        this.handleAddOption = this.handleAddOption.bind(this);
        this.handleDeleteOption = this.handleDeleteOption.bind(this);
        this.state = {
            //options: props.options
            options: []
        };

    } */

    componentDidMount() {
        try {
            const json = localStorage.getItem('options');
            const options = JSON.parse(json);
            if (options) {
                this.setState(()=>({options}));
            }
            console.log('FetchData...!');
        } catch (error) {
        }
    }

    componentDidUpdate(prevProps, prevState) {
        if(prevState.options.length !== this.state.options.length) {
            const json = JSON.stringify(this.state.options);
            localStorage.setItem('options', json);
            console.log('SavingData...!');
        }
    }

    componentWillUnmount() {
        console.log('Leaving Component...!');
    }
    render() {
        const sub_title = 'Indecision App Sub Title';
        return(
            <div>
                <Header sub_title={sub_title} />
                <div className="container">
                    <Action hasOptions={this.state.options.length > 0 ? true : false} handlePick={this.handlePick}/>
                    <div className="widget">
                        <Options options={this.state.options} handleRemove={this.handleRemoveRemoveAll} handleDeleteOption={this.handleDeleteOption} />
                        <AddOption handleAddOption={this.handleAddOption}/>
                    </div>
                </div>
                <OptionModal selectedOption={this.state.selectedOption} handleClearSelection={this.handleClearSelection}/>
            </div>
        );
    }
}
IndecisionApp.defaultProps = {
    options: []
};

export default IndecisionApp;