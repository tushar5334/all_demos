import React from 'react';
//with return statement
/* const Header = (props)=>{
    return (
        <div>
            <h1>
                {props.title}
            </h1>
            <h1>
                {props.sub_title}
            </h1>
        </div>
    );
} */

//with short hand statement
const Header = (props)=>(
    <div className="header">
        <div className="container">
            <h1 className="header__title">
                {props.title}
            </h1>
            <h2 className="header__subtitle">
                {props.sub_title}
            </h2>
        </div>
    </div>
);

Header.defaultProps = {
    title:'Default Title'
};

export default Header;