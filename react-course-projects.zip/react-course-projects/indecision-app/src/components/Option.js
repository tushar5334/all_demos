import React from 'react';
//with return statement
/* const Option = (props) => {
    return (
        <div>
            <p style={{ color: "red" }}>{props.optionText}</p>
            <button onClick={(e)=>{
                props.handleDeleteOption(props.optionText);
            }}>
            Remove</button>
        </div>
    );
} */
//with short hand statement

const Option = (props) => (
    <div className="option">
        {/* <p style={{ color: "red" }}>{props.optionText}</p> */}
        <p className="option__text">{props.count}. {props.optionText}</p>
        <button className="button button--link" onClick={(e)=>{
            props.handleDeleteOption(props.optionText);
        }}>
        Remove</button>
    </div>
);

export default Option;