/* const square = function (x) {
    return x*x;
} */

/* function square(x) {
    return x*x;
} */

//console.log(square(8));

/* const squareArrow = (x)=>{
    return x*x;
} */

/* const squareArrow = (x)=>x*x;
console.log(squareArrow(11)); */


/* const getFirstName = (fullName) => {
        return fullName.split(' ')[0];
} */

/* const getFirstName = (fullName) => fullName.split(' ')[0];

console.log(getFirstName('Dhaval Patil')); */


/* const add = function(a, b) {
    console.log(arguments);
    return a+b;
}

console.log(add(55,10,200)); */


/* const user = {
    name:'Manu',
    cities:['Ahmedabad','Rajkot','Nadiad'],
    printPLaces: function() {
        console.log(this.name);
        console.log(this.cities);
        const self = this;
        this.cities.forEach(function(city) {
            console.log(self.name);
            return self.name + ' ' +city;
        })
    }
} */
/*
const user = {
    name:'Manu',
    cities:['Ahmedabad','Rajkot','Nadiad'],
    printPLaces: function() {
        console.log(this.name);
        console.log(this.cities);
        this.cities.forEach((city)=> {
            console.log(this.name);
            return this.name + ' ' +city;
        })
    }
} */


/* const user = {
    name: 'Manu',
    cities: ['Ahmedabad', 'Rajkot', 'Nadiad'],
    printPLaces () {
        return this.cities.map((city) => {
            return this.name + ' is lived in ' + city;
        })
    }
}
console.log(user.printPLaces()); */


const multiplyer = {
    multiplyBy:2,
    numbers:[2,4,6],
    multiply() {
        return this.numbers.map((num) => num * this.multiplyBy);
    }
}


console.log(multiplyer.multiply())


