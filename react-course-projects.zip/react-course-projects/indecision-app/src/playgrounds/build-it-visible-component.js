class VisibilityToggle extends React.Component {

    constructor(props) {
        super(props)
        this.toggleVisibility = this.toggleVisibility.bind(this);
        this.state = {
            visibility:false
        };
    }

    toggleVisibility() {
        this.setState((prevState)=>{
            return {
                visibility: !prevState.visibility
            }
        });
    }

    render() {
        return (
            <div>
                <h1>This is visibility demo</h1>
                {this.state.visibility && (
                    <div>
                        <p>Hey!You can see detals now!</p>
                    </div>
                )}
                <button onClick={this.toggleVisibility}>{this.state.visibility ? 'Hide Details' : 'Show Details'}</button>
            </div>
        );
    }

}

ReactDOM.render(<VisibilityToggle />, document.getElementById('app'));