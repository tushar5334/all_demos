var nameVar = 'Andrew Mead';
//var nameVar = 'Mead'; //Redefining is possible with var
console.log('nameVar', nameVar);

let nameLet = 'Tushar Patil';
// let nameLet = 'Patil'; //Redefining is not possible with let

console.log('nameLet', nameLet);

const nameConst = 'Dhaval Patil';
//const nameConst = 'Patil'; //Redefining is not possible with const

console.log('nameConst', nameConst);

/* function getPetName() {
    var petName = 'Hal';
    return petName;
}
var petName = getPetName(); */

/* var fullName = 'Maanarth Patil';
if (fullName) {
    var firstName = fullName.split(' ')[0];
    console.log(firstName);
} */

/* var fullName = 'Maanarth Patil';
let firstName;
if (fullName) {
    firstName = fullName.split(' ')[0];
    console.log(firstName);
}

console.log(firstName); */

const fullName = 'Maanarth Patil';

let firstName
if (fullName) {
    firstName = fullName.split(' ')[0];
    console.log(firstName);
}
console.log(firstName);