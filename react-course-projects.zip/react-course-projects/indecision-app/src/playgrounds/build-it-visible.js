let visibility = false;
const toggleVisibility = () => {
    visibility = !visibility;
    render();
}
const render = () => {
    const jsx = (
        <div>
        <h1>This is visibility demo</h1>
        {visibility && (
            <div>
            <p>Hey!You can see detals now!</p>
            </div>
            )}
        <button onClick={toggleVisibility}>{visibility ? 'Hide Details' : 'Show Details'}</button>
        </div>
        );
    ReactDOM.render(jsx, document.getElementById('app'));
}
render();