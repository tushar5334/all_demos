const userName = 'Maanarth Patil';
const userAge = 27;
const userLocation = 'Naroda';

const user = {
    name: 'Maanarth',
    age: 26,
    location: 'Ahmedabad'
}
function getLocation(location) {
    if (location) {
        //return location;
        return <p>Location: {location}</p>;
    }
}
const templateTwo = (
    /* <div>
        <h1>Tushar Patil</h1>
        <p>Age:26</p>
        <p>Location:Ahmedabad</p>
    </div> */
    /* <div>
        <h1>{userName}</h1>
        <p>Age:{userAge}</p>
        <p>Location:{userLocation}</p>
    </div> */
    /* <div>
        <h1>{user.name}</h1>
        <h1>{user.name +'!'}</h1>
        <h1>{user.name.toUpperCase()}</h1>
        <p>Age:{user.age}</p>
        <p>Location:{user.location}</p>
    </div> */

    <div>
        <h1>{user.name ? user.name : 'Tushar Patil'}</h1>
        {(user.age && user.age >= 18) && <p>Age:{user.age}</p>}
        {getLocation(user.location)}
    </div>
);

let count = 0;
const incBtnID = 'inc';
const incClass = 'button-primary';
const addOne = () => {
    console.log('addOne');
    count++;
    renderCounterApp();
}

const minusOne = () => {
    console.log('minusOne');
    count--;
    renderCounterApp();
}

const reset = () => {
    console.log('reset');
    count = 0;
    renderCounterApp();
}

/* const templateThree = (
    <div>
        <h1>Count:{count}</h1>
        <button id="inc" className="button-primary" >+1</button>
    </div> */

/* <div>
    <h1>Count:{count}</h1>
    <button id={incBtnID} className={incClass} >+1</button>
</div> */
/*  <div>
     <h1>Count:{count}</h1>
     <button onClick={()=>{
         console.log('call function as argument');
     }} >+1</button>
 </div>
);*/

//console.log(templateThree);
const appRoot = document.getElementById('app');


const renderCounterApp = () => {
    const templateThree = (
        <div>
            <h1>Count:{count}</h1>
            <button onClick={addOne} >+1</button>&nbsp;
            <button onClick={minusOne} >-1</button>&nbsp;
            <button onClick={reset} >Reset</button>
        </div>

    );
    ReactDOM.render(templateThree, appRoot)
}

renderCounterApp();
/* ReactDOM.render(templateTwo, appRoot) */