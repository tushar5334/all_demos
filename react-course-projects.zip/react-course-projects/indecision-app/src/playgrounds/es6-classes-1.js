class Person {
    constructor(name='Dhaval', age=0) {
        //this.name = name || 'Dhaval'  // set default value to 'Dhaval' if not exist
        this.name = name;
        this.age = age;

    }

    getGreetings() {
        return `Hi, ${this.name}!`
    }

    getDescription() {
        return `Hi ${this.name}, your age is ${this.age}!`
    }
}

//const me = new Person('Tushar Patil', 33);

/* console.log(me);
console.log(me.getGreetings()); */

//console.log(me.getDescription());

//const other = new Person()

/* console.log(other);
console.log(other.getGreetings()); */

//console.log(other.getDescription());


class Student extends Person {
    constructor(name, age, major) {
        super(name, age); // call parent class constructor
        this.major = major;
    }

    hasMajor() {
        /* !undefined // true
        !!undefined // false */
        return !!this.major; //
    }

    getDescription() {
        let description = super.getDescription()
        if (this.hasMajor()) {
            description += `Their major is ${this.major}`;
        }
        return description;
    }
}

const me = new Student('Tushar Patil', 33, 'BCA');

//console.log(me);
console.log(me.getDescription());

//console.log(me.getDescription());

const other = new Student()

//console.log(other);
console.log(other.getDescription());

class Traveller extends Person {

    constructor(name, age, homeLocation) {
        super(name, age);
        this.homeLocation = homeLocation;
    }

    getDescription() {
        let description = super.getDescription();
        if (!!this.homeLocation) {
            description += `I'm visiting from ${this.homeLocation}`;
        }

        return description;
    }


}

const me1 = new Traveller('Maanarth', 12, 'Ahmedabad');
console.log(me1.getDescription())
const other1 = new Traveller();
console.log(other1.getDescription())