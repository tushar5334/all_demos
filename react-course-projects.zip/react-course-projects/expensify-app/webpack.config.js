const path=require('path');

module.exports = {
    entry:"./src/playgrounds/redux-101.js",
    output:{
        path:path.join(__dirname, "public"),
        filename:"bundle.js"
    },
    module: {
        rules: [{
            loader: 'babel-loader',
            test: /\.js$/,
            exclude: /node_modules/
        },
        {
            //test: /\.css$/,
            //test: /\.scss$/,
            test: /\.s?css$/,// can compile both css and scss
            use:[
                'style-loader',
                'css-loader',
                'sass-loader'
            ]
        }
        ]
    },
    devtool:'eval-cheap-module-source-map',
    devServer: {
        contentBase: path.join(__dirname, "public"),
        host: '127.0.0.1',
        port: 8081,
        historyApiFallback:true
    }
}