import React from 'react';
import {
    BrowserRouter as Router,
    Route,
    Switch
  } from "react-router-dom";

import ExpenseHomePageComponent from './../components/ExpenseHomePageComponent';
import Header from './../components/Header';
import NotFoundPage from './../components/NotFoundPage';
import HelpPage from './../components/HelpPage';
import EditExpensePage from './../components/EditExpensePage';
import AddExpensePageComponent from './../components/AddExpensePageComponent';
const AppRouter = ()=>(
<Router>
    <div>
        <Header />
        <Switch>
            <Route path="/" component={ExpenseHomePageComponent} exact={true} />
            <Route path="/create" component={AddExpensePageComponent} />
            {/* <Route path="/edit/:id/:id2" component={EditExpensePage} /> */}
            <Route path="/edit/:id" component={EditExpensePage} />
            <Route path="/help" component={HelpPage} />
            <Route component={NotFoundPage} />
        </Switch>
    </div>
</Router>
);

export default AppRouter;