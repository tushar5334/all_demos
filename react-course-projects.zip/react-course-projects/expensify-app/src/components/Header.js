import React from 'react';
import {
    Link,
    NavLink
  } from "react-router-dom";
const Header = () => (
    <header>
        <h1>Expensify</h1>
        {/* <Link to="/">Home</Link>&nbsp;
        <Link to="/create">Create Expense</Link>&nbsp;
        <Link to="/edit">Edit Expense</Link>&nbsp;
        <Link to="/help">Help Expense</Link>&nbsp; */}

        <NavLink to="/"  activeClassName="is-active" exact={true}>Home</NavLink>&nbsp;
        <NavLink to="/create" activeClassName="is-active">Create Expense</NavLink>&nbsp;
        <NavLink to="/help" activeClassName="is-active">Help</NavLink>&nbsp;

    </header>
);

export default Header;