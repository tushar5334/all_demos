import React from 'react';

const EditExpensePage = (props) => {
    console.log(props);
    //console.log(props.location.search);
    //console.log(props.location.hash);
    //console.log(props.match.params.id);
    //console.log(props.match.params.id2);

    return (
        <div>
            <h1>Edit component</h1>
        </div>
    );
};

export default EditExpensePage;