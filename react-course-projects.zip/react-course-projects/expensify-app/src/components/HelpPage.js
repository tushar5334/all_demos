import React from 'react';


const HelpPage = () => (
    <div>
        <h1>Help component</h1>
    </div>
);


export default HelpPage;