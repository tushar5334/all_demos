import React from 'react';

const ExpenseHomePageComponent = () => (
    <div>
        <h1>Dashboard component</h1>
    </div>
);

export default ExpenseHomePageComponent;