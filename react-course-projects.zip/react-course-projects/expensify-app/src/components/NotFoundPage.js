import React from 'react';

const NotFoundPage = () => (
    <div>
        <h1>Page Not Found component</h1>
        <Link to="/">Go Home</Link>
    </div>
);

export default NotFoundPage;