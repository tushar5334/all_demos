import React from 'react';

const AddExpensePageComponent = () => (
    <div>
        <h1>About Us component</h1>
    </div>
);

export default AddExpensePageComponent;