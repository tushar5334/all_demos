import React from 'react';
import {
    Link,
    NavLink
  } from "react-router-dom";
const Header = () => (
    <header>
        <h1>Portfolio Site</h1>
        <NavLink to="/"  activeClassName="is-active" exact={true}>Home</NavLink>&nbsp;
        <NavLink to="/portfolio" activeClassName="is-active" exact={true}>Portfolio</NavLink>&nbsp;
        <NavLink to="/contact-us" activeClassName="is-active" >Conatct Us</NavLink>&nbsp;
    </header>
);

export default Header;