import React from 'react';

const ContactusPageComponent  = () => (
    <div>
        <h1>Contactus component</h1>
        <p>Email:tushar5334@gmail.com</p>
    </div>
);

export default ContactusPageComponent;