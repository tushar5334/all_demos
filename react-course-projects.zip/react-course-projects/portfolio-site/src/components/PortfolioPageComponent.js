import React from 'react';
import { Link } from 'react-router-dom';

const PortfolioPageComponent = () => (
    <div>
        <h1>Portfolio List Page</h1>
        <Link to="/portfolio/1">Portfolio Iteam 1</Link>&nbsp;
        <Link to="/portfolio/2">Portfolio Iteam 2</Link>
    </div>
);


export default PortfolioPageComponent;