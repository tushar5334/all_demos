import React from 'react';

const ExpenseHomePageComponent = () => (
    <div>
        <h1>Dashboard component</h1>
        <p>This is my site! Take around</p>
    </div>
);

export default ExpenseHomePageComponent;