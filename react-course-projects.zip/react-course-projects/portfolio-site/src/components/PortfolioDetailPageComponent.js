import React from 'react';

const PortfolioDetailPageComponent = (props) => (
    <div>
        <h1>Portfolio Detail Page</h1>
        <p>Selected Iteam is {props.match.params.id}</p>
    </div>
);

export default PortfolioDetailPageComponent;