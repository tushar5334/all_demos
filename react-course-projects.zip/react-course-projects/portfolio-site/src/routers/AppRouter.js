import React from 'react';
import {
    BrowserRouter as Router,
    Route,
    Switch
  } from "react-router-dom";

import HomePageComponent from '../components/HomePageComponent';
import Header from './../components/Header';
import ContactusPageComponent from './../components/ContactusPageComponent';
import PortfolioPageComponent from './../components/PortfolioPageComponent';
import PortfolioDetailPageComponent from './../components/PortfolioDetailPageComponent';
import NotFoundPage from './../components/NotFoundPage';
const AppRouter = ()=>(
<Router>
    <div>
        <Header />
        <Switch>
            <Route path="/" component={HomePageComponent} exact={true} />
            <Route path="/contact-us" component={ContactusPageComponent} />
            <Route path="/portfolio" component={PortfolioPageComponent} exact={true} />
            <Route path="/portfolio/:id" component={PortfolioDetailPageComponent} />
            <Route component={NotFoundPage} />
        </Switch>
    </div>
</Router>
);

export default AppRouter;