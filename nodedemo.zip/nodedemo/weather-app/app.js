const request = require('request')
const geoCode = require('./utils/geocode')
const forCast = require('./utils/forcast')
//const url = 'https://api.darksky.net/forecast/a507e0c058efe28c03eb3fd543579aca/37.8267,-122.4233'

//request({url:url},(error, response)=>{
    //console.log(response.body);
/*    if(error){
    	console.log('Unable to connect network!');
    } else if(response.body.error){
    	console.log('Unable to connect given location!');
    } else {
    	//const data = JSON.parse(response.body)
    	//console.log(data.currently);
    }
*/
//})

//request({url:url,json:true},(error, response)=>{
	/*if(error){
    	console.log('Unable to connect network!');
    } else if(response.body.error){
    	console.log('Unable to connect given location!');
    } else {
	    //console.log("It is curently "+response.body.currently.temperature+" degree out.There is a "+response.body.currently.precipProbability+" chance.");
	    //debugger
    }*/
//})

//const geoLocationUrl = 'https://api.mapbox.com/geocoding/v5/mapbox.places/Los%20Angeles.json?access_token=pk.eyJ1IjoidHVzaGFyMTk4NyIsImEiOiJjazM1cTcxMXYwM3hhM21xcTZ0ZjYxdXcxIn0.ni844PcD_6F3R9TXFWo23Q&limit=1'
/*request({url:geoLocationUrl, json:true}, (error, response)=>{
	if(error){
		console.log('Unable to connect network!');
	} else if(response.body.features.length === 0){
		console.log('Unable to connect given location!');
	} else {
		//console.log(response.body.features[0].center);
		const latitude = response.body.features[0].center[1];
		const longitude = response.body.features[0].center[0];
	}
})*/



/*geoCode('bodakdev', (error, result)=>{
	console.log('Error :',error);
	console.log('Data :',result);
})*/

/*forCast('23.037121','72.515941',(error, response)=>{

	console.log('Error :',error)
	console.log('Data :',response)

})*/

console.log(process.argv)

const addressStr = process.argv[2];

/*if(!addressStr){
	console.log('please provide address as a search string')
} else {
	geoCode(addressStr, (error, result)=>{
		//console.log('Error :',error)
		//console.log('Data :',result)
		if(error){
			return console.log(error)
		}

		forCast(result.latitude,result.longitude,(error, response)=>{
			//console.log('Error :',error)
			//console.log('Data :',response)
			if(error){
				return console.log(error);
			}

			console.log(result.location)
			console.log(response)

		})
	})
}*/


if(!addressStr){
	console.log('please provide address as a search string')
} else {
	geoCode(addressStr, (error, {latitude, longitude, location})=>{
		/*console.log('Error :',error)
		console.log('Data :',result)*/
		if(error){
			return console.log(error)
		}

		forCast(latitude,longitude,(error, response)=>{
			/*console.log('Error :',error)
			console.log('Data :',response)*/
			if(error){
				return console.log(error);
			}

			console.log(location)
			console.log(response)

		})
	})
}