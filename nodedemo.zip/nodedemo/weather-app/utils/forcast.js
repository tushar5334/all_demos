const request = require('request')

/*const forCast = (latitude, longitude, callbackfunc)=>{

	const weatherApiUrl = 'https://api.darksky.net/forecast/a507e0c058efe28c03eb3fd543579aca/'+latitude+','+longitude
		request({url:weatherApiUrl, json:true},(error, data)=>{
			if(error){
				callbackfunc('Unable to connect network!', undefined);
			} else if(data.body.error){
				callbackfunc('Unable to connect given location!', undefined);
			} else {
				callbackfunc(undefined, "It is curently "+data.body.currently.temperature+" degree out.There is a "+data.body.currently.precipProbability+" chance.");
			}
		})
}*/

const forCast = (latitude, longitude, callbackfunc)=>{

	const url = 'https://api.darksky.net/forecast/a507e0c058efe28c03eb3fd543579aca/'+latitude+','+longitude
		request({url, json:true},(error, {body})=>{
			if(error){
				callbackfunc('Unable to connect network!', undefined);
			} else if(body.error){
				callbackfunc('Unable to connect given location!', undefined);
			} else {
				callbackfunc(undefined, "It is curently "+body.currently.temperature+" degree out.There is a "+body.currently.precipProbability+" chance.");
			}
		})
}

module.exports = forCast