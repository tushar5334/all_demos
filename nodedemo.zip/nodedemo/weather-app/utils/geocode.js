const request = require('request')

/*const geoCode = (address, callbackfunc)=>{

	const geoLocationUrl = 'https://api.mapbox.com/geocoding/v5/mapbox.places/'+encodeURIComponent(address)+'.json?access_token=pk.eyJ1IjoidHVzaGFyMTk4NyIsImEiOiJjazM1cTcxMXYwM3hhM21xcTZ0ZjYxdXcxIn0.ni844PcD_6F3R9TXFWo23Q&limit=1'
		request({url:geoLocationUrl, json:true}, (error, data)=>{
			if(error) {
				callbackfunc('Unable to connect network!', undefined);
			} else if(data.body.features.length === 0) {
				callbackfunc('Unable to connect given location!', undefined);
			} else {
				callbackfunc(undefined, {
					latitude:data.body.features[0].center[1],
					longitude:data.body.features[0].center[0],
					location:data.body.features[0].place_name
					});
			}
		})
}*/

const geoCode = (address, callbackfunc)=>{

	const url = 'https://api.mapbox.com/geocoding/v5/mapbox.places/'+encodeURIComponent(address)+'.json?access_token=pk.eyJ1IjoidHVzaGFyMTk4NyIsImEiOiJjazM1cTcxMXYwM3hhM21xcTZ0ZjYxdXcxIn0.ni844PcD_6F3R9TXFWo23Q&limit=1'
		request({url, json:true}, (error, {body})=>{
			if(error) {
				callbackfunc('Unable to connect network!', undefined);
			} else if(body.features.length === 0) {
				callbackfunc('Unable to connect given location!', undefined);
			} else {
				callbackfunc(undefined, {
					latitude:body.features[0].center[1],
					longitude:body.features[0].center[0],
					location:body.features[0].place_name
					});
			}
		})
}

module.exports = geoCode