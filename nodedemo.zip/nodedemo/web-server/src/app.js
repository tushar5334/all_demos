const path = require('path')
const express = require('express')

const app = express()

/*app.get('',(req,res)=>{
	res.send('wel come to express!')
})

app.get('/about',(req, res)=>{
	res.send('About us page')
})

app.get('/help',(req, res)=>{
	res.send('Help page')
})

app.get('/weather',(req, res)=>{
	res.send('Weather page')
})*/

//console.log('__dirname',__dirname)
//console.log('__filename',__filename)

//console.log(path.join(__dirname,'../public'))

const staticDirPath = path.join(__dirname,'../public')
console.log('staticDirPath',staticDirPath)
app.use(express.static(staticDirPath))

/*app.get('',(req,res)=>{
	res.send('<h1>wel come to express!</h1>')
})

app.get('/about',(req, res)=>{
	res.send([{
		name:"Tushar"
	},
	{
		name:"Dhaval"
	}
	])
})

app.get('/help',(req, res)=>{
	res.send('<h1>Help page</h1>')
})

app.get('/weather',(req, res)=>{
	res.send([{
		forecast:"It is raining"
	},
	{
		location:"India"
	}
	])
})*/

app.listen(3000,()=>{
	console.log('Server is listining at port:3000')
})