require('../src/db/mongoose')
User = require('../src/models/user')
Task = require('../src/models/task')

//5e05ea94da116f4f93f1ca0d
//5e09bac5dd3b753386fc2c3b
/*User.findByIdAndUpdate('5e09bac5dd3b753386fc2c3b',{age : 20})
.then((user)=>{
	console.log(user)
	return User.countDocuments({age:20})
})
.then((userCount)=>{
	console.log(userCount)
})
.catch((e)=>{
	console.log(e)
})*/


/*Task.findByIdAndDelete('5e0ad1a9fe262a1611c13e2b')
.then((result)=>{
	return Task.countDocuments({completed:false})
})
.then((taskCount)=>{
	console.log(taskCount)
})
.catch((e)=>{
	console.log(e)
})*/

/*const UpdateAgeAndCount = async (id, age)=>{
	const user = await User.findByIdAndUpdate(id,{age:age})
	const count = await User.countDocuments({age:age})
	return {user:user, count:count}
}

UpdateAgeAndCount('5e05ea94da116f4f93f1ca0d', 30)
.then((result)=>{
	console.log(result)
})
.catch((e)=>{
	console.log(e)
})*/

const deleteTaskAndCount = async (id, completed)=>{
	const task = await Task.findByIdAndDelete(id)
	const count = await Task.countDocuments({completed})
	return {task, count}
}

deleteTaskAndCount('5e0b38d1cd0c193ba577bdc5',false)
.then((result)=>{
	console.log(result)
})
.catch((e)=>{
	console.log(e)
})