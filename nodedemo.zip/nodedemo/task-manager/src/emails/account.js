const sgMail = require('@sendgrid/mail')
//const sendgridAPIKey = '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'
sgMail.setApiKey(process.env.SENDGRID_API_KEY)
/*sgMail.send({
	to:'tushar5334@gmail.com',
	from:'tushar5334@gmail.com',
	subject:'This is my sample mail demo',
	text:'This is nodejs test email'
	//html:'<h1>This is nodejs test email</h1>',
})*/

const sendWelcomeEmail = (email, name) => {
	console.log('sendWelcomeEmail')
		sgMail.send({
			to:'tushar5334@gmail.com',
			from:'tushar5334@gmail.com',
			subject:'Thanks for joining us!',
			text:`welcome to the app,${name}. Let me know how you along with the app`
			//html:'<h1>This is nodejs test email</h1>',
		})
}


const sendCancelationEmail = (email, name) => {
		console.log('sendCancelationEmail')
		sgMail.send({
			to:'tushar5334@gmail.com',
			from:'tushar5334@gmail.com',
			subject:'Sorry to see you go!',
			text:`Goodbye,${name}. I hope to see you back sometime soon.`
			//html:'<h1>This is nodejs test email</h1>',
		})
}


module.exports = {
	sendWelcomeEmail,
	sendCancelationEmail

}