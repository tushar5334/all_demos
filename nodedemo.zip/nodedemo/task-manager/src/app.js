const express = require('express')
require('./db/mongoose')
//Routes
const userRoutes = require('./routers/user-routes')
const taskRoutes = require('./routers/task-routes')

const app = express()
app.use(express.json())

//Register Routes
/*app.use(userRoutes)
app.use(taskRoutes)*/

app.use([userRoutes,taskRoutes])

module.exports = app