const path = require('path')
const express = require('express')
const hbs = require('hbs')

const app = express()

//define path for express config
const viewsPath = path.join(__dirname, '../templates')
const publicDirectoryPath = path.join(__dirname,'../public')


//setup handlebars engine and view location
app.set('view engine', 'hbs')
app.set('views', viewsPath)

//setup static directory to serve
app.use(express.static(publicDirectoryPath))

app.get('',(req, res)=>{
	res.render('index',{'title':'Its great!','name':'Tushar Patil'})
})

app.get('/about',(req, res)=>{
	res.render('about',{title:'About Me',name:'Tushar Patil'})
})

app.get('/help',(req, res)=>{
	res.render('help',{title:'Test Help Text!'})
})


app.listen(3000,()=>{
	console.log('Server is listining at port:3000')
})