const path = require('path')
const express = require('express')
const hbs = require('hbs')
const geoCode = require('./utils/geocode')
const forCast = require('./utils/forcast')

const app = express()

//define path for express config
const viewsPath = path.join(__dirname, '../templates/views')
const partialsPath = path.join(__dirname, '../templates/partials')
const publicDirectoryPath = path.join(__dirname,'../public')

//setup handlebars engine and view location
app.set('view engine', 'hbs')
app.set('views', viewsPath)
hbs.registerPartials(partialsPath)

//setup static directory to serve
app.use(express.static(publicDirectoryPath))

app.get('',(req, res)=>{
	res.render('index',{'title':'Its great!','name':'Tushar Patil'})
})

app.get('/about',(req, res)=>{
	res.render('about',{title:'About Me',name:'Tushar Patil'})
})

app.get('/help',(req, res)=>{
	res.render('help',{title:'Test Help Text!', name:''})
})

app.get('/help/*',(req, res)=>{
	res.render('page-not-found', {title:'Help artical not found'})
})

app.get('/product',(req, res)=>{
	//res.render('help',{title:'Test Help Text!', name:''})
	//console.log(req.query)
	if(!req.query.search){
		return res.send({error:'search parameter is missing'})
	}


	//console.log(req.query.search)

	res.send({product:[]})
})


app.get('/weather',(req, res)=>{
	if(!req.query.address){
		return res.send({error:'address parameter is missing'})
	}

	//console.log(req.query.search)
	geoCode(req.query.address, (error, {latitude, longitude, location}={})=>{
		if(error){
			return res.send({error})
		}
		forCast(latitude, longitude, (error, data)=>{

			if(error){
				return res.send({error})
			}

			res.send({forecast:data,location,address:req.query.address})
		})

	})

})

app.get('*',(req, res)=>{
	res.render('page-not-found', {title:'Page not found'})
})

app.listen(3000,()=>{
	console.log('Server is listining at port:3000')
})