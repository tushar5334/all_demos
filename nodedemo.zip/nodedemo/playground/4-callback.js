const add =(args1, args2, callbackfunc)=>{
    setTimeout(()=>{
        const result =  args1+args2
        callbackfunc(result)
    },2000)

}

const sum = (sum)=>{
	console.log('Sum: ',sum)
}

/*add(1, 2, (sum)=>{
    console.log(sum)
})*/

add(1, 3, sum)








const bcrypt = require('bcryptjs')

const password = 'Tushar1987'

const myHashPassword = async (password)=>{

	const hashPassword = await bcrypt.hash(password, 8)
	console.log(hashPassword)

	const isPasswordMatch = await bcrypt.compare('tushar1987', hashPassword)
	console.log(isPasswordMatch)
}

myHashPassword(password)


/*const myHashPassword1 = (password)=>{
	bcrypt.hash(password, 8)
}

myHashPassword1(password)
.then((result)=>{
	console.log('Then Res:', result)
})
.catch((e)=>{
		console.log('Catch error:', e)
})*/

/*const myHashPassword2 = (password, callback)=>{
	bcrypt.hash(password, 8, function(err, hash) {
		callback(hash);
	})
}

myHashPassword2(password,function(hash) {
		console.log(hash);
})*/