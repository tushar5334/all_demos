const name='Tom Jerry'
const age=12
const gender='Male'

const userInfo = {
	name:name,
	userAge:age,
	userGender:gender,
}

/*console.log(userInfo)*/

const userInfoModified = {
	name,
	userAge:age,
	userGender:gender,
}

/*console.log(userInfoModified)*/


const productInfo = {
	productName:'Sony Z2',
	productSku:'sz2',
	productImage:'test.jpg',
}

const {productName, productSku, productDescription='Test Description',productImage} = productInfo

/*console.log(productName)
console.log(productSku)
console.log(productDescription)
console.log(productImage)*/


const productInfoCopy = {
	productNameCP:'Sony Z2',
	productSkuCP:'sz2',
	productImageCP:'test.jpg',
	productDescriptionCP:'Hello...'
}

const {productNameCP, productSkuCP, productDescriptionCP='Test Description',productImageCP} = productInfoCopy

/*console.log(productNameCP)
console.log(productSkuCP)
console.log(productDescriptionCP)
console.log(productImageCP)*/



const transaction=(type,{productNameCP,productImageCP,productDescriptionCP='Test Description'})=>{
	console.log(type)
	console.log(productNameCP)
	console.log(productImageCP)
	console.log(productDescriptionCP)
}

transaction('order',productInfoCopy)


const transactionCP=(type,productObj)=>{
	console.log(type)
	console.log(productObj)
}

transactionCP('order',productInfoCopy)