const doWorkCallBack=(callback)=>{
	setTimeout(()=>{
		callback('error',undefined)
		//callback(undefined,[1,2])
	}, 2000)
}

doWorkCallBack((error, result)=>{
    if(error){
    	return console.log(error);
    }
    return console.log(result);
})


const doWorkPromise = new Promise((resolve, reject)=>{
	setTimeout(()=>{
		//resolve([3,4])
		reject('Error in promise')
	},2000)
})

doWorkPromise.then((result)=>{
	console.log(result)
}).catch((error)=>{
	console.log(error)
})