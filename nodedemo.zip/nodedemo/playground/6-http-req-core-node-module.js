const https = require('https')

const url='https://api.darksky.net/forecast/a507e0c058efe28c03eb3fd543579aca/40,-75'

const req = https.request(url, (res) => {
	let data = ''
	res.on('data', (chunk) => {
		data = data+chunk.toString()
		//console.log(data)
  	});

  	res.on('end', () => {
  		const body = JSON.parse(data)
  		console.log(body)
  	});
});

req.on('error',(error)=>{
	console.log('Error::', error)
})

req.end()