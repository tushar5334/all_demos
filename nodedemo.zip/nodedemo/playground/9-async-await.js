
/*const add = (a, b)=>{
	return new Promise((resolve, reject)=>{
		setTimeout(()=>{
			resolve(a + b)
		},2000)
	})
}

add(1,1)
.then((sum)=>{
	console.log(sum)
	return add(sum, 2)
})
.then((sum2)=>{
	console.log(sum2)
})
.catch((e)=>{
	console.log(e)
})*/

const add = (a, b)=>{
	return new Promise((resolve, reject)=>{
		setTimeout(()=>{
			if(a < 0 || b < 0){
				return reject('agruments should not be nagative')
			}
			resolve(a + b)
		},2000)
	})
}

/*const doWork = async () =>{
	throw new Error('Something went wrong')
	return 'Tushar'
}*/

const doWork = async () =>{
	const sum = await add(1, 99)
	//const sum2 = await add(sum, -1)
	const sum2 = await add(sum, 1)
	const sum3 = await add (sum2, 1)
	return sum3
}

doWork()
.then((res)=>{
	console.log('res', res)
})
.catch((e)=>{
	console.log('e', e)
})
