const path = require('path')
const http = require('http')
const express = require('express')
const socketio = require('socket.io')
const Filter = require('bad-words')

const {generateMessages, generateLocationMessages} = require('./utils/messages')

const { addUser,removeUser, getUser, getUsersInRoom } = require('./utils/users')

const app = express()
const server = http.createServer(app)
const io = socketio(server)


const port = process.env.PORT || 3000

const publicDirectoryPath = path.join(__dirname, '../public')

app.use(express.static(publicDirectoryPath))

io.on('connection', (socket)=>{

	socket.emit('message', generateMessages('Admin','Welcome!'))
	//socket.broadcast.emit('message', generateMessages('New user joined!'))

	socket.on('join', ({username, room}, callback) => {

		const {error, user} = addUser({id: socket.id, username, room})

		if(error) {
			return callback(error)
		}

		socket.join(user.room)
		socket.broadcast.to(user.room).emit('message', generateMessages('Admin',`${user.username} has joined ${user.room} room`))

		io.to(user.room).emit('roomData', {
			room: user.room,
			users: getUsersInRoom(user.room)
		})
		callback()
	})

	socket.on('sendMessage', (message, callback)=>{
		const user = getUser(socket.id)
		const filter = new Filter()
		if (filter.isProfane(message)) {
			return callback('Profinity is not allowed!')
		}

		io.to(user.room).emit('message', generateMessages(user.username, message))
		callback('The message is delivered successfully!')
	})

	socket.on('sendLocation', (position, callback)=>{
		const user = getUser(socket.id)
		//io.emit('message',`Location :${position.latitude} and ${position.longitude}`)
		io.to(user.room).emit('send-location-message',generateLocationMessages(user.username, `https://google.com/maps?q=${position.latitude},${position.longitude}`))

		callback('Location shared successfully!')
	})

	socket.on('disconnect', ()=>{
		const user = removeUser(socket.id)
		if (user) {
			io.to(user.room).emit('message', generateMessages('Admin', `A ${user.username} has left!`))
			io.to(user.room).emit('roomData', {
				room: user.room,
				users: getUsersInRoom(user.room)
			})
		}
	})

})

/*let count = 0
io.on('connection', (socket)=>{
	console.log('New websocket connection')

	socket.emit('countUpdated', count)

	socket.on('increment', ()=>{
		count++
		//socket.emit('countUpdated', count) //it does connection to single client
		io.emit('countUpdated', count) //it does connection to multiple clients
	})
})*/

server.listen(port, ()=>{
	console.log(`Server is up on port ${port}!`)
})

/*const path = require('path')
const express = require('express')

const app = express()

const port = process.env.PORT || 3000

const publicDirectoryPath = path.join(__dirname, '../public')

app.use(express.static(publicDirectoryPath))

app.listen(port, ()=>{
	console.log(`Server is up on port ${port}!`)
})*/
