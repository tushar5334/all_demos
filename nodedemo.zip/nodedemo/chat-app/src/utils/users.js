const users = []

const addUser = ({id, username, room})=>{
    //clean the data
    username = username.trim().toLowerCase()
    room = room.trim().toLowerCase()

    // validate data
    if(!username || !room) {
        return {
            error: 'Username and room are required!'
        }
    }

    // checkfor existing user
    const existingUser = users.find((user)=>{
        return user.room === room && user.username === username
    })

    if (existingUser) {

        return {
            error:'User is in use!'
        }
    }

    // store user

    const user = { id, username, room }

    users.push(user)

    return { user }
}

const removeUser = (id)=>{
    const index = users.findIndex((user) => user.id === id)

    if(index !== -1) {
        return users.splice(index, 1)[0]
    }
}

const getUser = (id) =>{
    return users.find((user) => user.id === id)
}

const getUsersInRoom = (room) => {
    room = room.trim().toLowerCase()
    return users.filter((user)=>
        user.room === room )
}

module.exports = {
    addUser,
    removeUser,
    getUser,
    getUsersInRoom
}
/* addUser({
        id:'22',
        username:'Tushar Patil',
        room:'Chatroom'
        })
addUser({
    id: '23',
    username: 'Dhaval Patil',
    room: 'Chatroom'
})

addUser({
    id: '24',
    username: 'Maanarth Patil',
    room: 'Chatroom2'
})

console.log(users) */

/* const res = addUser({
    id: '33',
    username: '',
    room: ''
})

console.log(res)*/

//const removedUser = removeUser('22')

//console.log(removedUser)
//console.log(users)

/* const user = getUser('22')
console.log('getUser', user) */

//const userList = getUsersInRoom('Chatroom')
//console.log('getUsersInRoom', userList)

