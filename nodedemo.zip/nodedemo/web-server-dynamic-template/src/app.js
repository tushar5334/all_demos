const path = require('path')
const express = require('express')
const hbs = require('hbs')
const app = express()

const staticDirPath = path.join(__dirname,'../public')
app.set('view engine', 'hbs')

app.use(express.static(staticDirPath))

app.get('',(req, res)=>{
	res.render('index',{'title':'Its great!','name':'Tushar Patil'})
})

app.get('/about',(req, res)=>{
	res.render('about',{title:'About Me',name:'Tushar Patil'})
})

app.get('/help',(req, res)=>{
	res.render('help',{title:'Test Help Text!'})
})


app.listen(3000,()=>{
	console.log('Server is listining at port:3000')
})