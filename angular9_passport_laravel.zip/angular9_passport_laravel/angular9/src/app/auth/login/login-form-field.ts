export class LoginFormField {

    constructor(
        public email: string = "",
        public password: string = "",
        //public alterEgo?: string
    ) { }

}
