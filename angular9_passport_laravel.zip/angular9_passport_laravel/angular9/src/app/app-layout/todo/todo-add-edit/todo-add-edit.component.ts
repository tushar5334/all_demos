import { Component, OnInit, OnDestroy } from '@angular/core';
import { AbstractControlOptions, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { TodoService } from '../todo.service';
@Component({
  selector: 'app-todo-add-edit',
  templateUrl: './todo-add-edit.component.html',
  styleUrls: ['./todo-add-edit.component.css']
})
export class TodoAddEditComponent implements OnInit, OnDestroy {
  submitted=false;
  isEdit = false;
  private todo_id:string="";
  serverErrors:any={};
  todoAddEditFrm : FormGroup;
  constructor(
    private _formBuilder: FormBuilder, 
    private _router: Router, 
    private _activatedRoute: ActivatedRoute,
    private _todoService: TodoService
    ) { }

  ngOnInit(): void {
    this.todoAddEditFrm = this._formBuilder.group(
      {
        todo_title: ['', Validators.required],
        todo_description: ['', Validators.required],
      }
    );
    
    this._activatedRoute.paramMap.subscribe((paramMap:ParamMap)=>{
      if (paramMap.has('todo_id')) {
        this.isEdit = true;
        this.todo_id = paramMap.get('todo_id');
        this._todoService.getTodoById(this.todo_id)
          .subscribe((result:any) => {
            this.todoAddEditFrm.patchValue(result.data)
          });
      }
    });
    // if (!this.isAdd) {
    //   this.todoAddEditFrm.patchValue({
    //     todo_title:'tushar'
    //   })
    // }


  }

  get todoAddEditFrmControl() {
    return this.todoAddEditFrm.controls;
  }
  onTodoSave() {
    this.submitted = true;
    this.serverErrors=[];
    if (this.todoAddEditFrm.invalid) {
      return;
    }

    if (this.isEdit) {
      this._todoService.updateTodo(this.todo_id, this.todoAddEditFrm.value)
        .subscribe((responseData) => {
          this.submitted = false;
          this._router.navigate(['/todo']);
        },
          error => {
            this.submitted = false;
            this.serverErrors = error.error.errors;
            console.log('server error', this.serverErrors);
          });
    } else {
        this._todoService.addTodo(this.todoAddEditFrm.value)
        .subscribe((responseData) => {
          this.submitted = false;
          this._router.navigate(['/todo']);
        },
        error => {
          this.submitted = false;
          this.serverErrors = error.error.errors;
          console.log('server error', this.serverErrors);
        });
    }
    

  }

  onReset() {
    this.submitted = false;
    this.todoAddEditFrm.reset();
  }

  ngOnDestroy() {

  }
}
