import { Component, OnInit } from '@angular/core';
import { AbstractControlOptions, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MustMatch } from 'src/app/_helpers/must-match.validator';
@Component({
  selector: 'app-todo-add-edit',
  templateUrl: './todo-add-edit.component.html',
  styleUrls: ['./todo-add-edit.component.css']
})
export class TodoAddEditComponent implements OnInit {
  submitted=false;
  isAdd = false;
  todoAddEditFrm : FormGroup;
  constructor(private _formBuilder:FormBuilder) { }

  ngOnInit(): void {
    this.todoAddEditFrm = this._formBuilder.group(
      {
        todo_title: ['', Validators.required],
        email: ['', Validators.compose([Validators.required, Validators.email])],
        phone: ['', Validators.compose([Validators.required, Validators.maxLength(10), Validators.pattern('^[0-9]+$')])],
        password: ['', Validators.compose([this.isAdd ? Validators.required : Validators.nullValidator, Validators.minLength(5)])],
        confirm_password: ['', this.isAdd ? Validators.required : Validators.nullValidator],
        accept_terms: [false, Validators.requiredTrue],
      },
      {
        validator: MustMatch('password', 'confirm_password')
      }
    );
    
    if (!this.isAdd) {
      this.todoAddEditFrm.patchValue({
        todo_title:'tushar',
        email: 'tushar@test.com',
        phone: '9913093603',
        password: '',
        confirm_password: '',
        accept_terms:true
      })
    }


  }

  get todoAddEditFrmControl() {
    return this.todoAddEditFrm.controls;
  }
  onTodoSave() {
    this.submitted = true;
    if (this.todoAddEditFrm.invalid) {
      return;
    }
    alert(JSON.stringify(this.todoAddEditFrm.value));
  }

  onReset() {
    this.submitted = false;
    this.todoAddEditFrm.reset();
  }
}
