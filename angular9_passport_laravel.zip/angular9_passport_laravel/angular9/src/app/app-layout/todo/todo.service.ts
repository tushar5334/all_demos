import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Todo } from './Todo.Model';
import { Router } from '@angular/router';
import { environment } from '../../../environments/environment';

const BACKEND_URL = environment.apiUrl + "/todo";
@Injectable()
export class TodoService {

  constructor(private http: HttpClient, private router: Router) { }

  getTodos() {
    return this.http.get<{ message: string, data: any}>(BACKEND_URL);
  }

  addTodo(formData:object) {
    return this.http.post<{ message: string, data: Todo }>(BACKEND_URL, formData);
  }

  getTodoById(todo_id:string) {
    return this.http.get<{ message: string, data: Todo }>(BACKEND_URL + '/' + todo_id);
  }

  updateTodo(todo_id: string, formData: object) {
    return this.http.put<{ message: string }>(BACKEND_URL + "/" + todo_id, formData);
  }

  deleteTodo(todo_id: string) {
    return this.http.delete<{ message: string }>(BACKEND_URL + "/" + todo_id);
  }
  
}
