import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TodoListComponent } from './todo-list/todo-list.component';
import { TodoAddEditComponent } from './todo-add-edit/todo-add-edit.component';

const routes: Routes = [
  { path: '', component: TodoListComponent },
  { path: 'add', component: TodoAddEditComponent },
  { path: 'add/:todo_id', component: TodoAddEditComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TodoRoutingModule { }
