export interface Todo {
    todo_id: string;
    todo_title: string;
}