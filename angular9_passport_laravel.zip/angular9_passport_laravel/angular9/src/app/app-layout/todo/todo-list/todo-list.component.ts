import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { Todo } from '../Todo.Model';
import { TodoService } from '../todo.service';
@Component({
  selector: 'app-todo-list',
  templateUrl: './todo-list.component.html',
  styleUrls: ['./todo-list.component.css']
})
export class TodoListComponent implements OnInit, OnDestroy {

  todos: Todo[] = [];
  totalPosts = 10;
  postsPerPage = 2;
  pageSizeOptions = [2, 5, 10, 25];
  currentPage = 1;
  private todosSub: Subscription;
  constructor(public todoService: TodoService) { }

  ngOnInit(): void {
    this.getTodos();
  }

  getTodos() {
    this.todosSub = this.todoService.getTodos().subscribe((todoData) => {
      this.todos = todoData.data;
    });
  }



  deleteTodo(todo_id:string) {
    if (confirm("Are you sure to delete this todo?")) {
      this.todoService.deleteTodo(todo_id).subscribe((response) => {
        this.getTodos();
      });
    }
  }
  ngOnDestroy() {
    this.todosSub.unsubscribe();
  }

}


