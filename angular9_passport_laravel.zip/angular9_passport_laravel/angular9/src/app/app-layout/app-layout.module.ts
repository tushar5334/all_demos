import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppLayoutRoutingModule } from './app-layout-routing.module';
import { AppLayoutComponent } from './app-layout.component';
import { HeaderComponent } from './common/header/header.component';
import { FooterComponent } from './common/footer/footer.component';
import { TodoService } from './todo/todo.service';
@NgModule({
  declarations: [AppLayoutComponent, HeaderComponent, FooterComponent],
  imports: [
    CommonModule,
    AppLayoutRoutingModule
  ],
  providers:[TodoService]
})
export class AppLayoutModule { }
