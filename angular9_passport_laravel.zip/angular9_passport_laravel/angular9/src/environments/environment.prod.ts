export const environment = {
  production: true,
  apiUrl: "http://localhost:4040/api"
};
