<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Todo;
class TodoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $todos = Todo::latest()->get();
        return response()->json([
                'data'=>$todos,
                'message' => 'Todo list fetched successfully!'
            ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $inputData = $request->all();

        $rules = [
            'todo_title'=>'required|string|max:255|unique:todos',
            'todo_description'=>'required',
        ];

        $messages = [
            'todo_title.required'=>'Todo fileld is required',
            'todo_title.unique'=>'Todo is already exists',
            'todo_description'=>'required',
        ];

        $this->validate($request, $rules, $messages);
        $todo = Todo::insertOrUpdate('', $inputData);
        return response()->json([
            'data'=>$todo,         
            'message' => 'Todo inserted successfully!'
        ], 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $todo_id
     * @return \Illuminate\Http\Response
     */
    public function show($todo_id)
    {
        $todo = Todo::findOrFail($todo_id);
        if($todo) {
            return response()->json([
                'data'=>$todo,         
                'message' => 'Todo fetched successfully!'
            ]);
        }
        return response()->json([
            'message' => 'Not Authorized!'
        ], 401);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $todo_id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $todo_id)
    {
        $inputData = $request->all();

        $rules = [
            'todo_title'=>'required|string|max:255|unique:todos,todo_title,'. $todo_id.',todo_id,deleted_at,NULL',
            'todo_description'=>'required',
        ];

        $messages = [
            'todo_title.required'=>'Todo fileld is required',
            'todo_title.unique'=>'Todo is already exists',
            'todo_description'=>'required',
        ];

        $this->validate($request, $rules, $messages);
        $todo = Todo::insertOrUpdate($todo_id, $inputData);
        return response()->json([        
            'message' => 'Todo updated successfully!'
        ], 201);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $todo_id
     * @return \Illuminate\Http\Response
     */
    public function destroy($todo_id)
    {
        if($todo_id) {
            $todo = Todo::findOrFail($todo_id);
            //delete todo
            $todo->delete();
            return response()->json([        
                'message' => 'Todo deleted successfully!'
            ]);
        }

        return response()->json([        
            'message' => 'Not Authorized!'
        ], 401);
    }
}
