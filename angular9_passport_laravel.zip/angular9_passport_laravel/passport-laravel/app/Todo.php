<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;
class Todo extends Model
{
    use SoftDeletes;
    protected $primaryKey = 'todo_id';
    public $incrementing = false;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'todo_title',
        'todo_description'
    ];

    protected static function boot()
    {
        parent::boot();

        Todo::creating(function ($model) {
            $model->setTodoId();
        });
    }

    public function setTodoId()
    {
        $this->attributes['todo_id'] = Str::uuid();
    }

    public static function insertOrUpdate($todo_id="", $inputData) {

	    $todo = Todo::updateOrCreate(
	        ['todo_id' => $todo_id],
	        $inputData
	    );

	    return $todo;
    }
}
