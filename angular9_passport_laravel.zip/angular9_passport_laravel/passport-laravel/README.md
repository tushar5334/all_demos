Personal access client created successfully.
Client ID: 93c38576-3809-4044-9eb4-7de0e1edc119
Client secret: wi3KBNVDBnmIYl1e1XN6iyqn6lpmrAXFyZl0ZSfG
Password grant client created successfully.
Client ID: 93c38576-5685-4dd8-9120-360b30f62fd7
Client secret: EgfcgXUDfH6g1BRShCddhL8SETgpJv4dsVOQGZjQ