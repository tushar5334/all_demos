<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="theme-color" content="#031C2B" />

        <title>TxLabs.co | Services</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="/css/front/front.css">
        <!-- Styles -->
        
    </head>
    <body>
        <header class="header inner-header">
            @include('common.header')
        </header>
        
        <section class="inner-body">
            <div class="page-title">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <h2><span>oUR</span> SERVICES</h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container services-main">
                <div class="row">
                    <div class="col-12 services-details-top">
                        <h4>PROVEN PROCESS. TALENTED PEOPLE. DELIVERING RESULTS.</h4>
                        <p>Our experience encompasses a variety of skillsets, delivered rapidly with agile methodology for maximum business impact.</p>
                        <div class="space10"></div>
                    </div>
                    <div class="col-md-6 col-lg-4 services">
                        <h4>
                            <span><img src="/images/icons/service1.svg" alt=""></span>
                            Bespoke SOFTWARE Development
                        </h4>
                        <p class="expandable">We develop software applications specifically for your custom requirements, understanding the limitations of "off the shelf" solutions
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                            <a class="expand-btn" href="#">Read more...</a>
                        </p>
                        <div class="tags expandable">More: 
                            <a href="">ExitReadinessReview, </a>
                            <a href="">MarketSoundings, </a>
                            <a href="">thePitch FactoryTM, </a>
                            <a href="">ProspectusBuilderTM </a>
                            <a href="">DealStructureStep-plan, </a>
                            <a href="">LegalDueDiligence, </a>
                            <a href="">Advisors, </a>
                            <a href="">FinancialDueDiligence, </a>
                            <a href="">CommercialDueDiligence, </a>
                            <a class="expand-btn" href="#">Read more...</a>
                        </div>
                        <a class="read-btn" href="/bespoke-software-development">Read More <img src="/images/icons/feather-arrow-right.svg" alt=""></a>
                    </div>
                    <div class="col-md-6 col-lg-4 services">
                        <h4>
                            <span><img src="/images/icons/service2.svg" alt=""></span>
                            APIs & SYSTEM <br> INTEGRATION
                        </h4>
                        <p>Application Programme Interfaces (APIs) offer a powerful set of tools to accelerate data exchange, improve inter-firm integration...</p>
                        <div class="tags">More: 
                            <a href="">web services, </a>
                            <a href="">erp integration, </a>
                            <a href="">OEM integration, </a>
                            <a href="">Apayment integration, </a>
                            <a href="">payment integration</a>
                        </div>
                        <a class="read-btn" href="/api-and-system-integration">Read More <img src="/images/icons/feather-arrow-right.svg" alt=""></a>
                    </div>
                    <div class="col-md-6 col-lg-4 services">
                        <h4>
                            <span><img src="/images/icons/service3.svg" alt=""></span>
                            Design, Wireframes & Rapid Prototyping
                        </h4>
                        <p>Rapidly translate your ideas into interactive designs and wireframes enabling you to visualize your business requirement and process flows...</p>
                        <div class="tags">More: 
                            <a href="">Web Design, </a>
                            <a href="">interactive designs, </a>
                            <a href="">product demos, </a>
                            <a href="">User Experience (UX/UI), </a>
                            <a href="">minimum viable products</a>
                        </div>
                        <a class="read-btn" href="/design-wirefrmes-and-rapid-prototyping">Read More <img src="/images/icons/feather-arrow-right.svg" alt=""></a>
                    </div>

                    <div class="col-md-6 col-lg-4 services">
                        <h4>
                            <span><img src="/images/icons/service4.svg" alt=""></span>
                            SEO & <br> Digital Marketing
                        </h4>
                        <p>Reaching your customers effectively through multiple channels and platforms to optimize their experience and maximise your reach...</p>
                        <div class="tags">More: 
                            <a href="">Google AdWords, </a>
                            <a href="">Google key Words, </a>
                            <a href="">Google Tags, </a>
                            <a href="">Google Analytics, </a>
                        </div>
                        <a class="read-btn" href="/seo-and-digital-marketing">Read More <img src="/images/icons/feather-arrow-right.svg" alt=""></a>
                    </div>

                    <div class="col-md-6 col-lg-4 services">
                        <h4>
                            <span><img src="/images/icons/service5.svg" alt=""></span>
                            Data Science <br> applications & WEB data
                        </h4>
                        <p>Whether it is data analytics, data mining, machine learning or algorithms to efficiently extract insights from web data, our Python ...</p>
                        <div class="tags">More: 
                            <a href="">Scrapeit Platform, </a>
                            <a href="">Artificial Intelligence, </a>
                            <a href="">Data Analytics, </a>
                            <a href="">Data Mining, </a>
                        </div>
                        <a class="read-btn" href="/data-science-applications-and-web-data">Read More <img src="/images/icons/feather-arrow-right.svg" alt=""></a>
                    </div>

                    <div class="col-md-6 col-lg-4 services">
                        <h4>
                            <span><img src="/images/icons/service6.svg" alt=""></span>
                            Native & Cross Platform Mobile Apps & IOT
                        </h4>
                        <p>We have an experienced team that can build mobile applications across all the different platforms required by your users...</p>
                        <div class="tags">More: 
                            <a href="">Mobile Deal Tracker, </a>
                            <a href="">Mobile Messaging, </a>
                            <a href="">Mobile Document Management, </a>
                            <a href="">Android</a>
                        </div>
                        <a class="read-btn" href="/native-and-cross-platform-mobile-apps-and-iot">Read More <img src="/images/icons/feather-arrow-right.svg" alt=""></a>
                    </div>
                </div>
            </div>
            <div class="services-counter">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 flex">
                            <article>
                                <h5>Successful work across</h5>
                                <h3>250+</h3>
                                <span>DIVERSE</span>
                            </article>
                            <article>
                                <h5>Deep expertise in</h5>
                                <h3>100+</h3>
                                <span>TECHNOLOGIES</span>
                            </article>
                            <article>
                                <h5>We have more than</h5>
                                <h3>50+</h3>
                                <span>SOFTWARE DEVELOPERS</span>
                            </article>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </body>
    <script src="/js/jquery.js"></script>
    <script src="/js/app.js"></script>
    <script src="/js/owl.carousel.min.js"></script>
    <script src="/js/front-main.js"></script>
</html>
