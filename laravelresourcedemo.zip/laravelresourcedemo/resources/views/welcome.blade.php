<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="theme-color" content="#031C2B" />
        <title>TxLabs.co</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="/css/front/front.css">
        <!-- Styles -->
        
    </head>
    <body>
        <header class="header">
            @include('common.header')
        </header>
        <div class="cookie-pop">
            <div class="cookie-overlay"></div>
            <div class="cookie-box">
                <div class="container">
                    <div class="row">
                        <div class="col-12 flex">
                            <p>This website uses cookies to enhance site navigation and improve functionality, analyze site usage, and assist in our marketing and advertising efforts. Please click "I accept cookies" to let us know you're okay with our use of all cookies. For more information please see the cookies section of our Privacy Policy.
                                <a class="cookie-btn" href="#">I Accept Cookies</a>
                            </p>
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <section class="home-banner">
            <div class="banner-sm">
                <a href="#"><img src="/images/icons/Facebook.svg" alt=""></a>
                <a href="#"><img src="/images/icons/Twitter.svg" alt=""></a>
                <a href="#"><img src="/images/icons/Linkedin.svg" alt=""></a>
                <div class="hairline"></div>
                <div class="homebanner-nav">
                    <div class="prev"><img width="7" src="/images/icons/arrow-left.svg" alt=""></div>
                    <div class="next"><img width="7" src="/images/icons/arrow-right.svg" alt=""></div>
                </div>           
            </div>
            <div class="owl-carousel owl-theme" id="home-banner">
                <div class="item">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-10 offset-md-1 banner-caption">
                                <h3>A TECHNOLOGY PARTNER FOR <br>
                                ENTREPRENEURS & Business Owners  <br>
                                TO <span>BUILD, fund & SCALE</span>  <br>
                                Web, Mobile & <em></em>DATA PLATFORMS</h3>
                                <p>Our Labs support new ventures and transformation of legacy systems with rapid <br>
                                 prototyping, proof of concept and MVPs to transform business models, customer <br>
                                  acquisition and engagement. Our teams of experienced software engineers, designers <br>
                                  and data scientists use proven processes to deliver rapid business results.</p>
                                <div class="banner-btnGrp">
                                    <a class="btn btn-outline-primary" href="#">RAPID PROTOTYPING, <br> PROOF OF CONCEPT & MVPs<img src="/images/icons/btn-arrow.svg" alt=""></a>
                                    <a class="btn btn-outline-primary" href="#">BESPOKE SOFTWARE, APIs <br> & SYSTEM INTEGRATION <img src="/images/icons/btn-arrow.svg" alt=""></a>
                                    <a class="btn btn-outline-primary" href="#">DATA SCIENCE APPLICATIONS, <br> CUSTOMISED WEB DATA <img src="/images/icons/btn-arrow.svg" alt=""></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-10 offset-md-1 banner-caption">
                                <h3>A TECHNOLOGY PARTNER FOR <br>
                                ENTREPRENEURS & Business Owners  <br>
                                TO <span>BUILD, fund & SCALE</span>  <br>
                                Web, Mobile & <em></em>DATA PLATFORMS</h3>
                                <p>Our Labs support new ventures and transformation of legacy systems with rapid <br>
                                 prototyping, proof of concept and MVPs to transform business models, customer <br>
                                  acquisition and engagement. Our teams of experienced software engineers, designers <br>
                                  and data scientists use proven processes to deliver rapid business results.</p>
                                <div class="banner-btnGrp">
                                    <a class="btn btn-outline-primary" href="#">RAPID PROTOTYPING, <br> PROOF OF CONCEPT & MVPs<img src="/images/icons/btn-arrow.svg" alt=""></a>
                                    <a class="btn btn-outline-primary" href="#">BESPOKE SOFTWARE, APIs <br> & SYSTEM INTEGRATION <img src="/images/icons/btn-arrow.svg" alt=""></a>
                                    <a class="btn btn-outline-primary" href="#">DATA SCIENCE APPLICATIONS, <br> CUSTOMISED WEB DATA <img src="/images/icons/btn-arrow.svg" alt=""></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="msg-sec">
                <div class="chat-popup">
                    <div class="chat-header">
                        <h5>We are Online</h5>
                        <div class="admin-id">
                            <div class="admin">
                                <img src="/images/icons/user.svg" alt="">
                                <b class="status"></b>
                            </div>
                            <span>Jalpa Kande</span>
                        </div>
                    </div>
                    <div class="chat-body">
                        <div class="chat-container">
                            <div class="incomming">
                                <div class="user-details">
                                    <img class="user-img" src="/images/icons/user2.svg" alt="">
                                    <p class="user-name">Jalpa Kande</p>
                                </div>
                                <div class="chat">
                                    <div class="msg"> Welcome</div>
                                    <span class="timing">Aug 6,2020. 4:44 PM</span>    
                                </div>
                                <div class="chat">
                                    <div class="msg">Hey there 👋 <br>   
                                    Thank you checking txlabs.co <br>
                                    Select the topic or write your question below</div>
                                    <span class="timing">Aug 6,2020. 4:44 PM</span>
                                </div>
                            </div>
                            <div class="quick-chats">
                                <a class="select-chat" href="#">Yes I have a question</a>
                                <a class="select-chat" href="#">Just Browsing</a>
                                <a class="select-chat" href="#">Request a callback</a>
                                <a class="select-chat" href="#">Something else</a>
                                <a class="select-chat" href="#">Request a Service</a>
                                <a class="select-chat" href="#">Inquiry</a>
                            </div>
                        </div>
                        <div class="chat-area">
                            <div class="chat-options">
                                <label class="chat-option"><img src="/images/icons/attach.svg" alt=""></label>
                                <a class="chat-option" href="#"><img src="/images/icons/smile.svg" alt=""></a>
                            </div>
                            <input type="text" class="enter-chat" name="" placeholder="Type here and press enter..." id="">
                        </div>
                    </div>
                </div>
                <!-- <div class="chat-popup">
                    <div class="chat-header">
                        <h5>We are Online</h5>
                        <p>Please fill out the form below to start chatting with the next available agent.</p>
                    </div>
                    <div class="chat-body">
                        <form>
                            <div class="form-group">
                              <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                            </div>
                            <div class="form-group">
                                <input type="password" placeholder="Name" class="form-control">
                            </div>
                            <div class="form-group">
                                <input type="password" placeholder="Email" class="form-control">
                            </div>
                            <div class="form-group">
                                <input type="password" placeholder="Phone Number" class="form-control">
                            </div>
                            <div class="form-group">
                                <textarea class="form-control" placeholder="Message"></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary">Start Chat</button>
                          </form>
                    </div>
                </div> -->
                <div class="chat-popup popmsg-info">
                    <div class="chat-header">
                        <h5>We are Online</h5>
                    </div>
                    <div class="chat-body">
                        <p>I am here to answer any questions you may have about txlabs.co. We have wealth of information on the website, but if there is anything we can help you in a few seconds</p>                    </div>
                </div>
                <a href="#" class="msg-icon">
                    <img class="chat-open" width="20px" src="/images/icons/chat.svg" alt="">
                    <img class="chat-close" width="20px" src="/images/icons/close.svg" alt="">
                </a>
            </div>
        </section>
    </body>
    <script src="/js/jquery.js"></script>
    <script src="/js/app.js"></script>
    <script src="/js/owl.carousel.min.js"></script>
    <script src="/js/front-main.js"></script>
</html>
