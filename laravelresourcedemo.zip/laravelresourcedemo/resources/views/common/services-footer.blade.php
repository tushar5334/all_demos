<div class="services-footer">
    <div class="container">
        <div class="row">
            <div class="col-md-4 has-border">
                <h4>OUR APPROACH</h4>
                <strong>Proven effective processes</strong>
                <p>We practice a detailed and established agile methodology. It allows us to deliver on projects in a timely manner without</p>
            </div>
            <div class="col-md-4 has-border">
                <h4>BENEFITS OF NEARSHORE</h4>
                <strong>Closing the skills gap</strong>
                <p>There is an evident skills gap in the UK technology space, which is unable to keep up with the plethora of software solution ideas being.</p>
            </div>
            <div class="col-md-4">
                <h4>ENSURING SUCCESS</h4>
                <strong>Our duty to excel</strong>
                <p>Technology is evolving at a fast pace. This is both exciting and daunting for anyone delving into the realms of software development.</p>
            </div>
        </div>
    </div>
</div>