<div class="container">
    <div class="row align-items-center">
        <div class="col-7 col-md-7 col-lg-5 flex">
            <div class="hamburger"><span></span><span></span><span></span></div>
            <a class="logo" href="/"><img src="/images/logo.png" alt=""></a>
            <a class="logo-icon" href=""><img src="/images/icons/mail.svg" alt=""> info@txlabs.co</a>
        </div>
        <div class="col-5 col-md-5 col-lg-7 no-pos">
            
            <nav class="main-menu">
                <ul>
                    <li {{{ (Request::is('/') ? 'class=active' : '') }}}>
                        <a href="/">Home</a>
                    </li>
                    <li {{{ (Request::is('services') || Request::is('bespoke-software-development') || Request::is('api-and-system-integration') || Request::is('design-wirefrmes-and-rapid-prototyping') || Request::is('seo-and-digital-marketing') || Request::is('data-science-applications-and-web-data') || Request::is('native-and-cross-platform-mobile-apps-and-iot')  ? 'class=active' : '') }}}><a href="/services">Services</a></li>
                    <li {{{ (Request::is('projects') ? 'class=active' : '') }}}><a href="/projects">Projects</a></li>
                    <li {{{ (Request::is('pov') ? 'class=active' : '') }}}><a href="/pov">POV</a></li>
                    <li {{{ (Request::is('hiring') ? 'class=active' : '') }}}><a href="/hiring">Hiring<span>*</span></a></li>
                    <li><a href="#">About</a></li>
                </ul>
            </nav>
            <div class="menu-right">
                <div class="country-drop">
                    <a class="country-link" href="javascript:"><img src="/images/flag.png" alt=""></a>
                    <div class="country-list">
                        <a class="countrys" href="javascript:"><img src="/images/flag.png" alt=""></a>
                        <a class="countrys" href="javascript:"><img src="/images/flag.png" alt=""></a>
                        <a class="countrys" href="javascript:"><img src="/images/flag.png" alt=""></a>
                        <a class="countrys" href="javascript:"><img src="/images/flag.png" alt=""></a>
                    </div>
                </div>
                <a class="openSearch" href="#"><img src="/images/icons/search.svg" alt=""></a>
                <a href="#"><img src="/images/icons/user.svg" alt=""></a>
            </div>
        </div>
    </div>
</div>
<div class="search-area">
    <input class="searchBar" type="search" value="" name="" placeholder="Search Here ...">
    <a class="close" href="#"><img src="/images/icons/close.svg" alt=""></a>
</div>

