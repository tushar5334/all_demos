<div class="col-12 language-slider">
    <div class="owl-carousel owl-theme" id="language-carousel">
        <div class="items"><a href="#"><img src="/images/php.svg" alt=""></a></div>
        <div class="items"><a href="#"><img src="/images/aws.svg" alt=""></a></div>
        <div class="items"><a href="#"><img src="/images/angular.svg" alt=""></a></div>
        <div class="items"><a href="#"><img src="/images/node.svg" alt=""></a></div>
        <div class="items"><a href="#"><img src="/images/html5.svg" alt=""></a></div>
        <div class="items"><a href="#"><img src="/images/android.svg" alt=""></a></div>
        <div class="items"><a href="#"><img src="/images/ios.svg" alt=""></a></div>
        <div class="items"><a href="#"><img src="/images/flutter.svg" alt=""></a></div>
        <div class="items"><a href="#"><img src="/images/python.svg" alt=""></a></div>
        <div class="items"><a href="#"><img src="/images/react.svg" alt=""></a></div>
        <div class="items"><a href="#"><img src="/images/ios.svg" alt=""></a></div>
        <div class="items"><a href="#"><img src="/images/flutter.svg" alt=""></a></div>
        <div class="items"><a href="#"><img src="/images/python.svg" alt=""></a></div>
        <div class="items"><a href="#"><img src="/images/react.svg" alt=""></a></div>
    </div>
</div>