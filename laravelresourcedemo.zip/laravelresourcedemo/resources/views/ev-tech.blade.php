<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="theme-color" content="#031C2B" />

        <title>TxLabs.co | Electric vehicle fleet management platform</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="/css/front/front.css">
        <!-- Styles -->
        
    </head>
    <body>
        <header class="header inner-header">
            @include('common.header')
        </header>
        <section class="inner-body">
            <div class="page-title">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <h2>Electric vehicle fleet management platform</h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container project-details">
                <div class="row">
                    <div class="col-12 project-top">
                        <div>
                            <h5>Client Info</h5>
                            <p>EV technologies</p>
                        </div>
                        <div>
                            <h5>Services</h5>
                            <p>Design, Wireframes, Bespoke Development</p>
                        </div>
                        <div>
                            <h5>Website</h5>
                            <p><a href="https://www.ev-tech.uk/" target="_blank">https://www.ev-tech.uk/</a></p>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="video-container">
                            <div class="embed-responsive embed-responsive-16by9">
                                <div class="video-thumb" style="background-image: url(/images/ev-tech-proj.jpg);"><img width="80" src="/images/icons/play.svg" alt=""></div>
                                <video class="video2" poster="images/maxresdefault.jpg" controls="">
                                    <source src="/images/banner-video.mp4" type="video/mp4">
                                </video>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <h4>Electric vehicle fleet management platform</h4>
                        <p>We have released a limited number of ‘commercial apps’ available on the App Store but most of their work is proprietary and not free/freemium B2C downloads. For example: the EV-Tech app is a complex platform that enables users of electric vehicles to measure, manage and track their journeys in an electric vehicle. Original intention was to alleviate ‘range anxiety’ and enable optimization of journeys (google maps integration) within a network of mapped available charge points (and their bookings and payment). It is integrated with a telematics device that extracts data live from the EV CANBUS (hardware device, that has been programmed and implemented by our team). The original implementation was intended to be a ‘consumer product’ but has pivoted towards a B2B product for customers that a transitioning their petrol/diesel commercial van fleets to electric vehicles (optimising journeys, driver behaviour, charging, scheduling journeys, variable electricity tariffs etc.). It is integrated together with a complete management control tool enabling fleet visibility and control. Largest user is DRAX (client of EV-Tech), they have rolled this out to a number of their large clients.</p>
                    </div>
                    <div class="col-md-6 projectinfo-slider">
                        <div class="owl-carousel owl-theme" id="projectInfo-carousel">
                            <div class="items"><img src="/images/ev-tech.jpg" alt=""></div>
                            <div class="items"><img src="/images/ev-tech.jpg" alt=""></div>
                            <div class="items"><img src="/images/ev-tech.jpg" alt=""></div>
                        </div>
                    </div>
                    <div class="col-12">
                        <a class="view-all" href="#"><img src="/images/icons/all.svg" alt=""> View All Projects</a>
                    </div>
                    <div class="col-md-6 project-nav">
                        <div style="background-image: url(/images/evtech.png);" class="project-bg">
                            <a href="#"><img src="/images/icons/arrow-dropLeft.svg" alt=""> Previous project</a>
                        </div>
                        <h4>Electric vehicle fleet management platform</h4>
                        <span>Click to view more</span>
                    </div>
                    <div class="col-md-6 project-nav">
                        <div style="background-image: url(/images/hourly.png);" class="project-bg">
                            <a href="#">NEXT project <img src="/images/icons/arrow-dropRight.svg" alt=""></a>
                        </div>
                        <h4>Ai-enabled short-cycle projects</h4>
                        <span>Click to view more</span>
                    </div>
                </div>
                
            </div>
            <div class="logo-slider">
                <div class="container">
                    <div class="row">
                        @include('common.logo-slider')   
                    </div>
                </div>
            </div>
            <div class="services-footer">
                <div class="container">
                    <div class="row">
                        <div class="col-md-4">
                            <h4>OUR APPROACH</h4>
                            <strong>Proven effective processes</strong>
                            <p>We practice a detailed and established agile methodology. It allows us to deliver on projects in a timely manner without compromising on quality.</p>
                        </div>
                        <div class="col-md-4">
                            <h4>BENEFITS OF NEARSHORE</h4>
                            <strong>Closing the skills gap</strong>
                            <p>There is an evident skills gap in the UK technology space, which is unable to keep up with the plethora of software solution ideas being born. Our nearshore services offer company culture parallel to your own, proficiency in English and a similar time zone.</p>
                        </div>
                        <div class="col-md-4">
                            <h4>ENSURING SUCCESS</h4>
                            <strong>Our duty to excel</strong>
                            <p>Technology is evolving at a fast pace. This is both exciting and daunting for anyone delving into the realms of software development.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </body>
    <script src="/js/jquery.js"></script>
    <script src="/js/app.js"></script>
    <script src="/js/owl.carousel.min.js"></script>
    <script src="/js/front-main.js"></script>
</html>
