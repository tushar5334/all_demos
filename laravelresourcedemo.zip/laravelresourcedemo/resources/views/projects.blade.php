<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="theme-color" content="#031C2B" />

        <title>TxLabs.co | Projects</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="/css/front/front.css">
        <!-- Styles -->
        
    </head>
    <body>
        <header class="header inner-header">
            @include('common.header')
        </header>
        <section class="inner-body">
            <div class="page-title">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <h2><span>Our</span> Projects</h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row project-main align-items-end">
                    <div class="col-lg-5 col-md-6">
                        <div style="background-image: url(/images/pcb-train.png);" class="project-bg">
                            <img class="prod-logo" src="/images/pcb-logo.png" alt="">
                            <figure>
                                <i class="quote-left"><img src="/images/icons/quote-left.svg" alt=""></i>
                                <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.
                                    <a href=""></a>
                                </p>
                                <div class="clint">
                                    <img src="/images/ellipse.png" alt="">
                                    <figcaption>
                                        <span>Patrick Henderson</span>
                                        <b>CEO</b>
                                    </figcaption>
                                </div>
                            </figure>
                        </div>
                    </div>
                    <div class="col-lg-7 col-md-6 project-details">
                        <h4>costing tool for API-based industrial bill of material</h4>
                        <p class="expandable">The product was developed to replace a complex manual process inside the organisation that was slow and expensive. The challenge was to integrate real-time data from multiple systems....
                            <a class="expand-btn" href="#">Read more...</a>
                        </p>
                        <div class="tags expandable">More: 
                            <a href="">ExitReadinessReview, </a>
                            <a href="">MarketSoundings, </a>
                            <a href="">thePitchFactoryTM, </a>
                            <a href="">ProspectusBuilderTM, </a>
                            <a href="">DealStructureStep-plan, </a>
                            <a href="">LegalDueDiligence, </a>
                            <a href="">Advisors</a>

                            <a class="expand-btn" href="#">Read more...</a>
                        </div>
                        <a class="btn-view" href="/project-details">view project <img src="/images/icons/feather-arrow-right.svg" alt=""></a>
                    </div>
                </div>
                <div class="row project-slider">
                    <div class="col-12">
                        <div class="owl-carousel owl-theme" id="project-carousel">
                            <div class="items">
                                <div style="background-image: url(/images/evtech.png);" class="project-bg">
                                    <img src="/images/ev-logo.png" alt="">
                                </div>
                                <h4><a href="/ev-tech">Electric vehicle fleet management platform</a></h4>
                                <div class="tags expandable">More: 
                                    <a href="">ExitReadinessReview, </a>
                                    <a href="">MarketSoundings, </a>
                                    <a href="">thePitchFactoryTM, </a>
                                    <a href="">ProspectusBuilderTM, </a>
                                    <a href="">DealStructureStep-plan, </a>
                                    <a href="">LegalDueDiligence, </a>
                                    <a href="">Advisors</a>

                                    <a class="expand-btn" href="#">Read more...</a>
                                </div>
                            </div>
                            <div class="items">
                                <div style="background-image: url(/images/hourly.png);" class="project-bg">
                                    <img src="/images/hc-logo.png" alt="">
                                </div>
                                <h4><a href="/ev-tech">Ai-enabled short-cycle projects</a></h4>
                                <div class="tags expandable">More: 
                                    <a href="">ExitReadinessReview, </a>
                                    <a href="">MarketSoundings, </a>
                                    <a href="">thePitchFactoryTM, </a>
                                    <a href="">ProspectusBuilderTM, </a>
                                    <a href="">DealStructureStep-plan, </a>
                                    <a href="">LegalDueDiligence, </a>
                                    <a href="">Advisors</a>

                                    <a class="expand-btn" href="#">Read more...</a>
                                </div>
                            </div>
                            <div class="items">
                                <div style="background-image: url(/images/fc.png);" class="project-bg">
                                    <img src="/images/fc-logo.png" alt="">
                                </div>
                                <h4><a href="/ev-tech">Affiliate marketing & online gaming</a></h4>
                                <div class="tags expandable">More: 
                                    <a href="">ExitReadinessReview, </a>
                                    <a href="">MarketSoundings, </a>
                                    <a href="">thePitchFactoryTM, </a>
                                    <a href="">ProspectusBuilderTM, </a>
                                    <a href="">DealStructureStep-plan, </a>
                                    <a href="">LegalDueDiligence, </a>
                                    <a href="">Advisors</a>

                                    <a class="expand-btn" href="#">Read more...</a>
                                </div>
                            </div>
                            <div class="items">
                                <div style="background-image: url(/images/evtech.png);" class="project-bg">
                                    <img src="/images/ev-logo.png" alt="">
                                </div>
                                <h4><a href="/ev-tech">Electric vehicle fleet management platform</a></h4>
                                <div class="tags expandable">More: 
                                    <a href="">ExitReadinessReview, </a>
                                    <a href="">MarketSoundings, </a>
                                    <a href="">thePitchFactoryTM, </a>
                                    <a href="">ProspectusBuilderTM, </a>
                                    <a href="">DealStructureStep-plan, </a>
                                    <a href="">LegalDueDiligence, </a>
                                    <a href="">Advisors</a>

                                    <a class="expand-btn" href="#">Read more...</a>
                                </div>
                            </div>
                            <div class="items">
                                <div style="background-image: url(/images/hourly.png);" class="project-bg">
                                    <img src="/images/hc-logo.png" alt="">
                                </div>
                                <h4><a href="/ev-tech">Ai-enabled short-cycle projects</a></h4>
                                <div class="tags expandable">More: 
                                    <a href="">ExitReadinessReview, </a>
                                    <a href="">MarketSoundings, </a>
                                    <a href="">thePitchFactoryTM, </a>
                                    <a href="">ProspectusBuilderTM, </a>
                                    <a href="">DealStructureStep-plan, </a>
                                    <a href="">LegalDueDiligence, </a>
                                    <a href="">Advisors</a>

                                    <a class="expand-btn" href="#">Read more...</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </body>
    <script src="/js/jquery.js"></script>
    <script src="/js/app.js"></script>
    <script src="/js/owl.carousel.min.js"></script>
    <script src="/js/front-main.js"></script>
</html>
