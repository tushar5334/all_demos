<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="theme-color" content="#031C2B" />

        <title>TxLabs.co | Data Science applications & WEB data</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="/css/front/front.css">
        <!-- Styles -->
        
    </head>
    <body>
        <header class="header inner-header">
            @include('common.header')
        </header>
        <section class="inner-body">
            <div class="page-title">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <h2><b><img src="/images/icons/service5.svg" alt=""></b> Data Science applications & WEB data</h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container services-details">
                <div class="row">
                    <div class="col-12 services-details-top">
                        <h4>PROVEN PROCESS. TALENTED PEOPLE. DELIVERING RESULTS.</h4>
                        <p>Our experience encompasses a variety of skillsets, delivered rapidly with agile methodology for maximum business impact.</p>
                    </div>
                    <div class="col-md-6 col-lg-4 services-details-list">
                        <span><img src="/images/icons/service-details21.svg" alt=""></span>
                        <h5>DATA science</h5>
                        <p>Our team combines domain expertise, programming skills & knowledge of mathematics & statistics to extract meaningful insights from data</p>
                        <div class="tags">More: 
                            <a href="">Crm software Development, </a>
                            <a href="">scrapeIT platform, </a>
                            <a href="">artificial intelligence, </a>
                            <a href="">machine learning, </a>
                            <a href="">data analytics</a>
                        </div>
                        <a class="read-btn" href="#">Explore Case studies  <img src="/images/icons/feather-arrow-right.svg" alt=""></a>
                    </div>
                    <div class="col-md-6 col-lg-4 services-details-list">
                        <span><img src="/images/icons/service-details22.svg" alt=""></span>
                        <h5>Algorithms</h5>
                        <p>We have built algorithms for client applications to optimize processes and automatic business processes</p>
                        <div class="tags">More: 
                            <a href="">Lead generation </a>
                            <a href="">data research, </a>
                            <a href="">linkedIN, </a>
                            <a href="">online research & data scraping, </a>
                            <a href="">uk, </a>
                            <a href="">europe, </a>
                            <a href="">us</a>
                        </div>
                        <a class="read-btn" href="#">Explore Case studies  <img src="/images/icons/feather-arrow-right.svg" alt=""></a>
                    </div>

                    <div class="col-md-6 col-lg-4 services-details-list">
                        <span><img src="/images/icons/service-details23.svg" alt=""></span>
                        <h5>DATA visualisation</h5>
                        <p>Our team will extract and graphically represent information and data. Our data visualization tool provides an accessible way to see and understand trends .</p>
                        <div class="tags">More: 
                            <a href="">Data miningn, </a>
                            <a href="">python, </a>
                            <a href="">web data scraping, </a>
                            <a href="">big data, </a>
                            <a href="">competitive analysis</a>
                            <a href="">algorithms</a>
                            <a href="">smart matching</a>
                        </div>
                        <a class="read-btn" href="#">Explore Case studies  <img src="/images/icons/feather-arrow-right.svg" alt=""></a>
                    </div>
                    <div class="col-md-6 col-lg-4 services-details-list">
                        <span><img src="/images/icons/service-details24.svg" alt=""></span>
                        <h5>custom data extraction</h5>
                        <p>Our site-specific data extraction solution delivers web data exactly the way you need it at the desired frequency via your preferred delivery</p>
                        <div class="tags">More: 
                            <a href="">Data mining, </a>
                            <a href="">python, </a>
                            <a href="">web data scraping, </a>
                            <a href="">big data, </a>
                            <a href="">competitive analysis, </a>
                            <a href="">algorithms, </a>
                            <a href="">smart matching</a>
                        </div>
                        <a class="read-btn" href="#">Explore Case studies  <img src="/images/icons/feather-arrow-right.svg" alt=""></a>
                    </div>

                    <div class="col-md-6 col-lg-4 services-details-list">
                        <span><img src="/images/icons/service-details24.svg" alt=""></span>
                        <h5>custom data research</h5>
                        <p>Our team of researchers uses automated and manual research to deliver quality data solutions for applications as lead generation and recruitment</p>
                        <div class="tags">More: 
                            <a href="">Data research, </a>
                            <a href="">linkedIN, </a>
                            <a href="">online research & data scraping, </a>
                            <a href="">machine learning, </a>
                            <a href="">data analytics</a>
                        </div>
                        <a class="read-btn" href="#">Explore Case studies  <img src="/images/icons/feather-arrow-right.svg" alt=""></a>
                    </div>
                    <div class="col-md-6 col-lg-4 services-details-list">
                        <span><img src="/images/icons/service-details25.svg" alt=""></span>
                        <h5>Scrapeit</h5>
                        <p>Our proprietary platform enables rapid & sustainable extraction processing & analysis of web data sources to support rapid decision making</p>
                        <div class="tags">More: 
                            <a href="">Crm software Development, </a>
                            <a href="">scrapeIT platform, </a>
                            <a href="">artificial intelligence, </a>
                            <a href="">machine learning, </a>
                            <a href="">data analytics</a>
                        </div>
                        <a class="read-btn" href="#">Explore Case studies  <img src="/images/icons/feather-arrow-right.svg" alt=""></a>
                    </div>
                </div>
            </div>
            <div class="pos-bottom">
                <div class="logo-slider">
                    <div class="container">
                        <div class="row">
                            @include('common.logo-slider')   
                        </div>
                    </div>
                </div>
                @include('common.services-footer')
            </div>
        </section>
    </body>
    <script src="/js/jquery.js"></script>
    <script src="/js/app.js"></script>
    <script src="/js/owl.carousel.min.js"></script>
    <script src="/js/front-main.js"></script>
</html>
