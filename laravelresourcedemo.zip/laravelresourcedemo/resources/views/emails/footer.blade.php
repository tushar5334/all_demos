<!-- Footer Ends -->
<tr>
    <td style="background: #222831; height: 20px;">
        &nbsp; &nbsp; &nbsp;
    </td>
</tr>
<!-- Footer Ends -->

</table>
</td>
</tr>
</table>
</body>
</html>