<!DOCTYPE html>
<html>
    <head>
    	<meta name="robots" content="noindex">
        <meta name="viewport" content="width=device-width">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Fanclash</title>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet">
    </head>
    <body style="margin: 0; padding: 0px; font-family: 'Poppins', sans-serif; color: #4d4d4d;">
        <table border="0" cellspacing="0" cellpadding="0" bgcolor="#EFEFEF" align="center" style="height:100%;width:100%;">
            <tr>
                <td valign="top" style="width: 100%; padding:0 0; background-color: #efefef; text-align: center;">
                    <table border="0" cellspacing="0" cellpadding="0" style="width: 100%;">

                        <!-- Header Start -->
                        <tr>
                            <td>
                                <table cellspacing="0" cellpadding="0" style=" width: 100%; min-width: 100%;">
                                    <tr>
                                        <td style="background-color: #222831; padding: 26px 0; color: #fff; font-weight: 500; text-align: center;" colspan="3">
                                            <img src="{{ getenv('APP_URL') }}/images/email/logo.png" width="150" alt="Fanclash">
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <!-- Header Ends -->