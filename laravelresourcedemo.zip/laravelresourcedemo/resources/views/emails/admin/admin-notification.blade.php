@include('emails/header')
<!-- Body Start -->
<tr>
    <td>
        <table cellspacing="0" cellpadding="0" style="background: #ebebeb; min-width: 100%; text-align: left;">
            <tr>
                <td style="padding: 25px;">
                    <table cellspacing="0" cellpadding="0" style="width: 640px; box-shadow: 2px 2px 5px #aaa; margin: 0px auto; background: #fff;">
                        <tr>
                            <td style=" vertical-align: top; text-align: center; padding: 50px 20px 30px 20px;">
                                <h4 style="margin: 0 0 25px; color: #222831; font-size: 50px; font-weight: 700;">Hello {{$mailcontent['name']}},</h4>
                                <p style="font-weight: 500; color: #222831; font-size: 14px; margin: 0 0 30px; line-height: 1.5;">
                                    {!! $mailcontent['message'] !!}
                                </p>
                                <p style="font-weight: 500; font-size: 13px; color: #222831; margin: 0 0 40px; line-height: 1.6;">If you did not intiate this request, Please contact us immediately <br>
                                    at <a style="color: #2788D1; text-decoration: none;" href="mailto:marketing@thefanclash.com">marketing@thefanclash.com</a>.</p>
                                <p style="font-weight: 500; color: #999; font-size: 13px; margin: 0 0 10px; line-height: 1.6;"><a style="color: #999; text-decoration: none;" href="#">Terms of Use</a><span style="padding: 0 5px;">|</span><a style="color: #999; text-decoration: none;" href="#">Privacy Policy</a></p>
                                <p style="font-weight: 500; color: #999; font-size: 13px; margin: 0 0 0; line-height: 1.6;">Copyright ©2020 Fanclash. All right reserved.</p>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
    </td>
</tr>

<!-- Body Ends -->
@include('emails/footer')