<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="theme-color" content="#031C2B" />

        <title>TxLabs.co | API-based industrial bill of material costing tool</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="/css/front/front.css">
        <!-- Styles -->
        
    </head>
    <body>
        <header class="header inner-header">
            @include('common.header')
        </header>
        <section class="inner-body">
            <div class="page-title">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <h2>API-based industrial bill of material costing tool</h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container project-details">
                <div class="row">
                    <div class="col-12 project-top">
                        <div>
                            <h5>Client Info</h5>
                            <p>PCB train - Part of Newbury Electronics Group</p>
                        </div>
                        <div>
                            <h5>Services</h5>
                            <p>Design, Wireframes, Bespoke Development</p>
                        </div>
                        <div>
                            <h5>Website</h5>
                            <p><a href="https://www.pcbtrain.co.uk/" target="_blank">https://www.pcbtrain.co.uk/</a></p>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="video-container">
                            <div class="embed-responsive embed-responsive-16by9">
                                <div class="video-thumb" style="background-image: url(images/pcb.jpg);"><img width="80" src="/images/icons/play.svg" alt=""></div>
                                <video class="video2" poster="images/maxresdefault.jpg" controls="">
                                    <source src="/images/banner-video.mp4" type="video/mp4">
                                </video>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <h4>API-based industrial bill of material costing tool</h4>
                        <p>The product was developed to replace a complex manual process inside the organisation that was slow and expensive. The challenge was to integrate real-time data from multiple systems internal (client stock, manufacturing, ordering, accounts) and external (US and UK OEMS such as RS Components) to the organisation to generate an automated bill of materials that would be costed both for parts, availability and manufacturing capacity, accounting for complex business rules and multiple formats of design drawings supplied by customers (including different part numbers and design practices). This is time-sensitive as prices, availability and manufacturing slots are changing real-time. The tool also needed to account for the multiple business rules and logic that are required to ensure correct specifications into a precision manufacturing process. The tool was specified to enable a customer to generate their own bill of materials and place an order based on the parameters generated. The client staff will then manage by exception. The tool was specified to ‘learn’ from experience to optimise the user process and avoid generating specification errors.</p>
                    </div>
                    <div class="col-md-6">
                        <p>The tool (in Beta release) enables a customer to self-service and generate a real-time BOM in 2-4 minutes, after ‘cleaning’ their uploaded BOM, checking the parts/pricing/availability from internal and external sources, selecting from the logic of options and generating an order. The process would have previously been done manually by the client and each staff member would process an average of 3 BOM/Quotes per day.</p>
                        <h4>Other Features</h4>
                        <p>The tool (in Beta release) enables a customer to self-service and generate a real-time BOM in 2-4 minutes, after ‘cleaning’ their uploaded BOM,</p>
                        <ul class="col2">
                            <li>Posuere malesuada</li>
                            <li>Posuere malesuada</li>
                            <li>Posuere malesuada</li>
                            <li>Posuere malesuada</li>
                            <li>Posuere malesuada</li>
                            <li>Posuere malesuada</li>
                            <li>Posuere malesuada</li>
                            <li>Posuere malesuada</li>
                        </ul>
                    </div>
                    <div class="col-12">
                        <a class="view-all" href="#"><img src="/images/icons/all.svg" alt=""> View All Projects</a>
                    </div>
                    <div class="col-6 project-nav">
                        <div style="background-image: url(images/evtech.png);" class="project-bg">
                            <a href="#"><img src="/images/icons/arrow-dropLeft.svg" alt=""> Previous project</a>
                        </div>
                        <h4>Electric vehicle fleet management</h4>
                        <span>Click to view more</span>
                    </div>
                    <div class="col-6 project-nav">
                        <div style="background-image: url(images/hourly.png);" class="project-bg">
                            <a href="#">NEXT project <img src="/images/icons/arrow-dropRight.svg" alt=""></a>
                        </div>
                        <h4>Ai-enabled short-cycle projects</h4>
                        <span>Click to view more</span>
                    </div>
                </div>
            </div>
            <div class="logo-slider">
                <div class="container">
                    <div class="row">
                        @include('common.logo-slider')   
                    </div>
                </div>
            </div>
            <div class="services-footer">
                <div class="container">
                    <div class="row">
                        <div class="col-md-4">
                            <h4>OUR APPROACH</h4>
                            <strong>Proven effective processes</strong>
                            <p>We practice a detailed and established agile methodology. It allows us to deliver on projects in a timely manner without compromising on quality.</p>
                        </div>
                        <div class="col-md-4">
                            <h4>BENEFITS OF NEARSHORE</h4>
                            <strong>Closing the skills gap</strong>
                            <p>There is an evident skills gap in the UK technology space, which is unable to keep up with the plethora of software solution ideas being born. Our nearshore services offer company culture parallel to your own, proficiency in English and a similar time zone.</p>
                        </div>
                        <div class="col-md-4">
                            <h4>ENSURING SUCCESS</h4>
                            <strong>Our duty to excel</strong>
                            <p>Technology is evolving at a fast pace. This is both exciting and daunting for anyone delving into the realms of software development.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </body>
    <script src="/js/jquery.js"></script>
    <script src="/js/app.js"></script>
    <script src="/js/owl.carousel.min.js"></script>
    <script src="/js/front-main.js"></script>
</html>
