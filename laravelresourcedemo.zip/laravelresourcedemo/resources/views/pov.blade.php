<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="theme-color" content="#031C2B" />

        <title>TxLabs.co | POV</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="/css/front/front.css">
        <!-- Styles -->
        
    </head>
    <body>
        <header class="header inner-header">
            @include('common.header')
        </header>
        <section class="inner-body">
            <div class="page-title">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <h2>POV</h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-md-7 col-lg-9">
                        <div class="pov-filter">
                            <div class="select-cstm">
                                <select>
                                    <option>Categories</option>
                                    <option>Home Posts</option>
                                    <option>Medical</option>
                                    <option>Post format</option>
                                    <option>Uncategorized</option>
                                </select>
                            </div>
                            <div class="select-cstm">
                                <select>
                                    <option>Tags</option>
                                    <option>Home Posts</option>
                                    <option>Medical</option>
                                    <option>Post format</option>
                                    <option>Uncategorized</option>
                                </select>
                            </div>
                            <a class="search-btn" href="#"><img src="/images/icons/search-grey.svg" alt=""></a>
                        </div>
                        <h3 class="sec-hd sm-hide">
                            Top News
                            <span>1 new post</span>
                        </h3>
                        <div class="row">
                            <div class="col-lg-6 col-md-12">
                                <div class="pov-box">
                                    <div class="pov-bg" style="background-image: url(images/pov.png);"></div>
                                    <h4>Bloomberg:</h4>
                                    <h5>Sources: our Labs support new ventures, rapid prototyping, digital
                                        transformation,robotic process</h5>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis ...</p>
                                    <p><b>More:</b> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim</p>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-12">
                                <div class="pov-box">
                                    <div class="pov-bg" style="background-image: url(images/pov.png);"></div>
                                    <h4>Bloomberg:</h4>
                                    <h5>Sources: our Labs support new ventures, rapid prototyping, digital
                                        transformation,robotic process</h5>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis ...</p>
                                    <p><b>More:</b> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim</p>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-12">
                                <div class="pov-box">
                                    <div class="pov-bg" style="background-image: url(images/pov.png);"></div>
                                    <h4>Bloomberg:</h4>
                                    <h5>Sources: our Labs support new ventures, rapid prototyping, digital
                                        transformation,robotic process</h5>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis ...</p>
                                    <p><b>More:</b> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim</p>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-12">
                                <div class="pov-box">
                                    <div class="pov-bg" style="background-image: url(images/pov.png);"></div>
                                    <h4>Bloomberg:</h4>
                                    <h5>Sources: our Labs support new ventures, rapid prototyping, digital
                                        transformation,robotic process</h5>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis ...</p>
                                    <p><b>More:</b> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim</p>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-12">
                                <div class="pov-box">
                                    <div class="pov-bg" style="background-image: url(images/pov.png);"></div>
                                    <h4>Bloomberg:</h4>
                                    <h5>Sources: our Labs support new ventures, rapid prototyping, digital
                                        transformation,robotic process</h5>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis ...</p>
                                    <p><b>More:</b> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim</p>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-12">
                                <div class="pov-box">
                                    <div class="pov-bg" style="background-image: url(images/pov.png);"></div>
                                    <h4>Bloomberg:</h4>
                                    <h5>Sources: our Labs support new ventures, rapid prototyping, digital
                                        transformation,robotic process</h5>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis ...</p>
                                    <p><b>More:</b> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-5 col-lg-3 pov-right sm-hide">
                        <div class="card">
                            <h4>Search</h4>
                            <form>
                                <div class="form-group">
                                    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                </div>
                            </form>
                        </div>

                        <div class="card">
                            <h4>Categories</h4>
                                
                            <ul class="nav flex-column">
                                <li class="nav-item">
                                  <a class="nav-link" href="#">Home Posts</a>
                                </li>
                                <li class="nav-item">
                                  <a class="nav-link" href="#">Medical</a>
                                </li>
                                <li class="nav-item">
                                  <a class="nav-link" href="#">Post format</a>
                                </li>
                                <li class="nav-item">
                                  <a class="nav-link" href="#">Uncategorized</a>
                                </li>
                              </ul>
                        </div>
                        <div class="card">
                            <h4>Tags</h4>
                            <div>
                                <a href="#" class="badge badge-pill badge-secondary">Doctor</a>
                                <a href="#" class="badge badge-pill badge-secondary">Family</a>
                                <a href="#" class="badge badge-pill badge-secondary">Lorem Ipsum</a>
                                <a href="#" class="badge badge-pill badge-secondary">Lorem</a>
                                <a href="#" class="badge badge-pill badge-secondary">Health</a>
                                <a href="#" class="badge badge-pill badge-secondary">Random</a>
                            </div>
                        </div>

                        <div class="card">
                            <h4>Newest</h4>
                            <article>
                                <h5>Peter Aldhous / BuzzFeed News:</h5>
                                <p>Hackers attacked GEDmatch servers and caused over 1M of its profiles to be opted-in for searching by law enforcement, which were previously opted-out</p>
                                <span>3 hours ago</span>
                            </article>

                            <article>
                                <h5>Peter Aldhous / BuzzFeed News:</h5>
                                <p>Hackers attacked GEDmatch servers and caused over 1M of its profiles to be opted-in for searching by law enforcement, which were previously opted-out</p>
                                <span>3 hours ago</span>
                            </article>

                            <article>
                                <h5>Peter Aldhous / BuzzFeed News:</h5>
                                <p>Hackers attacked GEDmatch servers and caused over 1M of its profiles to be opted-in for searching by law enforcement, which were previously opted-out</p>
                                <span>3 hours ago</span>
                            </article>
                        </div>

                        <div class="card upcoming">
                            <h4>Upcoming Tech Events</h4>
                            <article>
                                <p>Earnings: INTC, TWTR</p>
                                <span>Jul 23</span>
                            </article>

                            <article>
                                <p>House Judiciary Antitrust Subcommittee hearing with CEOs of Amazon, Apple, Facebook, and Google</p>
                                <span>Washington, DC</span>
                                <span>Jul 27</span>
                            </article>

                            <article>
                                <p>House Judiciary Antitrust Subcommittee hearing with CEOs of Amazon, Apple, Facebook, and Google</p>
                                <span>Washington, DC</span>
                                <span>Jul 27</span>
                            </article>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </body>
    <script src="/js/jquery.js"></script>
    <script src="/js/app.js"></script>
    <script src="/js/owl.carousel.min.js"></script>
    <script src="/js/front-main.js"></script>
</html>
