<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="theme-color" content="#031C2B" />

        <title>TxLabs.co | BESPOKE software DEVELOPMENT</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="/css/front/front.css">
        <!-- Styles -->
        
    </head>
    <body>
        <header class="header inner-header">
            @include('common.header')
        </header>
        <section class="inner-body">
            <div class="page-title">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <h2><b><img src="/images/icons/service1.svg" alt=""></b> BESPOKE software DEVELOPMENT</h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container services-details">
                <div class="row">
                    <div class="col-12 services-details-top">
                        <h4>PROVEN PROCESS. TALENTED PEOPLE. DELIVERING RESULTS.</h4>
                        <p>Our experience encompasses a variety of skillsets, delivered rapidly with agile methodology for maximum business impact.</p>
                    </div>
                    <div class="col-md-6 col-lg-4 services-details-list">
                        <span><img src="/images/icons/service-details4.svg" alt=""></span>
                        <h5>TEAM AUGMENTATION</h5>
                        <p>We can extend your team, building your vision and will rapidly delivering quality software. Think of us as a flexible and agile talent pool with the right skills, qualifications and experience. A force multiplier.</p>
                        <div class="tags">More: 
                            <a href="">DealStructureStep-plan, </a>
                            <a href="">LegalDueDiligence, </a>
                            <a href="">Advisors, </a>
                            <a href="">FinancialDueDiligence, </a>
                            <a href="">CommercialDueDiligence, </a>
                        </div>
                        <a class="read-btn" href="#">Explore Case studies  <img src="/images/icons/feather-arrow-right.svg" alt=""></a>
                    </div>
                    <div class="col-md-6 col-lg-4 services-details-list">
                        <span><img src="/images/icons/service-details1.svg" alt=""></span>
                        <h5>BESPOKE SOLUTIONS</h5>
                        <p>If you need a project delivered, we can handle it in its entirety. From setting out a detailed timeline and plan on day one to completion. We have the teams and processes to deliver any software, on time and on budget.</p>
                        <div class="tags">More: 
                            <a href="">TechnicalDueDiligence, </a>
                            <a href="">TermSheetBuilder, </a>
                            <a href="">online editing PitchDeckBuilder, </a>
                            <a href="">MetricsBuilder, </a>
                            <a href="">OnMarketTermsTM, </a>
                        </div>
                        <a class="read-btn" href="#">Explore Case studies  <img src="/images/icons/feather-arrow-right.svg" alt=""></a>
                    </div>

                    <div class="col-md-6 col-lg-4 services-details-list">
                        <span><img src="/images/icons/service-details5.svg" alt=""></span>
                        <h5>TECHNOLOGY AGNOSTIC</h5>
                        <p>We deliver software using a range of languages, which is continuously evolving. Our Labs can support and modernise any technologies, helping clients create a more future-proof software estate.</p>
                        <div class="tags">More: 
                            <a href="">CapTableBuilder, </a>
                            <a href="">Workbench (including Meeting TearSheet), </a>
                            <a href="">Announced Deals, </a>
                            <a href="">Funding Rounds, </a>
                        </div>
                        <a class="read-btn" href="#">Explore Case studies  <img src="/images/icons/feather-arrow-right.svg" alt=""></a>
                    </div>
                    <div class="col-md-6 col-lg-4 services-details-list">
                        <span><img src="/images/icons/service-details3.svg" alt=""></span>
                        <h5>UI/UX</h5>
                        <p>Software works best when it is designed with the user in mind. We create software with the user at its core. The productivity of software is defined by the effectiveness of the user experience and the interface design.</p>
                        <div class="tags">More: 
                            <a href="">Live Transactions, </a>
                            <a href="">Valuation, </a>
                            <a href="">Potential Opportunities, </a>
                            <a href="">Investor Profiles, </a>
                            <a href="">Natural owners, </a>
                            <a href="">Advisors </a>
                        </div>
                        <a class="read-btn" href="#">Explore Case studies  <img src="/images/icons/feather-arrow-right.svg" alt=""></a>
                    </div>

                    <div class="col-md-6 col-lg-4 services-details-list">
                        <span><img src="/images/icons/service-details2.svg" alt=""></span>
                        <h5>APPS & MOBILE</h5>
                        <p>When building a mobile application, scalability, reliability and security are key. We use the latest mobile development platforms to ensure efficient cross-platform solutions across Android, iOS and web/hybrid.</p>
                        <div class="tags">More: 
                            <a href="">PE Assets, </a>
                            <a href="">Unicorns, </a>
                            <a href="">NEDs, </a>
                            <a href="">Exit Calculator, </a>
                            <a href="">KYC Linkages, </a>
                            <a href="">Market View, </a>
                            <a href="">Company Reporting, </a>
                            <a href="">Analyst Briefings</a>
                        </div>
                        <a class="read-btn" href="#">Explore Case studies  <img src="/images/icons/feather-arrow-right.svg" alt=""></a>
                    </div>
                    <div class="col-md-6 col-lg-4 services-details-list">
                        <span><img src="/images/icons/service-details6.svg" alt=""></span>
                        <h5>INTEGRATION</h5>
                        <p>It is common for multiple software platforms and applications, distributed on premise or on the cloud, to need to talk together. We have extensive experience integrating systems of all manner of complexity</p>
                        <div class="tags">More: 
                            <a href="">On-demand research, </a>
                            <a href="">Rapid Diligence, </a>
                            <a href="">Portfolio Mapping, </a>
                            <a href="">White Space mapping, </a>
                            <a href="">Market Entry Strategy</a>
                        </div>
                        <a class="read-btn" href="#">Explore Case studies  <img src="/images/icons/feather-arrow-right.svg" alt=""></a>
                    </div>
                </div>
            </div>

            <div class="pos-bottom">
                <div class="logo-slider">
                    <div class="container">
                        <div class="row">
                            @include('common.logo-slider')   
                        </div>
                    </div>
                </div>
                @include('common.services-footer')
            </div>
        </section>
    </body>
    <script src="/js/jquery.js"></script>
    <script src="/js/app.js"></script>
    <script src="/js/owl.carousel.min.js"></script>
    <script src="/js/front-main.js"></script>
</html>
