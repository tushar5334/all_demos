<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="theme-color" content="#031C2B" />

        <title>TxLabs.co | Native & Cross Platform Mobile Apps & IOT</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="/css/front/front.css">
        <!-- Styles -->
        
    </head>
    <body>
        <header class="header inner-header">
            @include('common.header')
        </header>
        <section class="inner-body">
            <div class="page-title">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <h2><b><img src="/images/icons/service6.svg" alt=""></b> Native & Cross Platform Mobile Apps & IOT</h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container services-details">
                <div class="row">
                    <div class="col-12 services-details-top">
                        <h4>PROVEN PROCESS. TALENTED PEOPLE. DELIVERING RESULTS.</h4>
                        <p>Our experience encompasses a variety of skillsets, delivered rapidly with agile methodology for maximum business impact.</p>
                    </div>
                    <div class="col-md-6 col-lg-4 services-details-list">
                        <span><img src="/images/icons/service-details26.svg" alt=""></span>
                        <h5>IOS APPS</h5>
                        <p>Our team of experienced developers builds native IOS apps for Apple devices, mostly using Swift. Ensuring security for enterprise data, high quality standards and the ability for clients to rapidly monetise their apps through the Apple ecosystem</p>
                        <div class="tags">More: 
                            <a href="">Mobile deal tracker, </a>
                            <a href="">mobile messaging, </a>
                            <a href="">mobile document management, </a>
                            <a href="">Android, </a>
                            <a href="">iOS</a>
                        </div>
                        <a class="read-btn" href="#">Explore Case studies  <img src="/images/icons/feather-arrow-right.svg" alt=""></a>
                    </div>
                    <div class="col-md-6 col-lg-4 services-details-list">
                        <span><img src="/images/icons/service-details27.svg" alt=""></span>
                        <h5>ANDROID APPS</h5>
                        <p>Our developers build native apps that allow users to capitalise on a the massive Android user base and rapid development process. As an open source solution with a complete software stack we offer wide customisations and integrations into multiple platforms</p>
                        <div class="tags">More: 
                           <a href="">HarDware dongle, </a> 
                           <a href="">mapping, </a> 
                           <a href="">android, </a> 
                           <a href="">ios, </a> 
                           <a href="">user mobile applications, </a> 
                           <a href="">task management</a> 
                        </div>
                        <a class="read-btn" href="#">Explore Case studies  <img src="/images/icons/feather-arrow-right.svg" alt=""></a>
                    </div>

                    <div class="col-md-6 col-lg-4 services-details-list">
                        <span><img src="/images/icons/service-details28.svg" alt=""></span>
                        <h5>HYBRID / WEB APPS</h5>
                        <p>Our team build apps using web technologies that render mobile-optimised web pages, giving the user flexibility, low maintenance costs and an increasingly a optimised user experience.</p>
                        <div class="tags">More: 
                            <a href="">Mobile application user journey , </a>
                            <a href="">telematics device, </a>
                            <a href="">telematics information, </a>
                            <a href="">EV range management</a>
                        </div>
                        <a class="read-btn" href="#">Explore Case studies  <img src="/images/icons/feather-arrow-right.svg" alt=""></a>
                    </div>
                    <div class="col-md-6 col-lg-4 services-details-list">
                        <span><img src="/images/icons/service-details29.svg" alt=""></span>
                        <h5>DEVICES</h5>
                        <p>We have build hardware / software solutions in the telematics space to extract data from the EV Canbus on the OBD connector. This real-time data extract and conversion allows our clients to build rich applications for better decision-making and control</p>
                        <div class="tags">More: 
                            <a href="">Mobile application user journey , </a>
                            <a href="">telematics device, </a>
                            <a href="">telematics information, </a>
                            <a href="">EV range management</a>
                        </div>
                        <a class="read-btn" href="#">Explore Case studies  <img src="/images/icons/feather-arrow-right.svg" alt=""></a>
                    </div>

                    <div class="col-md-6 col-lg-4 services-details-list">
                        <span><img src="/images/icons/service-details30.svg" alt=""></span>
                        <h5>IOT & 5G</h5>
                        <p>Increasingly clients are harnessing the power of huge amounts of data generated over networks of interrelated devices with UIDs. 5G technologies will accelerate speed of data transmission and enable new and exciting business models.</p>
                        <div class="tags">More: 
                            <a href="">Remote monitoring, </a>
                            <a href="">android, </a>
                            <a href="">ios, </a>
                            <a href="">user mobile applications,</a>
                            <a href="">notifications, </a>
                            <a href="">flutter</a>
                        </div>
                        <a class="read-btn" href="#">Explore Case studies  <img src="/images/icons/feather-arrow-right.svg" alt=""></a>
                    </div>
                    <div class="col-md-6 col-lg-4 services-details-list">
                        <span><img src="/images/icons/service-details31.svg" alt=""></span>
                        <h5>MOBILE GAMING APPLICATIONS</h5>
                        <p>Our team of developers and designers develops mobile games for VAS providers on network operators in a rapidly-growing and popular marketplace.</p>
                        <div class="tags">More: 
                            <a href="">Mobile deal tracker, </a>
                            <a href="">mobile messaging, </a>
                            <a href="">mobile document management, </a>
                            <a href="">Android, </a>
                            <a href="">iOS</a>
                        </div>
                        <a class="read-btn" href="#">Explore Case studies  <img src="/images/icons/feather-arrow-right.svg" alt=""></a>
                    </div>
                </div>
            </div>
            <div class="pos-bottom">
                <div class="logo-slider">
                    <div class="container">
                        <div class="row">
                            @include('common.logo-slider')   
                        </div>
                    </div>
                </div>
                @include('common.services-footer')
            </div>
        </section>
    </body>
    <script src="/js/jquery.js"></script>
    <script src="/js/app.js"></script>
    <script src="/js/owl.carousel.min.js"></script>
    <script src="/js/front-main.js"></script>
</html>
