<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="theme-color" content="#031C2B" />

        <title>TxLabs.co | Hiring</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="/css/front/front.css">
        <!-- Styles -->
        
    </head>
    <body>
        <header class="header inner-header">
            @include('common.header')
        </header>
        <section class="inner-body">
            <div class="page-title">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <h2><span>Our</span> Hiring</h2>
                            <div class="filter-list">
                                <div class="select-drop">
                                    <select>
                                        <option>Jobs</option>
                                        <option>01-02 Years </option>
                                        <option>01-03 Years </option>
                                        <option>04-06 Years </option>
                                        <option>07-10 Years</option>
                                    </select>
                                </div>
                                <div class="select-drop">
                                    <select>
                                        <option>Experience level</option>
                                        <option>01-02 Years </option>
                                        <option>01-03 Years </option>
                                        <option>04-06 Years </option>
                                        <option>07-10 Years</option>
                                    </select>
                                </div>
                                <div class="select-drop">
                                    <select>
                                        <option>Location</option>
                                        <option>01-02 Years </option>
                                        <option>01-03 Years </option>
                                        <option>04-06 Years </option>
                                        <option>07-10 Years</option>
                                    </select>
                                </div>
                                <button class="btn btn-primary">Refine</button>
                            </div>
                            <!-- <div class="filter-nav">
                                <ul class="nav nav-pills">
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">UX</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link active" href="#">India</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Europe</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">US</a>
                                    </li>
                                </ul>
                            </div> -->
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-12 hiring-main">
                        <h3 class="hiring-title">Open Positions</h3>
                        <div id="position-slider" class="owl-carousel owl-theme position-slider">
                            <div class="items">
                                <article>
                                    <h4>Jr. Graphic Desinger</h4>
                                    <span>Experience - 6 Years</span>
                                    <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout</p>
                                    <div class="tags">More: 
                                        <a href="">Team augmentation, </a>
                                        <a href="">technology agnostics, </a>
                                        <a href="">UI/UX, </a>
                                        <a href="">Apps & mobile, </a>
                                        <a href="">Integration</a>
                                    </div>
                                    <a class="know-btn" href="/position">Know More</a>
                                </article>
                                <article>
                                    <h4>Jr. Graphic Desinger</h4>
                                    <span>Experience - 6 Years</span>
                                    <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout</p>
                                    <div class="tags">More: 
                                        <a href="">Team augmentation, </a>
                                        <a href="">technology agnostics, </a>
                                        <a href="">UI/UX, </a>
                                        <a href="">Apps & mobile, </a>
                                        <a href="">Integration</a>
                                    </div>
                                    <a class="know-btn" href="/position">Know More</a>
                                </article>
                                <article>
                                    <h4>Jr. Graphic Desinger</h4>
                                    <span>Experience - 6 Years</span>
                                    <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout</p>
                                    <div class="tags">More: 
                                        <a href="">Team augmentation, </a>
                                        <a href="">technology agnostics, </a>
                                        <a href="">UI/UX, </a>
                                        <a href="">Apps & mobile, </a>
                                        <a href="">Integration</a>
                                    </div>
                                    <a class="know-btn" href="/position">Know More</a>
                                </article>
                                <article>
                                    <h4>Jr. Graphic Desinger</h4>
                                    <span>Experience - 6 Years</span>
                                    <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout</p>
                                    <div class="tags">More: 
                                        <a href="">Team augmentation, </a>
                                        <a href="">technology agnostics, </a>
                                        <a href="">UI/UX, </a>
                                        <a href="">Apps & mobile, </a>
                                        <a href="">Integration</a>
                                    </div>
                                    <a class="know-btn" href="/position">Know More</a>
                                </article>
                                <article>
                                    <h4>Jr. Graphic Desinger</h4>
                                    <span>Experience - 6 Years</span>
                                    <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout</p>
                                    <div class="tags">More: 
                                        <a href="">Team augmentation, </a>
                                        <a href="">technology agnostics, </a>
                                        <a href="">UI/UX, </a>
                                        <a href="">Apps & mobile, </a>
                                        <a href="">Integration</a>
                                    </div>
                                    <a class="know-btn" href="/position">Know More</a>
                                </article>
                                <article>
                                    <h4>Jr. Graphic Desinger</h4>
                                    <span>Experience - 6 Years</span>
                                    <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout</p>
                                    <div class="tags">More: 
                                        <a href="">Team augmentation, </a>
                                        <a href="">technology agnostics, </a>
                                        <a href="">UI/UX, </a>
                                        <a href="">Apps & mobile, </a>
                                        <a href="">Integration</a>
                                    </div>
                                    <a class="know-btn" href="/position">Know More</a>
                                </article>
                            </div>
                            <div class="items">
                                <article>
                                    <h4>Jr. Graphic Desinger</h4>
                                    <span>Experience - 6 Years</span>
                                    <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout</p>
                                    <div class="tags">More: 
                                        <a href="">Team augmentation, </a>
                                        <a href="">technology agnostics, </a>
                                        <a href="">UI/UX, </a>
                                        <a href="">Apps & mobile, </a>
                                        <a href="">Integration</a>
                                    </div>
                                    <a class="know-btn" href="/position">Know More</a>
                                </article>
                                <article>
                                    <h4>Jr. Graphic Desinger</h4>
                                    <span>Experience - 6 Years</span>
                                    <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout</p>
                                    <div class="tags">More: 
                                        <a href="">Team augmentation, </a>
                                        <a href="">technology agnostics, </a>
                                        <a href="">UI/UX, </a>
                                        <a href="">Apps & mobile, </a>
                                        <a href="">Integration</a>
                                    </div>
                                    <a class="know-btn" href="/position">Know More</a>
                                </article>
                                <article>
                                    <h4>Jr. Graphic Desinger</h4>
                                    <span>Experience - 6 Years</span>
                                    <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout</p>
                                    <div class="tags">More: 
                                        <a href="">Team augmentation, </a>
                                        <a href="">technology agnostics, </a>
                                        <a href="">UI/UX, </a>
                                        <a href="">Apps & mobile, </a>
                                        <a href="">Integration</a>
                                    </div>
                                    <a class="know-btn" href="/position">Know More</a>
                                </article>
                                <article>
                                    <h4>Jr. Graphic Desinger</h4>
                                    <span>Experience - 6 Years</span>
                                    <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout</p>
                                    <div class="tags">More: 
                                        <a href="">Team augmentation, </a>
                                        <a href="">technology agnostics, </a>
                                        <a href="">UI/UX, </a>
                                        <a href="">Apps & mobile, </a>
                                        <a href="">Integration</a>
                                    </div>
                                    <a class="know-btn" href="/position">Know More</a>
                                </article>
                                <article>
                                    <h4>Jr. Graphic Desinger</h4>
                                    <span>Experience - 6 Years</span>
                                    <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout</p>
                                    <div class="tags">More: 
                                        <a href="">Team augmentation, </a>
                                        <a href="">technology agnostics, </a>
                                        <a href="">UI/UX, </a>
                                        <a href="">Apps & mobile, </a>
                                        <a href="">Integration</a>
                                    </div>
                                    <a class="know-btn" href="/position">Know More</a>
                                </article>
                                <article>
                                    <h4>Jr. Graphic Desinger</h4>
                                    <span>Experience - 6 Years</span>
                                    <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout</p>
                                    <div class="tags">More: 
                                        <a href="">Team augmentation, </a>
                                        <a href="">technology agnostics, </a>
                                        <a href="">UI/UX, </a>
                                        <a href="">Apps & mobile, </a>
                                        <a href="">Integration</a>
                                    </div>
                                    <a class="know-btn" href="/position">Know More</a>
                                </article>
                            </div>
                        </div>
                        <p class="hiring-pera">Interested Candidates may send their resume on <a href="mailto:career@txtech.co">career@txtech.co</a></p>
                    </div>
                </div>
            </div>
            
        </section>
    </body>
    <script src="/js/jquery.js"></script>
    <script src="/js/app.js"></script>
    <script src="/js/owl.carousel.min.js"></script>
    <script src="/js/front-main.js"></script>
</html>
