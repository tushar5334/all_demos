<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="theme-color" content="#031C2B" />

        <title>TxLabs.co | Lead UX Designer Ahmedabad - 5-8 years</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="/css/front/front.css">
        <!-- Styles -->
        
    </head>
    <body>
        <header class="header inner-header">
            @include('common.header')
        </header>
        <section class="inner-body">
            <div class="page-title">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <h2 class="column-lines">
                                Lead UX Designer
                                <span>Ahmedabad - 5-8 years <em>&#9679;</em> Multiple locations <em>&#9679;</em> Posted on: 19/8/2020</span>
                            </h2>
                            <div class="filter-nav">
                                <ul class="nav nav-pills">
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">UX</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Illustrator</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Sketch</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container position-main">
                <div class="row justify-content-between">
                    <div class="col-12 ">
                        <div class="space15"></div>
                        <p>Experience Required: <b>4+ Years</b> </p>
                        <p>Location: <b>Ahmedabad, Full-time</b></p>
                        <div class="space15"></div>
                        <p><span>Drive inbound & outbound sales for our services with highest level of integrity.</span></p>
                        <div class="space15"></div>
                    </div>
                    <div class="col-md-7 col-lg-6">
                        <figure>
                            <h4>Role :</h4>
                            <ul>
                                <li>Plan & generate leads for our services. </li>
                                <li>Identify potential clients & setup meetings. </li>
                                <li>Understand scope, prepare proposals & give presentations. </li>
                                <li>Build long term partnerships & business relationships with clients. </li>
                                <li>Achieve revenue targets on quarterly basis. </li>
                                <li>Work closely with content & design team.</li>
                            </ul>
                        </figure>
                        <div class="space15"></div>
                        <figure>
                            <h4>Experience & Mindset :</h4>
                            <ul>
                                <li>4+ years in IT services/design sales experience across geographies. </li>
                                <li>You possess an outstanding eye for detail & speed. </li>
                                <li>Must have excellent working knowlegde on Google Slides, CRM, mailing lists etc. </li>
                                <li>You are comfortable with both planning & executing things. </li>
                                <li>You have a proactive nature that enables you to meet deadlines & targets. </li>
                                <li>You possess excellent written & verbal communication skills. </li>
                                <li>You must like design & show a flair towards it.</li>
                            </ul>
                        </figure>
                        <div class="space15"></div>
                    </div>
                    <div class="col-md-5 col-lg-3">
                        <p><span>Mail your resume to:</span> </p>
                        <a class="mailID" href="mailto:careers@txlabs.com">careers@txlabs.com</a>
                        <div class="space15"></div>
                    </div>
                    <div class="col-12">
                        <a class="btn btn-primary btn-rounded" href="#">Apply Now</a>
                        <div class="space15"></div>
                    </div>
                    <div class="msg-sec">
                        <div class="chat-popup">
                            <div class="chat-header">
                                <h5>We are Online</h5>
                                <div class="admin-id">
                                    <div class="admin">
                                        <img src="/images/icons/user.svg" alt="">
                                        <b class="status"></b>
                                    </div>
                                    <span>Jalpa Kande</span>
                                </div>
                            </div>
                            <div class="chat-body">
                                <div class="chat-container">
                                    <div class="incomming">
                                        <div class="user-details">
                                            <img class="user-img" src="/images/icons/user2.svg" alt="">
                                            <p class="user-name">Jalpa Kande</p>
                                        </div>
                                        <div class="chat">
                                            <div class="msg"> Welcome</div>
                                            <span class="timing">Aug 6,2020. 4:44 PM</span>    
                                        </div>
                                        <div class="chat">
                                            <div class="msg">Hey there 👋 <br>   
                                            Thank you checking txlabs.co <br>
                                            Select the topic or write your question below</div>
                                            <span class="timing">Aug 6,2020. 4:44 PM</span>
                                        </div>
                                    </div>
                                    <div class="quick-chats">
                                        <a class="select-chat" href="#">Yes I have a question</a>
                                        <a class="select-chat" href="#">Just Browsing</a>
                                        <a class="select-chat" href="#">Request a callback</a>
                                        <a class="select-chat" href="#">Something else</a>
                                        <a class="select-chat" href="#">Request a Service</a>
                                        <a class="select-chat" href="#">Inquiry</a>
                                    </div>
                                </div>
                                <div class="chat-area">
                                    <div class="chat-options">
                                        <label class="chat-option"><img src="/images/icons/attach.svg" alt=""></label>
                                        <a class="chat-option" href="#"><img src="/images/icons/smile.svg" alt=""></a>
                                    </div>
                                    <input type="text" class="enter-chat" name="" placeholder="Type here and press enter..." id="">
                                </div>
                            </div>
                        </div>
                        <!-- <div class="chat-popup">
                            <div class="chat-header">
                                <h5>We are Online</h5>
                                <p>Please fill out the form below to start chatting with the next available agent.</p>
                            </div>
                            <div class="chat-body">
                                <form>
                                    <div class="form-group">
                                    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                    </div>
                                    <div class="form-group">
                                        <input type="password" placeholder="Name" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <input type="password" placeholder="Email" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <input type="password" placeholder="Phone Number" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <textarea class="form-control" placeholder="Message"></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Start Chat</button>
                                </form>
                            </div>
                        </div> -->
                        <a href="#" class="msg-icon">
                            <img class="chat-open" width="20px" src="/images/icons/chat.svg" alt="">
                            <img class="chat-close" width="20px" src="/images/icons/close.svg" alt="">
                        </a>
                    </div>
                </div>
            </div>
            
        </section>
    </body>
    <script src="/js/jquery.js"></script>
    <script src="/js/app.js"></script>
    <script src="/js/owl.carousel.min.js"></script>
    <script src="/js/front-main.js"></script>
</html>
