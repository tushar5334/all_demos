<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="theme-color" content="#031C2B" />

        <title>TxLabs.co | SEO & Digital Marketing</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="/css/front/front.css">
        <!-- Styles -->
        
    </head>
    <body>
        <header class="header inner-header">
            @include('common.header')
        </header>
        <section class="inner-body">
            <div class="page-title">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <h2><b><img src="/images/icons/service4.svg" alt=""></b> SEO & Digital Marketing</h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container services-details">
                <div class="row">
                    <div class="col-12 services-details-top">
                        <h4>PROVEN PROCESS. TALENTED PEOPLE. DELIVERING RESULTS.</h4>
                        <p>Our experience encompasses a variety of skillsets, delivered rapidly with agile methodology for maximum business impact.</p>
                    </div>
                    <div class="col-md-6 col-lg-4 services-details-list">
                        <span><img src="/images/icons/service-details1.svg" alt=""></span>
                        <h5>On-page</h5>
                        <p>Proin ac quam et lectus vestibulum blandit. Nunc maximus nibh at placerat tincidunt. Nam sem lacus, ornare non ante sed, ultricies fringilla massa. Ut congue, elit non tempus elementum, sem risus tincidunt diam, vitae sodales diam </p>
                        <div class="tags">More: 
                            <a href="">Google adwords, </a>
                            <a href="">google key words, </a>
                            <a href="">google tags, </a>
                            <a href="">google analytics, </a>
                            <a href="">On PAge SEO,</a>
                            <a href="">Off Page SEO</a>
                        </div>
                        <a class="read-btn" href="#">Explore Case studies  <img src="/images/icons/feather-arrow-right.svg" alt=""></a>
                    </div>
                    <div class="col-md-6 col-lg-4 services-details-list">
                        <span><img src="/images/icons/service-details1.svg" alt=""></span>
                        <h5>off-page</h5>
                        <p>Proin ac quam et lectus vestibulum blandit. Nunc maximus nibh at placerat tincidunt. Nam sem lacus, ornare non ante sed, ultricies fringilla massa. Ut congue, elit non tempus elementum, sem risus tincidunt diam, vitae sodales diam </p>
                        <div class="tags">More: 
                            <a href="">Google Tag Manager, </a>
                            <a href="">Facebook marketing, </a>
                            <a href="">Social media marketing and posting, </a>
                            <a href="">social media </a>
                        </div>
                        <a class="read-btn" href="#">Explore Case studies  <img src="/images/icons/feather-arrow-right.svg" alt=""></a>
                    </div>

                    <div class="col-md-6 col-lg-4 services-details-list">
                        <span><img src="/images/icons/service-details1.svg" alt=""></span>
                        <h5>technical</h5>
                        <p>Proin ac quam et lectus vestibulum blandit. Nunc maximus nibh at placerat tincidunt. Nam sem lacus, ornare non ante sed, ultricies fringilla massa. Ut congue, elit non tempus elementum, sem risus tincidunt diam, vitae sodales diam </p>
                        <div class="tags">More: 
                            <a href="">Google Keywork analytics, </a>
                            <a href="">Competitor Analysis, </a>
                            <a href="">Google Keywork analytics, </a>
                            <a href="">Competitor Analysis </a>
                        </div>
                        <a class="read-btn" href="#">Explore Case studies  <img src="/images/icons/feather-arrow-right.svg" alt=""></a>
                    </div>
                    
                    <div class="col-md-6 col-lg-4 services-details-list">
                        <span><img src="/images/icons/service-details18.svg" alt=""></span>
                        <h5>Social media marketing</h5>
                        <p>ensure you are present on the platforms your users are spending the most time on. Including Facebook, Twitter, LinkedIn, Snapchat, and Instagram, distributing content. Enable two-way communication so your customers can interact with you on your content through likes, comments, direct messages, or by posting on your official pages.</p>
                        <div class="tags">More: 
                            <a href="">Google Keywork analytics, </a>
                            <a href="">Competitor Analysis, </a>
                            <a href="">Google Keywork analytics, </a>
                            <a href="">Competitor Analysis </a>
                        </div>
                        <a class="read-btn" href="#">Explore Case studies  <img src="/images/icons/feather-arrow-right.svg" alt=""></a>
                    </div>
                    <div class="col-md-6 col-lg-4 services-details-list">
                        <span><img src="/images/icons/service-details19.svg" alt=""></span>
                        <h5>affiliate marketing</h5>
                        <p>similar to commission-based sales. You can provide custom links to affiliates. Affiliates earn a specific cut/commission every time someone buys through their custom link. Influence marketing could be considered a modern and evolved spin-off of affiliate marketing.</p>
                        <div class="tags">More: 
                            <a href="">Influencer marketing, </a>
                            <a href="">facebook, </a>
                            <a href="">google analytics, </a>
                            <a href="">facebook pixel, </a>
                            <a href="">instagram, </a>
                            <a href="">Facebook marketing</a>
                        </div>
                        <a class="read-btn" href="#">Explore Case studies  <img src="/images/icons/feather-arrow-right.svg" alt=""></a>
                    </div>
                    <div class="col-md-6 col-lg-4 services-details-list">
                        <span><img src="/images/icons/service-details20.svg" alt=""></span>
                        <h5>conversational ai</h5>
                        <p>Technologies such as artificial intelligence (AI) and machine learning (ML) enable more evolved marketing strategies such as conversational AI. As the adoption of voice search, chatbots, and digital assistants becomes prevalent, conversational AI becomes vital to digital marketing.</p>
                        <div class="tags">More: 
                            <a href="">Google Tag Manager, </a>
                            <a href=""> Facebook marketing, </a>
                            <a href="">Social media marketing and posting, </a>
                            <a href="">social media </a>
                        </div>
                        <a class="read-btn" href="#">Explore Case studies  <img src="/images/icons/feather-arrow-right.svg" alt=""></a>
                    </div>
                </div>
            </div>
            <div class="pos-bottom">
                <div class="logo-slider">
                    <div class="container">
                        <div class="row">
                            @include('common.logo-slider')   
                        </div>
                    </div>
                </div>
                @include('common.services-footer')
            </div>
        </section>
    </body>
    <script src="/js/jquery.js"></script>
    <script src="/js/app.js"></script>
    <script src="/js/owl.carousel.min.js"></script>
    <script src="/js/front-main.js"></script>
</html>
