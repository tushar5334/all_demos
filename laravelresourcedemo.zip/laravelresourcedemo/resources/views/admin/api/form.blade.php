@extends('admin.include.layout')

@section('content')


<!-- Main content -->
<div class="main-container">
  <div class="container-fluid">
	<div class="row">
	  <div class="col-md-6 col-12">
		<div class="site-breadcrumb">
			<ul>
			  <li><a href="/admin">Dashboard</a></li>
			  <li>API simulator</li>
			</ul>
		</div>
	  </div>
	</div>
	<div class="row">
		<div class="col-12">
			<div class="card card-main">
				{{-- <div class="card-header  header-sm">
					<div class="card-title">API simulator</div>
				</div> --}}
				<form action="{{ route('api.form') }}" method="POST" enctype="multipart/form-data">
					<div class="card-body">

						<input type="hidden" name="_token" value="{{ csrf_token() }}">
						<input type="hidden" id="selectedAPI" name="selectedAPI" value="">

						<div class="row">
							<div class="col-lg-2 col-md-6">
								<div class="form-group is-filled select-grp">
									<label class="bmd-label-floating"> Select API </label>
									<div class="select-drop">
										<select class="form-control" name="api_links" id="api_links">
											<option value=""> SELECT API </option>
											@if(isset($dropDownArr) && isset($dropDownArr['api']['options']))
											@foreach($dropDownArr['api']['options'] as $key => $value)
												<option value="{{$key}}" > {{$value}}</option>
											@endforeach
											@endif
										</select>
									</div>
								</div>
							</div>

							<div class="col-lg-10 col-12" id="SubAPI" style="display:none">
								<div class="row">
									@if(isset($dropDownArr) && isset($dropDownArr['request']['options']['SubAPI']))
										@foreach ($dropDownArr['request']['options']['SubAPI'] as $key => $item)

										@if($key=='serviceid')
											<div class="col-lg col-md-6 col-6">
												<div class="form-group">
													<label class="bmd-label-floating"> {{ lcfirst(strtolower($key)) }}</label>
													<select name="SubAPI[{{$key}}]" class="form-control">
														@if(isset($dropDownArr) && isset($dropDownArr['serviceidList']['options']))
														@foreach($dropDownArr['serviceidList']['options'] as $key => $value)
															<option value="{{$value['product_code']}}"  {{ (isset($item) && $value['product_code'] == $item) ? 'selected' : '' }}> {{$value['product_code']}}</option>
														@endforeach
														@endif
													</select>
												</div>
											</div>
										@elseif($key=='chnl')
											<div class="col-lg col-md-6 col-6">
												<div class="form-group">
													<label class="bmd-label-floating"> {{ lcfirst(strtolower($key)) }}</label>
													<select name="SubAPI[{{$key}}]" class="form-control">
														@if(isset($dropDownArr) && isset($dropDownArr['chnlList']['options']))
														@foreach($dropDownArr['chnlList']['options'] as $key => $value)
															<option value="{{$value}}"  {{ (isset($item) && $value == $item) ? 'selected' : '' }}> {{$value}}</option>
														@endforeach
														@endif
													</select>
												</div>
											</div>
										@else
											<div class="col-lg col-md-6 col-6">
												<div class="form-group">
												<label class="bmd-label-floating">{{ lcfirst(strtolower($key)) }} </label>
												<input type="text" name="SubAPI[{{$key}}]" class="form-control"  value="{{$item}}">
												@if($key === 'msisdn')
													<p id="SubAPIInvalid_msisdn" class="help-block text-danger"></p>
												@endif
												</div>
											</div>
										@endif
										@endforeach
									@endif
								</div>
							</div>

							<div class="col-lg-10 col-12" id="CheckStatus" style="display:none">
								<div class="row">
									@if(isset($dropDownArr) && isset($dropDownArr['request']['options']['CheckStatus']))
										@foreach ($dropDownArr['request']['options']['CheckStatus'] as $key => $item)

											@if($key=='serviceid')
												<div class="col-lg col-md-6 col-6">
													<div class="form-group">
														<label class="bmd-label-floating"> {{ lcfirst(strtolower($key)) }}</label>
														<select name="CheckStatus[{{$key}}]" class="form-control">
															@if(isset($dropDownArr) && isset($dropDownArr['serviceidList']['options']))
															@foreach($dropDownArr['serviceidList']['options'] as $key => $value)
																<option value="{{$value['product_code']}}"  {{ (isset($item) && $value['product_code'] == $item) ? 'selected' : '' }}> {{$value['product_code']}}</option>
															@endforeach
															@endif
														</select>
													</div>
												</div>
											@else
												<div class="col-lg col-md-6 col-6">
													<div class="form-group">
														<label class="bmd-label-floating"> {{ lcfirst(strtolower($key)) }}</label>
														<input type="text" name="CheckStatus[{{$key}}]" class="form-control"  value="{{$item}}">
														@if($key === 'msisdn')
															<p id="CheckStatusInvalid_msisdn" class="help-block text-danger"></p>
														@endif
													</div>
												</div>
											@endif

										@endforeach
									@endif

								</div>
							</div>

							<div class="col-lg-10 col-12"  id="UnsubAPI" style="display:none">
								<div class="row">
									@if(isset($dropDownArr) && isset($dropDownArr['request']['options']['UnsubAPI']))

										@foreach ($dropDownArr['request']['options']['UnsubAPI'] as $key => $item)

										@if($key=='serviceid')
											<div class="col-lg col-md-6 col-6">
												<div class="form-group">
													<label class="bmd-label-floating"> {{ lcfirst(strtolower($key)) }}</label>
													<select name="UnsubAPI[{{$key}}]" class="form-control">
														@if(isset($dropDownArr) && isset($dropDownArr['serviceidList']['options']))
														@foreach($dropDownArr['serviceidList']['options'] as $skey => $svalue)
															<option value="{{$svalue['product_code']}}"  {{ (isset($item) && $svalue['product_code'] == $item) ? 'selected' : '' }}> {{$svalue['product_code']}}</option>
														@endforeach
														@endif
													</select>
												</div>
											</div>
										@elseif($key=='chnl')
											<div class="col-lg col-md-6 col-6">
												<div class="form-group">
													<label class="bmd-label-floating">{{ lcfirst(strtolower($key)) }}</label>
													<select name="UnsubAPI[{{$key}}]" class="form-control">
														@if(isset($dropDownArr) && isset($dropDownArr['chnlList']['options']))
														@foreach($dropDownArr['chnlList']['options'] as $chkey => $chvalue)
															<option value="{{$chvalue}}"  {{ (isset($item) && $chvalue == $item) ? 'selected' : '' }}> {{$chvalue}}</option>
														@endforeach
														@endif
													</select>
												</div>
											</div>
										@else
										<div class="col-lg col-md-6 col-6">
											<div class="form-group">
											<label class="bmd-label-floating"> {{ lcfirst(strtolower($key)) }}</label>
											<input type="text" name="UnsubAPI[{{$key}}]" class="form-control"  value="{{$item}}">
											@if($key === 'msisdn')
												<p id="UnsubAPIInvalid_msisdn" class="help-block text-danger"></p>
											@endif
											</div>
										</div>
										@endif

										@endforeach
									@endif
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-12 mb-3">
							<button type="button" id="submitForm" class="btn btn-primary">Submit</button>&nbsp;
							<a href="/admin" class="btn btn-default">Cancel</a>
							</div>
						</div>

						<div class="row">
							<div class="col-sm-12">
								<div class="card card-main" id="response" style="display: none">
									<div class="card-header">
										<div class="card-title">Response</div>
									</div>
									<div class="display_result">
									</div>
								</div>
							</div>
						</div>



					</div>
				</form>
			</div>
		</div>
	</div>



  </div>
</div>


<script>
    $(function () {
		/* **********************************************
		** on select api
		********************************************** */
		$('#submitForm').prop('disabled', true);

		$('#api_links').on('change', function () {
			$('p[id*="SubAPIInvalid_"]').html("");
			$('p[id*="CheckStatusInvalid_"]').html("");
			$('p[id*="UnsubAPIInvalid_"]').html("");
			var selectedText = $("#api_links option:selected").html();
			selectedText = selectedText.split(" ").join("");

			$('#CheckStatus').hide();
			$('#SubAPI').hide();
			$('#UnsubAPI').hide();
			$('#'+selectedText).show();

			$('#selectedAPI').val(selectedText);

			// HIDE RESPONSE
			$('#response').hide();
			$('.display_result').html('');

			// Disable or Enable button
			if(this.value){
				$('#submitForm').prop('disabled', false);
			} else {
				$('#submitForm').prop('disabled', true);
			}

		});

		/* **********************************************
		** Response API
		********************************************** */
        $('#submitForm').on('click', function(e) {
			$('#submitForm').prop('disabled', true);
			$('#response').show();

            // e.preventDefault();
			var data = $('form').serialize();
            var addAPIUrl = "/admin/api/simulator";
            $.ajax({
                url: addAPIUrl,
                type: 'POST',
				data:data,
				beforeSend: function () {
					$('.display_result').html('<div style="text-align:center; padding:10px">Loading...</div>');
				},
				success: function (res) {
					$('#submitForm').prop('disabled', false);
					$('p[id*="SubAPIInvalid_"]').html("");
					$('p[id*="CheckStatusInvalid_"]').html("");
					$('p[id*="UnsubAPIInvalid_"]').html("");
                    if(res && res.success) {
						// $('#response').show();
						let responseData = res.data;
						responseData = JSON.stringify(responseData, null, 4);
						$('.display_result').html('<pre>'+responseData+'</pre>');
                    //   notification('success', res.message);
                    } else {

                		 if(typeof res.message === 'object'){
	                        $.each(res.message, function( index, value ) {
	                        	console.log(index, value)
	                          $('#SubAPIInvalid_'+index).html(value);
	                          $('#CheckStatusInvalid_'+index).html(value);
	                          $('#UnsubAPIInvalid_'+index).html(value);
	                        });
	                      }

						$('.display_result').html('No response available.');
					}
                },
                error: function(xhr) {
                    notification('error', res.message);
                }
            });
        });

	});
</script>

@stop

