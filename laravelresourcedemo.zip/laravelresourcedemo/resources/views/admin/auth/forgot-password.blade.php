@extends('admin.auth.layout')
@section('content')
    <div class="login-page">
        <div class="login-cell">
            <div class="container-fluid">
                <div class="row justify-content-md-center">
                    <div class="col col-lg-5">
                        <a class="login-logo" href="#">
                            <img src="/images/txlabs.png" alt="">
                        </a>
                        <div class="card login-container">
                            <div class="card-body">
                                <h5 class="card-title">Forgot Password</h5>
                                <p class="forgot-details">Please enter your email address to request a password reset.</p>
                                <!-- @if($errors->has('general_error'))
                                    <div class="alert alert-danger alert-dismissible">
                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                        <h4><i class="icon fa fa-check"></i> Error</h4>
                                        {{ $errors->first('general_error') }}
                                    </div>
                                @endif -->

                                <form method="post">
                                    {{ csrf_field() }}                                           
                                    <div class="form-group">
                                        <label>Email Address <span class="text-danger">*</span></label>
                                        <input type="email" class="form-login {{$errors->has('email') ? 'is-invalid' : ''}}" placeholder="Please enter email address" name="email" value="{{ old('email') }}">
                                        @if ($errors->has('email')) <p class="help-block text-danger">{{ $errors->first('email') }}</p> @endif

                                        {{-- @if ($errors->has('email'))
                                        <span class="help-block text-danger">
                                            <strong>{{ $errors->first('email') }}</strong>
                                        </span>
                                        @endif --}}
                                    </div>

                                    <div class="space30"></div>
                                    
                                    <div class="row">
                                        <div class="col-md-12 mb-3">
                                        <button type="submit" class="btn btn-primary">RESET PASSWORD</button>
                                        <a href="/" class="btn btn-default">Cancel</a>
                                        </div>
                                    </div>

                                </form>
                                
                            </div>
                        </div>
                    </div> 
                </div>
            </div>
        </div>
    </div>
@stop