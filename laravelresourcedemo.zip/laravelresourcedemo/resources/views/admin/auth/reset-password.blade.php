@extends('admin.auth.layout')
@section('content')
            <div class="login-page">
                <div class="login-cell">
                    <div class="container-fluid">
                        <div class="row justify-content-md-center">
                            <div class="col col-lg-5">
                                <a class="login-logo" href="#">
                                  <img src="/images/txlabs.png" alt="">
                                </a>
                                <div class="card login-container">
                                    <div class="card-body">
                                      <h5 class="card-title">Reset Password</h5>

                                        <!-- @if(session()->has('success'))
                                            <div class="alert alert-success alert-dismissible">
                                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                                <h4><i class="icon fa fa-check"></i> Success</h4>
                                                {{ session()->get('success') }}
                                            </div>
                                        @endif -->

                                        <!-- @if($errors->has('general_error'))
                                            <div class="alert alert-danger alert-dismissible">
                                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                                <h4><i class="icon fa fa-check"></i> Error</h4>
                                                {{ $errors->first('general_error') }}
                                            </div>
                                        @endif
                                        -->
                                        
                                        <form method="post">
                                          {{ csrf_field() }}                                           
                                            <input type="hidden" class="form-login" name="token" value="{{ collect(request()->segments())->last() }}">
                                            
                                            <div class="form-group">
                                                <label>Passowrd <span class="text-danger">*</span></label>
                                                <input type="password" class="form-login {{$errors->has('password') ? 'is-invalid' : ''}}" name="password" placeholder="Please enter password">
                                                @if ($errors->has('password')) <p class="help-block text-danger">{{ $errors->first('password') }}</p> @endif

                                                {{-- @if ($errors->has('password'))
                                                    <span class="help-block text-danger">
                                                        <strong>{{ $errors->first('password') }}</strong>
                                                    </span>
                                                @endif --}}
                                            </div>

                                            <div class="form-group">
                                                <label>Confirm Passowrd <span class="text-danger">*</span></label>
                                                <input type="password" class="form-login {{$errors->has('password_confirmation') ? 'is-invalid' : ''}}" name="password_confirmation" placeholder="Please enter confirm password">
                                                @if ($errors->has('password_confirmation')) <p class="help-block text-danger">{{ $errors->first('password_confirmation') }}</p> @endif

                                                {{-- @if ($errors->has('password'))
                                                    <span class="help-block text-danger">
                                                        <strong>{{ $errors->first('password_confirmation') }}</strong>
                                                    </span>
                                                @endif --}}
                                            </div>

                                            <div class="space30"></div>
                                            <!-- <button type="submit" class="btn btn-primary">Reset Password</button> -->
                                            <div class="row">
                                                <div class="col-md-12 mb-3">
                                                <button type="submit" class="btn btn-primary">RESET PASSWORD</button>
                                                <a href="/" class="btn btn-default">Cancel</a>
                                                </div>
                                            </div>    
                                        </form>
                                        
                                    </div>
                                </div>
                            </div> 
                        </div>
                    </div>
                </div>
            </div>
@stop