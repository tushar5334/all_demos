@extends('admin.auth.layout')
@section('content')
    <div class="login-page">
        <div class="login-cell">
            <div class="container-fluid">
                <div class="row justify-content-md-center">
                    <div class="col col-lg-5">
                        <a class="login-logo" href="#">
                            <img src="/images/txlabs.png" alt="">
                        </a>
                        <div class="card login-container">
                            <div class="card-body">
                                <h5 class="card-title">SIGN IN</h5>

                                <!-- @if(session()->has('success'))
                                    <div class="alert alert-success alert-dismissible">
                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                        <h4><i class="icon fa fa-check"></i> Success</h4>
                                        {{ session()->get('success') }}
                                    </div>
                                @endif -->
                                
                                <form method="post">
                                    {{ csrf_field() }}                                           

                                    <div class="form-group">
                                        <label>Username <span class="text-danger">*</span></label>
                                        <input type="email" class="form-login {{$errors->has('email') ? 'is-invalid' : ''}}" placeholder="Please enter username" name="email" value="{{ old('email') }}">
                                        @if ($errors->has('email')) <p class="help-block text-danger">{{ $errors->first('email') }}</p> @endif

                                        {{-- @if ($errors->has('email'))
                                        <span class="help-block text-danger">
                                            <strong>{{ $errors->first('email') }}</strong>
                                        </span>
                                        @endif --}}
                                    </div>

                                    <div class="form-group">
                                        <label>Password <span class="text-danger">*</span></label>
                                        <input type="password" class="form-login {{$errors->has('password') ? 'is-invalid' : ''}}" name="password" placeholder="Please enter password">
                                        @if ($errors->has('password')) <p class="help-block text-danger">{{ $errors->first('password') }}</p> @endif

                                        {{-- @if ($errors->has('password'))
                                            <span class="help-block text-danger">
                                                <strong>{{ $errors->first('password') }}</strong>
                                            </span>
                                        @endif --}}
                                        <a class="forgot-link" href="{!! route('admin.forgot-password') !!}">Forgot password?</a>
                                        {{-- <a class="forgot-link" href="{!! route('organisations.index', ['menu' => 'p11-c3']) !!}">forgot password?</a>--}}
                                    </div>
                                    <div class="space30"></div>
                                    <button type="submit" class="btn btn-primary">SIGN IN</button>
                                </form>
                                
                            </div>
                        </div>
                    </div> 
                </div>
            </div>
        </div>
    </div>
@stop