@extends('admin.include.layout')
@section('content')

 
<!-- Main content -->
<div class="main-container">
  <div class="container-fluid">    
    <div class="row">
      <div class="col-md-6 col-12">
        <div class="site-breadcrumb">
            <ul>
              <li><a href="/admin/testimonial">Testimonial</a></li>
              <li>@if((isset($data)) && $data->testimonial_id) Edit @else Add @endif Testimonial</li>
            </ul>
        </div>
      </div>
    </div>
    <div class="row"> 
        <div class="col-12">
          <div class="card card-main">
         <form id="testimonialForm" method="POST" action="{{ !empty($data->testimonial_id) ? route('testimonial.update', $data) : route('testimonial.store') }}" enctype="multipart/form-data">
                  {{ !empty($data->testimonial_id) ? method_field('PUT') :  method_field('POST') }}
              <div class="card-body">
                @csrf  
                <input id="testimonial_id" type="hidden" name="testimonial_id" value="{{ isset($data) ? $data->testimonial_id : '' }}">
                <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group is-focused select-grp">
                    <label class="bmd-label-floating">Project Name <span class="text-danger">*</span></label>    
                    <div class="select-drop">
                      <select class="form-control {{$errors->has('project_id') ? 'is-invalid' : ''}}" name="project_id" id="project_id">
                        <option value=""> Select Project Name </option>
                        @if(isset($ListOfProject) && !empty($ListOfProject))
                        @foreach($ListOfProject as $Project)
                          <option value="{{$Project->project_id}}" {{ old('project_id',$data->project_id) == $Project->project_id ? 'selected' : '' }}> {{$Project->project_name}} </option>
                        @endforeach
                        @endif
                      </select>                
                    </div>          
                    @if ($errors->has('project_id')) <p class="help-block text-danger">{{ $errors->first('project_id') }}</p> @endif                        
                    </div>
                  </div>                                                            
                  <div class="col-sm-6">                                        
                    <div class="form-group">
                    <label class="bmd-label-floating"> Testimonial User Name <span class="text-danger">*</span></label>
                    <input type="text" name="testimonial_user_name" class="form-control {{$errors->has('testimonial_user_name') ? 'is-invalid' : ''}}" value="{{ old('testimonial_user_name',$data->testimonial_user_name) }}">
                    @if ($errors->has('testimonial_user_name')) <p class="help-block text-danger">{{ $errors->first('testimonial_user_name') }}</p> @endif
                    </div>
                  </div>                                                            
                </div>
                <div class="row">
                  <div class="col-sm-6">                                        
                    <div class="form-group">
                    <label class="bmd-label-floating"> Testimonial User Position </label>
                    <input type="text" name="testimonial_user_position" class="form-control {{$errors->has('testimonial_user_position') ? 'is-invalid' : ''}}" value="{{ old('testimonial_user_position',$data->testimonial_user_position) }}">                                           
                    @if ($errors->has('testimonial_user_position')) <p class="help-block text-danger">{{ $errors->first('testimonial_user_position') }}</p> @endif
                    </div>
                  </div>                                                            
                 <div class="col-sm-6">  
                    <div class="form-group">
                      <label class="bmd-label-floating">Status </label> </br>
                      <div class="radio">
                          <label>
                            <input class="form-control" type="radio" name="status" id="active" value="1"{{ old('status',isset($data->status) ? $data->status : '') == "1" ? 'checked' : '' }} checked>
                            <span class="ml-4 font-weight-normal">&nbsp;Active</span>
                          </label>
                          &nbsp;&nbsp;
                          <label>
                            <input class="form-control" type="radio" name="status" id="inactive" value="0" {{ old('status',isset($data->status) ? $data->status : '') == "0" ? 'checked' : '' }}>
                            <span class="ml-4 font-weight-normal">&nbsp;InActive</span>
                          </label>
                      </div>
                      @if ($errors->has('status')) <p class="help-block text-danger">{{ $errors->first('status') }}</p> @endif 
                    </div>
                  </div>                                                            
                </div>
                <div class="row">                                                         
                  <div class="col-sm-6">                                        
                    <div class="form-group">
                      <label><strong>Testimonial Description </strong></label></br>
                      <textarea class="ckeditor form-control" name="testimonial_description" id="testimonial_description">{!!  old('testimonial_description',$data->testimonial_description) !!}</textarea>
                       @if ($errors->has('testimonial_description')) <p class="help-block text-danger">{{ $errors->first('testimonial_description') }}</p> @endif
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label for="profilePicture">Testimonial Image</label>
                      <div class="userimg-sec drop-rectangle">
                        <div class="img-dropbox">
                            <label for="profile-img">
                              <span class="file-msg">
                                <img src="/images/icons/upload.svg" width="50" alt="">
                                <strong>Drag and drop your image here</strong>
                              </span>
                              <input class="upload-profilepic {{$errors->has('testimonial_image') ? 'is-invalid' : ''}}" data-preview="#preview" name="testimonial_image" type="file" id="testimonialImage">
                            </label>
                        </div>
                        @if(isset($data) && $data->testimonial_image )
                          <div class="prod-img">
                            <img id="preview" width="100" src="{{ $data->testimonial_image}}">
                          </div>
                        @endif
                      </div>
                    @if ($errors->has('testimonial_image')) <p class="help-block text-danger">{{ $errors->first('testimonial_image') }}</p> @endif                            
                                                    
                    </div>
                  </div>                                                          
                </div>
                <div class="row">
                  <div class="col-md-12 mb-3">
                  <button type="submit" class="btn btn-primary">Submit</button>&nbsp;
                  <a href="/admin/testimonial" class="btn btn-default">Cancel</a>
                  </div>
                </div>

              </div> 
            </form>

          </div>
        </div>
    </div>
  </div>
</div>
  
<script>
/* window.onload = function() {
 CKEDITOR.replace( 'description', {
    extraPlugins: 'easyimage',
    removePlugins: 'image',
    // cloudServices_tokenUrl: 'https://example.com/cs-token-endpoint',
    // cloudServices_uploadUrl: 'https://your-organization-id.cke-cs.com/easyimage/upload/'
} );
}; */
//CKEDITOR.replace( 'description' );
CKEDITOR.replace( 'testimonial_description', {
    extraPlugins: 'easyimage',
    removePlugins: 'image',
} );
//$('#description').ckeditor();
</script>

@stop

