@extends('admin.include.layout')
@section('content')
<div class="main-container">
   <div class="container-fluid">
      <div class="row">
         <div class="col-md-6 col-12">
            <div class="site-breadcrumb">
               <ul>
                  <li><a href="/admin/cms">Category</a></li>
                  <li>@if((isset($data)) && $data->category_id) Edit @else Add @endif Category</li>
               </ul>
            </div>
         </div>
      </div>
      <div class="row">
         <div class="col-12">
            <div class="card card-main">
               <form id="cmsForm" method="POST" action="{{ !empty($data->category_id) ? route('category.update', $data) : route('category.store') }}" enctype="multipart/form-data">
                  {{ !empty($data->category_id) ? method_field('PUT') :  method_field('POST') }}
                  <div class="card-body">
                     @csrf
                     <input id="hiring_id" type="hidden" name="category_id" value="{{ isset($data) ? $data->category_id : '' }}">
                     <div class="row">
                        <div class="col-sm-6">
                           <div class="form-group select-grp bmd-form-group is-filled">
                              <label class="bmd-label-floating">Parent Category</label>
                              <div class="select-drop">
                                 <select name="parent_category_id" class="form-control {{$errors->has('parent_category_id') ? 'is-invalid' : ''}}">
                                    <option value=""> Select Parent Category </option>
                                    @isset($categoryList)
                                    @foreach($categoryList AS $category)
                                    <option value="{{$category['category_id']}}" {{ old('parent_category_id',$data->parent_category_id) == $category['category_id'] ? 'selected' : '' }} {{ old('parent_category_id',$data->category_id) == $category['category_id'] ? 'disabled' : '' }}>{{$category['category_name']}}</option>
                                    @endforeach
                                    @endisset
                                 </select>
                              </div>
                              @if ($errors->has('parent_category_id'))
                              <p class="help-block text-danger">
                                 {{ $errors->first('parent_category_id') }}
                              </p>
                              @endif
                           </div>
                        </div>
                        <div class="col-sm-6">
                           <div class="form-group">
                              <label class="bmd-label-floating">Category Name <span class="text-danger">*</span></label>
                              <input type="text" name="category_name" class="form-control {{$errors->has('category_name') ? 'is-invalid' : ''}}" value="{{ old('category_name',$data->category_name) }}">
                              @if ($errors->has('category_name') || $errors->has('category_slug'))
                              <p class="help-block text-danger">
                                 {{ $errors->first('category_name') ? $errors->first('category_name') : $errors->first('category_slug') }}
                              </p>
                              @endif
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <div class="col-sm-12">
                           <div class="form-group">
                              <label class="bmd-label-floating">Category Description</label>
                              <textarea name="category_description" class="form-control {{$errors->has('category_description') ? 'is-invalid' : ''}}">{{ old('category_description',$data->category_description) }}</textarea>
                              @if ($errors->has('category_description'))
                              <p class="help-block text-danger">
                                 {{ $errors->first('category_description') }}
                              </p>
                              @endif
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <div class="col-md-12 mb-3">
                           <button type="submit" class="btn btn-primary">Submit</button>&nbsp;
                           <a href="/admin/category" class="btn btn-default">Cancel</a>
                        </div>
                     </div>
                  </div>
               </form>
            </div>
         </div>
      </div>
   </div>
</div>
@endsection

