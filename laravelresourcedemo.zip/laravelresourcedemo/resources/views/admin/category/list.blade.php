@extends('admin.include.layout')
@section('content')
<div class="main-container">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-6 col-12">
				<div class="site-breadcrumb">
					<ul>
						<li><a href="/admin">Dashboard</a></li>
						<li>CMS</li>
					</ul>
				</div>
			</div>
			<div class="col-md-6 col-12">
				<div class="right-actionbar float-right">
					<a href="/admin/category/create" class="btn btn-bordered"><img src="/images/icons/plus-square.svg" alt=""> ADD Category</a>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-12">
				<div class="card card-main">
					<div class="card-header">
						<div class="card-title">Category List</div>
					</div>
					<table id="categoryDatatable" class="table table-hover">
						<thead>
							<tr>
								<th scope="col">#</th>
								<th scope="col">Category Name</th>
								<th scope="col">Category Level</th>
								<th scope="col">Action</th>
							</tr>
						</thead>
						<tbody>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	$(function () {
		var dataTable = $('#categoryDatatable').DataTable({
			processing: false,
			serverSide: true,
			info: false,
			lengthChange: false,
			responsive: true,
			language: {
				emptyTable: "No Category Found"
			},
			ajax: {
				// url: '/admin/category/api/category-list'
				url: "{{route('category.index')}}"
			},
			order:[[ 1, "asc" ]],
			columns: [
			{
				sTitle: "#",
				data: "category_id",
				name: "category_id",
				orderable: false,
				render: function(data, type, row, meta) {
					var pageinfo = dataTable.page.info();
					var currentpage = (pageinfo.page) * pageinfo.length;
					var display_number = (meta.row + 1) + currentpage;
					return display_number;
				}
			},
			{
				data: "category_name",
				name: "category_name",
				orderable: true,
				searchable: true,
			},
			{
				data: "category_level",
				name: "category_level",
				orderable: true,
				searchable: true,
			},
			{
				data: "action",
				name: "action",
				orderable: false,
				searchable: false,
				render: function(data, type, row, meta) {
					var str = "";
					str += '<a class="action-btn" title="Edit" id="'+row.category_id+'" href="/admin/category/'+row.category_id+'/edit"><img src="/images/icons/pencil.svg" width="18" alt="edit"></a>';

					str += '<a class="action-btn delete_record" title="Delete" href="#" data-id="'+row.category_id+'" data-toggle="modal" data-target="#modal-sm-'+row.category_id+'"><img src="/images/icons/delete.svg" width="18" alt="delete"></a>';

					return str;
				}
			}
			],
			fnRowCallback: function( nRow, aData, iDisplayIndex ) {
				return nRow;
			},
			fnDrawCallback: function( oSettings ) {
				$('.delete_record').on( 'click', function (e) {
					let delId = $(this).attr("data-id");
					console.log("delId:: ",delId);
					let url = "category/"+delId;
					self.confirmDelete(delId, url, dataTable);
				});
			}
		});
	});
</script>
@endsection