@extends('admin.include.layout')

@section('content')

<!-- Main content -->
<div class="main-container">
  <div class="container-fluid">
    
    <div class="row">
      <div class="col-md-6 col-12">
        <div class="site-breadcrumb">
            <ul>
              <li><a href="/admin">Dashboard</a></li>
              <li>Hiring</li>
            </ul>
        </div>
      </div>
      <div class="col-md-6 col-12">
        <div class="right-actionbar float-right">
          <a href="/admin/hiring/create" class="btn btn-bordered"><img src="/images/icons/plus-square.svg" alt=""> ADD Hiring</a>
          {{-- <div class="date-selector">
            <input type="text" id="datepicker01" class="input-date">
          </div> --}}
        </div>
      </div>
    </div>

    <div class="row"> 
        <div class="col-12">
          <div class="card card-main">
              <div class="card-header">
                  <div class="card-title">Hiring List</div>
              </div>
              <table id="hiringDatatable" class="table table-hover">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Hiring Title</th>
                      <th scope="col">Experience</th>                      
                      <th scope="col">Location</th>                                                                 
                      <th scope="col">Description</th>                                                                 
                      <th scope="col">Status</th>                                                                 
                      <th scope="col">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {{-- <tr>
                      <th>
                          <div class="checkbox">
                              <label>
                                <input type="checkbox">
                              </label>
                          </div>
                      </th>
                      <td>
                        <span class="user-image">
                          <img src="../images/avatar5.png" width="25" height="25" alt="">
                        </span>
                        <a href="">Richard Green</a>
                      </td>
                      <td>08/03/1959</td>
                      <td>2806</td>
                      <td>3397</td>
                      <td>895</td>
                      <td>4982</td>
                      <td>42,5332.00</td>
                      <td>86,8321.32</td>
                      <td>
                          <a data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" href="#"><img src="../images/icons/action.svg" alt=""></a>
                          <div class="dropdown-menu dropdown-menu-right">
                              <a class="dropdown-item" href="#">Remove Product Access</a>
                              <a class="dropdown-item" href="#">Add Product Access</a>
                              <a class="dropdown-item" href="#">View Reports</a>
                              <a class="dropdown-item" href="#">settings</a>
                            </div>
                      </td>
                    </tr> --}}
                  </tbody>
                </table>
          </div>
        </div>

    </div>
  </div>
</div>


  {{-- <section class="content">
    <div class="row">
      <div class="col-12">

        <div class="card">
          <div class="card-header">
            <h3 class="card-title">User List</h3>
            <a href="/admin/user/create">
              <div class="btn btn-primary float-sm-right">
                <i class="fas fa-user fa-lg mr-2"></i> 
                Add User
              </div>
              </a>
          </div>
          <div class="card-body">
            <table id="userDatatable" class="table table-bordered table-hover">
              <thead>
                <tr>
                    <th width="5%">#</th>
                    <th width="55%">User Information</th>                  
                    <th width="30%">User Type</th>
                    <th width="10%">Action</th>
                </tr>
              </thead>
              <tbody>                                         
              </tbody>              
            </table>
          </div>
        </div>
        
      </div>
    </div>
  </section> --}}

<script type="text/javascript">

  $(function () {   
    var dataTable = $('#hiringDatatable').DataTable({
          processing: false,
          serverSide: true,          
          info: false,
          lengthChange: false,
          responsive: true,
          language: {
            emptyTable: "No Cms Found"
          },
          ajax: {
              url: "{{route('hiring.index')}}"
          },
          order:[[ 1, "asc" ]],
          /*columnDefs: [
            {
                'targets': [0,1,2,3],
                'createdCell':  function (td, cellData, rowData, row, col) {
                    $(td).attr('data-title', 'cell-' + rowData); 
                }
            }
          ],*/
          columns: [
            {
              sTitle: "#",
              data: "hiring_id",
              name: "hiring_id",
              orderable: false,
              render: function(data, type, row, meta) {                  
                  var pageinfo = dataTable.page.info();
                  var currentpage = (pageinfo.page) * pageinfo.length;
                  var display_number = (meta.row + 1) + currentpage;
                  return display_number;
              }
            },
            
            {
              data: "hiring_title", 
              name: "hiring_title",
              orderable: true,
              searchable: true,
              render: function(data, type, row, meta) {                                    
                var str = "";
                if(data){
                  str +=  data;                
                }                               
                return str;

              }
            },
            {
              data: "experience", 
              name: "experience",
              orderable: true,
              searchable: true,
              render: function(data, type, row, meta) {                                    
                var str = "";
                if(data){
                  str +=  data;                
                }                               
                return str;

              }
            },
            {
              data: "location", 
              name: "location",
              orderable: true,
              searchable: true,
              render: function(data, type, row, meta) {                                    
                var str = "";
                if(data){
                  str +=  data;                
                }                               
                return str;

              }
            },
            {
              data: "description", 
              name: "description",
              orderable: true,
              searchable: true,
              render: function(data, type, row, meta) {
                var Char = 20;                                    
                var str = "";
               if(data){
                if(data.length > Char) {

                  var SmallText= data.substring(0,Char);
                  var cleanStr= data.replace(/["']/g, "");
                  str +=  '<div id="showrequest_'+row.hiring_id+'">';
                  str +=  '<a class="font-weight-light" title="'+cleanStr+'"> '+SmallText + '</a>';
                  str +=  "<a id=\"toggleButton\" class='text-primary btn-sm toggleButton' data-id="+row.hiring_id+" data-content="+cleanStr+" href=\"javascript:void(0);\">... more</a>";
                  str +=  '</div>';

                  str +=  '<div id="hiderequest_'+row.hiring_id+'" style="display:none">';
                  str +=  '<a style="word-break:break-all" class="font-weight-light" title="'+cleanStr+'"> '+cleanStr + '</a>';
                  str +=  "<a id=\"toggleButton\" class='text-primary btn-sm toggleButton' data-id="+row.hiring_id+" data-content="+cleanStr+" href=\"javascript:void(0);\">less</a>";
                  str +=  '</div>';

                } else {
                  str +=  data;
                }                        
              } else {
                str += 'N/A';
              }                              
                return str;

              }
            },
            {
              data: "status", 
              name: "status",
              orderable: true,
              searchable: true,
              render: function(data, type, row, meta) {                                    
                var str = "";
                if(row.status === 1){
                  str += 'Active';
                } else {
                  str += 'InActive';
                }                      
                return str;

              }
            },
            {
              data: "action",
              name: "action",
              orderable: false,
              searchable: false,
              render: function(data, type, row, meta) {                                    
                var str = "";
                str += '<a class="action-btn" title="Edit" id="'+row.hiring_id+'" href="/admin/hiring/'+row.hiring_id+'/edit"><img src="/images/icons/pencil.svg" width="18" alt="edit"></a>';
               
                str += '<a class="action-btn delete_record" title="Delete" href="#" data-id="'+row.hiring_id+'" data-toggle="modal" data-target="#modal-sm-'+row.hiring_id+'"><img src="/images/icons/delete.svg" width="18" alt="delete"></a>';
              
                return str;
              }
            }
          ],
          fnRowCallback: function( nRow, aData, iDisplayIndex ) {           
            return nRow;
          },
          fnDrawCallback: function( oSettings ) {
            // Delete Record
            $('.delete_record').on( 'click', function (e) {
              let delId = $(this).attr("data-id");
              let url = "hiring/"+delId;
              self.confirmDelete(delId, url, dataTable);                                                 
            });
            $('a.toggleButton').on( 'click', function (e) {
              let reqId = this.dataset.id;
              let content = this.dataset.content;
              $('#showrequest_'+reqId).toggle();
              $('#hiderequest_'+reqId).toggle();
            });

            $('a.responseToggle').on( 'click', function (e) {
              let reqId = this.dataset.id;
              let content = this.dataset.content;
              $('#responseShowRequest_'+reqId).toggle();
              $('#responseHideRequest_'+reqId).toggle();
            });
          },
          createdRow: function( row, data, dataIndex ) {
            // Set the data-status attribute, and add a class
            $( row ).find('td:eq(0)')
            .attr('data-title', '#');
            $( row ).find('td:eq(1)')
            .attr('data-title', 'Hiring Title');
            $( row ).find('td:eq(2)')
            .attr('data-title', 'Experience');
            $( row ).find('td:eq(3)')
            .attr('data-title', 'Location');
            $( row ).find('td:eq(4)')
            .attr('data-title', 'Description');
            $( row ).find('td:eq(5)')
            .attr('data-title', 'Status');
            $( row ).find('td:eq(6)')
            .attr('data-title', 'Action');
            /*$( row ).find('td:eq(0)')
            .attr('data-status', data.status ? 'locked' : 'unlocked')
            .addClass('asset-context box');*/
          }
      });
  });
</script>

@stop