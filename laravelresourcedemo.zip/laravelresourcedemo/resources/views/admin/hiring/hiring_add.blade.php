@extends('admin.include.layout')
@section('content')

 
<!-- Main content -->
<div class="main-container">
  <div class="container-fluid">    
    <div class="row">
      <div class="col-md-6 col-12">
        <div class="site-breadcrumb">
            <ul>
              <li><a href="/admin/hiring">Hiring</a></li>
              <li>@if((isset($data)) && $data->hiring_id) Edit @else Add @endif Hiring</li>
            </ul>
        </div>
      </div>
    </div>
    <div class="row"> 
        <div class="col-12">
          <div class="card card-main">
          <form id="hiringForm" method="POST" action="{{ !empty($data->hiring_id) ? route('hiring.update', $data) : route('hiring.store') }}" enctype="multipart/form-data">
                  {{ !empty($data->hiring_id) ? method_field('PUT') :  method_field('POST') }}
              <div class="card-body">
                @csrf 
                <input id="hiring_id" type="hidden" name="hiring_id" value="{{ isset($data) ? $data->hiring_id : '' }}">
                <div class="row">
                  <div class="col-sm-6">                                        
                    <div class="form-group">
                    <label class="bmd-label-floating"> Hiring Title <span class="text-danger">*</span></label>
                    <input type="text" name="hiring_title" class="form-control {{$errors->has('hiring_title') ? 'is-invalid' : ''}}" value="{{ old('hiring_title',$data->hiring_title) }}">                                           
                    @if ($errors->has('hiring_title')) <p class="help-block text-danger">{{ $errors->first('hiring_title') }}</p> @endif
                    </div>
                  </div>                                                            
                  <div class="col-sm-6">                                        
                    <div class="form-group">
                    <label class="bmd-label-floating"> Experience </label>
                    <input type="text" name="experience" class="form-control {{$errors->has('experience') ? 'is-invalid' : ''}}" value="{{ old('experience',$data->experience) }}">
                    @if ($errors->has('experience')) <p class="help-block text-danger">{{ $errors->first('experience') }}</p> @endif
                    </div>
                  </div>                                                            
                </div>
                 <div class="row">
                  <div class="col-sm-6">                                        
                    <div class="form-group">
                    <label class="bmd-label-floating"> Location <span class="text-danger">*</span></label>
                    <input type="text" name="location" class="form-control {{$errors->has('location') ? 'is-invalid' : ''}}" value="{{ old('location',$data->location) }}">                                           
                    @if ($errors->has('location')) <p class="help-block text-danger">{{ $errors->first('location') }}</p> @endif
                    </div>
                  </div>                                                         
                  <div class="col-sm-6">  
                    <div class="form-group">
                      <label class="bmd-label-floating">Status </label> </br>
                      <div class="radio">
                          <label>
                            <input class="form-control" type="radio" name="status" id="active" value="1"{{ old('status',isset($data->status) ? $data->status : '') == "1" ? 'checked' : '' }} checked>
                            <span class="ml-4 font-weight-normal">&nbsp;Active</span>
                          </label>
                          &nbsp;&nbsp;
                          <label>
                            <input class="form-control" type="radio" name="status" id="inactive" value="0" {{ old('status',isset($data->status) ? $data->status : '') == "0" ? 'checked' : '' }}>
                            <span class="ml-4 font-weight-normal">&nbsp;InActive</span>
                          </label>
                      </div>
                      @if ($errors->has('status')) <p class="help-block text-danger">{{ $errors->first('status') }}</p> @endif 
                    </div>
                  </div>                                                         
                </div>
                <div class="row">                                                         
                  <div class="col-sm-6">                                        
                    <div class="form-group">
                      <label><strong>Description <span class="text-danger">*</span></strong></label></br>
                      <textarea class="ckeditor form-control" name="description" id="description">{!! old('description',$data->description) !!}</textarea>
                       @if ($errors->has('description')) <p class="help-block text-danger">{{ $errors->first('description') }}</p> @endif
                    </div>
                  </div>                                                            
                </div>
                <div class="row">
                  <div class="col-md-12 mb-3">
                  <button type="submit" class="btn btn-primary">Submit</button>&nbsp;
                  <a href="/admin/hiring" class="btn btn-default">Cancel</a>
                  </div>
                </div>

              </div> 
            </form>

          </div>
        </div>
    </div>
  </div>
</div>
  
<script>
window.onload = function() {
 CKEDITOR.replace( 'description', {
    extraPlugins: 'easyimage',
    removePlugins: 'image',
    cloudServices_tokenUrl: 'https://example.com/cs-token-endpoint',
    cloudServices_uploadUrl: 'https://your-organization-id.cke-cs.com/easyimage/upload/'
} );
};

</script>

@stop

