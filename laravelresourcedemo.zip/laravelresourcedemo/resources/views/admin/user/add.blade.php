@extends('admin.include.layout')
@section('content')

 
<!-- Main content -->
<div class="main-container">
  <div class="container-fluid">    
    <div class="row">
      <div class="col-md-6 col-12">
        <div class="site-breadcrumb">
            <ul>
              <li><a href="/admin/user">User</a></li>
              <li>@if((isset($data)) && $data->user_id) Edit @else Add @endif User</li>
            </ul>
        </div>
      </div>
    </div>
    <div class="row"> 
        <div class="col-12">
          <div class="card card-main">
          @if((isset($data)) && $data->user_id)
            {{-- <div class="card-header header-sm">
              <div class="card-title">Update User</div>
            </div> --}}
            <form id="userForm" action="{{ route('user.update', $data) }}" method="POST" enctype="multipart/form-data">          
              {{ method_field('PUT') }}
            @php
              $passwordPlaceHolder = '********';
              $confirmPasswordPlaceHolder = '********';
            @endphp
          @else 
            {{-- <div class="card-header header-sm">
              <div class="card-title">Add User</div>
            </div> --}}
            <form id="userForm" method="POST" action="{{ route('user.store') }}" enctype="multipart/form-data">

            @php
              $passwordPlaceHolder = 'Enter Password';
              $confirmPasswordPlaceHolder = 'Enter Confirm Password';
            @endphp
          @endif
              <div class="card-body">
                <input type="hidden" name="_token" value="{{ csrf_token() }}">  
                <input id="user_id" type="hidden" name="user_id" value="{{ isset($data) ? $data->user_id : '' }}">
                {{-- <input type="hidden" id="form_type" name="form_type" value="NEWFORM"> --}}

                <div class="row">
                  <div class="col-sm-6">                                        
                    <div class="form-group">
                    <label class="bmd-label-floating"> Name <span class="text-danger">*</span></label>
                    <input type="text" name="name" class="form-control {{$errors->has('name') ? 'is-invalid' : ''}}" value="{{ isset($data) ? $data->name : old('name') }}">                                           
                    @if ($errors->has('name')) <p class="help-block text-danger">{{ $errors->first('name') }}</p> @endif
                    </div>
                  </div>                                        
                  <div class="col-sm-6">    
                    <div class="form-group">
                      <label class="bmd-label-floating"> Email <span class="text-danger">*</span> </label>
                        <input type="email" name="email" class="form-control {{$errors->has('email') ? 'is-invalid' : ''}}" value="{{ isset($data) ? $data->email : old('email') }}">                                           
                      @if ($errors->has('email')) <p class="help-block text-danger">{{ $errors->first('email') }}</p> @endif
                    </div>
                  </div>                     
                </div>  

                @if((isset($data)) && $data->user_id)
                <div class="row">
                  <div class="col-sm-6">                                        
                    <div class="form-group">
                      <label class="bmd-label-floating"> Password <span class="text-danger">*</span></label>
                      <input type="password" name="password" class="form-control {{$errors->has('password') ? 'is-invalid' : ''}}" >                                           
                      @if ($errors->has('password')) <p class="help-block text-danger">{{ $errors->first('password') }}</p> @endif
                    </div>                     
                  </div>
                  <div class="col-sm-6">    
                    <div class="form-group">                                    
                      <label class="bmd-label-floating"> Confirm Password <span class="text-danger">*</span></label>
                      <input type="password" name="password_confirmation" class="form-control {{$errors->has('password_confirmation') ? 'is-invalid' : ''}}" >                                           
                      @if ($errors->has('password_confirmation')) <p class="help-block text-danger">{{ $errors->first('password_confirmation') }}</p> @endif
                    </div>
                  </div>                     
                </div> 
                @endif

                <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group is-focused select-grp">
                    <label class="bmd-label-floating">User Type <span class="text-danger">*</span></label>    
                    <div class="select-drop">
                      <select class="form-control {{$errors->has('user_type') ? 'is-invalid' : ''}}" name="user_type" id="user_type">
                        <option value=""> Select User type </option>
                        @if(isset($dropDownArr) && isset($dropDownArr['userTypeArray']['options']))
                        @foreach($dropDownArr['userTypeArray']['options'] as $key => $value)
                          <option value="{{$key}}" {{( isset($data->user_type) && $data->user_type === $key || old('user_type') == $key) ? 'selected' : '' }}> {{$value}} </option>
                        @endforeach
                        @endif
                      </select>                
                    </div>          
                    @if ($errors->has('user_type')) <p class="help-block text-danger">{{ $errors->first('user_type') }}</p> @endif                        
                    </div>
                  </div>  
                </div>
                <div class="row">
                  <div class="col-lg-6">
                    <div class="form-group">
                      <label for="profilePicture">Profile Picture</label>
                      <div class="userimg-sec drop-rectangle">
                        <div class="img-dropbox">
                            <label for="profile-img">
                              <span class="file-msg">
                                <img src="/images/icons/upload.svg" width="50" alt="">
                                <strong>Drag and drop your image here</strong>
                              </span>
                              <input class="upload-profilepic {{$errors->has('profile_picture') ? 'is-invalid' : ''}}" data-preview="#preview" name="profile_picture" type="file" id="profilePicture">
                            </label>
                        </div>
                        @if(isset($data) && $data->profile_picture )
                          <div class="prod-img">
                            <img id="preview" width="100" src="{{ $data->profile_picture}}">
                          </div>
                        @endif
                    </div>
                    @if ($errors->has('profile_picture')) <p class="help-block text-danger">{{ $errors->first('profile_picture') }}</p> @endif                            
                                                    
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-12 mb-3">
                  <button type="submit" class="btn btn-primary">Submit</button>&nbsp;
                  <a href="/admin/user" class="btn btn-default">Cancel</a>
                  </div>
                </div>

              </div> 
            </form>

          </div>
        </div>
    </div>
  </div>
</div>
  

@stop

