@extends('admin.include.layout')
@section('content')

 
<!-- Main content -->
<div class="main-container">
  <div class="container-fluid">    
	<div class="row">
	  <div class="col-md-6 col-12">
		<div class="site-breadcrumb">
			<ul>
			  <li><a href="/admin">Profile</a></li>
			  <li>@if((isset($data)) && $data->user_id) Edit @else Add @endif Profile</li>
			</ul>
		</div>
	  </div>
	</div>
	<div class="row"> 
		<div class="col-12">
			<div class="card card-main">
				
				<form action="{{ route('profile.update', $data) }}" method="POST" enctype="multipart/form-data">          
					{{ method_field('PUT') }}
					@php
					$passwordPlaceHolder = '********';
					$confirmPasswordPlaceHolder = '********';
					@endphp                    
					<div class="card-body">

						<input type="hidden" name="_token" value="{{ csrf_token() }}">  
						<input type="hidden" name="user_id" value="{{ isset($data) ? $data->user_id : '' }}">                              
						
						<div class="row">
							<div class="col-12">
								<div class="userimg-sec">
									<div class="defult-img">
										@if(isset($data) && $data->profile_picture )
											<div class="selected-profileimg">
												<img class="prevImg" id="preview" src="{{ $data->profile_picture}}">
											</div>
										@endif
										<a class="edit-btn" href="javascript:;"><img src="/images/icons/pencil.svg" alt=""></a>
									</div>
									<div class="img-dropbox">
										<label for="profile-img">
											<span class="file-msg">
												<img src="/images/icons/upload.svg" width="50" alt="">
												<strong>Drag and drop your image here</strong>
											</span>
											<!-- <input class="upload-profilepic" id="profile-img" type="file" name="" value=""> -->
											<input class="upload-profilepic {{$errors->has('profile_picture') ? 'is-invalid' : ''}}" data-preview="#preview" name="profile_picture" type="file" id="profilePicture">
										</label>
									</div>
								</div>
								<div class="space40"></div>
							</div>
						<div class="col-sm-6">   
							<div class="form-group">
							<label class="bmd-label-floating"> Name </label>
							<input type="text" name="name" class="form-control {{$errors->has('name') ? 'is-invalid' : ''}}" value="{{ isset($data) ? $data->name : old('name') }}">                                           
							@if ($errors->has('name')) <p class="help-block text-danger">{{ $errors->first('name') }}</p> @endif
							</div>
						</div>                               
						<div class="col-sm-6">    
							<div class="form-group">
								<label class="bmd-label-floating"> Email </label>
								<input type="email" name="email" class="form-control {{$errors->has('email') ? 'is-invalid' : ''}}"  value="{{ isset($data) ? $data->email : old('email') }}">                                           
									@if ($errors->has('email')) <p class="help-block text-danger">{{ $errors->first('email') }}</p> @endif
							</div>                                    
						</div>                     
						</div>    
						<div class="row">
						<div class="col-sm-6"> 
							<div class="form-group">
								<label class="bmd-label-floating"> Password </label>
								<input type="password" name="password" class="form-control {{$errors->has('password') ? 'is-invalid' : ''}}" >                                           
									@if ($errors->has('password')) <p class="help-block text-danger">{{ $errors->first('password') }}</p> @endif
							</div>
						</div>                     
						
						<div class="col-sm-6">
							<div class="form-group">                                  
								<label class="bmd-label-floating"> Confirm Password </label>
								<input type="password" name="password_confirmation" class="form-control {{$errors->has('password_confirmation') ? 'is-invalid' : ''}}" >                                           
									@if ($errors->has('password_confirmation')) <p class="help-block text-danger">{{ $errors->first('password_confirmation') }}</p> @endif
							</div>
						</div>                     
						</div>        
						<div class="row">
							<div class="col-sm-6">
								<div class="form-group is-focused select-grp">
									<label class="bmd-label-floating" >User Type</label>    
								
										<div class="select-drop">
											<select class="form-control {{$errors->has('user_type') ? 'is-invalid' : ''}}" name="user_type" id="user_type">
												<option value=""> Select User type </option>
												@if(isset($dropDownArr) && isset($dropDownArr['userTypeArray']['options']))
												@foreach($dropDownArr['userTypeArray']['options'] as $key => $value)
												<option value="{{$key}}" {{( isset($data->user_type) && $data->user_type === $key || old('user_type') == $key) ? 'selected' : '' }}> {{$value}} </option>
												@endforeach
												@endif
											</select> 
										</div>          
				
										               
										@if ($errors->has('user_type')) <p class="help-block text-danger">{{ $errors->first('user_type') }}</p> @endif                        
								</div>
							</div>  
						</div>

						<div class="row">
							<div class="col-md-12 mb-3">
							<button type="submit" class="btn btn-primary">Update</button>&nbsp;
							<a href="/admin" class="btn btn-default">Cancel</a>
							</div>
						</div>
					</div>              
				</form>
			</div>
		</div>
	</div>
  </div>
</div>
	

<script>
	$(function () {		
  
	/* **********************************************
	** on select affiliate on editmode
	********************************************** */
  
	  var user_id = $("#user_id").val();
	  if(user_id!=''){
	   
		if($('#user_type').val()=='Affiliate'){
		  $('#affiliateForm').show();
		}
  
		$('#user_type').on('change', function () {
		  if(this.value=='Affiliate'){        
			$('#affiliateForm').show();
		  } else {
			$('#affiliateForm').hide();
		  }
		});
	  
	  }
	});
  </script>

@stop

