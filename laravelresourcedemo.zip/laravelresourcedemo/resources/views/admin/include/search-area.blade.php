<div class="search-area col-12">
    <div class="input-group">
        <span class="search-icon"><img src="images/icons/search.svg" alt=""></span>
        <div class="form-control">
            <input type="text" class="search-bar" aria-label="Text input with dropdown button">
        </div>
        <div class="input-group-append">
            <button class="btn btn-primary dropdown-toggle" data-click="company-ticker" type="button">Company/Ticker</button>
            <div class="search-dropdown" data-id="company-ticker">
                <div class="dropdown-search">
                    <span><img src="images/icons/search.svg" alt=""></span>
                    <input type="text" class="form-control" placeholder="Search tags.....">
                </div>
                <div class="dropdown-scroller">
                    <a class="dropdown-item" href="#">3D Printing (1)</a>
                    <a class="dropdown-item" href="#">3D Printing, </a>
                    <a class="dropdown-item" href="#">E-commerce, Manufacturing </a>
                    <a class="dropdown-item" href="#">3D Printing, Manufacturing</a>
                    <a class="dropdown-item" href="#">AdTech </a>
                    <a class="dropdown-item" href="#">AdTech, Artificial Intelligence </a>
                    <a class="dropdown-item" href="#">AdTech, Big Data </a>
                    <a class="dropdown-item" href="#">AdTech, Deep Learning </a>
                    <a class="dropdown-item" href="#">AdTech, E-commerce </a>
                    <a class="dropdown-item" href="#">AdTech, Manufacturing </a>
                    <a class="dropdown-item" href="#">AdTech, Mobile Apps </a>
                    <a class="dropdown-item" href="#">AdTech, Mobile Apps, Saas </a>
                    <a class="dropdown-item" href="#">AdTech, Mobile Apps, Social Media </a>
                    <a class="dropdown-item" href="#">AdTech, Paas </a>
                    <a class="dropdown-item" href="#">AdTech, Saas, Smart Supply Chain </a>
                    <a class="dropdown-item" href="#">Agtech </a>
                    <a class="dropdown-item" href="#">Agtech, Manufacturing </a>
                    <a class="dropdown-item" href="#">Agtech, Manufacturing, Smart Agriculture/Farming </a>
                    <a class="dropdown-item" href="#">Agtech, Saas </a>
                    <a class="dropdown-item" href="#">Agtech, Smart Agriculture/Farming </a>
                    <a class="dropdown-item" href="#">Artificial Intelligence </a>
                    <a class="dropdown-item" href="#">Artificial Intelligence, Big Data, Cloud Computing </a>
                    <a class="dropdown-item" href="#">Artificial Intelligence, Big Data, E-commerce </a>
                    <a class="dropdown-item" href="#">Artificial Intelligence, Cloud Computing, Mobile Apps </a>
                    <a class="dropdown-item" href="#">Artificial Intelligence, E-commerce</a>
                </div>
            </div>    
        </div>
        <div class="input-group-append">
            <button class="btn btn-primary dropdown-toggle" data-click="sector-business" type="button">Sector/ Business Model</button>
            <div class="search-dropdown" data-id="sector-business">
                <div class="dropdown-search"><span><img src="images/icons/search.svg" alt=""></span><input type="text" class="form-control" placeholder="Search tags....."></div>
                <div class="dropdown-scroller">
                    <a class="dropdown-item" href="#">3D Printing (2)</a>
                    <a class="dropdown-item" href="#">3D Printing, </a>
                    <a class="dropdown-item" href="#">E-commerce, Manufacturing </a>
                    <a class="dropdown-item" href="#">3D Printing, Manufacturing</a>
                    <a class="dropdown-item" href="#">AdTech </a>
                    <a class="dropdown-item" href="#">AdTech, Artificial Intelligence </a>
                    <a class="dropdown-item" href="#">AdTech, Big Data </a>
                    <a class="dropdown-item" href="#">AdTech, Deep Learning </a>
                    <a class="dropdown-item" href="#">AdTech, E-commerce </a>
                    <a class="dropdown-item" href="#">AdTech, Manufacturing </a>
                    <a class="dropdown-item" href="#">AdTech, Mobile Apps </a>
                    <a class="dropdown-item" href="#">AdTech, Mobile Apps, Saas </a>
                    <a class="dropdown-item" href="#">AdTech, Mobile Apps, Social Media </a>
                    <a class="dropdown-item" href="#">AdTech, Paas </a>
                    <a class="dropdown-item" href="#">AdTech, Saas, Smart Supply Chain </a>
                    <a class="dropdown-item" href="#">Agtech </a>
                    <a class="dropdown-item" href="#">Agtech, Manufacturing </a>
                    <a class="dropdown-item" href="#">Agtech, Manufacturing, Smart Agriculture/Farming </a>
                    <a class="dropdown-item" href="#">Agtech, Saas </a>
                    <a class="dropdown-item" href="#">Agtech, Smart Agriculture/Farming </a>
                    <a class="dropdown-item" href="#">Artificial Intelligence </a>
                    <a class="dropdown-item" href="#">Artificial Intelligence, Big Data, Cloud Computing </a>
                    <a class="dropdown-item" href="#">Artificial Intelligence, Big Data, E-commerce </a>
                    <a class="dropdown-item" href="#">Artificial Intelligence, Cloud Computing, Mobile Apps </a>
                    <a class="dropdown-item" href="#">Artificial Intelligence, E-commerce</a>
                </div>
            </div>    
        </div>
        <div class="input-group-append">
            <button class="btn btn-primary dropdown-toggle" data-click="tags" type="button">Tags</button>
            <div class="search-dropdown" data-id="tags">
                <div class="dropdown-search"><span><img src="images/icons/search.svg" alt=""></span><input type="text" class="form-control" placeholder="Search tags....."></div>
                <div class="dropdown-scroller">
                    <a class="dropdown-item" href="#">3D Printing (3)</a>
                    <a class="dropdown-item" href="#">3D Printing, </a>
                    <a class="dropdown-item" href="#">E-commerce, Manufacturing </a>
                    <a class="dropdown-item" href="#">3D Printing, Manufacturing</a>
                    <a class="dropdown-item" href="#">AdTech </a>
                    <a class="dropdown-item" href="#">AdTech, Artificial Intelligence </a>
                    <a class="dropdown-item" href="#">AdTech, Big Data </a>
                    <a class="dropdown-item" href="#">AdTech, Deep Learning </a>
                    <a class="dropdown-item" href="#">AdTech, E-commerce </a>
                    <a class="dropdown-item" href="#">AdTech, Manufacturing </a>
                    <a class="dropdown-item" href="#">AdTech, Mobile Apps </a>
                    <a class="dropdown-item" href="#">AdTech, Mobile Apps, Saas </a>
                    <a class="dropdown-item" href="#">AdTech, Mobile Apps, Social Media </a>
                    <a class="dropdown-item" href="#">AdTech, Paas </a>
                    <a class="dropdown-item" href="#">AdTech, Saas, Smart Supply Chain </a>
                    <a class="dropdown-item" href="#">Agtech </a>
                    <a class="dropdown-item" href="#">Agtech, Manufacturing </a>
                    <a class="dropdown-item" href="#">Agtech, Manufacturing, Smart Agriculture/Farming </a>
                    <a class="dropdown-item" href="#">Agtech, Saas </a>
                    <a class="dropdown-item" href="#">Agtech, Smart Agriculture/Farming </a>
                    <a class="dropdown-item" href="#">Artificial Intelligence </a>
                    <a class="dropdown-item" href="#">Artificial Intelligence, Big Data, Cloud Computing </a>
                    <a class="dropdown-item" href="#">Artificial Intelligence, Big Data, E-commerce </a>
                    <a class="dropdown-item" href="#">Artificial Intelligence, Cloud Computing, Mobile Apps </a>
                    <a class="dropdown-item" href="#">Artificial Intelligence, E-commerce</a>
                </div>
            </div>
        </div>
    </div>
    <div class="popover-content">
        <div>
            <ul class="menu search-menu">
                <li class="menu-header">
                    <h6 class="heading">Categories</h6>
                </li><label class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>B2B SaaS</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>Cybersecurity</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>top 10 SaaS</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>APM</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>DevOps/Dev Tools</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>PLG</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>Cloud Infrastructure</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>BVP Cloud</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>Consumer Subscription</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>Data &amp; Analytics</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>API</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>General Internet Marketplace</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>Transportation</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>Payments</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>SMB</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>non-PLG</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>Sales &amp; Marketing</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>Consumer Social</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>Education</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>Vertical SaaS</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>FAANG</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>Consumer Health</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>Travel</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>Cloud Infrastucture</label>
                <li class="menu-header">
                    <h6 class="heading">Companies</h6>
                </li><label class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>FTCH (Farfetch Limited)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>CRWD (Crowdstrike)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>DDOG (Datadog)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>ZM (Zoom Video)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>PTON (Peloton)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>AYX (Alteryx)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>TWLO (Twilio)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>ESTC (Elastic N.V.)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>REAL (The RealReal)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>SDC (Smile Direct Club)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>LYFT (Lyft)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>NET (Cloudflare)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>SMAR (Smartsheet)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>BILL (Bill.com)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>WORK (Slack)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>COUP (Coupa Software)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>SHOP (Shopify)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>CLDR (Cloudera)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>OKTA (Okta)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>MDB (MongoDB)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>FSLY (Fastly)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>SNAP (Snap)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>ADYYF (Adyen)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>FVRR (Fiverr)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>PLAN (Anaplan)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>TWOU (2U)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>SQ (Square)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>AVLR (Avalara)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>DOCU (DocuSign)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>UBER (Uber Technologies)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>TEAM (Atlassian Corporation)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>EVBG (Everbridge)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>ZS (Zscaler)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>PD (PagerDuty)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>ETSY (Etsy)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>CRM (Salesforce.com)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>TTD (The Trade Desk)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>VEEV (Veeva Systems)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>RNG (Ringcentral)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>APPF (AppFolio)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>ZEN (Zendesk)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>RPD (Rapid7)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>NOW (ServiceNow)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>PS (Pluralsight)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>EGHT (8x8)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>NFLX (Netflix)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>HUBS (HubSpot)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>QTWO (Q2 Holdings)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>TENB (Tenable Holdings)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>BL (BlackLine)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>PAYC (Paycom Software)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>RAMP (LiveRamp Holdings)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>YEXT (Yext)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>FIVN (Five9)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>TDOC (Teladoc)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>MDLA (Medallia)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>SPLK (Splunk)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>SPT (Sprout Social)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>MIME (Mimecast Limited)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>DT (Dynatrace)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>WIX (Wix.com)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>WK (Workiva)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>SVMK (Survey Monkey)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>SPOT (Spotify)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>WDAY (Workday)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>INST (Instructure)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>PCTY (Paylocity)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>NEWR (New Relic)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>PFPT (Proofpoint)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>SFIX (Stichfix)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>ADSK (Autodesk)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>AMZN (Amazon)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>TLND (Talend S.A.)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>MTCH (Match Group)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>UPWK (Upwork)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>ADBE (Adobe)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>DBX (Dropbox)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>BAND (Bandwidth)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>PYPL (Paypal)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>JCOM (J2 Global)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>DOMO (Domo)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>APPN (Appian Corporation)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>PANW (Palo Alto Networks)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>PING (Ping Identity)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>QLYS (Qualys)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>CDAY (Ceridian HCM Holding)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>MSFT (Microsoft Corporation)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>INTU (Intuit)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>RP (RealPage)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>GDDY (GoDaddy)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>BOX (Box)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>SWI (SolarWinds)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>ZUO (Zuora)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>SAIL (SailPoint Technologies)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>EB (Eventbrite)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>SAP (SAP SE)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>FEYE (FireEye)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>BLKB (Blackbaud)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>EXPE (Expedia)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>BKI (Black Knight)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>LOGM (LogMein)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>BKNG (Bookings)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>CHKP (Check Point Software)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>NTNX (Nutanix)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>SSTK (Shutterstock)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>GWRE (Guidewire Software)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>EBAY (Ebay)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>TRIP (TripAdvisor)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>APRN (Blue Apron)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>FB (Facebook)</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>Retail &amp; Goods Marketplace</label><label
                    class="control checkbox inline search-checkbox-item"><input type="checkbox"><span
                        class="control-indicator"></span>Enterprise Software</label>
            </ul>
        </div>
    </div>
</div>
