{{-- AJAX Message --}}
<script>
        
    function confirmDelete(delId, deleteUrl, dataTable){
        Swal.fire({
                title: 'Are you sure?',
                text: "You want to delete this record!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Delete'
            }).then((result) => {
            if (result.value) {
                $.ajax({
                    url: deleteUrl,
                    type: 'DELETE',
                    data: {
                    id:delId,
                    "_token": "{{ csrf_token() }}"
                    },
                    success: function (res) {
                        if(res && res.success) {
                        notification('success', res.message);                       
                        } else {
                        notification('error', res.message); 
                        }
                        dataTable.ajax.reload();                        
                    },
                    error: function(xhr) {
                        notification('error', res.message);
                    }
                }); 
            }
        })
        
    }

    function generate_token(length=30) {
        var token = "";
        var codeAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        codeAlphabet += "abcdefghijklmnopqrstuvwxyz";
        codeAlphabet += "0123456789";
        var max = codeAlphabet.length - 1;
        for (var i=0; i < length; i++) {
            token += codeAlphabet.charAt(Math.floor(Math.random() * max));
        }
        return token;
    }
   
    function dynamicTableFields(fieldType, number, fieldsHtml){      
        var html = '<tr id="'+fieldType+'_'+number+'">';
        html += fieldsHtml;
        if(number>1){
          html += '<td><button type="button" data-id="'+fieldType+'_'+number+'" class="btn btn-normal bg-gradient-danger remove-item-'+fieldType+'"><strong>Remove</strong></button></td></tr>';
          $('#'+fieldType+'Group tbody').append(html);
        } else {
          html += '<td><button type="button" data-id="'+fieldType+'_'+number+'" class="btn btn-normal bg-gradient-primary add-more-'+fieldType+'"><strong>Add</strong></button></td></tr>';        
          $('#'+fieldType+'Group tbody').html(html);
        }
    }

    

    function dynamicElementFields(fieldType, number, fieldsHtml){
        var html = '<div class="row border-bottom" id="row_'+fieldType+'_'+number+'">';
        html += fieldsHtml;        
        if(number>1){                       
            html += '<div class="col-sm-2">';
            html += '<div class="form-group">';
                html += '<button type="button" data-id="row_'+fieldType+'_'+number+'" class="btn btn-normal bg-gradient-danger remove-item-'+fieldType+'"><strong>Remove</strong></button>';
            html += '</div>';
            html += '</div>';
            html += '</div>';
            $('#'+fieldType+'Group fieldset').append(html);
        } else {
            html += '<div class="col-sm-2">';
            html += '<div class="form-group">';
                html += '<button type="button" data-id="row_'+fieldType+'_'+number+'" class="btn btn-normal bg-gradient-primary add-more-'+fieldType+'"><strong>Add</strong></button>';        
            html += '</div>';
            html += '</div>';   
            html += '</div>';  
            $('#'+fieldType+'Group fieldset').html(html);
        }
    }


    function formatDate(date, type="full") {
        if(type=='datetime'){
            var date = new Date(date);
                date.setMinutes(date.getMinutes() - date.getTimezoneOffset());
        }

        var monthNames = [
        "January", "February", "March",
        "April", "May", "June", "July",
        "August", "September", "October",
        "November", "December"
        ];
        var monthNamesShort = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

        var day = date.getDate();
        var monthIndex = date.getMonth();
        var year = date.getFullYear();

        if(type=='datetime'){
            var hr = date.getHours();
            var min = date.getMinutes();
            if (min < 10) {
                min = "0" + min;
            }
            var ampm = "AM";
            if( hr > 12 ) {
                hr -= 12;
                ampm = "PM";
            }
        }

        var month = '';
        if(type=='full'){
            return day + ' ' + monthNames[monthIndex] + ' ' + year;
        } else if(type=='short') {
            return day + ' ' + monthNamesShort[monthIndex] + ' ' + year;
        } else if(type=='datetime') {
            return day + ' ' + monthNamesShort[monthIndex] + ' ' + year + ', ' + hr + ':' + min + ' ' + ampm;            
        }
        else {
            return day + '-' + monthIndex + '-' + year;
        }
    }
    
</script>