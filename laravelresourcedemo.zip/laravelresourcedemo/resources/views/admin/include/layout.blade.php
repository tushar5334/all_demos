<!DOCTYPE html>
<html>
    <head>
        <title>Tx Labs</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
        <!-- All CSS links and favicon are included here -->
        @include('admin.include.css-links')

        {{-- <script src="/js/jquery-3.2.1.slim.min.js" ></script> --}}
        <script src="/js/jquery-3.2.1.min.js" ></script>
        
    </head>
    <body>
        <div class="wrapper">

            @include('admin.include.header')
            <div class="content-wrapper">
                @include('admin.include.leftmenu')
                @include('admin.include.flash-message')
                @include('admin.include.functions')

                @yield('content')
                @include('admin.include.footer')
            </div>

        </div>
    </body>

    <!-- All javascript and jquery are included here -->
    @include('admin.include.javascripts')

</html>