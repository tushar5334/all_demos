<div class="header">
	<div class="logo">
		<a href="">
			<img src="/images/tx.png" alt="">
		</a>
	</div>
	<div class="hamburger">
		<span></span>
		<span></span>
		<span></span>
	</div>
	<div class="header-product" id="productList">

	</div>

	<div class="right-header">
		<div class="notification">
			<a href="">
				<img src="/images/icons/notification.svg" alt="">
			</a>
		</div>
		<div class="btn-group">
			<div class="userprofile">

				@if (Auth::user()->profile_picture != "" &&
				file_exists(public_path('/upload/user_image/'.Auth::user()->profile_picture)))
				<img src="/upload/user_image/{{ Auth::user()->profile_picture }}" alt="" width="60" height="60">
				@else
				<img src="/images/avatar5.png" alt="" width="60" height="60">
				@endif

				<span>
					{{ Auth::user()->name }}
					@if(isset(Auth::user()->user_type) && Auth::user()->user_type)
					<span> {{ Auth::user()->user_type }}'s Account</span>
					@endif
				</span>
			</div>
			<button type="button" class="dropdown-toggle dropdown-toggle-split" data-toggle="dropdown"
				aria-haspopup="true" aria-expanded="false">
				<span class="sr-only"></span>
			</button>
			<div class="dropdown-menu">
				<a class="dropdown-item" href="/admin/profile/{{Auth::user()->user_id}}/edit">Profile</a>
				<div class="dropdown-divider"></div>
				{{-- <a class="dropdown-item" href="">Logout</a>--}}
				<a href="/admin/logout"
					onclick="event.preventDefault(); document.getElementById('logout-form').submit();"
					class="dropdown-item">Sign out</a>
				<form id="logout-form" action="/admin/logout" method="POST" style="display: none;">
					{{ csrf_field() }}
				</form>
			</div>
		</div>
	</div>
</div>