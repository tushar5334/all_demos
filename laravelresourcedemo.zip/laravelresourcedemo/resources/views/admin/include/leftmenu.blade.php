<aside class="leftmenu">
    <ul>
        <li class="{{ (Request::path() == 'admin') ? 'active' : '' }}">
            <a href="/admin">
                <div class="icon"><i class="fas fa-tachometer-alt"></i></div>
                <span>Dashboard</span>
            </a>
        </li>
        <li class="{{ (Request::path() == 'admin/user' || Request::path() == 'admin/user/create' || Request::is('admin/user/*/edit')) ? 'active' : '' }}">
            <a href="/admin/user">
                <div class="icon"><i class="far fa-user"></i></div>
                <span>Users</span>
            </a>
        </li>
        <li class="{{ (Request::path() == 'admin/page' || Request::path() == 'admin/page/create' || Request::is('admin/page/*/edit')) ? 'active' : '' }}">
            <a href="/admin/page">
                <div class="icon"><i class="fas fa-pager"></i></div>
                <span>CMS</span>
            </a>
        </li>
        <li class="{{ (Request::path() == 'admin/hiring' || Request::path() == 'admin/hiring/create' || Request::is('admin/hiring/*/edit')) ? 'active' : '' }}">
            <a href="/admin/hiring">
                <div class="icon"><i class="fas fa-search"></i></div>
                <span>Hiring</span>
            </a>
        </li>
        <li class="{{ (Request::path() == 'admin/category' || Request::path() == 'admin/category/create' || Request::is('admin/category/*/edit')) ? 'active' : '' }}">
            <a href="/admin/category">
                <div class="icon"><i class="fas fa-project-diagram"></i></div>
                <span>Category</span>
            </a>
        </li>
        <li class="{{ (Request::path() == 'admin/project' || Request::path() == 'admin/project/create' || Request::is('admin/project/*/edit')) ? 'active' : '' }}">
            <a href="/admin/project">
                <div class="icon"><i class="fas fa-file"></i></div>
                    <span>Project</span>
            </a>
        </li>

        <li class="{{ (Request::path() == 'admin/service' || Request::path() == 'admin/service/create' || Request::is('admin/service/*/edit')) ? 'active' : '' }}">
            <a href="/admin/service">
                <div class="icon"><i class="fas fa-cog"></i></div>
                    <span>Services</span>

        <li class="{{ (Request::path() == 'admin/tag' || Request::path() == 'admin/tag/create' || Request::is('admin/tag/*/edit')) ? 'active' : '' }}">
            <a href="/admin/tag">
                <div class="icon"><i class="fas fa-tags"></i></div>
                    <span>Tag</span>
            </a>
        </li>
        <li class="{{ (Request::path() == 'admin/testimonial' || Request::path() == 'admin/testimonial/create' || Request::is('admin/testimonial/*/edit')) ? 'active' : '' }}">
            <a href="/admin/testimonial">
                <div class="icon"><i class="fas fa-comment"></i></div>
                    <span>Testimonial</span>
            </a>
        </li>
        <li class="{{ (Request::path() == 'admin/banner' || Request::path() == 'admin/banner/create' || Request::is('admin/banner/*/edit')) ? 'active' : '' }}">
            <a href="/admin/banner">
                <div class="icon"><i class="fas fa-sliders-h"></i></div>
                    <span>Banner</span>
            </a>
        </li>
    </ul>
</aside>
