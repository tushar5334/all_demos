@extends('admin.include.layout')
@section('content')

<!-- Main content -->
<div class="main-container">
  <div class="container-fluid">    
    <div class="row">
      <div class="col-md-6 col-12">
        <div class="site-breadcrumb">
            <ul>
              <li><a href="/admin/tag">Tag</a></li>
              <li>@if((isset($data)) && !empty($data)) Edit @else Add @endif Tag</li>
            </ul>
        </div>
      </div>
    </div>
    <div class="row"> 
        <div class="col-12">
          <div class="card card-main">
          @if((isset($data)) && !empty($data))
            <form id="tagForm" action="{{ route('tag.update', $data) }}" method="POST" enctype="multipart/form-data">          
              {{ method_field('PUT') }}           
          @else 
            <form id="tagForm" method="POST" action="{{ route('tag.store') }}" enctype="multipart/form-data">
          @endif
              <div class="card-body">
                <input type="hidden" name="_token" value="{{ csrf_token() }}">  
                <input id="tag_id" type="hidden" name="tag_id" value="{{ isset($data) ? $data->tag_id : '' }}">
                <div class="row">
                  <div class="col-sm-6">                                        
                    <div class="form-group">
                    <label class="bmd-label-floating"> Tag Name <span class="text-danger">*</span></label>
                    <input type="text" name="tag_name" class="form-control {{$errors->has('tag_name') ? 'is-invalid' : ''}}" value="{{ isset($data) ? $data->tag_name : old('tag_name') }}">                                           
                    @if ($errors->has('tag_name') || $errors->has('tag_slug'))
                    <p class="help-block text-danger">
                        {{ $errors->first('tag_name') ? $errors->first('tag_name') : $errors->first('tag_slug') }}
                    </p>
                    @endif
                    </div>
                  </div>                
                </div>
                
                {{-- {{dd(Config::get('constants.tagStatus'))}} --}}
                {{-- <div class="row">
                  <div class="col-sm-6">                                        
                    <div class="form-group">
                    <label class="bmd-label-floating"> Status</label>
                    <select name="status" id="status" class="form-control {{$errors->has('tag_slug') ? 'is-invalid' : ''}}">
                      <option value=""> Select Status</option>
                      @if(isset($dropDownArr) && isset($dropDownArr['tagStatus']['options']))
                        @foreach($dropDownArr['tagStatus']['options'] as $key => $value)
                            <option value="{{$key}}"  {{ (isset($data['status']) && $key == $data['status']) ? 'selected' : '' }}> {{$value}}</option>
                        @endforeach
                      @endif
                    </select>
                    @if ($errors->has('status')) <p class="help-block text-danger">{{ $errors->first('status') }}</p> @endif
                    </div>
                  </div>                                                    
                </div> --}}                           

                <div class="row">
                  <div class="col-md-12 mb-3">
                  <button type="submit" class="btn btn-primary">Submit</button>&nbsp;
                  <a href="/admin/tag" class="btn btn-default">Cancel</a>
                  </div>
                </div>

              </div> 
            </form>

          </div>
        </div>
    </div>
  </div>
</div>


@stop

