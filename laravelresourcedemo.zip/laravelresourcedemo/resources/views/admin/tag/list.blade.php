@extends('admin.include.layout')

@section('content')

<!-- Main content -->
<div class="main-container">
  <div class="container-fluid">
    
    <div class="row">
      <div class="col-md-6 col-12">
        <div class="site-breadcrumb">
            <ul>
              <li><a href="/admin">Dashboard</a></li>
              <li>Tag</li>
            </ul>
        </div>
      </div>
      <div class="col-md-6 col-12">
        <div class="right-actionbar float-right">
          <a href="/admin/tag/create" class="btn btn-bordered"><img src="/images/icons/plus-square.svg" alt=""> ADD TAG</a>          
        </div>
      </div>
    </div>

    <div class="row"> 
        <div class="col-12">
          <div class="card card-main">
              <div class="card-header">
                  <div class="card-title">Tag List</div>
              </div>
              <table id="tagDatatable" class="table table-hover">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Tag name</th>
                      <th scope="col">Tag Slug</th>                      
                      <th scope="col">Status</th>
                      <th scope="col">Action</th>
                    </tr>
                  </thead>
                  <tbody>                   
                  </tbody>
                </table>
          </div>
        </div>

    </div>
  </div>
</div>
 
<script type="text/javascript">

  $(function () {   
    var dataTable = $('#tagDatatable').DataTable({
          processing: false,
          serverSide: true,          
          info: false,
          lengthChange: false,
          responsive: true,
          language: {
            emptyTable: "No Tag Found"
          },
          ajax: {
                url: "{{route('tag.index')}}"
          },
          order:[[ 1, "asc" ]],          
          columns: [
            {
              sTitle: "#",
              data: "tag_id",
              name: "tag_id",
              orderable: false,
              render: function(data, type, row, meta) {                  
                  var pageinfo = dataTable.page.info();
                  var currentpage = (pageinfo.page) * pageinfo.length;
                  var display_number = (meta.row + 1) + currentpage;
                  return display_number;
              }
            },            
            {
              data: "tag_name", 
              name: "tag_name",
              orderable: true,
              searchable: true,
              render: function(data, type, row, meta) {                                    
                var str = "";
                if(data){
                  str +=  data;                
                }                               
                return str;

              }
            },
            {
              data: "tag_slug", 
              name: "tag_slug",
              orderable: true,
              searchable: true,
              render: function(data, type, row, meta) {                                    
                var str = "";
                if(data){
                  str +=  data;                
                }                               
                return str;

              }
            },            
             {
              data: "status", 
              name: "status",
              orderable: true,
              searchable: true,
              render: function(data, type, row, meta) {                                    
                var str = "";
                if(row.status === 1){
                  str += 'Active';
                } else {
                  str += 'InActive';
                }                      
                return str;

              }
            },
            {
              data: "action",
              name: "action",
              orderable: false,
              searchable: false,
              render: function(data, type, row, meta) {                                    
                var str = "";
                str += '<a class="action-btn" title="Edit" id="'+row.tag_id+'" href="/admin/tag/'+row.tag_id+'/edit"><img src="/images/icons/pencil.svg" width="18" alt="edit"></a>';
                str += '<a class="action-btn delete_record" title="Delete" href="#" data-id="'+row.tag_id+'" data-toggle="modal" data-target="#modal-sm-'+row.tag_id+'"><img src="/images/icons/delete.svg" width="18" alt="delete"></a>';
                return str;
              }
            }
          ],
          fnRowCallback: function( nRow, aData, iDisplayIndex ) {           
            return nRow;
          },
          fnDrawCallback: function( oSettings ) {
            $('.delete_record').on( 'click', function (e) {
              let delId = $(this).attr("data-id");
              let url = "tag/"+delId;
              self.confirmDelete(delId, url, dataTable);                                                 
            });
          }
      });
  });
</script>

@stop