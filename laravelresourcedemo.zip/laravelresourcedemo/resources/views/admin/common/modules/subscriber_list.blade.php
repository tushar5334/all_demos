<div class="card card-main">
    <div class="card-header justify-content-between">
        <div class="card-title">Subscriber List</div>
        <div class="right-actionbar pr-2">
          <a href="javascript:;" id="exportSubscriberExcel" class="btn btn-bordered"><img src="/images/icons/msexcel.svg" alt=""> Export as excel</a>
          <div class="date-selector">
            <input type="text" id="subscriberListDatepicker" class="input-date">
          </div>
        </div>
    </div>
      <table id="subscribersTable" class="table table-hover">
          <thead>
            <tr>
              <th width="5%" scope="col">#</th>
              <th width="10%" scope="col">Msisdn</th>
              <th width="10%" scope="col">Service Id</th>
              <th width="10%" scope="col">Scode</th>
              <th width="30%" scope="col">Request server parameter</th>
              <th width="35%" scope="col">Response parameter</th>
              <th width="10%" scope="col">Created At</th>
            </tr>
          </thead>
          <tbody>
          </tbody>
        </table>
  </div>


  <script type="text/javascript">     

    $(function () {
        var dataTable= $('#subscribersTable').DataTable({
                processing: false,
                serverSide: true,
                info: false,
                lengthChange: false,
                paging: true,
                searching: false,
                language: {
                  emptyTable: "No Subscriber Found"
                },               
                ajax:{
                    url: '{!! route('subscriber.dataTable') !!}',
                    dataType: "json",
                    type: "GET",                    
                    data:{ 
                      affiliateId: '{!! request()->route('affiliateId') !!}',
                    }            
                },
                order:[[ 0, "asc" ]],
                columns: [
                  {
                    sTitle: "#",
                    data: "subscription_history_id",
                    name: "subscription_history_id",
                    orderable: false,
                    render: function(data, type, row, meta) {
                        var pageinfo = dataTable.page.info();
                        var currentpage = (pageinfo.page) * pageinfo.length;
                        var display_number = (meta.row + 1) + currentpage;
                        return display_number;
                    }
                  },
                  {
                    data: "msisdn",
                    name: "msisdn",
                    orderable: false,
                    searchable: false,
                    render: function(data, type, row, meta) {
                      var str = "";
                      if(data){
                        str +=  data;
                      }
                      return str;
                    }
                  },
                  {
                    data: "serviceid",
                    name: "serviceid",
                    orderable: false,
                    searchable: false,
                    render: function(data, type, row, meta) {
                      var str = "";
                      if(data){
                        str +=  data;
                      }
                      return str;
                    }
                  },           
                  {
                    data: "scode",
                    name: "scode",
                    orderable: false,
                    searchable: false,
                    render: function(data, type, row, meta) {
                      var str = "";
                      str +=  (data) ? data : 'N/A';
                      return str;
                    }
                  },
                  {
                    data: "request_all_server_parameter",
                    name: "request_all_server_parameter",
                    orderable: false,
                    searchable: false,
                    render: function(data, type, row, meta) {
                      var showChar = 120;
                      var str = "";
                      if(data){
                        if(data.length > showChar) {

                          var shortText= data.substring(0,showChar);
                          var cleanStr= data.replace(/["']/g, "");
                          str +=  '<div id="showrequest_'+row.subscription_history_id+'">';
                          str +=  '<a class="font-weight-light" title="'+cleanStr+'"> '+shortText + '</a>';
                          str +=  "<a id=\"toggleButton\" class='text-primary btn-sm toggleButton' data-id="+row.subscription_history_id+" data-content="+cleanStr+" href=\"javascript:void(0);\">... more</a>";
                          str +=  '</div>';

                          str +=  '<div id="hiderequest_'+row.subscription_history_id+'" style="display:none">';
                          str +=  '<a style="word-break:break-all" class="font-weight-light" title="'+cleanStr+'"> '+cleanStr + '</a>';
                          str +=  "<a id=\"toggleButton\" class='text-primary btn-sm toggleButton' data-id="+row.subscription_history_id+" data-content="+cleanStr+" href=\"javascript:void(0);\">less</a>";
                          str +=  '</div>';

                        } else {
                          str +=  data;
                        }                        
                      } else {
                        str += 'N/A';
                      }
                      return str;
                      
                    }
                  },
                  {
                    data: "response_parameter",
                    name: "response_parameter",
                    orderable: false,
                    searchable: false,
                    render: function(data, type, row, meta) {
                      var showChar = 120;
                      var str = "";
                      if(data){
                        if(data.length > showChar) {                          
                          var shortText= data.substring(0,showChar);
                          var cleanStr= data.replace(/["']/g, "");
                          str +=  '<div id="responseShowRequest_'+row.subscription_history_id+'">';
                          str +=  '<a class="font-weight-light" title="'+cleanStr+'"> '+shortText + '</a>';
                          str +=  "<a id=\"responseToggle\" class='text-primary btn-sm responseToggle' data-id="+row.subscription_history_id+" data-content="+cleanStr+" href=\"javascript:void(0);\">... more</a>";
                          str +=  '</div>';

                          str +=  '<div id="responseHideRequest_'+row.subscription_history_id+'" style="display:none">';
                          str +=  '<a style="word-break:break-all" class="font-weight-light" title="'+cleanStr+'"> '+cleanStr + '</a>';
                          str +=  "<a id=\"responseToggle\" class='text-primary btn-sm responseToggle' data-id="+row.subscription_history_id+" data-content="+cleanStr+" href=\"javascript:void(0);\"> less</a>";
                          str +=  '</div>';

                        } else {
                          str +=  data;
                        }                        
                      } else {
                        str += 'N/A';
                      }
                      return str;
                    }
                  },
                  {
                    data: "displayCreatedAt",
                    name: "displayCreatedAt",
                    orderable: false,
                    searchable: false,
                    render: function(data, type, row, meta) {
                      var str = "";
                      str +=  (data) ? data : 'N/A';
                      return str;
                    }
                  },
                ],                
                fnRowCallback: function( nRow, aData, iDisplayIndex ) {
                  return nRow;
                },
                fnDrawCallback: function( oSettings ) {
                                    
                  $('a.toggleButton').on( 'click', function (e) {
                    let reqId = this.dataset.id;
                    let content = this.dataset.content;
                    $('#showrequest_'+reqId).toggle();
                    $('#hiderequest_'+reqId).toggle();
                  });

                  $('a.responseToggle').on( 'click', function (e) {
                    let reqId = this.dataset.id;
                    let content = this.dataset.content;
                    $('#responseShowRequest_'+reqId).toggle();
                    $('#responseHideRequest_'+reqId).toggle();
                  });

                }
                
        });
        
       
        
        // DATERANGEPICKER
        $('#subscriberListDatepicker').daterangepicker({
            ranges: {
                'Today': [moment(), moment()],
                'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                'This Month': [moment().startOf('month'), moment().endOf('month')],
                'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            },
            "alwaysShowCalendars": true,
            locale: {
                format: 'DD/MM/YYYY',
                cancelLabel: 'Clear'
            },
            "opens": "left"
        }, function(start, end, label) {
          console.log('New date range selected: ' + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD') + ' (predefined range: ' + label + ')');
        });

        var startdate = moment().format('YYYY-MM-DD');
        var enddate = moment().format('YYYY-MM-DD');
        $('#subscriberListDatepicker').on('apply.daterangepicker', function(ev, picker) {
          startdate =picker.startDate.format('YYYY-MM-DD');
          enddate   =picker.endDate.format('YYYY-MM-DD');         
        });

        $('#exportSubscriberExcel').on( 'click', function (e) {
            window.location.href = "/admin/export-subscriber-excel?export=true&startdate="+startdate+"&enddate="+enddate+"&affiliateId={!! request()->route('affiliateId') !!}";
        });
    });

</script>
