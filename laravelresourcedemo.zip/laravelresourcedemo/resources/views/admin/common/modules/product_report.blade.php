<div class="card card-main">
    <div class="card-header justify-content-between">
        <div class="card-title">Product Report</div>
        <div class="right-actionbar pr-2">
          <a href="javascript:;" id="exportReportExcel" class="btn btn-bordered"><img src="/images/icons/msexcel.svg" alt=""> Export as excel</a>
          <div class="date-selector">
            <input type="text" id="reportDatepicker" class="input-date reportDatepicker">
          </div>
        </div>
    </div>
      <table id="reportTable" class="table table-hover">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Date</th>
              <th scope="col">Total New Subs/Rens</th>
              <th scope="col">Total Unsubs </th>
              <th scope="col">Total Subs </th>
              <th scope="col">Total Bills </th>
              <th scope="col">Daily Revenue </th>
              <th scope="col">Cumulative Revenue </th>
            </tr>
          </thead>
          <tbody>
          </tbody>
        </table>
  </div>


  <script type="text/javascript">
    var weekBackDays = 6;
    
    $(function () {
      var defaultStartdate = moment().subtract(weekBackDays, 'days');
      var defaultEnddate = moment();
        var dataTable= $('#reportTable').DataTable({
                processing: false,
                serverSide: true,
                info: false,
                lengthChange: false,
                paging: true,
                searching: false,
                language: {
                  emptyTable: "No Report Found"
                },                
                ajax:{
                    url: '{!! route('product-report.dataTable') !!}',
                    dataType: "json",
                    type: "GET",                    
                    data:{ 
                      affiliateId: '{!! request()->route('affiliateId') !!}',
                      startdate:defaultStartdate.format('YYYY-MM-DD'),
                      enddate: defaultEnddate.format('YYYY-MM-DD') 
                    }            
                },
                order:[[ 0, "asc" ]],
                columns: [
                  {
                    sTitle: "#",
                    data: "user_id",
                    name: "user_id",
                    orderable: false,
                    render: function(data, type, row, meta) {
                        var pageinfo = dataTable.page.info();
                        var currentpage = (pageinfo.page) * pageinfo.length;
                        var display_number = (meta.row + 1) + currentpage;
                        return display_number;
                    }
                  },
                  { 
                    data: "created_at",
                    name: "created_at",
                    orderable: false,
                    searchable: false,
                    render: function(data, type, row, meta) {
                      var str = "";
                      if(data){
                        str +=  data;
                      }
                      return str;
                    }
                  },
                  {
                    data: "total_new_subs",
                    name: "total_new_subs",
                    orderable: false,
                    searchable: false,
                    render: function(data, type, row, meta) {
                      var str = 0;
                      str +=  data;
                      return str;
                    }
                  },
                  {
                    data: "total_unsubs",
                    name: "total_unsubs",
                    orderable: false,
                    searchable: false,
                    render: function(data, type, row, meta) {
                      var str = 0;
                      str +=  data;

                      return str;
                    }
                  },
                  {
                    data: "total_subs",
                    name: "total_subs",
                    orderable: false,
                    searchable: false,
                    render: function(data, type, row, meta) {
                      var str = (data) ? data : 0;
                      return str;
                    }
                  },
                  {
                      data: "total_bill",
                      name: "total_bill",
                      orderable: false,
                      searchable: false,
                      render: function(data, type, row, meta) {
                        var str = (data) ? data : 0;
                        return str;
                      }
                    },
                    {
                      data: "daily_revenue",
                      name: "daily_revenue",
                      orderable: false,
                      searchable: false,
                      render: function(data, type, row, meta) {
                        var str = (data) ? data : 0;
                        return str;
                      }
                    },
                    {
                      data: "cumulative_revenue",
                      name: "cumulative_revenue",
                      orderable: false,
                      searchable: false,
                      render: function(data, type, row, meta) {
                        var str = (data) ? data : 0;
                        return str;
                      }
                    }
                ],
                fnRowCallback: function( nRow, aData, iDisplayIndex ) {
                  return nRow;
                },
                fnDrawCallback: function( oSettings ) {
                  
                }
        });


        // DATERANGEPICKER
        $('#reportDatepicker').daterangepicker({
            ranges: {
                'Today': [moment(), moment()],
                'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                'Last 7 Days': [moment().subtract(weekBackDays, 'days'), moment()],
                'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                'This Month': [moment().startOf('month'), moment().endOf('month')],
                'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            },
            "alwaysShowCalendars": true,
            startDate: defaultStartdate,
            endDate: defaultEnddate,
            locale: {
                format: 'DD/MM/YYYY',
                cancelLabel: 'Clear'
            },
            "opens": "left"
        }, function(start, end, label) {
          console.log('New date range selected: ' + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD') + ' (predefined range: ' + label + ')');
        });


        var startdate = defaultStartdate.format('YYYY-MM-DD');
        var enddate = defaultEnddate.format('YYYY-MM-DD');
        $('#reportDatepicker').on('apply.daterangepicker', function(ev, picker) {
          startdate =picker.startDate.format('YYYY-MM-DD');
          enddate   =picker.endDate.format('YYYY-MM-DD');         
        });

        $('#exportReportExcel').on( 'click', function (e) {
            window.location.href = "/admin/export-product-report-excel?export=true&startdate="+startdate+"&enddate="+enddate+"&affiliateId={!! request()->route('affiliateId') !!}";
        });
        
    });

</script>
