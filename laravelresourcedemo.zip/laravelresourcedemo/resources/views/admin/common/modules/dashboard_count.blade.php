<div class="card card-main">
    <div class="card-body">
        <div class="widget01">
            <div class="widget01-top">
                <h1>
                  {{ (isset($count['totalActiveSub']) && $count['totalActiveSub']) ? $count['totalActiveSub'] : 0 }}
                </h1>
                <span>Total Active Subs</span>
            </div>
            <div class="widget01-bottom">
                <h2>
                  {{ (isset($count['totalActiveUnsub']) && $count['totalActiveUnsub']) ? $count['totalActiveUnsub'] : 0 }}
                </h2>
                <span>Total Unsubs</span>
            </div>
            <div class="widget01-bottom">
                <p>
                  Today
                  <b>
                    <span class="text-success">
                      {{ (isset($count['todaysTotalActiveSub']) && $count['todaysTotalActiveSub']) ? $count['todaysTotalActiveSub'] : 0 }}
                    </span>
                    <span class="text-muted font-weight-light">|</span>
                    <span class="text-danger">
                    {{ (isset($count['todaysTotalActiveUnsub']) && $count['todaysTotalActiveUnsub']) ? $count['todaysTotalActiveUnsub'] : 0 }}
                    </span>
                  </b>
                </p>
                <p>
                  7 Days
                  <b>
                    <span class="text-success">
                      {{ (isset($count['sevenDaysTotalActiveSub']) && $count['sevenDaysTotalActiveSub']) ? $count['sevenDaysTotalActiveSub'] : 0 }}
                    </span>
                    <span class="text-muted font-weight-light">|</span>
                    <span class="text-danger">
                    {{ (isset($count['sevenDaysTotalActiveUnsub']) && $count['sevenDaysTotalActiveUnsub']) ? $count['sevenDaysTotalActiveUnsub'] : 0 }}
                    </span>
                  </b>
                </p>
                <p>
                  30 Days
                  <b>
                    <span class="text-success">
                      {{ (isset($count['thirtyDaysTotalActiveSub']) && $count['thirtyDaysTotalActiveSub']) ? $count['thirtyDaysTotalActiveSub'] : 0 }}
                    </span>
                    <span class="text-muted font-weight-light">|</span>
                    <span class="text-danger">
                    {{ (isset($count['thirtyDaysTotalActiveUnsub']) && $count['thirtyDaysTotalActiveUnsub']) ? $count['thirtyDaysTotalActiveUnsub'] : 0 }}
                    </span>
                  </b>
                </p>
            </div>
        </div>
    </div>
</div>