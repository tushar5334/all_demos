<div class="card card-main" style="height: 349px;">
    <div class="card-header header-sm">
        <div class="card-title">Subscription Index</div>
    </div>
    <div class="card-body align-content-center">
        <canvas id="subscriptionCanvas" width="1379" height="349" class="chartjs-render-monitor">
    </div>
</div>

<script type="text/javascript">

    $(window).on('load', function(){
        if($('#subscriptionCanvas').is(":visible")) {
            var ctx = document.getElementById('subscriptionCanvas').getContext('2d');
            window.myLine = new Chart(ctx, config);
        }

        setTimeout(() => {
            var tableparent = $('.dataTables_wrapper').parent();
            $(tableparent).addClass("hasTable");
        }, 200);
    });


    var labelsArr = {!! json_encode($chartData['labels']) !!};
    var subData = {!! json_encode($chartData['sub']) !!};
    var unsubData = {!! json_encode($chartData['unsub']) !!};

    var config = {
        type: 'line',
        data: {
            labels: labelsArr,
            datasets: [
                {
                    label: 'UNSUB',
                    borderColor: "rgb(255, 109, 109)",
                    fill: false,
                    backgroundColor: "rgba(255, 109, 109, 0.1)",
                    data: unsubData,
                },
                {
                    label: 'SUB',
                    backgroundColor: "rgba(39, 209, 135, 0.1)",
                    borderColor: "rgba(39, 209, 135, 1)",
                    fill: false,
                    data: subData,

                }
            ]
        },
        options: {
            responsive: true,
            title: {
                display: false,
            },
            legend: {
                display: false,
            },
            scales: {
                xAxes: [{
                    display: true,
                    scaleLabel: {
                        display: true,
                        labelString: 'Date'
                    },

                }],
                yAxes: [{
                    display: true,
                    scaleLabel: {
                        display: true,
                        labelString: 'Index Returns'
                    },
                    ticks: {
                        min: 0,
                        max: 1250,
                        stepSize: 250
                    }
                }]
            }
        }
    };

</script>