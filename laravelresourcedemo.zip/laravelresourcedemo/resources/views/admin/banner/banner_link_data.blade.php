<div class="banner">
@php
$bannerArrayLength = 1;					
@endphp	
@if(!empty($bannerLinkData))
  @php
    $bannerObj = $bannerLinkData;
    $bannerArrayLength = count($bannerLinkData) > 0 ? count($bannerLinkData) : 1;
  @endphp
@else 
  @if(old('banner'))
    @foreach(old('banner') as $key => $val)
      @php
      $bannerArrayLength = count($val);break;
      @endphp
    @endforeach
  @endif
@endif
<input type="hidden" name="hid_banner_length" id="hid_banner_length" value="{{$bannerArrayLength}}">
@for($i=0;$i<$bannerArrayLength;$i++)
@php $showIndex = $i+1; @endphp
<div class="banner_input addmore_input-row">
  <div class="row">
    <div class="col-sm-4">                                        
      <div class="form-group">
      <label class="bmd-label-floating"> Banner Link Title<span class="text-danger">*</span></label>
      <input type="text" id="banner_link_title_{{$showIndex}}" name="banner[banner_link_title][]" class="form-control {{$errors->has('banner.banner_link_title.'.$i) ? 'is-invalid' : ''}}" value="{{old('banner.banner_link_title.'.$i,isset($bannerLinkData[$i]->banner_link_title) ? $bannerLinkData[$i]->banner_link_title : '')}}">                                           
      @if ($errors->has('banner.banner_link_title.'.$i)) <p class="help-block text-danger">{{ $errors->first('banner.banner_link_title.'.$i) }}</p> @endif
      </div>
    </div>
    <div class="col-sm-4">  
      <div class="form-group">
      <label class="bmd-label-floating"> Banner Link Url <span class="text-danger">*</span></label>
      <input type="text" id="banner_link_url_{{$showIndex}}" name="banner[banner_link_url][]" class="form-control {{$errors->has('banner.banner_link_url.'.$i) ? 'is-invalid' : ''}}" value="{{old('banner.banner_link_url.'.$i,isset($bannerLinkData[$i]->banner_link_url) ? $bannerLinkData[$i]->banner_link_url : '')}}">                                           
      @if ($errors->has('banner.banner_link_url.'.$i)) <p class="help-block text-danger">{{ $errors->first('banner.banner_link_url.'.$i) }}</p> @endif
      </div>
    </div>
    <div class="col-sm-4">
    @php
    $addBut = 'none';
    $removeBut = 'block';
    @endphp
    @if($i==$bannerArrayLength-1)
    @php
    $addBut = 'block';
    $removeBut = 'none';
    @endphp
    @endif
      <button style="display: {{$addBut}}" type="button" class="form-control btn btn-primary but-append-banner add-remove-btn" id="but_append_banner_{{$showIndex}}"><i class="fas fa-plus-square fa-lg mr-2"></i>  Add</button>
      <button style="display: {{$removeBut}};" type="button" class="form-control btn btn-danger banner-remove add-remove-btn" id="but_banner_remove_{{$showIndex}}"><i class="fas fa-trash fa-lg mr-2"></i> Remove</button>
    </div>
  </div>
</div>
@endfor
</div>
<script type="text/javascript">
	$( document ).ready(function() {
		var regex = /^(.+?)(\d+)$/i;		
		var cloneIndex = $(".banner_input").length + 1;				
		console.log(cloneIndex);
		$(document).on('click','.but-append-banner',function(){
			$(".banner_input:last").clone()
			.appendTo(".banner")			
			.find("*")
			.each(function() {

				var id = this.id || "";				
				var match = id.match(regex) || [];				
				if (match.length == 3) {					
					this.id = match[1] + (cloneIndex);
					$('#'+this.id).val(null);
				}

				var label = $(this).closest('label').attr('for') || "";					
				var matchLabel = label.match(regex) || [];				
				if (matchLabel.length == 3) {					
					$(this).closest('label').attr('for',matchLabel[1] + (cloneIndex));
				}

				var labelHtml = $(this).closest('label').html() || "";
				var matchLabelHtml = labelHtml.match(regex) || [];				
				if (matchLabelHtml.length == 3) {					
					$(this).closest('label').html(matchLabelHtml[1] + (cloneIndex));
				}
			});
			$('#but_banner_remove_'+(cloneIndex-1)).show();
			$('#but_append_banner_'+(cloneIndex-1)).hide();
			$('#hid_banner_length').val(cloneIndex);
			cloneIndex++;
		});

		$(document).on('click', ".banner-remove", function () {			
			$(this).closest('.banner_input').remove();
			cloneIndex--;			
			$(".banner > .banner_input").each(function( index, element ) {				
				$(this).find("*").each(function() {
					var newIndex = index+1;

					var id = this.id || "";				
					var match = id.match(regex) || [];				
					if (match.length == 3) {
						this.id = match[1] + (newIndex);
					}

					var label = $(this).closest('label').attr('for') || "";					
					var matchLabel = label.match(regex) || [];				
					if (matchLabel.length == 3) {					
						$(this).closest('label').attr('for',matchLabel[1] + (newIndex));
					}

					var labelHtml = $(this).closest('label').html() || "";
					var matchLabelHtml = labelHtml.match(regex) || [];				
					if (matchLabelHtml.length == 3) {					
						$(this).closest('label').html(matchLabelHtml[1] + (newIndex));
					}
				});
			});			
			$('#hid_banner_length').val(cloneIndex-1);					
		});		
	});
</script>