@extends('admin.include.layout')
@section('content')

 
<!-- Main content -->
<div class="main-container">
  <div class="container-fluid">    
    <div class="row">
      <div class="col-md-6 col-12">
        <div class="site-breadcrumb">
            <ul>
              <li><a href="/admin/banner">Banner</a></li>
              <li>@if((isset($data)) && $data->banner_id) Edit @else Add @endif Banner</li>
            </ul>
        </div>
      </div>
    </div>
    <div class="row"> 
        <div class="col-12">
          <div class="card card-main">
           <form id="bannerForm" method="POST" action="{{ !empty($data->banner_id) ? route('banner.update', $data) : route('banner.store') }}" enctype="multipart/form-data">
                  {{ !empty($data->banner_id) ? method_field('PUT') :  method_field('POST') }}
              <div class="card-body">
               @csrf 
                <input id="banner_id" type="hidden" name="banner_id" value="{{ isset($data) ? $data->banner_id : '' }}">
                <div class="row">
                  <div class="col-sm-6">                                        
                    <div class="form-group">
                    <label class="bmd-label-floating"> Banner Title <span class="text-danger">*</span></label>
                    <input type="text" name="banner_title" class="form-control {{$errors->has('banner_title') ? 'is-invalid' : ''}}" value="{{ old('banner_title',$data->banner_title) }}">                                           
                    @if ($errors->has('banner_title')) <p class="help-block text-danger">{{ $errors->first('banner_title') }}</p> @endif
                    </div>
                  </div>
                  <div class="col-sm-6">  
                    <div class="form-group">
                      <label class="bmd-label-floating">Status </label> </br>
                      <div class="radio">
                          <label>
                            <input class="form-control" type="radio" name="status" id="active" value="1"{{ old('status',isset($data->status) ? $data->status : '') == "1" ? 'checked' : '' }} checked>
                            <span class="ml-4 font-weight-normal">&nbsp;Active</span>
                          </label>
                          &nbsp;&nbsp;
                          <label>
                            <input class="form-control" type="radio" name="status" id="inactive" value="0" {{ old('status',isset($data->status) ? $data->status : '') == "0" ? 'checked' : '' }}>
                            <span class="ml-4 font-weight-normal">&nbsp;InActive</span>
                          </label>
                      </div>
                      @if ($errors->has('status')) <p class="help-block text-danger">{{ $errors->first('status') }}</p> @endif 
                    </div>
                  </div>                                                         
                </div>
                <div class="row">                                                         
                  <div class="col-sm-6">                                        
                    <div class="form-group">
                      <label><strong>Banner Description <span class="text-danger">*</span></strong></label></br>
                      <textarea class="ckeditor form-control" name="banner_description" id="banner_description">{!!  old('banner_description',$data->banner_description) !!}</textarea>
                       @if ($errors->has('banner_description')) <p class="help-block text-danger">{{ $errors->first('banner_description') }}</p> @endif
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label for="profilePicture">Banner Image</label>
                      <div class="userimg-sec drop-rectangle">
                        <div class="img-dropbox">
                            <label for="profile-img">
                              <span class="file-msg">
                                <img src="/images/icons/upload.svg" width="50" alt="">
                                <strong>Drag and drop your image here</strong>
                              </span>
                              <input class="upload-profilepic {{$errors->has('banner_image') ? 'is-invalid' : ''}}" data-preview="#preview" name="banner_image" type="file" id="projectImage">
                            </label>
                        </div>
                        @if(isset($data) && $data->banner_image )
                          <div class="prod-img">
                            <img id="preview" width="100" src="{{ $data->banner_image}}">
                          </div>
                        @endif
                      </div>
                    @if ($errors->has('banner_image')) <p class="help-block text-danger">{{ $errors->first('banner_image') }}</p> @endif                            
                                                    
                    </div>
                  </div>                                                          
                </div>
                  @include('admin.banner.banner_link_data')
                <div class="row">
                  <div class="col-md-12 mb-3">
                  <button type="submit" class="btn btn-primary">Submit</button>&nbsp;
                  <a href="/admin/banner" class="btn btn-default">Cancel</a>
                  </div>
                </div>

              </div> 
            </form>

          </div>
        </div>
    </div>
  </div>
</div>
  
<script>
window.onload = function() {
 CKEDITOR.replace( 'banner_description', {
    extraPlugins: 'easyimage',
    removePlugins: 'image',
    // cloudServices_tokenUrl: 'https://example.com/cs-token-endpoint',
    // cloudServices_uploadUrl: 'https://your-organization-id.cke-cs.com/easyimage/upload/'
} );
};
//CKEDITOR.replace( 'description' );
/* CKEDITOR.replace( 'project_description', {
    extraPlugins: 'easyimage',
    removePlugins: 'image',
} ); */
//$('#description').ckeditor();
</script>

@stop

