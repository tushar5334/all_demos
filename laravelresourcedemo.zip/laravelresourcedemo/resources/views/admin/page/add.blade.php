@extends('admin.include.layout')
@section('content')

 
<!-- Main content -->
<div class="main-container">
  <div class="container-fluid">    
    <div class="row">
      <div class="col-md-6 col-12">
        <div class="site-breadcrumb">
            <ul>
              <li><a href="/admin/page">CMS</a></li>
              <li>@if((isset($data)) && $data->page_id) Edit @else Add @endif CMS</li>
            </ul>
        </div>
      </div>
    </div>
    <div class="row"> 
        <div class="col-12">
          <div class="card card-main">
            <form id="cmsForm" action="{{ !empty($data->page_id) ? route('page.update', $data) : route('page.store') }}" method="POST" enctype="multipart/form-data">          
               {{ !empty($data->page_id) ? method_field('PUT') :  method_field('POST') }}
              <div class="card-body">
               @csrf  
                <input id="page_id" type="hidden" name="page_id" value="{{ isset($data) ? $data->page_id : '' }}">
                <div class="row">
                  <div class="col-sm-6">                                        
                    <div class="form-group">
                    <label class="bmd-label-floating"> Title <span class="text-danger">*</span></label>
                    <input type="text" name="title" class="form-control {{$errors->has('title') ? 'is-invalid' : ''}}" value="{{ old('title',$data->title) }}">                                           
                    @if ($errors->has('title')) <p class="help-block text-danger">{{ $errors->first('title') }}</p> @endif
                    </div>
                  </div>                                                            
                  <div class="col-sm-6">                                        
                    <div class="form-group">
                    <label class="bmd-label-floating"> Meta Title </label>
                    <input type="text" name="meta_title" class="form-control {{$errors->has('meta_title') ? 'is-invalid' : ''}}" value="{{ old('meta_title',$data->meta_title) }}">                                           
                    @if ($errors->has('meta_title')) <p class="help-block text-danger">{{ $errors->first('meta_title') }}</p> @endif
                    </div>
                  </div>                                                            
                </div>
                <div class="row">
                  <div class="col-sm-6">                                        
                    <div class="form-group">
                    <label class="bmd-label-floating"> Meta Keywords </label>
                    <textarea name="meta_keywords" class="form-control {{$errors->has('meta_keywords') ? 'is-invalid' : ''}}">{{ old('meta_keywords',$data->meta_keywords) }}</textarea>                                     
                    @if ($errors->has('meta_keywords')) <p class="help-block text-danger">{{ $errors->first('meta_keywords') }}</p> @endif
                    </div>
                  </div>                                                            
                  <div class="col-sm-6">                                        
                    <div class="form-group">
                      <label><strong>Description </strong></label><br>
                      <textarea class="ckeditor form-control" name="description" id="description">{!!  old('description',$data->description) !!}</textarea>
                       @if ($errors->has('description')) <p class="help-block text-danger">{{ $errors->first('description') }}</p> @endif
                    </div>
                  </div>                                                            
                </div>
                 <div class="row">
                  <div class="col-sm-6">                                        
                    <div class="form-group">
                    <label class="bmd-label-floating"> Name <span class="text-danger">*</span></label>
                    <input type="text" name="name" class="form-control {{$errors->has('name') ? 'is-invalid' : ''}}" value="{{ old('name',$data->name) }}">                                           
                     @if ($errors->has('name') || $errors->has('page_slug'))
                      <p class="help-block text-danger">
                          {{ $errors->first('name') ? $errors->first('name') : $errors->first('page_slug') }}
                      </p>
                      @endif
                    </div>
                  </div>
                   <div class="col-sm-6">  
                    <div class="form-group">
                      <label class="bmd-label-floating">Status </label> </br>
                      <div class="radio">
                          <label>
                            <input class="form-control" type="radio" name="status" id="active" value="1"{{ old('status',isset($data->status) ? $data->status : '') == "1" ? 'checked' : '' }} checked>
                            <span class="ml-4 font-weight-normal">&nbsp;Active</span>
                          </label>
                          &nbsp;&nbsp;
                          <label>
                            <input class="form-control" type="radio" name="status" id="inactive" value="0" {{ old('status',isset($data->status) ? $data->status : '') == "0" ? 'checked' : '' }}>
                            <span class="ml-4 font-weight-normal">&nbsp;InActive</span>
                          </label>
                      </div>
                      @if ($errors->has('status')) <p class="help-block text-danger">{{ $errors->first('status') }}</p> @endif 
                    </div>
                  </div>                                                         
                </div>
                <div class="row">
                  <div class="col-md-12 mb-3">
                  <button type="submit" class="btn btn-primary">Submit</button>&nbsp;
                  <a href="/admin/page" class="btn btn-default">Cancel</a>
                  </div>
                </div>

              </div> 
            </form>

          </div>
        </div>
    </div>
  </div>
</div>
<script>
window.onload = function() {
 CKEDITOR.replace( 'description', {
    extraPlugins: 'easyimage',
    removePlugins: 'image',
    cloudServices_tokenUrl: 'https://example.com/cs-token-endpoint',
    cloudServices_uploadUrl: 'https://your-organization-id.cke-cs.com/easyimage/upload/'
} );
};
//CKEDITOR.replace( 'description' );
// CKEDITOR.replace( 'description', {
//     extraPlugins: 'easyimage',
//     removePlugins: 'image',
//    /*  cloudServices_tokenUrl: 'https://example.com/cs-token-endpoint',
//     cloudServices_uploadUrl: 'https://your-organization-id.cke-cs.com/easyimage/upload/' */
// } );
</script>

@stop

