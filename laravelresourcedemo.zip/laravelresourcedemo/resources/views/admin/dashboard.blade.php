@extends('admin.include.layout')

@section('content')

<div class="main-container">
  <div class="container-fluid">
      <div class="row">
        <div class="col-md-6 col-12">
          <div class="site-breadcrumb">
              <ul>
                <li><a href="/admin">Dashboard</a></li>
              </ul>
          </div>
        </div>
        
      </div>
      <div class="row">
          
      </div>
  </div>
</div>



@stop

