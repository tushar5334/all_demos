@extends('admin.include.layout')
@section('content')

 
<!-- Main content -->
<div class="main-container">
  <div class="container-fluid">    
    <div class="row">
      <div class="col-md-6 col-12">
        <div class="site-breadcrumb">
            <ul>
              <li><a href="/admin/project">Project</a></li>
              <li>@if((isset($data)) && $data->project_id) Edit @else Add @endif Project</li>
            </ul>
        </div>
      </div>
    </div>
    <div class="row"> 
        <div class="col-12">
          <div class="card card-main">
          <form id="projectForm" method="POST" action="{{ !empty($data->project_id) ? route('project.update', $data) : route('project.store') }}" enctype="multipart/form-data">
                  {{ !empty($data->project_id) ? method_field('PUT') :  method_field('POST') }}
              <div class="card-body">
               @csrf
                <input id="project_id" type="hidden" name="project_id" value="{{ isset($data) ? $data->project_id : '' }}">
                <div class="row">
                  <div class="col-sm-6">                                        
                    <div class="form-group">
                    <label class="bmd-label-floating"> Project Name <span class="text-danger">*</span></label>
                    <input type="text" name="project_name" class="form-control {{$errors->has('project_name') ? 'is-invalid' : ''}}" value="{{ old('project_name',$data->project_name) }}">                                           
                    @if ($errors->has('project_name') || $errors->has('project_slug'))
                    <p class="help-block text-danger">
                        {{ $errors->first('project_name') ? $errors->first('project_name') : $errors->first('project_slug') }}
                    </p>
                    @endif
                    </div>
                  </div>                                                            
                  <div class="col-sm-6">                                        
                    <div class="form-group">
                    <label class="bmd-label-floating"> Client Info <span class="text-danger">*</span></label>
                    <input type="text" name="client_info" class="form-control {{$errors->has('client_info') ? 'is-invalid' : ''}}" value="{{ old('client_info',$data->client_info) }}">
                    @if ($errors->has('client_info')) <p class="help-block text-danger">{{ $errors->first('client_info') }}</p> @endif
                    </div>
                  </div>                                                            
                </div>
                <div class="row">
                  <div class="col-sm-6">                                        
                    <div class="form-group">
                    <label class="bmd-label-floating"> Project Url <span class="text-danger">*</span></label>
                    <input type="text" name="project_url" class="form-control {{$errors->has('project_url') ? 'is-invalid' : ''}}" value="{{ old('project_url',$data->project_url) }}">                                           
                    @if ($errors->has('project_url')) <p class="help-block text-danger">{{ $errors->first('project_url') }}</p> @endif
                    </div>
                  </div>                                                            
                  <div class="col-sm-6">                                        
                    <div class="form-group">
                    <label class="bmd-label-floating"> Video Url <span class="text-danger">*</span></label>
                    <input type="text" name="video_url" class="form-control {{$errors->has('video_url') ? 'is-invalid' : ''}}" value="{{ old('video_url',$data->video_url) }}">
                    @if ($errors->has('video_url')) <p class="help-block text-danger">{{ $errors->first('video_url') }}</p> @endif
                    </div>
                  </div>                                                            
                </div>
                <div class="row">                                                         
                  <div class="col-sm-6">                                        
                    <div class="form-group">
                      <label><strong>Project Description <span class="text-danger">*</span></strong></label></br>
                      <textarea class="ckeditor form-control" name="project_description" id="project_description">{!! old('project_description',$data->project_description) !!}</textarea>
                       @if ($errors->has('project_description')) <p class="help-block text-danger">{{ $errors->first('project_description') }}</p> @endif
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label for="profilePicture">Project Image</label>
                      <div class="userimg-sec drop-rectangle">
                        <div class="img-dropbox">
                            <label for="profile-img">
                              <span class="file-msg">
                                <img src="/images/icons/upload.svg" width="50" alt="">
                                <strong>Drag and drop your image here</strong>
                              </span>
                              <input class="upload-profilepic {{$errors->has('project_image') ? 'is-invalid' : ''}}" data-preview="#preview" name="project_image" type="file" id="projectImage">
                            </label>
                        </div>
                        @if(isset($data) && $data->project_image )
                          <div class="prod-img">
                            <img id="preview" width="100" src="{{ $data->project_image}}">
                          </div>
                        @endif
                      </div>
                    @if ($errors->has('project_image')) <p class="help-block text-danger">{{ $errors->first('project_image') }}</p> @endif                            
                                                    
                    </div>
                  </div>                                                          
                </div>
                <div class="row">
                   <div class="col-sm-6">  
                    <div class="form-group">
                      <label class="bmd-label-floating">Status </label> </br>
                      <div class="radio">
                          <label>
                            <input class="form-control" type="radio" name="status" id="active" value="1"{{ old('status',isset($data->status) ? $data->status : '') == "1" ? 'checked' : '' }} checked>
                            <span class="ml-4 font-weight-normal">&nbsp;Active</span>
                          </label>
                          &nbsp;&nbsp;
                          <label>
                            <input class="form-control" type="radio" name="status" id="inactive" value="0" {{ old('status',isset($data->status) ? $data->status : '') == "0" ? 'checked' : '' }}>
                            <span class="ml-4 font-weight-normal">&nbsp;InActive</span>
                          </label>
                      </div>
                      @if ($errors->has('status')) <p class="help-block text-danger">{{ $errors->first('status') }}</p> @endif 
                    </div>
                  </div>  
                </div>
                <div class="row">
                  <div class="col-md-12 mb-3">
                  <button type="submit" class="btn btn-primary">Submit</button>&nbsp;
                  <a href="/admin/project" class="btn btn-default">Cancel</a>
                  </div>
                </div>

              </div> 
            </form>

          </div>
        </div>
    </div>
  </div>
</div>
  
<script>
window.onload = function() {
 CKEDITOR.replace( 'project_description', {
    extraPlugins: 'easyimage',
    removePlugins: 'image',
    // cloudServices_tokenUrl: 'https://example.com/cs-token-endpoint',
    // cloudServices_uploadUrl: 'https://your-organization-id.cke-cs.com/easyimage/upload/'
} );
};
//CKEDITOR.replace( 'description' );
/* CKEDITOR.replace( 'project_description', {
    extraPlugins: 'easyimage',
    removePlugins: 'image',
} ); */
//$('#description').ckeditor();
</script>

@stop

