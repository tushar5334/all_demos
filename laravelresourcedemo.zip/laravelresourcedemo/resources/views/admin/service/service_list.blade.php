@extends('admin.include.layout')

@section('content')

<!-- Main content -->
<div class="main-container">
  <div class="container-fluid">
    
    <div class="row">
      <div class="col-md-6 col-12">
        <div class="site-breadcrumb">
            <ul>
              <li><a href="/admin">Dashboard</a></li>
              <li>Services</li>
            </ul>
        </div>
      </div>
      <div class="col-md-6 col-12">
        <div class="right-actionbar float-right">
          <a href="/admin/service/create" class="btn btn-bordered"><img src="/images/icons/plus-square.svg" alt=""> ADD Service</a>
          {{-- <div class="date-selector">
            <input type="text" id="datepicker01" class="input-date">
          </div> --}}
        </div>
      </div>
    </div>

    <div class="row"> 
        <div class="col-12">
          <div class="card card-main">
              <div class="card-header">
                  <div class="card-title">Service List</div>
              </div>
              <table id="serviceDatatable" class="table table-hover">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Service Name</th>
                      <th scope="col">Service Description</th>                      
                      <th scope="col">Service Image</th>
                      <th scope="col">Service Status</th>                                                                 
                      <th scope="col">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    
                  </tbody>
                </table>
          </div>
        </div>

    </div>
  </div>
</div>


<script type="text/javascript">

  $(function () {   
    var dataTable = $('#serviceDatatable').DataTable({
          processing: false,
          serverSide: true,          
          info: false,
          lengthChange: false,
          responsive: true,
          language: {
            emptyTable: "No Services Found"
          },
          ajax: {
              url: "{{route('service.index')}}"
          },
          order:[[ 1, "asc" ]],
          /*columnDefs: [
            {
                'targets': [0,1,2,3],
                'createdCell':  function (td, cellData, rowData, row, col) {
                    $(td).attr('data-title', 'cell-' + rowData); 
                }
            }
          ],*/
          columns: [
            {
              sTitle: "#",
              data: "service_id",
              name: "service_id",
              orderable: false,
              render: function(data, type, row, meta) {                  
                  var pageinfo = dataTable.page.info();
                  var currentpage = (pageinfo.page) * pageinfo.length;
                  var display_number = (meta.row + 1) + currentpage;
                  return display_number;
              }
            },
            
            {
              data: "service_name", 
              name: "service_name",
              orderable: true,
              searchable: true,
              render: function(data, type, row, meta) {                                    
                var str = "";
                if(data){
                  str +=  data;                
                }                               
                return str;

              }
            },
            {
              data: "service_description", 
              name: "service_description",
              orderable: true,
              searchable: true,
              render: function(data, type, row, meta) {                                    
               var Char = 20;                                    
                var str = "";
               if(data){
                if(data.length > Char) {

                  var SmallText= data.substring(0,Char);
                  var cleanStr= data.replace(/["']/g, "");
                  str +=  '<div id="showrequest_'+row.service_id+'">';
                  str +=  '<a class="font-weight-light" title="'+cleanStr+'"> '+SmallText + '</a>';
                  str +=  "<a id=\"toggleButton\" class='text-primary btn-sm toggleButton' data-id="+row.service_id+" data-content="+cleanStr+" href=\"javascript:void(0);\">... more</a>";
                  str +=  '</div>';

                  str +=  '<div id="hiderequest_'+row.service_id+'" style="display:none">';
                  str +=  '<a style="word-break:break-all" class="font-weight-light" title="'+cleanStr+'"> '+cleanStr + '</a>';
                  str +=  "<a id=\"toggleButton\" class='text-primary btn-sm toggleButton' data-id="+row.service_id+" data-content="+cleanStr+" href=\"javascript:void(0);\">less</a>";
                  str +=  '</div>';

                } else {
                  str +=  data;
                }                        
              } else {
                str += 'N/A';
              }                                            
                return str;

              }
            },
            {
              data: "service_image", 
              name: "service_image",
              orderable: true,
              searchable: true,
              render: function(data, type, row, meta) {                                    
                var str = "";
                str += '<div class="icon">';
                str += '<div class="mr-2 float-left">';
                if(row.service_image){
                  str += '<img class="user-image" width="42" height="42" src="'+row.service_image+'" onerror="this.onerror=null;this.src="/images/avatar5.png";" />';
                } else {
                  str += '<img class="user-image" width="42" height="42" src="/images/avatar5.png">';
                }
                str += '</div></div>';                            
                return str;

              }
            },
            {
              data: "status", 
              name: "status",
              orderable: true,
              searchable: true,
              render: function(data, type, row, meta) {                                    
                var str = "";
                if(row.status === 1){
                  str += 'Active';
                } else {
                  str += 'InActive';
                }                      
                return str;

              }
            },
            {
              data: "action",
              name: "action",
              orderable: false,
              searchable: false,
              render: function(data, type, row, meta) {                                    
                var str = "";
                str += '<a class="action-btn" title="Edit" id="'+row.service_id+'" href="/admin/service/'+row.service_id+'/edit"><img src="/images/icons/pencil.svg" width="18" alt="edit"></a>';
               
                str += '<a class="action-btn delete_record" title="Delete" href="#" data-id="'+row.service_id+'" data-toggle="modal" data-target="#modal-sm-'+row.service_id+'"><img src="/images/icons/delete.svg" width="18" alt="delete"></a>';
              
                return str;
              }
            }
          ],
          fnRowCallback: function( nRow, aData, iDisplayIndex ) {           
            return nRow;
          },
          fnDrawCallback: function( oSettings ) {
            // Delete Record
            $('.delete_record').on( 'click', function (e) {
              let delId = $(this).attr("data-id");
              let url = "service/"+delId;
              self.confirmDelete(delId, url, dataTable);                                                 
            });
            $('a.toggleButton').on( 'click', function (e) {
              let reqId = this.dataset.id;
              let content = this.dataset.content;
              $('#showrequest_'+reqId).toggle();
              $('#hiderequest_'+reqId).toggle();
            });

            $('a.responseToggle').on( 'click', function (e) {
              let reqId = this.dataset.id;
              let content = this.dataset.content;
              $('#responseShowRequest_'+reqId).toggle();
              $('#responseHideRequest_'+reqId).toggle();
            });
          },
          createdRow: function( row, data, dataIndex ) {
            // Set the data-status attribute, and add a class
            $( row ).find('td:eq(0)')
            .attr('data-title', '#');
            $( row ).find('td:eq(1)')
            .attr('data-title', 'Service Name');
            $( row ).find('td:eq(2)')
            .attr('data-title', 'Service Description');
            $( row ).find('td:eq(3)')
            .attr('data-title', 'Service Image');
            $( row ).find('td:eq(4)')
            .attr('data-title', 'Service Status');
            $( row ).find('td:eq(5)')
            .attr('data-title', 'Action');
            /*$( row ).find('td:eq(0)')
            .attr('data-status', data.status ? 'locked' : 'unlocked')
            .addClass('asset-context box');*/
          }
      });
  });
</script>

@stop