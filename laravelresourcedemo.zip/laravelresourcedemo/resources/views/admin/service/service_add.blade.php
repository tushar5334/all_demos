@extends('admin.include.layout')
@section('content')

 
<!-- Main content -->
<div class="main-container">
  <div class="container-fluid">    
    <div class="row">
      <div class="col-md-6 col-12">
        <div class="site-breadcrumb">
            <ul>
              <li><a href="/admin/service">Srvices</a></li>
              <li>@if((isset($data)) && $data->service_id) Edit @else Add @endif Service</li>
            </ul>
        </div>
      </div>
    </div>
    <div class="row"> 
        <div class="col-12">
          <div class="card card-main">
           <form id="cmsForm" method="POST" action="{{ !empty($data->service_id) ? route('service.update', $data) : route('service.store') }}" enctype="multipart/form-data">
                  {{ !empty($data->service_id) ? method_field('PUT') :  method_field('POST') }}
              <div class="card-body">
              @csrf 
                <input id="service_id" type="hidden" name="service_id" value="{{ isset($data) ? $data->service_id : '' }}">
                <div class="row">
                  <div class="col-sm-6">                                        
                    <div class="form-group">
                    <label class="bmd-label-floating"> Service Name <span class="text-danger">*</span></label>
                    <input type="text" name="service_name" class="form-control {{$errors->has('service_name') ? 'is-invalid' : ''}}" value="{{ old('service_name',$data->service_name) }}">                                           
                    @if ($errors->has('service_name') || $errors->has('service_slug'))
                    <p class="help-block text-danger">
                        {{ $errors->first('service_name') ? $errors->first('service_name') : $errors->first('service_slug') }}
                    </p>
                    @endif
                    </div>
                  </div>         
                  <div class="col-sm-6">  
                    <div class="form-group">
                      <label class="bmd-label-floating">Status </label> </br>
                      <div class="radio">
                          <label>
                            <input class="form-control" type="radio" name="status" id="active" value="1"{{ old('status',isset($data->status) ? $data->status : '') == "1" ? 'checked' : '' }} checked>
                            <span class="ml-4 font-weight-normal">&nbsp;Active</span>
                          </label>
                          &nbsp;&nbsp;
                          <label>
                            <input class="form-control" type="radio" name="status" id="inactive" value="0" {{ old('status',isset($data->status) ? $data->status : '') == "0" ? 'checked' : '' }}>
                            <span class="ml-4 font-weight-normal">&nbsp;InActive</span>
                          </label>
                      </div>
                      @if ($errors->has('status')) <p class="help-block text-danger">{{ $errors->first('status') }}</p> @endif 
                    </div>
                  </div>                                                                                                     
                </div>
                <div class="row">                                                         
                  <div class="col-sm-6">                                        
                    <div class="form-group">
                      <label><strong>Description <span class="text-danger">*</span></strong></label></br>
                      <textarea class="ckeditor form-control" name="service_description" id="service_description">{!! old('service_description',$data->service_description) !!}</textarea>
                       @if ($errors->has('service_description')) <p class="help-block text-danger">{{ $errors->first('service_description') }}</p> @endif
                    </div>
                  </div>   
                  <div class="col-lg-6">
                    <div class="form-group">
                      <label >Service Image</label>
                      <div class="userimg-sec drop-rectangle">
                        <div class="img-dropbox">
                            <label for="profile-img">
                              <span class="file-msg">
                                <img src="/images/icons/upload.svg" width="50" alt="">
                                <strong>Drag and drop your image here</strong>
                              </span>
                              <input class="upload-profilepic {{$errors->has('service_image') ? 'is-invalid' : ''}}" data-preview="#service-preview" name="service_image" type="file" id="ServiceImage">
                            </label>
                        </div>
                        @if(isset($data->service_image) && $data->service_image)
                          <div class="prod-img">
                            <img id="image-preview" width="50" src="{{ $data->service_image}}">
                          </div>
                        @endif
                    </div>
                      @if ($errors->has('service_image')) <p class="help-block text-danger">{{ $errors->first('service_image') }}</p> @endif                            
                    </div>
                  </div>                                                             
                </div>
                <div class="row">
                  <div class="col-md-12 mb-3">
                  <button type="submit" class="btn btn-primary">Submit</button>&nbsp;
                  <a href="/admin/service" class="btn btn-default">Cancel</a>
                  </div>
                </div>

              </div> 
            </form>

          </div>
        </div>
    </div>
  </div>
</div>
  
<script>
window.onload = function() {
 CKEDITOR.replace( 'description', {
    extraPlugins: 'easyimage',
    removePlugins: 'image',
    cloudServices_tokenUrl: 'https://example.com/cs-token-endpoint',
    cloudServices_uploadUrl: 'https://your-organization-id.cke-cs.com/easyimage/upload/'
} );
};
//CKEDITOR.replace( 'description' );
/* CKEDITOR.replace( 'description', {
    extraPlugins: 'easyimage',
    removePlugins: 'image',
} ); */
//$('#description').ckeditor();
</script>
<script>
$(document).ready(function () {
   if ($("#serviceForm").length > 0) {
    $("#serviceForm").validate({
      rules: {
        service_name:{
          required:true
        },
        service_description:{
          required:true
        },
        service_image:{
          // required: true,
          accept:"jpeg,png,jpg,gif,svg"
        },
      },
      messages: {
        service_name:{
          required:'<p class="help-block text-danger"> Service name field is required. </p>'
        },
        service_description:{
          required:'<p class="help-block text-danger"> Service description field is required. </p>'
        },
        service_image:{
          accept:'<p class="help-block text-danger"> Only image type jpeg/png/jpg/gif/svg is allowed. </p>'
        },
      },
    })
  }
});
</script>

@stop

