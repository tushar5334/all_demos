@extends('admin.include.layout')
@section('content')


<!-- Main content -->
<div class="main-container">
  <div class="container-fluid">
	<div class="row">
	  <div class="col-md-6 col-12">
		<div class="site-breadcrumb">
			<ul>
			  <li><a href="/admin">Dashboard</a></li>
			  <li>Affiliate Credential</li>
			</ul>
		</div>
	  </div>
	</div>
	<div class="row">
		<div class="scroll-to-top"><img src="/images/icons/up-arrow.svg" alt=""></div>
		<div class="col-12">
			<div class="affiliate-tab">
				<a data-id="#integration-guide" class="active" href="#">API Integration Guide</a>
				<a data-id="#affiliate-credentials" href="#">Affiliate Credentials</a>
			</div>

			<div id="integration-guide" class="affiliate-credential affiliate-content show">
				<div class="row">
					<div class="col-md-3 affilete-menu">
						<h4>General Usage</h4>
						<ol class="accordion-fc">
							<li><a href="#Introduction">Introduction</a></li>
							<li><a href="#Authentication">Authentication</a></li>
							<li><a href="#Subscriptions">Subscriptions</a>
								<ol>
									<li><a href="#Get-Services">Get Services</a></li>
									<li><a href="#request">Request</a></li>
									<li><a href="#JSON-request-format">JSON request format</a></li>
									<li><a href="#Parameters">Parameters</a></li>
									<!-- <li><a href="#Get-Services">Get Services</a></li>
									<li><a href="#Request">Request</a></li>
									<li><a href="#JSON-request-format">JSON request format</a></li>
									<li><a href="#Parameters">Parameters</a></li> -->
								</ol>
							</li>
							<li><a href="#UnSubscription">UnSubscription</a></li>
							<li><a href="#Check-Subscription-Status">Check-Subscription-Status</a></li>
							<li><a href="#Abbreviations">Abbreviations</a></li>
							<li><a href="#Error-Codes">Error Codes</a></li>
						</ol>
					</div>
					<div class="col-md-9 offset-md-3 affilete-content">
						<div id="Introduction">
							<h3>1. Introduction</h3>
							<div class="affilete-details">
								<p>This document gives an overview of the API methods that can be used by the third party vendors
									for integrating fanclash API on HTTP protocol.</p>
							</div>
						</div>
						<div id="Authentication">
							<h3>2. Authentication</h3>
							<div class="affilete-details">
								<h5>2.1 Headers</h5>
								<p>Each request to Fanclash API on server side would require Access Token and Data Signature in
									HTTP headers.</p>
								<div>
									The HTTP header names are:
									<ul>
										<li> Access Token : Authorization </li>
										<li> Data Signature : x-signature </li>
									</ul>
								</div>

								<h5>2.2 Access Token</h5>
								<p>Access Token: Authentication is also part of the URL access by the Vendors.</p>
								<p>Sample for reference: <code>"Authorization: Bearer
									eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwOlwvXC9mYW5jbGFzaC5sb2NhbF
									wvYXBpXC9sb2dpbiIsImlhdCI6MTU5MjM5ODE1OSwiZXhwIjoxNTkyNDAxNzU5L"</code></p>
								<p>Note: User details will be changed at any point of time with prior information.</p>
								<div class="space20"></div>
								<p class="text-danger">**Note: user-id and user-password refer to your login credentials for Fanclash Dashboard. E.g. email/password.</p>



								<h5 id="JSON-request-format">2.2.1 JSON request format</h5>
								<div>
	<code>
	<pre>
	POST .../api/login
	HTTP/1.1
	Accept: application/json
	Content-Type: application/json
	{
		"email":"user-id",
		"password":"user-password"
	}
	</pre>
	</code>
								</div>

								<h5>2.2.2 Success Response JSON Format</h5>
								<div>
	<code>
	<pre>
	HTTP/1.1 200 OK
	Content-Type: application/json
	{
		"status": true,
		"statusCode": 200,
		"message": "Login success",
		"data": {
			"token": "Authentication token",
			"userData": {
				// user details show here.
			}
		}
	}
	</pre>
	</code>
								</div>

								<h5>2.3 Data Signature</h5>
								<p>Data Signature: can be generated in the following manner:</p>

								<!-- tabbing start	 -->
								<div class="col-md-12 affilete-right">
									<div class="code-header">
										<ul class="nav nav-tabs">
											<li class="nav-item">
											<a class="nav-link active" data-id="#node" href="#">NODE.JS</a>
											</li>
											<li class="nav-item">
											<a class="nav-link" data-id="#python" href="#">PYTHON</a>
											</li>
											<li class="nav-item">
											<a class="nav-link" data-id="#php" href="#">PHP</a>
											</li>
										</ul>
									</div>
									<div class="code-main show" id="node">
										<div class="code-container">
											<div class="code-title">
												<span>Data Encryption script using Node Js</span>
												<a data-toggle="tooltip" data-placement="top" title="Copy to Clipboard" class="copy-btn" id="copy-nodeData"><img src="/images/icons/copy.svg" alt="">
													<span>Copied!</span>
												</a>
												<script>
													$(document).on('click', '#copy-nodeData', function() {
														var range = document.createRange();
														range.selectNode(document.getElementById("nodeData"));
														window.getSelection().removeAllRanges(); // clear current selection
														window.getSelection().addRange(range); // to select text
														document.execCommand("copy");
														window.getSelection().removeAllRanges();// to deselect
														$(this).children('span').addClass('animate').delay(2000).queue(function(){
															$(this).removeClass('animate');
															$(this).dequeue();
														});
													});
												</script>
											</div>
											<pre>
												<code id="nodeData">
const secret_key = "secret_key";
const secret_iv = "api_salt";
$string = 'your data key=value concatenation with &';

const ENC_KEY = crypto.createHash('sha256').update(secret_key).digest('hex').substr(0,32);
const iv_hash = crypto.createHash('sha256').update(secret_iv).digest('hex');

const IV = iv_hash.substr(0, 16);

var encrypt = ((val) => {
    let cipher = crypto.createCipheriv('aes-256-cbc', ENC_KEY, IV);
    let encrypted = cipher.update(val, 'utf8', 'base64');
    encrypted += cipher.final('base64');

    let base64data = Buffer(encrypted).toString('base64');
    return base64data;
});

encrypted_key = encrypt(phrase);
console.log("encrypt :: ", encrypted_key);
												</code>
											</pre>
										</div>
									</div>
									<div class="code-main" id="python">
										<div class="code-container">
											<div class="code-title">
												<span>Data Encryption script using Python</span>
												<a data-toggle="tooltip" data-placement="top" class="copy-btn" title="Copy to Clipboard" id="copy-pythonData"><img src="/images/icons/copy.svg" alt="">
													<span class="">Copied!</span>
												</a>
												<script>
													$(document).on('click', '#copy-pythonData', function() {
														var range = document.createRange();
														range.selectNode(document.getElementById("pythonData"));
														window.getSelection().removeAllRanges(); // clear current selection
														window.getSelection().addRange(range); // to select text
														document.execCommand("copy");
														window.getSelection().removeAllRanges();// to deselect
														$(this).children('span').addClass('animate').delay(2000).queue(function(){
															$(this).removeClass('animate');
															$(this).dequeue();
														});
													});
												</script>
											</div>
											<pre>
												<code id="pythonData">

class AESCipher(object):

def __init__(self, key, iv):
	self.bs = AES.block_size
	self.key = hashlib.sha256(key.encode('utf-8')).hexdigest()[:32].encode("utf-8")
	self.iv = hashlib.sha256(iv.encode('utf-8')).hexdigest()[:16].encode("utf-8")

def encrypt( self, raw ):
	raw = self._pad(raw)
    cipher = AES.new(self.key, AES.MODE_CBC, self.iv)
    encrypted = base64.b64encode(cipher.encrypt(raw))
    return base64.b64encode(encrypted)

def _pad(self, s):
    return s + (self.bs - len(s) % self.bs) * chr(self.bs - len(s) % self.bs)

@staticmethod
def _unpad(s):
    return s[:-ord(s[len(s)-1:])]

secret_key = 'secret_key';
secret_iv  = 'api_salt';
string     = 'your data key=value concat with &';

aes_obj   = AESCipher(secret_key, secret_iv)
encrypted = aes_obj.encrypt(string)

print("ENCRYPTION: ", str(encrypted))
												</code>
											</pre>
										</div>
									</div>
									<div class="code-main" id="php">
										<div class="code-container">
											<div class="code-title">
												<span>Data Encryption script using PHP</span>
												<a data-toggle="tooltip" data-placement="top" class="copy-btn" title="Copy to Clipboard" id="copy-phpdata"><img src="/images/icons/copy.svg" alt="">
													<span class="">Copied!</span>
												</a>
												<script>
													$(document).on('click', '#copy-phpdata', function() {
														var range = document.createRange();
														range.selectNode(document.getElementById("phpdata"));
														window.getSelection().removeAllRanges(); // clear current selection
														window.getSelection().addRange(range); // to select text
														document.execCommand("copy");
														window.getSelection().removeAllRanges();// to deselect
														$(this).children('span').addClass('animate').delay(2000).queue(function(){
															$(this).removeClass('animate');
															$(this).dequeue();
														});
													});
												</script>
											</div>
											<pre>
												<code id="phpdata">
$secret_key = "secret_key";
$secret_iv = "api_salt";
$string = 'your data key=value concatenation with &';

$encrypt_method = "AES-256-CBC";

$key = hash('sha256', $secret_key);
$iv = substr(hash('sha256', $secret_iv), 0, 16);

$encrypted = base64_encode( openssl_encrypt( $string, $encrypt_method, $key, 0, $iv ));

return $encrypted;
												</code>
											</pre>
										</div>
									</div>
								</div>
								<!-- tabbing End -->

								<p></p>
								<p>1) Send the encrypt string in the X-SIGNATURE HTTP Header and same data object will pass in
request body. </p>
								<p>Note: In case encrypted string does not match at the server, error will be returned with the error
code, 401 – Bad Request.</p>
							</div>
						</div>
						<div id="Subscriptions">
							<h3>3. Subscriptions</h3>
							<div class="affilete-details">
								<h5 id="Get-Services">3.1 Get Services</h5>
								<p>This method is used to get the available services in the platform. Below is the request and response format of the API.</p>
								<h5 id="request">3.2 Request</h5>
								<h5>3.2.1 Parameters</h5>
								<div class="card card-main">
									<table>
										<thead>
											<tr>
												<th>S.No</th>
												<th>Parameter</th>
												<th>Data Type</th>
												<th>Description</th>
												<th>Requirement</th>
											</tr>
										</thead>
										<tbody>
											<tr>
												<td data-title="S.No">1</td>
												<td data-title="Parameter">reqtype</td>
												<td data-title="Data Type">varchar(50)</td>
												<td data-title="Description">Always pass 'SUB'.</td>
												<td data-title="Requirement">Mandatory</td>
											</tr>
											<tr>
												<td data-title="S.No">2</td>
												<td data-title="Parameter">msisdn</td>
												<td data-title="Data Type">double</td>
												<td data-title="Description">Always pass the Mobile number of the subscriber with prefix 0 & without country code 27.<br><i class="text-danger">**Note: msisdn must be in string formate</i></td>
												<td data-title="Requirement">Mandatory</td>
											</tr>
											<tr>
												<td data-title="S.No">3</td>
												<td data-title="Parameter">serviceid</td>
												<td data-title="Data Type">varchar(50)</td>
												<td data-title="Description">Always pass 'BGAMES'.</td>
												<td data-title="Requirement">Mandatory</td>
											</tr>
											<tr>
												<td data-title="S.No">4</td>
												<td data-title="Parameter">scode</td>
												<td data-title="Data Type">double</td>
												<td data-title="Description">Always pass '2783123686'.</td>
												<td data-title="Requirement">Mandatory</td>
											</tr>
											<tr>
												<td data-title="S.No">5</td>
												<td data-title="Parameter">chnl</td>
												<td data-title="Data Type">varchar(100)</td>
												<td data-title="Description">Always pass 'BGMG'.</td>
												<td data-title="Requirement">Mandatory</td>
											</tr>
											<!-- <tr>
												<td colspan="5">
													<strong>Note: The parameters are mutually exclusive, only one of them can be given, even if the
														parameters are mandatory.</strong>
												</td>
											</tr> -->
										</tbody>
									</table>
								</div>

								<h5 id="JSON-request-format">3.2.2 JSON request format</h5>
								<div>
<code>
<pre>
POST .../api/subscribe
HTTP/1.1
Accept: application/json
Content-Type: application/json
Authorization: Bearer &lt;base64 encoded application credentials&gt;
{
	"service":
	{
		"reqtype": "SERVICES",
		"msisdn": "-------",
		"serviceid": "--------",
		"scode": "--------",
		"chnl": "------"
	}
}
</pre>
</code>
								</div>

								<h5>3.3 Response</h5>
								<h5 id="Parameters">3.3.1 Parameters</h5>
								<div class="card card-main">
									<table>
										<thead>
											<tr>
												<th>S. No</th>
												<th>Parameter</th>
												<th>Data Type</th>
												<th>Description</th>
												<th>Requirement</th>
											</tr>
										</thead>
										<tbody>
											<tr>
												<td data-title="S. No">1</td>
												<td data-title="Parameter">serviceid</td>
												<td data-title="Data Type"></td>
												<td data-title="Description">Service identification key.	Eg:.SUB_NEWS,SUB_JOKE</td>
												<td data-title="Requirement"></td>
											</tr>
											<tr>
												<td data-title="S. No">2</td>
												<td data-title="Parameter">rescode</td>
												<td data-title="Data Type"></td>
												<td data-title="Description">Response code, refer to one of the
													error code mentioned below.</td>
												<td data-title="Requirement"></td>
											</tr>
											<tr>
												<td data-title="S. No">3</td>
												<td data-title="Parameter">resdescription</td>
												<td data-title="Data Type"></td>
												<td data-title="Description">Short description of the service.
													Example: Horoscope Alerts-5xxxx,
													CRIODI Alerts-5xxxx etc.</td>
												<td data-title="Requirement"></td>
											</tr>
											<tr>
												<td data-title="S. No">4</td>
												<td data-title="Parameter">status</td>
												<td data-title="Data Type"></td>
												<td data-title="Description">Status of the API action. Status value
													can be either 0 or -1. Here 0 – Success
													and - 1 for Fail.</td>
												<td data-title="Requirement"></td>
											</tr>

										</tbody>
									</table>
								</div>
								<h5>3.3.2 Success Response JSON Format</h5>
								<div>
<code>
<pre>
HTTP/1.1 200 OK
Content-Type: application/json
{
	"service":
	{
		"status": "0",
		“rescode”:””,
		"resdescription": "DESC",
		"serviceid": "KEYWORD",
	}
}
</pre>
</code>
								</div>

								<h5>3.3.3 Error Response JSON Format</h5>
								<div>
<code>
<pre>
HTTP/1.1 200 OK
Content-Type: application/json
{
	"service":
	{
		“status”:”0”
		“rescode”:”205”,
		"resdescription":"Yello. You have insufficient funds to complete this subscription request."
		"serviceid": "KEYWORD",
	}
}
</pre>
</code>
								</div>


								<div id="UnSubscription">
									<h3>4. UnSubscription</h3>
									<div class="affilete-details">
										<h5>4.1 Request</h5>
										<h5>4.1.1 Parameters</h5>
										<div class="card card-main">
											<table>
												<thead>
													<tr>
														<th>S.No</th>
														<th>Parameter</th>
														<th>Data Type</th>
														<th>Description</th>
														<th>Requirement</th>
													</tr>
												</thead>
												<tbody>

													<tr>
														<td data-title="S.No">1</td>
														<td data-title="Parameter">reqtype</td>
														<td data-title="Data Type">varchar(50)</td>
														<td data-title="Description">Always pass 'UNSUB'.</td>
														<td data-title="Requirement">Mandatory</td>
													</tr>
													<tr>
														<td data-title="S.No">2</td>
														<td data-title="Parameter">msisdn</td>
														<td data-title="Data Type">double</td>
														<td data-title="Description">Always pass the Mobile number of the subscriber with prefix 0 & without country code 27.<br><i class="text-danger">**Note: msisdn must be in string formate</i></td>
														<td data-title="Requirement">Mandatory</td>
													</tr>
													<tr>
														<td data-title="S.No">3</td>
														<td data-title="Parameter">serviceid</td>
														<td data-title="Data Type">varchar(50)</td>
														<td data-title="Description">Always pass 'BGAMES'.</td>
														<td data-title="Requirement">Mandatory</td>
													</tr>
													<tr>
														<td data-title="S.No">4</td>
														<td data-title="Parameter">scode</td>
														<td data-title="Data Type">double</td>
														<td data-title="Description">Always pass '2783123686'.</td>
														<td data-title="Requirement">Mandatory</td>
													</tr>
													<tr>
														<td data-title="S.No">5</td>
														<td data-title="Parameter">chnl</td>
														<td data-title="Data Type">varchar(100)</td>
														<td data-title="Description">Always pass 'BGMG'.</td>
														<td data-title="Requirement">Mandatory</td>
													</tr>
													<!-- <tr>
														<td colspan="5">
															<strong>Note: The parameters are mutually exclusive, only one of them can be given, even if the
																parameters are mandatory.</strong>
														</td>
													</tr> -->
												</tbody>
											</table>
										</div>

										<h5>4.1.2 JSON Request Format</h5>
								<div>
<code>
<pre>
POST .../api/un-subscribe/
HTTP/1.1
Accept: application/json
Content-Type: application/json
Authorization: Basic&lt;base64 encoded application credentials&gt;
{
	"service":
	{
		"reqtype": "UNSUB",
		"msisdn": "-------",
		"serviceid": "--------",
		"chnl": "------",
		"scode":"----"
	}
}
</pre>
</code>
								</div>

									</div>

									<h5>4.2 Response</h5>
									<h5>4.2.1 Parameter</h5>
									<div class="card card-main">
										<table>
											<thead>
												<tr>
													<th>S. No</th>
													<th>Parameter</th>
													<th>Data Type</th>
													<th>Description</th>
													<th>Requirement</th>
												</tr>
											</thead>
											<tbody>
												<tr>
													<td data-title="S. No">1</td>
													<td data-title="Parameter">serviceid</td>
													<td data-title="Data Type"></td>
													<td data-title="Description">Service identification key.	Eg:.SUB_NEWS,SUB_JOKE</td>
													<td data-title="Requirement"></td>
												</tr>
												<tr>
													<td data-title="S. No">2</td>
													<td data-title="Parameter">rescode</td>
													<td data-title="Data Type"></td>
													<td data-title="Description">Response code, refer to one of the
														error code mentioned below.</td>
													<td data-title="Requirement"></td>
												</tr>
												<tr>
													<td data-title="S. No">3</td>
													<td data-title="Parameter">resdescription</td>
													<td data-title="Data Type"></td>
													<td data-title="Description">Short description of the service.
														Example: Horoscope Alerts-5xxxx,
														CRIODI Alerts-5xxxx etc.</td>
													<td data-title="Requirement"></td>
												</tr>
												<tr>
													<td data-title="S. No">4</td>
													<td data-title="Parameter">status</td>
													<td data-title="Data Type"></td>
													<td data-title="Description">Status of the API action. Status value
														can be either 0 or -1. Here 0 – Success
														and - 1 for Fail.</td>
													<td data-title="Requirement"></td>
												</tr>
											</tbody>
										</table>
									</div>

									<h5>4.2.2 Success Response JSON Format</h5>
								<div>
<code>
<pre>
HTTP/1.1 200 OK
Content-Type: application/json
{
	"service":
	{
		"status": "0",
		"rescode":"",
		"resdescription": "success",
		"serviceid": "KEYWORD",
	}
}
</pre>
</code>
								</div>

								</div>



								<div id="Check-Subscription-Status">
									<h3>5. Check Subscription Status</h3>
									<p>This method can be used to get the subscriber status. API request and response JSON format is
										given below.</p>
									<div class="affilete-details">
										<h5>5.1 Request</h5>
										<h5>5.1.1 Parameter</h5>
										<div class="card card-main">
											<table>
												<thead>
													<tr>
														<th>S.No</th>
														<th>Parameter</th>
														<th>Data Type</th>
														<th>Description</th>
														<th>Requirement</th>
													</tr>
												</thead>
												<tbody>
													<tr>
														<td data-title="S.No">1</td>
														<td data-title="Parameter">reqtype</td>
														<td data-title="Data Type">varchar(50)</td>
														<td data-title="Description">Always pass 'CHECK'.</td>
														<td data-title="Requirement">Mandatory</td>
													</tr>
													<tr>
														<td data-title="S.No">2</td>
														<td data-title="Parameter">msisdn</td>
														<td data-title="Data Type">double</td>
														<td data-title="Description">Always pass the Mobile number of the subscriber with prefix 0 & without country code 27.<br><i class="text-danger">**Note: msisdn must be in string formate</i></td>
														<td data-title="Requirement">Mandatory</td>
													</tr>
													<tr>
														<td data-title="S.No">3</td>
														<td data-title="Parameter">serviceid</td>
														<td data-title="Data Type">varchar(50)</td>
														<td data-title="Description">Always pass 'BGAMES'.</td>
														<td data-title="Requirement">Mandatory</td>
													</tr>
													<tr>
														<td data-title="S.No">4</td>
														<td data-title="Parameter">scode</td>
														<td data-title="Data Type">double</td>
														<td data-title="Description">Always pass '2783123686'.</td>
														<td data-title="Requirement">Mandatory</td>
													</tr>
													<tr>
														<td data-title="S.No">5</td>
														<td data-title="Parameter">Status</td>
														<td data-title="Data Type">varchar(100)</td>
														<td data-title="Description">Status of the user to the service
															Active/Suspend/deactive/retry/queue</td>
														<td data-title="Requirement">Mandatory</td>
													</tr>
												</tbody>
											</table>
										</div>

										<h5>5.1.2 JSON Request Format</h5>
										<div>
<code>
<pre>
POST .../api/check-status
HTTP/1.1
Accept: application/json
Content-Type: application/json
Authorization: Bearer &lt;base64 encoded application credentials&gt;
{
	"service":
	{
		"reqtype": "CHECK",
		"msisdn": "-------",
		"serviceid": "-------",
		"scode": "----",
		"status": "----"
	}
}
</pre>
</code>
										</div>

										<h5>5.2 Response</h5>
										<h5>5.2.1 Parameter</h5>
										<div class="card card-main">
											<table>
												<thead>
													<tr>
														<th>S.No</th>
														<th>Parameter</th>
														<th>Data Type</th>
														<th>Description</th>
														<th>Requirement</th>
													</tr>
												</thead>
												<tbody>
													<tr>
														<td data-title="S.No">1</td>
														<td data-title="Parameter">serviceid</td>
														<td data-title="Data Type"></td>
														<td data-title="Description">Service identification info For example,
															SUB_MATCH, SUB_NEWS (Service keyword).
															Unique value for each service. Shared at the
															time of integration, service creation.</td>
														<td data-title="Requirement">Mandatory</td>
													</tr>
													<tr>
														<td data-title="S.No">2</td>
														<td data-title="Parameter">servicedesc</td>
														<td data-title="Data Type"></td>
														<td data-title="Description">Service Description.</td>
														<td data-title="Requirement">Mandatory</td>
													</tr>
													<tr>
														<td data-title="S.No">3</td>
														<td data-title="Parameter">state</td>
														<td data-title="Data Type"></td>
														<td data-title="Description">User Subscription Status, Values can be
															ACTIVE/DEACTIVE/ CANCEL/GRACE
															/SUSPEND/UNSUB/DEACTIVE/PENDING/ERR
															OR User subscription retry status
															RETRY/QUEUE</td>
														<td data-title="Requirement">Optional</td>
													</tr>
													<tr>
														<td data-title="S.No">4</td>
														<td data-title="Parameter">status</td>
														<td data-title="Data Type"></td>
														<td data-title="Description">Status of the API action. Status value can be
															either 0 or -1. Here 0 – Success and -1 for
															Fail.</td>
														<td data-title="Requirement">Optional</td>
													</tr>
													<tr>
														<td data-title="S.No">5</td>
														<td data-title="Parameter">rescode</td>
														<td data-title="Data Type"></td>
														<td data-title="Description">Response code returned by the Api</td>
														<td data-title="Requirement">Optional</td>
													</tr>
													<tr>
														<td data-title="S.No">6</td>
														<td data-title="Parameter">resdescription</td>
														<td data-title="Data Type"></td>
														<td data-title="Description">Description of response type</td>
														<td data-title="Requirement"></td>
													</tr>
													<tr>
														<td data-title="S.No">7</td>
														<td data-title="Parameter">shortcode</td>
														<td data-title="Data Type"></td>
														<td data-title="Description">Shortcode of the service</td>
														<td data-title="Requirement"></td>
													</tr>
													<tr>
														<td data-title="S.No">8</td>
														<td data-title="Parameter">serviceprice</td>
														<td data-title="Data Type"></td>
														<td data-title="Description">Subscription price of the service</td>
														<td data-title="Requirement"></td>
													</tr>
													<tr>
														<td data-title="S.No">9</td>
														<td data-title="Parameter">serviceactdate</td>
														<td data-title="Data Type"></td>
														<td data-title="Description">Service activation date</td>
														<td data-title="Requirement"></td>
													</tr>
													<tr>
														<td data-title="S.No">10</td>
														<td data-title="Parameter">nexrendate</td>
														<td data-title="Data Type"></td>
														<td data-title="Description">Renewal date</td>
														<td data-title="Requirement"></td>
													</tr>
													<tr>
														<td data-title="S.No">11</td>
														<td data-title="Parameter">serdeactdate</td>
														<td data-title="Data Type"></td>
														<td data-title="Description">Service de-activation date</td>
														<td data-title="Requirement"></td>
													</tr>
													<tr>
														<td data-title="S.No">12</td>
														<td data-title="Parameter">actchannel</td>
														<td data-title="Data Type"></td>
														<td data-title="Description">Service activation channel</td>
														<td data-title="Requirement"></td>
													</tr>
													<tr>
														<td data-title="S.No">13</td>
														<td data-title="Parameter">deactchannel</td>
														<td data-title="Data Type"></td>
														<td data-title="Description">Service de-activation channel</td>
														<td data-title="Requirement"></td>
													</tr>
													<tr>
														<td data-title="S.No">14</td>
														<td data-title="Parameter">servicetype</td>
														<td data-title="Data Type"></td>
														<td data-title="Description">Service type Daily/Weekly/Monthly/MT</td>
														<td data-title="Requirement"></td>
													</tr>
													<tr>
														<td data-title="S.No">15</td>
														<td data-title="Parameter">appid</td>
														<td data-title="Data Type"></td>
														<td data-title="Description">IMI service id</td>
														<td data-title="Requirement"></td>
													</tr>

												</tbody>
											</table>
										</div>

										<h5>5.2.2 Success Response JSO Format</h5>
										<div>
<code>
<pre>
HTTP/1.1 200 OK
Content-Type: application/json
{
	"response":
	{
	"status": "0",
	"rescode": "1000",
	"resdescription": "SUCCESS"
	},
	"services": [
		{
		"appid":"----",
		"serviceid": "----",
		"shortcode": "----",
		"servicedesc": "---",
		"state": "ACTIVE"
		"serviceprice": "----",
		"serviceactdate": "----",
		"nextrendate": "----",
		"serdeactdate": "----",
		"actchannel": "----",
		"deactchannel": "----",
		"servicetype": "----"
		}
	]
}
</pre>
</code>
										</div>

										<h5>5.2.3 Error Response JSON Format</h5>
										<div>
<code>
<pre>
HTTP/1.1 200 OK
Content-Type: application/json
{
	"response":
	{
	"status": "-1",
	"rescode": "1001",
	"resdescription": "error"
	},
	"service": null
}
</pre>
</code>
										</div>

										<h5>5.2.4 Subscription Status Description</h5>
										<div class="card card-main">
											<table>
												<thead>
													<tr>
														<th>S.No</th>
														<th>Status</th>
														<th>Description</th>
													</tr>
												</thead>
												<tbody>
													<tr>
														<td data-title="S.No">1</td>
														<td data-title="Status">ACTIVE</td>
														<td data-title="Description">User is active for the service.</td>
													</tr>
													<tr>
														<td data-title="S.No">2</td>
														<td data-title="Status">GRACE</td>
														<td data-title="Description">User is validity has completed but due to billing failure user is kept in
															grace period. User will be retried for billing during this period. User will
															be given service during this period.</td>
													</tr>
													<tr>
														<td data-title="S.No">3</td>
														<td data-title="Status">SUSPEND</td>
														<td data-title="Description">User is validity has completed but due to billing failure user is kept in grace period. User will be retried for the billing during this period. User
															will not be given service during this period. This status is also called as
															PARKING status.</td>
													</tr>
													<tr>
														<td data-title="S.No">4</td>
														<td data-title="Status">DEACTIVE</td>
														<td data-title="Description">User is not in active status. User is unsubscribed from the service.</td>
													</tr>
													<tr>
														<td data-title="S.No">5</td>
														<td data-title="Status">CANCEL</td>
														<td data-title="Description">User is requested for the un-subscription but user validity still exists.
															Service will be given till the user validity expires. This option will be
															only service and channel specific.</td>
													</tr>
													<tr>
														<td data-title="S.No">6</td>
														<td data-title="Status">PENDING</td>
														<td data-title="Description">This status comes in case of offline billing model is enabled. User will
															be kept in the pending status till his billing is completed.</td>
													</tr>

												</tbody>
											</table>
										</div>

									</div>
								</div>



								<div id="Abbreviations">
									<h3>6. Abbreviations</h3>
									<div class="affilete-details">
										<div class="card card-main">
											<table>
												<thead>
													<tr>
														<th>Term</th>
														<th>Abbreviations</th>
													</tr>
												</thead>
												<tbody>
													<tr>
														<td data-title="Term">MSISDN</td>
														<td data-title="Abbreviations">Mobile Station International Subscriber Directory Number.</td>
													</tr>
													<tr>
														<td data-title="Term">JSON</td>
														<td data-title="Abbreviations">JavaScript Object Notation.</td>
													</tr>
													<tr>
														<td data-title="Term">HTTP</td>
														<td data-title="Abbreviations">Hyper Text Transfer protocol</td>
													</tr>
												</tbody>
											</table>
										</div>
									</div>
								</div>

								<div id="Error-Codes">
									<h3>7. Error Codes</h3>
									<div class="affilete-details">
										<h5>7.1 Subscription Error Codes</h5>
										<div class="card card-main">
											<table>
												<thead>
													<tr>
														<th>S.No</th>
														<th>Response Code</th>
														<th>Parameter Name</th>
													</tr>
												</thead>
												<tbody>
													<tr>
														<td data-title="S.No">1</td>
														<td data-title="Response Code">0</td>
														<td data-title="Parameter Name">Success</td>
													</tr>
													<tr>
														<td data-title="S.No">2</td>
														<td data-title="Response Code">28</td>
														<td data-title="Parameter Name">Billing Failed at server</td>
													</tr>
													<tr>
														<td data-title="S.No">3</td>
														<td data-title="Response Code">35</td>
														<td data-title="Parameter Name">Invalid Parameters</td>
													</tr>
													<tr>
														<td data-title="S.No">4</td>
														<td data-title="Response Code">60</td>
														<td data-title="Parameter Name">Service not available</td>
													</tr>
													<tr>
														<td data-title="S.No">5</td>
														<td data-title="Response Code">64</td>
														<td data-title="Parameter Name">Plan not defined</td>
													</tr>
													<tr>
														<td data-title="S.No">6</td>
														<td data-title="Response Code">89</td>
														<td data-title="Parameter Name">Service not available</td>
													</tr>
													<tr>
														<td data-title="S.No">7</td>
														<td data-title="Response Code">90</td>
														<td data-title="Parameter Name">Service Closed</td>
													</tr>
													<tr>
														<td data-title="S.No">8</td>
														<td data-title="Response Code">91</td>
														<td data-title="Parameter Name">Already subscribed</td>
													</tr>
													<tr>
														<td data-title="S.No">9</td>
														<td data-title="Response Code">105</td>
														<td data-title="Parameter Name">Error while Processing</td>
													</tr>
													<tr>
														<td data-title="S.No">10</td>
														<td data-title="Response Code">201</td>
														<td data-title="Parameter Name">Already request is in pending</td>
													</tr>
													<tr>
														<td data-title="S.No">11</td>
														<td data-title="Response Code">205</td>
														<td data-title="Parameter Name">Request sent for retry</td>
													</tr>
													<tr>
														<td data-title="S.No">12</td>
														<td data-title="Response Code">206</td>
														<td data-title="Parameter Name">User in Retry status</td>
													</tr>
												</tbody>
											</table>
										</div>

										<h5>7.2 Un-Subscription Error Codes</h5>
										<div class="card card-main">
											<table>
												<thead>
													<tr>
														<th>S.No</th>
														<th>Response Code</th>
														<th>Parameter Name</th>
													</tr>
												</thead>
												<tbody>
													<tr>
														<td data-title="S.No">1</td>
														<td data-title="Response Code">0</td>
														<td data-title="Parameter Name">Success</td>
													</tr>
													<tr>
														<td data-title="S.No">2</td>
														<td data-title="Response Code">28</td>
														<td data-title="Parameter Name">Billing Failed at server</td>
													</tr>
													<tr>
														<td data-title="S.No">3</td>
														<td data-title="Response Code">35</td>
														<td data-title="Parameter Name">Invalid Parameters</td>
													</tr>
													<tr>
														<td data-title="S.No">4</td>
														<td data-title="Response Code">60</td>
														<td data-title="Parameter Name">Service not available</td>
													</tr>
													<tr>
														<td data-title="S.No">5</td>
														<td data-title="Response Code">64</td>
														<td data-title="Parameter Name">Plan not defined</td>
													</tr>
													<tr>
														<td data-title="S.No">6</td>
														<td data-title="Response Code">69</td>
														<td data-title="Parameter Name">User does not exists for un-subscription</td>
													</tr>
													<tr>
														<td data-title="S.No">7</td>
														<td data-title="Response Code">89</td>
														<td data-title="Parameter Name">Service not available</td>
													</tr>
													<tr>
														<td data-title="S.No">8</td>
														<td data-title="Response Code">90</td>
														<td data-title="Parameter Name">Service Closed</td>
													</tr>
													<tr>
														<td data-title="S.No">9</td>
														<td data-title="Response Code">105</td>
														<td data-title="Parameter Name">Error while Processing</td>
													</tr>
													<tr>
														<td data-title="S.No">10</td>
														<td data-title="Response Code">106</td>
														<td data-title="Parameter Name">User already unsubscribed</td>
													</tr>
													<tr>
														<td data-title="S.No">11</td>
														<td data-title="Response Code">201</td>
														<td data-title="Parameter Name">Already request is in pending</td>
													</tr>
													<tr>
														<td data-title="S.No">12</td>
														<td data-title="Response Code">205</td>
														<td data-title="Parameter Name">Request sent for retry</td>
													</tr>
													<tr>
														<td data-title="S.No">13</td>
														<td data-title="Response Code">206</td>
														<td data-title="Parameter Name">User in Retry status</td>
													</tr>
												</tbody>
											</table>
										</div>

										<h5>7.3 Getservices Error Codes</h5>
										<div class="card card-main">
											<table>
												<thead>
													<tr>
														<th>S.No</th>
														<th>Response Code</th>
														<th>Parameter Name</th>
													</tr>
												</thead>
												<tbody>
													<tr>
														<td data-title="S.No">1</td>
														<td data-title="Response Code">0</td>
														<td data-title="Parameter Name">Success Response</td>
													</tr>
													<tr>
														<td data-title="S.No">2</td>
														<td data-title="Response Code">1001</td>
														<td data-title="Parameter Name">Invalid JSON Specified</td>
													</tr>
													<tr>
														<td data-title="S.No">3</td>
														<td data-title="Response Code">1002</td>
														<td data-title="Parameter Name">Invalid Request type</td>
													</tr>
													<tr>
														<td data-title="S.No">4</td>
														<td data-title="Response Code">1003</td>
														<td data-title="Parameter Name">Invalid Channel</td>
													</tr>
													<tr>
														<td data-title="S.No">5</td>
														<td data-title="Response Code">1000</td>
														<td data-title="Parameter Name">Success</td>
													</tr>
												</tbody>
											</table>
										</div>
									</div>
								</div>



							</div>
						</div>
					</div>
					<!-- <div class="col-md-4 affilete-right">
						<div class="code-header">
							<ul class="nav nav-tabs">
								<li class="nav-item">
								  <a class="nav-link active" data-id="#node" href="#">NODE.JS</a>
								</li>
								<li class="nav-item">
								  <a class="nav-link" data-id="#python" href="#">PYTHON</a>
								</li>
								<li class="nav-item">
								  <a class="nav-link" data-id="#php" href="#">PHP</a>
								</li>
							</ul>
						</div>
						<div class="code-main show" id="node">
							<div class="code-container">
								<div class="code-title">
									<span>JSON request format</span>
									<a class="copy-btn" href="javascript:;"><img sc="/images/icons/copy.svg" alt=""></a>
								</div>
								<pre>
									<code>
										// Download the helper library from https://www.twilio.com/docs/node/install
										// Your Account Sid and Auth Token from twilio.com/console
										// DANGER! This is insecure. See http://twil.io/secure
										const accountSid = 'ACXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';
										const authToken = 'your_auth_token';
										const client = require('twilio')(accountSid, authToken);

										client.messages
											.create({
												body: 'This will be the body of the new message!',
												from: '+15017122661',
												to: '+15558675310'
											})
											.then(message => console.log(message.sid));
									</code>
								</pre>
							</div>
						</div>
						<div class="code-main" id="python">
							<div class="code-container">
								<div class="code-title">
									<span>JSON request format</span>
									<a class="copy-btn" href="javascript:;"><img src="/images/icons/copy.svg" alt=""></a>
								</div>
								<pre>
									<code>
										# Download the helper library from https://www.twilio.com/docs/python/install
										from twilio.rest import Client


										# Your Account Sid and Auth Token from twilio.com/console
										# DANGER! This is insecure. See http://twil.io/secure
										account_sid = 'ACXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'
										auth_token = 'your_auth_token'
										client = Client(account_sid, auth_token)

										message = client.messages.create(
											body='This will be the body of the new message!',
											from_='+15017122661',
											to='+15558675310'
										)

										print(message.sid)
									</code>
								</pre>
							</div>
						</div>
						<div class="code-main" id="php">
							<div class="code-container">
								<div class="code-title">
									<span>JSON request format</span>
									<a class="copy-btn" href="javascript:;"><img src="/images/icons/copy.svg" alt=""></a>
								</div>
								<pre>
									<code>
										// Install the C# / .NET helper library from twilio.com/docs/csharp/install

										using System;
										using Twilio;
										using Twilio.Rest.Api.V2010.Account;


										class Program
										{
											static void Main(string[] args)
											{
												// Find your Account Sid and Token at twilio.com/console
												// DANGER! This is insecure. See http://twil.io/secure
												const string accountSid = "ACXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
												const string authToken = "your_auth_token";

												TwilioClient.Init(accountSid, authToken);

												var message = MessageResource.Create(
													body: "This will be the body of the new message!",
													from: new Twilio.Types.PhoneNumber("+15017122661"),
													to: new Twilio.Types.PhoneNumber("+15558675310")
												);

												Console.WriteLine(message.Sid);
											}
										}
									</code>
								</pre>
							</div>
						</div>
					</div> -->


				</div>
			</div>

			<!-- Affiliate Credentials -->
			<div id="affiliate-credentials" class="card card-main affiliate-content">
				<div class="card-body">
					<div class="row">
						<div class="col-sm-4">
							<div class="card api-box">
								<div class="card-body">
									<h6 class="card-title mb-2 text-muted"> API Secret Key
										<a data-toggle="tooltip" data-placement="top" title="Copy to Clipboard" id="copy-secretKey" class="copy-btn"><img width="30" src="/images/icons/copy-light.svg" alt="">
											<span class="">Copied!</span>
										</a>
									</h6>
									<span id="secretKey">
										{{ (isset($data) && isset($data->api_secret_key) && $data->api_secret_key) ? $data->api_secret_key : 'N/A' }}
									</span>
									<script>
										$(document).on('click', '#copy-secretKey', function() {
											var range = document.createRange();
											range.selectNode(document.getElementById("secretKey"));
											window.getSelection().removeAllRanges(); // clear current selection
											window.getSelection().addRange(range); // to select text
											document.execCommand("copy");
											window.getSelection().removeAllRanges();// to deselect
											$(this).children('span').addClass('animate').delay(2000).queue(function(){
												$(this).removeClass('animate');
												$(this).dequeue();
											});
										});
									</script>
								</div>
							</div>
						</div>
						{{--<div class="col-sm-4">
							<div class="card api-box">
								<div class="card-body">
									<h6 class="card-title mb-2 text-muted"> API Access Token
										<a data-toggle="tooltip" data-placement="top" title="Copy to Clipboard" id="copy-accessToken" class="copy-btn"><img width="30" src="/images/icons/copy-light.svg" alt="">
											<span class="">Copied!</span>
										</a>
									</h6>
									<span id="accessToken">
										{{ (isset($data) && isset($data->api_access_token) && $data->api_access_token) ? $data->api_access_token : 'N/A' }}
									</span>
									<script>
										$(document).on('click', '#copy-accessToken', function() {
											var range = document.createRange();
											range.selectNode(document.getElementById("accessToken"));
											window.getSelection().removeAllRanges(); // clear current selection
											window.getSelection().addRange(range); // to select text
											document.execCommand("copy");
											window.getSelection().removeAllRanges();// to deselect
											$(this).children('span').addClass('animate').delay(2000).queue(function(){
												$(this).removeClass('animate');
												$(this).dequeue();
											});
										});
									</script>
								</div>
							</div>
						</div>--}}
						<div class="col-sm-4">
							<div class="card api-box">
								<div class="card-body">
									<h6 class="card-title mb-2 text-muted"> API Salt
										<a data-toggle="tooltip" data-placement="top" title="Copy to Clipboard" id="copySalt" class="copy-btn"><img width="30" src="/images/icons/copy-light.svg" alt="">
											<span class="">Copied!</span>
										</a>
									</h6>
									<span id="apiSalt">
										{{ (isset($data) && isset($data->api_salt) && $data->api_salt) ? $data->api_salt : 'N/A' }}
									</span>
									<script>
										$(document).on('click', '#copySalt', function() {
											var range = document.createRange();
											range.selectNode(document.getElementById("apiSalt"));
											window.getSelection().removeAllRanges(); // clear current selection
											window.getSelection().addRange(range); // to select text
											document.execCommand("copy");
											window.getSelection().removeAllRanges();// to deselect
											$(this).children('span').addClass('animate').delay(2000).queue(function(){
												$(this).removeClass('animate');
												$(this).dequeue();
											});
										});
									</script>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

		</div>
	</div>
  </div>
</div>

@stop



