<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Webservices language file
    |--------------------------------------------------------------------------
    | @author Ashwin Vadgama <ashwinvadgama@gmail.com>
    */

    'SOMETHING_WENT_WRONG' => 'Something went wrong, Please contact administrator',
    'msg_invalid_credential' => 'Username and password are invalid',
    'msg_login_success' => 'Login success',
    'msg_app_version_not_match' => 'App version not match. Please download latest app version.',
    'msg_api_version_not_match' => 'Webservice version does not match.',
    'msg_invalid_request' => 'Invalid request.',
    'msg_file_not_exists' => 'File not exist.',
];
