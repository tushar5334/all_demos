<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

//CUSTOMIZATION START - ASHWIN <<ashwinvadgama@gmail.com>>

Route::post('login', 'Api\v1\WebserviceController@postLogin');
Route::post('subscribe', 'Api\v1\WebserviceController@postSubscribe');
Route::post('un-subscribe', 'Api\v1\WebserviceController@postUnSubscribe');
Route::post('check-status', 'Api\v1\WebserviceController@postCheckStatus');
Route::post('encryption-string', 'Api\v1\WebserviceController@postEncryptionString');

Route::prefix('v1')->group(function () {
	Route::post('check-version', 'Api\v1\WebserviceController@postCheckVersion');
	//Route::post('get-dashboard-data', 'Api\v1\WebserviceController@postDashboardData');
	
});
//CUSTOMIZATION END - ASHWIN <<ashwinvadgama@gmail.com>>


/*Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});*/
