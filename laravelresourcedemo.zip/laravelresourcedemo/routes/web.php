<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



/*Route::match(array('GET', 'POST'), '/', function()
{
    return redirect('/admin/login');
});
*/
Route::get('/', function () {
    return view('welcome');
});
Route::get('/pov', function () {
    return view('pov');
});
Route::get('/services', function () {
    return view('services');
});
Route::get('/bespoke-software-development', function () {
    return view('bespoke-software-development');
});
Route::get('/api-and-system-integration', function () {
    return view('api-and-system-integration');
});
Route::get('/design-wirefrmes-and-rapid-prototyping', function () {
    return view('design-wirefrmes-and-rapid-prototyping');
});
Route::get('/seo-and-digital-marketing', function () {
    return view('seo-and-digital-marketing');
});
Route::get('/data-science-applications-and-web-data', function () {
    return view('data-science-applications-and-web-data');
});
Route::get('/native-and-cross-platform-mobile-apps-and-iot', function () {
    return view('native-and-cross-platform-mobile-apps-and-iot');
});

Route::get('/projects', function () {
    return view('projects');
});
Route::get('/project-details', function () {
    return view('project-details');
});
Route::get('/ev-tech', function () {
    return view('ev-tech');
});

Route::get('/hiring', function () {
    return view('hiring');
});
Route::get('/position', function () {
    return view('position');
});

Auth::routes();

Route::middleware([])->prefix('admin')->group(function () {
    Route::get('login', 'Auth\LoginController@showLoginForm')->name('admin.login');
    Route::post('login', [ 'as' => '/admin/login', 'uses' => 'Auth\LoginController@postLogin'])->name('admin.login');
    Route::get('forgot-password', 'Auth\ForgotPasswordController@showFrogotPasswordForm')->name('admin.forgot-password');
    Route::post('forgot-password', [ 'as' => '/admin/forgot-password', 'uses' => 'Auth\ForgotPasswordController@postForgotPassword'])->name('admin.forgot-password');
    Route::get('reset-password/{token}', 'Auth\ResetPasswordController@showResetPasswordForm');
    Route::post('reset-password/{token}', 'Auth\ResetPasswordController@postResetPassword');
    Route::get('set-password/{token}', 'Auth\SetPasswordController@showSetPasswordForm');
    Route::post('set-password/{token}', 'Auth\SetPasswordController@postSetPassword');
});

Route::middleware(['auth', 'revalidate'])->prefix('admin')->group(function () {

    // Logout
    Route::post('logout', 'Auth\LoginController@postLogout');

    // Error Handler
    Route::get('api/error-logs', 'UserController@getErrorLogs');
    Route::get('api/error-logs/list', 'UserController@getErrorLogsList');

    // Dashboard
    Route::get('/', 'DashboardController@DisplayDashboard');

    // Profile
    Route::get('profile/{user}/edit', 'UserController@editProfile');
    Route::put('profile/{user}', 'UserController@updateProfile')->name('profile.update');

    // User Module
    Route::resource('user', 'UserController');
    Route::get('user/api/user-list', 'UserController@getDataTableList');

    // CMS Module
    Route::resource('page', 'PageController');
    //Route::get('page/api/page-list', 'PageController@getDataTableList');

    // Hiring Module
    Route::resource('hiring', 'HiringController');
    //Route::get('hiring/api/hiring-list', 'HiringController@getDataTableList');

    // Category Module
    Route::resource('category', 'CategoryController');
    // Route::get('category/api/category-list', 'CategoryController@getDataTableList');

    // Services Module
    Route::resource('service', 'ServiceController');
    Route::get('service/api/service-list', 'ServiceController@getDataTableList');

    // Tag Module
    Route::resource('tag', 'TagController');

    //Project Module
    Route::resource('project', 'ProjectController');
    //Route::get('project/api/project-list', 'ProjectController@getDataTableList');

     //testimonial Module
    Route::resource('testimonial', 'TestimonialController');
    //Route::get('testimonial/api/testimonial-list', 'TestimonialController@getDataTableList');

     //banner Module
    Route::resource('banner', 'BannerController');
    Route::get('banner/api/banner-list', 'BannerController@getDataTableList');
});

