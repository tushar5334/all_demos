<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Input;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\ColumnFillable;
use DB;
use Config;


class Tag extends Model
{
    protected $table = 'tags';
    protected $primaryKey = 'tag_id';
    public $incrementing = false;
    use SoftDeletes;
    use ColumnFillable;

    protected $dates = ['deleted_at'];
}




