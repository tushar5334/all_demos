<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class ProjectRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'project_name' => 'required',
            'project_slug' => 'required|unique:projects,project_slug,'.$this->project_id.',project_id,deleted_at,NULL',
            'client_info' => 'required',
            'project_url' => 'required|url',
            'video_url' => 'required|url',
            'project_description' => 'required',
            'project_image' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048'
        ];
    }
    public function messages(){
        return [
            'project_slug.required' => 'The project name field is required.',
            'project_slug.unique' => 'The project name has already been taken.',
            'project_name.required' => 'Project Name Title field is required.',
            'client_info.required' => 'Client Info field is required.',
            'project_url.required' => 'Project Url field is required.',
            'video_url.required' => 'Video Url field is required.',
            'project_description.required' => 'Project Description field is required.',
            'project_image.image' => 'Project Image must be an image..',
            'project_image.mimes' => 'The project Image must be a file of type: jpeg, png, jpg, gif, svg.',
            'project_image.max' => 'The file may not be greater than 2048 kilobytes.'
        ];
    }

    protected function getValidatorInstance(){
        $data = $this->all();
        $data['project_slug'] = str_slug($data['project_name'], '_');
        $this->getInputSource()->replace($data);
        return parent::getValidatorInstance();
    }
}
