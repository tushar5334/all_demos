<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class TestimonialRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
           'project_id' => 'required',
           'testimonial_user_name' => 'required',
           'testimonial_image' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048'
        ];
    }
    public function messages(){
        return [
            'project_id.required' => 'Please Select Project Name field is required.',
            'testimonial_user_name.required' => 'Testimonial User Name field is required.',
            'testimonial_image.image' => 'Testimonial Image must be an image..',
            'testimonial_image.mimes' => 'The testimonial Image must be a file of type: jpeg, png, jpg, gif, svg.',
            'testimonial_image.max' => 'The file may not be greater than 2048 kilobytes.'
        ];
    }
}
