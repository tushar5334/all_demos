<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Auth;
use App\Libraries\GUID;

class TagRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'tag_name' => 'required',
            'tag_slug' => 'required|unique:tags,tag_slug,'.$this->tag_id.',tag_id,deleted_at,NULL'
        ];
    }

    public function messages(){
        return [
            'tag_slug.required' => 'The tag name field is required.',
            'tag_slug.unique' => 'The tag name has already been taken.',
        ];
    }

    protected function getValidatorInstance(){
        $data = $this->all();
        $authId = Auth::id();
        $data['tag_slug'] = str_slug($data['tag_name'], '-');
        if(empty($data['tag_id'])){
            $data['tag_id'] = GUID::create_guid();
            $data['created_by'] = $authId;
        }
        $data['updated_by'] = $authId;
        $this->getInputSource()->replace($data);
        return parent::getValidatorInstance();
    }
}
