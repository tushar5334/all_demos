<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class ServiceRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'service_name' => 'required',
            'service_slug' => 'required|unique:services,service_slug,'.$this->service_id.',service_id,deleted_at,NULL',
            'service_description' => 'required'
        ];
    }
    public function messages(){
        return [
            'service_slug.required' => 'The service name field is required.',
            'service_slug.unique' => 'The service name has already been taken.',
            'service_description.required' => 'Description field is required.'
        ];
    }
     protected function getValidatorInstance(){
        $data = $this->all();
        $data['service_slug'] = str_slug($data['service_name'], '_');
        $this->getInputSource()->replace($data);
        return parent::getValidatorInstance();
    }
}
