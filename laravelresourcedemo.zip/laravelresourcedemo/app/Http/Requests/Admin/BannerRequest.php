<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class BannerRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'banner_title' => 'required|unique:banners,banner_title,'.$this->banner_id.',banner_id,deleted_at,NULL',
            'banner_description' => 'required',
            'banner_image' => 'image|mimes:jpeg,png,jpg,gif,svg',
            'banner.banner_link_url.*' => 'required|url',
            'banner.banner_link_title.*' => 'required'
        ];
    }
    public function messages(){
        return [
            'banner_title.required' => 'Banner Title field is required.',
            'banner_description.required' => 'Banner Description field is required.',
            'banner_image.image' => 'Banner Image must be an image..',
            'banner_image.mimes' => 'The banner Image must be a file of type: jpeg, png, jpg, gif, svg.',
            'banner_image.max' => 'The file may not be greater than 2048 kilobytes.',
            'banner.banner_link_url.*.required' => 'The Banner Link Url field is required.',
            'banner.banner_link_url.*.url' => 'Please Enter Valid URl..',
            'banner.banner_link_title.*.required' => 'The Banner Link Title field is required.'
        ];
    }
}
