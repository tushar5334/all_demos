<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class HiringRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'hiring_title' => 'required|unique:hirings,hiring_title,'.$this->hiring_id.',hiring_id,deleted_at,NULL',
            'experience' => 'required',
            'location' => 'required',
            'description' => 'required'
        ];
    }
    public function messages(){
        return [
            'hiring_title.required' => 'Hiring Title field is required.',
            'experience.required' => 'Experience field is required.',
            'location.required' => 'Location field is required.',
            'description.required' => 'Description field is required.'
        ];
    }
}
