<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Auth;
use App\Libraries\GUID;
use App\Category;

class CategoryRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize(){
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(){
        return [
            'category_name' => 'required',
            'category_slug' => 'required|unique:categories,category_slug,'.$this->category_id.',category_id,deleted_at,NULL'
        ];
    }

    public function messages(){
        return [
            'category_slug.required' => 'The category name field is required.',
            'category_slug.unique' => 'The category name has already been taken.',
        ];
    }

    protected function getValidatorInstance(){
        $data = $this->all();
        $data['category_slug'] = str_slug($data['category_name'], '_');
        $authId = Auth::id();
        if(empty($data['category_id'])){
            $data['category_id'] = GUID::create_guid();
            $data['created_by'] = $authId;
        }
        $data['updated_by'] = $authId;
        $categoryLevel = 1;
        if(!empty($data['parent_category_id'])){
            $categoryLevel = Category::where('category_id',$data['parent_category_id'])->max('category_level') + 1;
        }
        $data['category_level'] = $categoryLevel;
        $this->getInputSource()->replace($data);
        return parent::getValidatorInstance();
    }
}
