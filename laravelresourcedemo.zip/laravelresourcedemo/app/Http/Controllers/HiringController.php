<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Libraries\General;
use App\Libraries\GUID;
use App\Libraries\CustomErrorHandler;

use App\Hiring;
use App\WSErrorHandler;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Illuminate\Contracts\Routing\ResponseFactory;
use Yajra\DataTables\DataTablesServiceProvider;
use App\Http\Requests\Admin\HiringRequest;

use DB;
use Hash;
use Redirect;
use Validator;
use DataTables;


class HiringController extends Controller
{

    /**
     * Constructor
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        //$this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if($request->ajax()){
            $masterList = Hiring::select('*')->WHERENULL('deleted_at');
            return DataTables::eloquent($masterList)
            ->editColumn('description', function ($masterList) {
                if(isset($masterList->description) && $masterList->description !=""){
                    return html_entity_decode(strip_tags($masterList->description));
                }else{
                    return '';
                }
            })
            ->make(true);
        }
        return view('admin.hiring.hiring_list');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Hiring $hiring)
    {
       $retData = array(
            'data' => $hiring
        );
        //echo '<pre>';print_r($retData);echo'</pre>';exit; 
        return view('admin.hiring.hiring_add',$retData);

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(HiringRequest $request)
    {
        $requestData = $request->all();
        $authId = Auth::id();

        DB::beginTransaction();
        try {
            $hiringId = GUID::create_guid();
            $requestData['hiring_id'] = $hiringId;
            $requestData['created_by'] = $authId;
           
            Hiring::create($requestData);
            DB::commit();
            return redirect('/admin/hiring')->with('success', 'Hiring Added Successfully.');
        } catch (\Exception $e) {
            DB::rollback();
            CustomErrorHandler::APIServiceLog($e->getMessage(), "HiringController: store");
            return back()->with('error', 'Something Went Wrong.');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Hiring  $hiring
     * @return \Illuminate\Http\Response
     */
    public function show(Hiring $hiring)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Hiring  $hiring
     * @return \Illuminate\Http\Response
     */
    public function edit(Hiring $hiring)
    {  
         $retData = array(
            'data' => $hiring
        );      
        return view('admin.hiring.hiring_add',$retData);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Hiring  $hiring
     * @return \Illuminate\Http\Response
     */
    public function update(HiringRequest $request, $hiringId)
    {
        $requestData = $request->all();
        $authId = Auth::id();
        DB::beginTransaction();
        try {
            $hiringObj = Hiring::findOrFail($hiringId);
            $requestData['updated_by'] = $authId;
            $hiringObj->update($requestData);
            DB::commit();
            return redirect('/admin/hiring')->with('success', 'Hiring Updated Successfully.');

        } catch (\Exception $e) {
            DB::rollback();
            CustomErrorHandler::APIServiceLog($e->getMessage(), "HiringController: update");
            return back()->with('error', 'Something Went Wrong.');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Hiring  $hiring
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        DB::beginTransaction();
        try {
            Hiring::destroy($id);
            DB::commit();
            return response()->json([
                'success' => true,
                'message'   => 'Hiring deleted successfully.'
            ], 200);
        } catch (\Exception $e) {
            DB::rollback();
            CustomErrorHandler::APIServiceLog($e->getMessage(), "HiringController: destroy");
            return response()->json([
                'success' => false,
                'message'   => 'Something Went Wrong.'
            ], 200);
        }
    }
}

