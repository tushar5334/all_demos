<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Libraries\General;
use App\Libraries\GUID;
use App\Libraries\CustomErrorHandler;

use App\Page;
use App\WSErrorHandler;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Illuminate\Contracts\Routing\ResponseFactory;
use Yajra\DataTables\DataTablesServiceProvider;
use App\Http\Requests\Admin\PageRequest;

use DB;
use Hash;
use Redirect;
use Validator;
use DataTables;


class PageController extends Controller
{

    /**
     * Constructor
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        //$this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request  $request)
    {
        if($request->ajax()){
            $masterList = Page::select('*')->WHERENULL('deleted_at');
           return Datatables::eloquent($masterList)
            ->editColumn('description', function ($masterList) {
                if(isset($masterList->description) && $masterList->description !=""){
                    return html_entity_decode(strip_tags($masterList->description));
                }else{
                    return '';
                }
            })
            ->make(true);
        }
         return view('admin.page.list');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Page $page)
    {
        $retData = array(
            'data' => $page
        );
        return view('admin.page.add',$retData);

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(PageRequest $request)
    {
        $requestData = $request->all();
        $authId = Auth::id();

        DB::beginTransaction();
        try {
                $pageId = GUID::create_guid();
                $requestData['page_id'] = $pageId;
                $requestData['created_by'] = $authId;
               
                Page::create($requestData);

                DB::commit();
                return redirect('/admin/page')->with('success', 'Cms Added Successfully.');
        } catch (\Exception $e) {
            DB::rollback();
            CustomErrorHandler::APIServiceLog($e->getMessage(), "PageController: store");
            return back()->with('error', 'Something Went Wrong.');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Page  $page
     * @return \Illuminate\Http\Response
     */
    public function show(Page $page)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Page  $page
     * @return \Illuminate\Http\Response
     */
    public function edit(Page $page)
    {  
        $retData = array(
            'data' => $page
        );
        //echo '<pre>';print_r($retData);echo'</pre>';exit;
        return view('admin.page.add',$retData);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Page  $page
     * @return \Illuminate\Http\Response
     */
    public function update(PageRequest $request, $pageId)
    {
        $requestData = $request->all();
        $authId = Auth::id();
        DB::beginTransaction();
        try {
            $pageObj = Page::findOrFail($pageId);
            $requestData['updated_by'] = $authId;
            $pageObj->update($requestData);
            DB::commit();
            return redirect('/admin/page')->with('success', 'Cms Updated Successfully.');
        } catch (\Exception $e) {
            DB::rollback();
            CustomErrorHandler::APIServiceLog($e->getMessage(), "PageController: update");
            return back()->with('error', 'Something Went Wrong.');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Page  $page
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        DB::beginTransaction();
        try {
            Page::destroy($id);
            DB::commit();
            return response()->json([
                'success' => true,
                'message'   => 'Cms deleted successfully.'
            ], 200);
        } catch (\Exception $e) {
            DB::rollback();
            CustomErrorHandler::APIServiceLog($e->getMessage(), "PageController: destroy");
            return response()->json([
                'success' => false,
                'message'   => 'Something Went Wrong.'
            ], 200);
        }
    }

    /**
     * Get Datatable Listing Data.
     *
     * @return \Illuminate\Http\Response
     */
}

