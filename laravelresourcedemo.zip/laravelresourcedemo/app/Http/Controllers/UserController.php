<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Libraries\General;
use App\Libraries\GUID;
use App\Libraries\CustomErrorHandler;
use App\Libraries\Emailsend;

use App\User;
use App\WSErrorHandler;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Illuminate\Contracts\Routing\ResponseFactory;
use Yajra\DataTables\DataTablesServiceProvider;

use DB;
use Hash;
use Redirect;
use Validator;
use DataTables;


class UserController extends Controller
{

    /**
     * Constructor
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        //$this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return \View::make('admin.user.list', array());
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        $dropDownArr['userTypeArray']['options'] = General::GetUserTypeArray();
        return view('admin.user.add')->with('dropDownArr', $dropDownArr);

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $requestData = $request->all();
        $authId = Auth::id();

        DB::beginTransaction();
        try {
            $rules = array(
                'name' => 'required',
                'email' => 'required|email|unique:users,email,NULL,user_id',
                // 'password' => 'required|min:5|required_with:password_confirmation|same:password_confirmation',
                // 'password_confirmation' => 'required|min:5',
                'user_type' => 'required',
                'profile_picture' => 'image|mimes:jpeg,png,jpg,gif,svg'
            );
            $messsages = array(
                'name.required' => 'Name field is required.',
                'email.required' => 'Email field is required.',
                // 'password.required' => 'Password Field is required.',
                // 'password_confirmation.required' => 'Confirm password field is required.',
                'user_type.required' => 'User type field is required.'
            );
            $validator = Validator::make($requestData, $rules, $messsages);
            if ($validator->fails()) {
                return back()->withInput($request->all())->withErrors($validator);
            } else {

                $userId = GUID::create_guid();
                $userObj = new User();
                $userObj->user_id = $userId;
                $userObj->name = (isset($requestData['name']) && $requestData['name']) ? $requestData['name'] : '';
                $userObj->email = (isset($requestData['email']) && $requestData['email']) ? $requestData['email'] : '';
                $userObj->user_type = (isset($requestData['user_type']) && $requestData['user_type']) ? $requestData['user_type'] : '';
                // if (isset($requestData['password']) && $requestData['password']) {
                //     $userObj->password = Hash::make($requestData['password']);
                // }
                if (isset($requestData['profile_picture']) && $requestData['profile_picture']) {
                    $fileData = General::fileUpload($requestData['profile_picture'], "user_image", $userObj->profile_picture);
                    $userObj->profile_picture = $fileData;
                }
                $userObj->created_by = $authId;
                $userObj->updated_by = $authId;

                $autoSetToken = General::generate_token();
                $userObj->token = $autoSetToken;

                if($userObj->save()){

                }

                DB::commit();
                return redirect('/admin/user')->with('success', 'User Added Successfully.');
            }
        } catch (\Exception $e) {
            DB::rollback();
            CustomErrorHandler::APIServiceLog($e->getMessage(), "UserController: store");
            return back()->with('error', 'Something Went Wrong.');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function show(User $user)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function edit(User $user)
    {
        if(!empty($user)){
            $user->profile_picture = General::imageUrlPath('user_image', $user->profile_picture, 1, 1, '', 'avatar5.png');
        }

        $dropDownArr['userTypeArray']['options'] = General::GetUserTypeArray();

        return view('admin.user.add')->with('data', $user)->with('dropDownArr', $dropDownArr);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $userId)
    {
        $requestData = $request->all();
        $authId = Auth::id();
        DB::beginTransaction();
        try {
            $rules = array(
                'name' => 'required',
                'email' => 'required|email|unique:users,email,'.$requestData['user_id'].',user_id',
                'password' => 'nullable|min:5|required_with:password_confirmation|same:password_confirmation',
                'password_confirmation' => 'nullable|min:5',
                'user_type' => 'required'
            );

            $messsages = array(
                'name.required' => 'Name field is required.',
                'email.required' => 'Email field is required.',
                'password.required' => 'Password Field is required.',
                'password_confirmation.required' => 'Confirm password field is required.',
                'user_type.required' => 'User type field is required.'
            );

            $validator = Validator::make($requestData, $rules, $messsages);
            if ($validator->fails()) {
                return back()->withInput($request->all())->withErrors($validator);
            } else {
                $userObj = User::findOrFail($userId);
                $userObj->name = (isset($requestData['name']) && $requestData['name']) ? $requestData['name'] : '';
                $userObj->email = (isset($requestData['email']) && $requestData['email']) ? $requestData['email'] : '';
                $userObj->user_type = (isset($requestData['user_type']) && $requestData['user_type']) ? $requestData['user_type'] : '';
                if (isset($requestData['password']) && $requestData['password']) {
                    $userObj->password = Hash::make($requestData['password']);
                }

                if (isset($requestData['profile_picture']) && $requestData['profile_picture']) {
                    $fileData = General::fileUpload($requestData['profile_picture'], "user_image", $userObj->profile_picture);
                    $userObj->profile_picture = $fileData;
                }
                $userObj->updated_by = $authId;

                if($userObj->save()){

                }

                DB::commit();
                return redirect('/admin/user')->with('success', 'User Updated Successfully.');
            }
        } catch (\Exception $e) {
            DB::rollback();
            CustomErrorHandler::APIServiceLog($e->getMessage(), "UserController: update");
            return back()->with('error', 'Something Went Wrong.');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        DB::beginTransaction();
        try {
            User::destroy($id);
            DB::commit();
            return response()->json([
                'success' => true,
                'message'   => 'User deleted successfully.'
            ], 200);
        } catch (\Exception $e) {
            DB::rollback();
            CustomErrorHandler::APIServiceLog($e->getMessage(), "UserController: destroy");
            return response()->json([
                'success' => false,
                'message'   => 'Something Went Wrong.'
            ], 200);
        }
    }

    /**
     * Get Datatable Listing Data.
     *
     * @return \Illuminate\Http\Response
     */
    public function getDataTableList(Datatables $datatables)
    {
        return Datatables::of(User::query())
        ->editColumn('profile_picture', function ($userObj) {
            $image_path = public_path('/upload/user_image/'.$userObj->profile_picture);
            if(file_exists($image_path) && isset($userObj->profile_picture) && $userObj->profile_picture !=""){
                return '/upload/user_image/'.$userObj->profile_picture;
            }else{
                return '/images/avatar5.png';
            }
        })->make(true);
    }

    /**
     * Profile - form for editing the specified resource.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function editProfile(User $user)
    {
        if(!empty($user)){
            $user->profile_picture = General::imageUrlPath('user_image', $user->profile_picture, 1, 1, '', 'avatar5.png');
        }
        $dropDownArr['userTypeArray']['options'] = General::GetUserTypeArray();
        //$dropDownArr['countryList'] = General::getCountryArray();

        //$affiliateProfileData = AffiliateProfile::find($user->user_id);
        return view('admin.user.profile')->with('data', $user)->with('dropDownArr', $dropDownArr);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function updateProfile(Request $request, $userId)
    {
        $requestData = $request->all();
        $authId = Auth::id();

        DB::beginTransaction();
        try {
            $rules = array(
                'name' => 'required',
                'email' => 'required|email|unique:users,email,'.$userId.',user_id',
                'password' => 'nullable|min:5|required_with:password_confirmation|same:password_confirmation',
                'password_confirmation' => 'nullable|min:5',
                'user_type' => 'required'
            );
             $messsages = array(
                'name.required' => 'Name field is required.',
                'email.required' => 'Email field is required.',
                'password.required' => 'Password Field is required.',
                'password_confirmation.required' => 'Confirm password field is required.',
                'user_type.required' => 'User type field is required.'
            );


            $validator = Validator::make($requestData, $rules, $messsages);
            if ($validator->fails()) {
                return back()->withInput($request->all())->withErrors($validator);
            } else {
                $userObj = User::findOrFail($userId);
                $userObj->name = (isset($requestData['name']) && $requestData['name']) ? $requestData['name'] : '';
                $userObj->email = (isset($requestData['email']) && $requestData['email']) ? $requestData['email'] : '';
                $userObj->user_type = (isset($requestData['user_type']) && $requestData['user_type']) ? $requestData['user_type'] : '';
                if (isset($requestData['password']) && $requestData['password']) {
                    $userObj->password = Hash::make($requestData['password']);
                }

                if (isset($requestData['profile_picture']) && $requestData['profile_picture']) {
                    $fileData = General::fileUpload($requestData['profile_picture'], "user_image", $userObj->profile_picture);
                    $userObj->profile_picture = $fileData;
                }
                $userObj->updated_by = $authId;

                if($userObj->save()){
                    
                }

                DB::commit();
                return redirect('/admin/user')->with('success', 'Profile Updated Successfully.');
            }
        } catch (\Exception $e) {
            DB::rollback();
            CustomErrorHandler::APIServiceLog($e->getMessage(), "UserController: update");
            return back()->with('error', 'Something Went Wrong.');
        }
    }


  
    // Error Logs
    public static function getErrorLogs(){
        return \View::make('admin.include.errorlogs', array());
    }

    public static function getErrorLogsList(){
        $query = WSErrorHandler::SELECT(
            'error_handler.*',
            'users.name');
        $query = $query->LEFTJOIN('users', 'users.user_id', '=', 'error_handler.created_by');
        $query = $query->ORDERBY('error_handler.created_at','DESC');
        return Datatables::of($query)
        ->addColumn('user_name', function($row){
            return $row->name;
        })
        ->make(true);
    }

}

