<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Illuminate\Contracts\Routing\ResponseFactory;
use Yajra\DataTables\DataTablesServiceProvider;

use App\Libraries\General;
use App\Libraries\CustomErrorHandler;
use App\Libraries\Emailsend;
use App\Http\Requests\Admin\CategoryRequest;

use App\Category;

use DB;
use DataTables;
// use Hash;
// use Redirect;
// use Validator;
// use Config;

class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request){
        // app()->setLocale();
        // echo trans('auth.failed');exit;
        if($request->ajax()){
            $masterList = Category::select(
                '*'
            );
            return DataTables::eloquent($masterList)
            ->toJson();
        }
        return view('admin.category.list');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Category $category){
        $categoryList = Category::getParentCategoryList();
        $retData = array(
            'categoryList'=>$categoryList,
            'data' => $category
        );
        return view('admin.category.add',$retData);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(CategoryRequest $request){
        $requestData = $request->all();
        $authId = Auth::id();
        DB::beginTransaction();
        try {
            Category::create($requestData);
            DB::commit();
            return redirect('/admin/category')->with('success', 'Category Added Successfully.');
        } catch (\Exception $e) {
            DB::rollback();
            CustomErrorHandler::APIServiceLog($e->getMessage(), "CategoryController: store");
            return back()->with('error', 'Something Went Wrong.');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id){
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Category $category){
        $categoryList = Category::getParentCategoryList();
        $retData = array(
            'categoryList'=>$categoryList,
            'data' => $category
        );
        return view('admin.category.add',$retData);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(CategoryRequest $request, $id){
        $requestData = $request->all();
        $authId = Auth::id();
        DB::beginTransaction();
        try {
            $categoryObj = Category::findOrFail($id);
            $categoryObj->update($requestData);
            DB::commit();
            return redirect('/admin/category')->with('success', 'Category Updated Successfully.');
        } catch (\Exception $e) {
            DB::rollback();
            CustomErrorHandler::APIServiceLog($e->getMessage(), "CategoryController: update");
            return back()->with('error', 'Something Went Wrong.');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id){
        DB::beginTransaction();
        try {
            $categoryCount = Category::where('parent_category_id',$id)->count();
            if($categoryCount > 0){
                return response()->json([
                    'success' => false,
                    'message'   => 'Children category already exists. you can not delete parent category.'
                ], 200);
            } else {
                Category::destroy($id);
                DB::commit();
                return response()->json([
                    'success' => true,
                    'message'   => 'Category deleted successfully.'
                ], 200);
            }
        } catch (\Exception $e) {
            DB::rollback();
            CustomErrorHandler::APIServiceLog($e->getMessage(), "CategoryController: destroy");
            return response()->json([
                'success' => false,
                'message'   => 'Something Went Wrong.'
            ], 200);
        }
    }
}
