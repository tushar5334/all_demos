<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Libraries\General;
use App\Libraries\GUID;
use App\Libraries\CustomErrorHandler;

use App\Testimonial;
use App\Project;
use App\WSErrorHandler;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Illuminate\Contracts\Routing\ResponseFactory;
use Yajra\DataTables\DataTablesServiceProvider;
use App\Http\Requests\Admin\TestimonialRequest;

use DB;
use Hash;
use Redirect;
use Validator;
use DataTables;


class TestimonialController extends Controller
{

    /**
     * Constructor
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        //$this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request  $request)
    {
        if($request->ajax()){
            $DataList = Testimonial::select(
            '*',
            'projects.project_name'
            )->LEFTJOIN('projects','projects.project_id','=','testimonials.project_id');
            return DataTables::eloquent($DataList)
            ->editColumn('testimonial_image', function ($DataList) {
                $image_path = public_path('/upload/testimonial_image/'.$DataList->testimonial_image);
                if(file_exists($image_path) && isset($DataList->testimonial_image) && $DataList->testimonial_image !=""){
                    return '/upload/testimonial_image/'.$DataList->testimonial_image;
                }else{
                    return '/images/NoImageAvailable.png';
                }
            })
            ->editColumn('testimonial_description', function ($DataList) {
                if(isset($DataList->testimonial_description) && $DataList->testimonial_description !=""){
                    return html_entity_decode(strip_tags($DataList->testimonial_description));
                }else{
                    return '';
                }
            })
            ->make(true);
        }
        return View('admin.testimonial.testimonial_list');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Testimonial $testimonial)
    {
        $ListOfProject = Project::SELECT('project_id','project_name')->WHERE('status',1)->WHERENULL('deleted_at')->get();
        $retData = array(
            'ListOfProject'=>$ListOfProject,
            'data' => $testimonial
        );
        return view('admin.testimonial.testimonial_add',$retData);

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(TestimonialRequest $request)
    {
        $requestData = $request->all();
        $authId = Auth::id();

        DB::beginTransaction();
        try {
            $testimonialId = GUID::create_guid();
                if (isset($requestData['testimonial_image']) && $requestData['testimonial_image']) {
                $fileData = General::fileUpload($requestData['testimonial_image'], "testimonial_image");
                $requestData['testimonial_image'] = $fileData;
            }
            $requestData['testimonial_id'] = $testimonialId;
            $requestData['created_by'] = $authId;
            
            Testimonial::create($requestData);

            DB::commit();
            return redirect('/admin/testimonial')->with('success', 'Testimonial Added Successfully.');
        } catch (\Exception $e) {
            DB::rollback();
            CustomErrorHandler::APIServiceLog($e->getMessage(), "TestimonialController: store");
            return back()->with('error', 'Something Went Wrong.');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Testimonial  $testimonial
     * @return \Illuminate\Http\Response
     */
    public function show(Testimonial $testimonial)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Testimonial  $testimonial
     * @return \Illuminate\Http\Response
     */
    public function edit(Testimonial $testimonial)
    {  
        $ListOfProject = Project::SELECT('project_id','project_name')->WHERE('status',1)->WHERENULL('deleted_at')->get();
         if(!empty($testimonial)){
            $testimonial->testimonial_image = General::imageUrlPath('testimonial_image', $testimonial->testimonial_image, 1, 1, '', 'avatar5.png');
        }
        $retData = array(
            'ListOfProject'=>$ListOfProject,
            'data' => $testimonial
        );
        return view('admin.testimonial.testimonial_add',$retData);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Testimonial  $testimonial
     * @return \Illuminate\Http\Response
     */
    public function update(TestimonialRequest $request, $testimonialId)
    {
        $requestData = $request->all();
        $authId = Auth::id();
        DB::beginTransaction();
        try {
            $testimonialObj = Testimonial::findOrFail($testimonialId);
                if (isset($requestData['testimonial_image']) && $requestData['testimonial_image']) {
                $fileData = General::fileUpload($requestData['testimonial_image'], "testimonial_image", $testimonialObj->testimonial_image);
                $requestData['testimonial_image'] = $fileData;
            }
            $requestData['updated_by'] = $authId;
            $testimonialObj->update($requestData);

            DB::commit();
            return redirect('/admin/testimonial')->with('success', 'Testimonial Updated Successfully.');
        } catch (\Exception $e) {
            DB::rollback();
            CustomErrorHandler::APIServiceLog($e->getMessage(), "TestimonialController: update");
            return back()->with('error', 'Something Went Wrong.');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Testimonial  $Testimonial
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        DB::beginTransaction();
        try {
            Testimonial::destroy($id);
            DB::commit();
            return response()->json([
                'success' => true,
                'message'   => 'Testimonial deleted successfully.'
            ], 200);
        } catch (\Exception $e) {
            DB::rollback();
            CustomErrorHandler::APIServiceLog($e->getMessage(), "TestimonialController: destroy");
            return response()->json([
                'success' => false,
                'message'   => 'Something Went Wrong.'
            ], 200);
        }
    }

}

