<?php

/**
 * @uses Dashboard Controller
 * @author Ranjitsinh Bhalgariya <ranjit.bhalgariya@txtech.com>
 * @return
 */
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Libraries\General;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

use Illuminate\Http\Response;
use Illuminate\Support\Facades\Input;
use Illuminate\Contracts\Routing\ResponseFactory;
use Yajra\DataTables\DataTablesServiceProvider;

use DB;
use DataTables;
// use Excel;
use App\Exports\SubscribersExport;
use Maatwebsite\Excel\Facades\Excel;

use App\User;
use App\Subscription;
use App\Subscriber;
use App\BillingHistory;
use App\SubscriptionHistory;

class DashboardController extends Controller
{

    
    /**
     * Get count and subscriber index for display dashboard
     *
     * @return Array Response
     */
    public function DisplayDashboard(Request $request, $affiliateId='')
    {
        if(Auth::user()) {
            $post = $request->all();
            
            $userDetail = Auth::user();
            $user_type = $userDetail->user_type;
            $logged_user_id = Auth::id();          

            // return \View::make('admin.dashboard', array( 
            //     'post' => $post
            //   )
            // );
             return \View::make('admin.dashboard');
            
        } else {
          return redirect('/admin/login');
        }
        //return \View::make('admin.dashboard');
    }


    /**
     * Get Subscriber Datatable Listing Data.
     *
     * @return Array Response
     */
    public function getDataTableList(Datatables $datatables, Request $request)
    {
        $requestData = $request->all();
        $datatableData = SELF::datatableQuery($datatables, $request);
        $datatableData = $datatableData->make(true);
        return $datatableData;
    }
   
    public function exportSubscriberExcel(Request $request){
        $requestData = $request->all();
        $datatableData = SELF::datatableQuery('', $requestData);
        $queryResult = $datatableData->skipPaging()->toArray();

        $subscriberHeading = array(
            'Msisdn',
            'Service Id',
            'Scode',
            'Request server parameter',
            'Response parameter',
            'Created At'
        );

        $subscriberArr = array();
        if(isset($queryResult['data']) && $queryResult['data']){
            foreach ($queryResult['data'] as $subscriber) {
                $subscriberArr[] = array(
                    'msisdn' => $subscriber['msisdn'],
                    'serviceid' => $subscriber['serviceid'],
                    'scode' => $subscriber['scode'],
                    'request_all_server_parameter' => html_entity_decode($subscriber['request_all_server_parameter']),
                    'response_parameter' => html_entity_decode($subscriber['response_parameter']),
                    'created_at' => $subscriber['displayCreatedAt'],

                );
            }
        }
        $export = new SubscribersExport($subscriberHeading, $subscriberArr);
        return Excel::download($export, Carbon::now()->format('d_m_Y_H_i_s').'_subscribers.xlsx');

    }

    public function datatableQuery($datatables='', $request=''){
               
        $authId = (isset($request['affiliateId']) && $request['affiliateId']) ? $request['affiliateId'] : Auth::id();
        $authUserType = (isset($request['affiliateId']) && $request['affiliateId']) ? 'Affiliate' : Auth::user()->user_type;

        $subscriberList = SubscriptionHistory::select(
                'subscription_history.subscription_history_id',
                'subscription_history.affiliate_id',
                'subscription_history.reqtype',
                'subscription_history.msisdn',
                'subscription_history.serviceid',
                'subscription_history.scode',
                'subscription_history.chnl',
                'subscription_history.created_by',
                'subscription_history.updated_by',
                'subscription_history.created_at',
                'api_logs.request_all_server_parameter',
                'api_logs.response_parameter',
                DB::raw('DATE_FORMAT(fan_subscription_history.created_at, "%d/%m/%Y") as displayCreatedAt')
        );         

        if($request['startdate'] && $request['enddate']){
            $subscriberList = $subscriberList->whereBetween('subscription_history.created_at', [Carbon::parse($request['startdate'])->format('Y-m-d 00:00:00'), Carbon::parse($request['enddate'])->format('Y-m-d 23:59:59')]);
        }

        $subscriberList = $subscriberList->WHERE('subscription_history.affiliate_id', $authId);

        $subscriberList = $subscriberList->JOIN('api_logs', function($join) use($authId) {
            $join->ON('api_logs.api_log_id', '=', 'subscription_history.api_log_id');
            $join->WHERENULL('api_logs.deleted_at');
        });

        $subscriberList = $subscriberList->orderBy('subscription_history.created_at', 'desc');

        $datatableData =  Datatables::eloquent($subscriberList);          

        return $datatableData;
    }

    /**
     * Get Product Report Datatable Listing Data.
     *
     * @return Array Response
     */
    public function getProductReportDataTableList(Datatables $datatables, Request $request)
    {
        $requestData = $request->all();
        $datatableData = SELF::datatableProductReportQuery($datatables, $request);
        $datatableData = $datatableData->make(true);
        return $datatableData;
    }
    
    public function exportProductReportExcel(Request $request){
        $requestData = $request->all();
        $datatableData = SELF::datatableProductReportQuery('', $requestData);

        $queryResult = $datatableData->skipPaging()->toArray();

        $productReportHeading = array(
            'Date',
            'Total New Subs',
            'Total Unsubs',
            'Total Subs',
            'Total Bill',
            'Daily Revenue',
            'Cumulative Revenue'
        );

        $productReportArr = array();
        if(isset($queryResult['data']) && $queryResult['data']){
            foreach ($queryResult['data'] as $productReport) {
                $productReportArr[] = array(
                    'created_at' => $productReport['created_at'],
                    'total_new_subs' => ($productReport['total_new_subs']) ? $productReport['total_new_subs'] : '0',
                    'total_unsubs' => ($productReport['total_unsubs']) ? $productReport['total_unsubs'] : '0',
                    'total_subs' => ($productReport['total_subs']) ? $productReport['total_subs'] : '0',
                    'total_bill' => ($productReport['total_bill']) ? $productReport['total_bill'] : '0',
                    'daily_revenue' => ($productReport['daily_revenue']) ? $productReport['daily_revenue'] : '0',                    
                    'cumulative_revenue' => ($productReport['cumulative_revenue']) ? $productReport['cumulative_revenue'] : '0'
                );
            }
        }
        $export = new SubscribersExport($productReportHeading, $productReportArr);
        return Excel::download($export, Carbon::now()->format('d_m_Y_H_i_s').'_product_report.xlsx');

    }

    public function datatableProductReportQuery($datatables='', $request=''){
        
        $authId = (isset($request['affiliateId']) && $request['affiliateId']) ? $request['affiliateId'] : Auth::id();        
        $authUserType = (isset($request['affiliateId']) && $request['affiliateId']) ? 'Affiliate' : Auth::user()->user_type;
       
        $subscriberList = BillingHistory::SELECT(
            'billing_histories.msisdn',
            'billing_histories.created_at',
            'billing_histories.status',           
            DB::raw('"0" AS total_new_subs'),
            DB::raw('"0" AS total_unsubs'),
            DB::raw('"0" AS total_subs'),
            DB::raw('"0" AS total_bill'),
            DB::raw('"0" AS daily_revenue'),
            DB::raw('"0" AS cumulative_revenue')                        
            // DB::raw('(CASE 
            //             WHEN fan_subscriber.status = "ACTIVE" THEN SUM(fan_subscriber.price)
            //             ELSE "0" 
            //             END) AS daily_revenue')
        );        
        if($request['startdate'] && $request['enddate']){
            $subscriberList = $subscriberList->whereBetween('billing_histories.created_at', [Carbon::parse($request['startdate'])->format('Y-m-d 00:00:00'), Carbon::parse($request['enddate'])->format('Y-m-d 23:59:59')]);
        }
        if($authUserType=='Affiliate') {
            $subscriberList = $subscriberList->JOIN('subscription', function($join) {
                $join->ON('subscription.msisdn', '=', 'billing_histories.msisdn');
                $join->WHERENULL('subscription.deleted_at');
            });
            $subscriberList = $subscriberList->JOIN('users', function($join) use($authId) {
                $join->ON('users.user_id', '=', 'subscription.affiliate_id');
                $join->WHERE('users.user_id', $authId);
                $join->WHERENULL('users.deleted_at');
            });
        }
        $subscriberList = $subscriberList->orderBy('billing_histories.created_at', 'DESC')
        ->GROUPBY(DB::raw('DATE(fan_billing_histories.created_at)'));
        
        // $subscriberList = Subscriber::select(
        //     'subscriber.subscriber_id',
        //     'subscriber.created_at',
        //     'subscriber.status',
           
        //     DB::raw('"0" AS total_new_subs'),
        //     DB::raw('"0" AS total_unsubs'),

        //     DB::raw('"0" AS total_subs'),
        //     DB::raw('"0" AS total_bill'),
        //     DB::raw('"0" AS daily_revenue'),
                        
        //     // DB::raw('(CASE 
        //     //             WHEN fan_subscriber.status = "ACTIVE" THEN SUM(fan_subscriber.price)
        //     //             ELSE "0" 
        //     //             END) AS daily_revenue'),

        //     DB::raw('"0" AS cumulative_revenue')
        // );

        // if($request['startdate'] && $request['enddate']){
        //     $subscriberList = $subscriberList->whereBetween('subscriber.created_at', [Carbon::parse($request['startdate'])->format('Y-m-d 00:00:00'), Carbon::parse($request['enddate'])->format('Y-m-d 23:59:59')]);
        // }
                
        // if($authUserType=='Affiliate') {
        //     $subscriberList = $subscriberList->JOIN('subscription', function($join) {
        //         $join->ON('subscription.msisdn', '=', 'subscriber.msisdn');
        //         $join->WHERENULL('subscription.deleted_at');
        //     });

        //     $subscriberList = $subscriberList->JOIN('users', function($join) use($authId) {
        //         $join->ON('users.user_id', '=', 'subscription.affiliate_id');
        //         $join->WHERE('users.user_id', $authId);
        //         $join->WHERENULL('users.deleted_at');
        //     });
        // }
        // $subscriberList = $subscriberList->orderBy('subscriber.created_at', 'DESC')
        // ->GROUPBY(DB::raw('DATE(fan_subscriber.created_at)'));
        
        $datatableData =  Datatables::eloquent($subscriberList)                        
            ->addColumn('action', function(){
                return '';
            })            
            ->editColumn('created_at', function ($subscriberList) {                
                return Carbon::parse($subscriberList->created_at)->format('d/m/Y');
            })
            ->editColumn('total_new_subs', function ($subscriberList) use($authId, $authUserType) {   
               
                $sql = "select t.msisdn
                from fan_billing_histories t
                inner join (
                    select msisdn, max(created_at) as MaxDate
                    from fan_billing_histories
                    group by msisdn
                ) tm on t.msisdn = tm.msisdn and t.created_at = tm.MaxDate";
                $sql .= " ";
                if($authUserType=='Affiliate') {
                    $sql .= " ";
                    $sql .= "inner join `fan_subscription` on `fan_subscription`.`msisdn` = `t`.`msisdn` 
                    and `fan_subscription`.`resstatus` = 0 
                    and `fan_subscription`.`deleted_at` is null 
                    inner join `fan_users` on `fan_users`.`user_id` = `fan_subscription`.`affiliate_id` 
                    and `fan_users`.`user_id` = '".$authId."' 
                    and `fan_users`.`deleted_at` is null"; 
                }
                $sql .= " ";
                $sql .= "where date(t.created_at) = '".Carbon::parse($subscriberList->created_at)->format('Y-m-d')."'";
                $sql .= " ";
                $sql .= "and (t.action LIKE 'SUBSCRIPTION' 
                or t.action LIKE 'SUB' 
                or t.action LIKE 'REN') 
                and t.deleted_at is null group by t.created_at";
                $total_subs = DB::select(DB::raw($sql));                  
                $total_subs = count($total_subs);
                $total_subs = ($total_subs) ? $total_subs : 0;
                return $total_subs;

                // $total_new_subs = BillingHistory::SELECT('billing_histories.msisdn')
                // ->where(function($total_new_subs){
                //     $total_new_subs->where('billing_histories.action', 'LIKE', 'SUBSCRIPTION');
                //     $total_new_subs->orWhere('billing_histories.action', 'LIKE', 'SUB');
                //     $total_new_subs->orWhere('billing_histories.action', 'LIKE', 'REN');
                // })
                // ->whereDate('billing_histories.created_at', '=', Carbon::parse($subscriberList->created_at)->format('Y-m-d')); 
                // if($authUserType=='Affiliate') {
                //     $total_new_subs = $total_new_subs->JOIN('subscription', function($join) {
                //         $join->ON('subscription.msisdn', '=', 'billing_histories.msisdn');
                //         $join->WHERENULL('subscription.deleted_at');
                //     });
                //     $total_new_subs = $total_new_subs->JOIN('users', function($join) use($authId) {
                //         $join->ON('users.user_id', '=', 'subscription.affiliate_id');
                //         $join->WHERE('users.user_id', $authId);
                //         $join->WHERENULL('users.deleted_at');
                //     });
                //     // $total_new_subs = $total_new_subs->distinct('billing_histories.created_at');
                // }
                // $total_new_subs = $total_new_subs->GROUPBY(DB::raw('fan_billing_histories.msisdn'));
                // $total_new_subs = $total_new_subs->count('billing_histories.created_at');
                // return $total_new_subs;
                
                // $total_new_subs = Subscriber::SELECT('subscriber.*')
                //     ->WHERE('subscriber.status', 'ACTIVE')
                //     ->whereDate('subscriber.created_at', '=', Carbon::parse($subscriberList->created_at)->format('Y-m-d')); 

                // if($authUserType=='Affiliate') {
                //     $total_new_subs = $total_new_subs->JOIN('subscription', function($join) {
                //         $join->ON('subscription.msisdn', '=', 'subscriber.msisdn');
                //         $join->WHERENULL('subscription.deleted_at');
                //     });
        
                //     $total_new_subs = $total_new_subs->JOIN('users', function($join) use($authId) {
                //         $join->ON('users.user_id', '=', 'subscription.affiliate_id');
                //         $join->WHERE('users.user_id', $authId);
                //         $join->WHERENULL('users.deleted_at');
                //     });
                // }
                // $total_new_subs = $total_new_subs->count();

                // return $total_new_subs;
            })
            ->editColumn('total_unsubs', function ($subscriberList) use($authId, $authUserType) {

                $sql = "select t.msisdn
                from fan_billing_histories t
                inner join (
                    select msisdn, max(created_at) as MaxDate
                    from fan_billing_histories
                    group by msisdn
                ) tm on t.msisdn = tm.msisdn and t.created_at = tm.MaxDate";
                $sql .= " ";
                if($authUserType=='Affiliate') {
                    $sql .= " ";
                    $sql .= "inner join `fan_subscription` on `fan_subscription`.`msisdn` = `t`.`msisdn` 
                    and `fan_subscription`.`resstatus` = 0 
                    and `fan_subscription`.`deleted_at` is null 
                    inner join `fan_users` on `fan_users`.`user_id` = `fan_subscription`.`affiliate_id` 
                    and `fan_users`.`user_id` = '".$authId."' 
                    and `fan_users`.`deleted_at` is null"; 
                }
                $sql .= " ";
                $sql .= "where date(t.created_at) = '".Carbon::parse($subscriberList->created_at)->format('Y-m-d')."'";
                $sql .= " ";
                $sql .= "and t.action LIKE 'UNSUB'
                and t.deleted_at is null group by t.created_at";
                $total_unsubs = DB::select(DB::raw($sql));                  
                $total_unsubs = count($total_unsubs);
                $total_unsubs = ($total_unsubs) ? $total_unsubs : 0;
                return $total_unsubs;

                // $total_unsubs = BillingHistory::SELECT('billing_histories.msisdn')
                // ->WHERE('billing_histories.action', 'UNSUB')
                // ->whereDate('billing_histories.created_at', '=', Carbon::parse($subscriberList->created_at)->format('Y-m-d')); 
                // if($authUserType=='Affiliate') {
                //     $total_unsubs = $total_unsubs->JOIN('subscription', function($join) {
                //         $join->ON('subscription.msisdn', '=', 'billing_histories.msisdn');
                //         $join->WHERENULL('subscription.deleted_at');
                //     });
                //     $total_unsubs = $total_unsubs->JOIN('users', function($join) use($authId) {
                //         $join->ON('users.user_id', '=', 'subscription.affiliate_id');
                //         $join->WHERE('users.user_id', $authId);
                //         $join->WHERENULL('users.deleted_at');
                //     });
                //     // $total_unsubs = $total_unsubs->distinct('billing_histories.msisdn');
                // }
                // $total_unsubs = $total_unsubs->GROUPBY(DB::raw('fan_billing_histories.msisdn'));
                // // $total_unsubs = $total_unsubs->distinct('billing_histories.created_at');
                // $total_unsubs = $total_unsubs->count('billing_histories.msisdn');
                // return $total_unsubs;

                // $total_unsubs = Subscriber::SELECT('subscriber.*')
                //     ->WHERE('subscriber.status', 'INACTIVE')
                //     ->whereDate('subscriber.created_at', '=', Carbon::parse($subscriberList->created_at)->format('Y-m-d')); 

                // if($authUserType=='Affiliate') {
                //     $total_unsubs = $total_unsubs->JOIN('subscription', function($join) {
                //         $join->ON('subscription.msisdn', '=', 'subscriber.msisdn');
                //         $join->WHERENULL('subscription.deleted_at');
                //     });
        
                //     $total_unsubs = $total_unsubs->JOIN('users', function($join) use($authId) {
                //         $join->ON('users.user_id', '=', 'subscription.affiliate_id');
                //         $join->WHERE('users.user_id', $authId);
                //         $join->WHERENULL('users.deleted_at');
                //     });
                // }
                // $total_unsubs = $total_unsubs->count();

                // return $total_unsubs;
            })      
            ->editColumn('total_subs', function ($subscriberList) use($authId, $authUserType) {   
                // $total_subs = BillingHistory::SELECT('billing_histories.msisdn')
                // ->where(function($total_subs){
                //     $total_subs->where('billing_histories.action', 'LIKE', 'SUBSCRIPTION');
                //     $total_subs->orWhere('billing_histories.action', 'LIKE', 'SUB');
                //     $total_subs->orWhere('billing_histories.action', 'LIKE', 'REN');
                // })
                // ->whereDate('billing_histories.created_at', '<=', Carbon::parse($subscriberList->created_at)->format('Y-m-d')); 

                // if($authUserType=='Affiliate') {
                //     $total_subs = $total_subs->JOIN('subscription', function($join) {
                //         $join->ON('subscription.msisdn', '=', 'billing_histories.msisdn');
                //         $join->WHERENULL('subscription.deleted_at');
                //     });
                //     $total_subs = $total_subs->JOIN('users', function($join) use($authId) {
                //         $join->ON('users.user_id', '=', 'subscription.affiliate_id');
                //         $join->WHERE('users.user_id', $authId);
                //         $join->WHERENULL('users.deleted_at');
                //     });
                //     // $total_subs = $total_subs->distinct('billing_histories.msisdn');
                // }
                // $total_subs = $total_subs->GROUPBY(DB::raw('fan_billing_histories.msisdn'));
                // // $total_subs = $total_subs->distinct('billing_histories.created_at');
                // $total_subs = $total_subs->count('billing_histories.created_at');

                // return $total_subs;

                $sql = "select t.msisdn
                from fan_billing_histories t
                inner join (
                    select msisdn, max(created_at) as MaxDate
                    from fan_billing_histories
                    group by msisdn
                ) tm on t.msisdn = tm.msisdn and t.created_at = tm.MaxDate";
                $sql .= " ";
                if($authUserType=='Affiliate') {
                    $sql .= " ";
                    $sql .= "inner join `fan_subscription` on `fan_subscription`.`msisdn` = `t`.`msisdn` 
                    and `fan_subscription`.`resstatus` = 0 
                    and `fan_subscription`.`deleted_at` is null 
                    inner join `fan_users` on `fan_users`.`user_id` = `fan_subscription`.`affiliate_id` 
                    and `fan_users`.`user_id` = '".$authId."' 
                    and `fan_users`.`deleted_at` is null"; 
                }
                $sql .= " ";
                $sql .= "where date(t.created_at) <= '".Carbon::parse($subscriberList->created_at)->format('Y-m-d')."'";
                $sql .= " ";
                $sql .= "and (t.action LIKE 'SUBSCRIPTION' 
                or t.action LIKE 'SUB' 
                or t.action LIKE 'REN') 
                and t.deleted_at is null group by t.created_at";
                $total_subs = DB::select(DB::raw($sql));                  
                $total_subs = count($total_subs);
                $total_subs = ($total_subs) ? $total_subs : 0;
                return $total_subs;

                // $total_subs = Subscriber::SELECT('subscriber.*')
                //     ->WHERE('subscriber.status', 'ACTIVE')
                //     ->whereDate('subscriber.created_at', '<=', Carbon::parse($subscriberList->created_at)->format('Y-m-d')); 
                // if($authUserType=='Affiliate') {
                //     $total_subs = $total_subs->JOIN('subscription', function($join) {
                //         $join->ON('subscription.msisdn', '=', 'subscriber.msisdn');
                //         $join->WHERENULL('subscription.deleted_at');
                //     });
                //     $total_subs = $total_subs->JOIN('users', function($join) use($authId) {
                //         $join->ON('users.user_id', '=', 'subscription.affiliate_id');
                //         $join->WHERE('users.user_id', $authId);
                //         $join->WHERENULL('users.deleted_at');
                //     });
                // }
                // $total_subs = $total_subs->count();
                // return $total_subs;
            })

            ->editColumn('total_bill', function ($subscriberList) use($authId, $authUserType) { 
                
                // $sql = "select t.msisdn
                // from fan_billing_histories t
                // inner join (
                //     select msisdn, max(created_at) as MaxDate
                //     from fan_billing_histories
                //     group by msisdn
                // ) tm on t.msisdn = tm.msisdn and t.created_at = tm.MaxDate";
                // $sql .= " ";
                // if($authUserType=='Affiliate') {
                //     $sql .= " ";
                //     $sql .= "inner join `fan_subscription` on `fan_subscription`.`msisdn` = `t`.`msisdn` 
                //     and `fan_subscription`.`resstatus` = 0 
                //     and `fan_subscription`.`deleted_at` is null 
                //     inner join `fan_users` on `fan_users`.`user_id` = `fan_subscription`.`affiliate_id` 
                //     and `fan_users`.`user_id` = '".$authId."' 
                //     and `fan_users`.`deleted_at` is null"; 
                // }
                // $sql .= " ";
                // $sql .= "where date(t.created_at) = '".Carbon::parse($subscriberList->created_at)->format('Y-m-d')."'";
                // $sql .= " ";
                // $sql .= "and (t.action LIKE 'SUBSCRIPTION' 
                // or t.action LIKE 'SUB' 
                // or t.action LIKE 'REN') 
                // and t.deleted_at is null group by t.created_at";
                // $total_subs = DB::select(DB::raw($sql));                  
                // $total_subs = count($total_subs);
                // $total_subs = ($total_subs) ? $total_subs : 0;
                // return $total_subs;

               
                $total_bill = BillingHistory::SELECT('billing_histories.msisdn')
                ->whereDate('billing_histories.created_at', '=', Carbon::parse($subscriberList->created_at)->format('Y-m-d'))
                ->WHERENULL('billing_histories.deleted_at')
                ->where(function($total_bill){
                    $total_bill->where('billing_histories.action', 'LIKE', 'SUBSCRIPTION');
                    $total_bill->orWhere('billing_histories.action', 'LIKE', 'SUB');
                    $total_bill->orWhere('billing_histories.action', 'LIKE', 'REN');
                });                         
                if($authUserType=='Affiliate') {
                    $total_bill = $total_bill->JOIN('subscription', function($join) {
                        $join->ON('subscription.msisdn', '=', 'billing_histories.msisdn');
                        $join->WHERENULL('subscription.deleted_at');
                    });
                    $total_bill = $total_bill->JOIN('users', function($join) use($authId) {
                        $join->ON('users.user_id', '=', 'subscription.affiliate_id');
                        $join->WHERE('users.user_id', $authId);
                        $join->WHERENULL('users.deleted_at');
                    });
                }
                // $total_bill = $total_bill->GROUPBY(DB::raw('fan_billing_histories.msisdn'));
                $total_bill = $total_bill->distinct('billing_histories.created_at');
                $total_bill = $total_bill->count('billing_histories.created_at');

                //$total_bill = $total_bill->GROUPBY(DB::raw('DATE(fan_billing_histories.created_at)'));
                // $total_bill = $total_bill->count();
                
                return $total_bill;
                
            })
            ->editColumn('daily_revenue', function ($subscriberList) use($authId, $authUserType) {   
                
                $sql = "select `fan_billing_histories`.`msisdn`, 
                SUM(`fan_billing_histories`.`price`) as group_price 
                from `fan_billing_histories`";
                if($authUserType=='Affiliate') {
                    $sql .= " ";
                    $sql .= "inner join `fan_subscription` on `fan_subscription`.`msisdn` = `fan_billing_histories`.`msisdn` 
                    and `fan_subscription`.`resstatus` = 0 
                    and `fan_subscription`.`deleted_at` is null 
                    inner join `fan_users` on `fan_users`.`user_id` = `fan_subscription`.`affiliate_id` 
                    and `fan_users`.`user_id` = '".$authId."' 
                    and `fan_users`.`deleted_at` is null"; 
                }
                $sql .= " ";
                $sql .= "where date(`fan_billing_histories`.`created_at`) = '".Carbon::parse($subscriberList->created_at)->format('Y-m-d')."' 
                and `fan_billing_histories`.`deleted_at` is null 
                and (`fan_billing_histories`.`action` LIKE 'SUBSCRIPTION' 
                or `fan_billing_histories`.`action` LIKE 'SUB' 
                or `fan_billing_histories`.`action` LIKE 'REN') 
                and `fan_billing_histories`.`deleted_at` is null 
                group by `fan_billing_histories`.`msisdn`";
               

                $daily_revenue = DB::select(DB::raw($sql));
                $daily_revenue = array_sum(array_column($daily_revenue,'group_price'));
                $daily_revenue = ($daily_revenue) ? General::decimalValues($daily_revenue, 2) : 0;
                return $daily_revenue;
                

//                 $daily_revenue = BillingHistory::SELECT(
//                     'billing_histories.msisdn', 
//                     DB::raw("SUM('fan_billing_histories.price') as group_price") 
//                     )
//                 ->whereDate('billing_histories.created_at', '=', Carbon::parse($subscriberList->created_at)->format('Y-m-d'))
//                 ->WHERENULL('billing_histories.deleted_at')
//                 ->where(function($daily_revenue){
//                     $daily_revenue->where('billing_histories.action', 'LIKE', 'SUBSCRIPTION');
//                     $daily_revenue->orWhere('billing_histories.action', 'LIKE', 'SUB');
//                     $daily_revenue->orWhere('billing_histories.action', 'LIKE', 'REN');
//                 });
//                 $daily_revenue = $daily_revenue->GROUPBY('billing_histories.msisdn');

//                 if($authUserType=='Affiliate') {
//                     $daily_revenue->JOIN('subscription', function($join) {
//                         $join->ON('subscription.msisdn', '=', 'billing_histories.msisdn');
//                         $join->WHERE('subscription.resstatus', 0);
//                         $join->WHERENULL('subscription.deleted_at');
//                     });
        
//                     $daily_revenue->JOIN('users', function($join) use($authId) {
//                         $join->ON('users.user_id', '=', 'subscription.affiliate_id');
//                         $join->WHERE('users.user_id', $authId);
//                         $join->WHERENULL('users.deleted_at');
//                     });
//                 }

//                 // $daily_revenue = $daily_reveue->distinct('billing_histories.created_at');
//                 $daily_revenue = $daily_revenue->GROUPBY('billing_histories1.msisdn')->get();
//                 // $daily_revenue = $daily_revenue->sum('billing_histories.price');
//                 // $sum = (!empty($daily_revenue)) ? array_sum($daily_revenue) : 0;
// return($daily_revenue);
//                 // $daily_revenue = $daily_revenue->sum('billing_histories.price'); 
//                 // dd($daily_revenue->toSql());
                
//                 $daily_revenue = ($daily_revenue) ? General::decimalValues($daily_revenue, 2) : 0;
//                 return $daily_revenue;
            })
            ->editColumn('cumulative_revenue', function ($subscriberList) use($authId, $authUserType) {   
                

                $sql = "select `fan_billing_histories`.`msisdn`, 
                SUM(`fan_billing_histories`.`price`) as group_price 
                from `fan_billing_histories`";
                if($authUserType=='Affiliate') {
                    $sql .= " ";
                    $sql .= "inner join `fan_subscription` on `fan_subscription`.`msisdn` = `fan_billing_histories`.`msisdn` 
                    and `fan_subscription`.`resstatus` = 0 
                    and `fan_subscription`.`deleted_at` is null 
                    inner join `fan_users` on `fan_users`.`user_id` = `fan_subscription`.`affiliate_id` 
                    and `fan_users`.`user_id` = '".$authId."' 
                    and `fan_users`.`deleted_at` is null"; 
                }
                $sql .= " ";
                $sql .= "where date(`fan_billing_histories`.`created_at`) <= '".Carbon::parse($subscriberList->created_at)->format('Y-m-d')."' 
                and `fan_billing_histories`.`deleted_at` is null 
                and (`fan_billing_histories`.`action` LIKE 'SUBSCRIPTION' 
                or `fan_billing_histories`.`action` LIKE 'SUB' 
                or `fan_billing_histories`.`action` LIKE 'REN') 
                and `fan_billing_histories`.`deleted_at` is null 
                group by `fan_billing_histories`.`msisdn`";

                $cumulative_revenue = DB::select(DB::raw($sql));
                $cumulative_revenue = array_sum(array_column($cumulative_revenue,'group_price'));
                $cumulative_revenue = ($cumulative_revenue) ? General::decimalValues($cumulative_revenue, 2) : 0;
                return $cumulative_revenue;

                // $cumulative_revenue = BillingHistory::SELECT('billing_histories.msisdn')
                // ->whereDate('billing_histories.created_at', '<=', Carbon::parse($subscriberList->created_at)->format('Y-m-d'))
                // ->WHERENULL('billing_histories.deleted_at')
                // ->where(function($cumulative_revenue){
                //     $cumulative_revenue->where('billing_histories.action', 'LIKE', 'SUBSCRIPTION');
                //     $cumulative_revenue->orWhere('billing_histories.action', 'LIKE', 'SUB');
                //     $cumulative_revenue->orWhere('billing_histories.action', 'LIKE', 'REN');
                // });


                // if($authUserType=='Affiliate') {
                //     $cumulative_revenue = $cumulative_revenue->JOIN('subscription', function($join) {
                //         $join->ON('subscription.msisdn', '=', 'billing_histories.msisdn');
                //         $join->WHERENULL('subscription.deleted_at');
                //     });
        
                //     $cumulative_revenue = $cumulative_revenue->JOIN('users', function($join) use($authId) {
                //         $join->ON('users.user_id', '=', 'subscription.affiliate_id');
                //         $join->WHERE('users.user_id', $authId);
                //         $join->WHERENULL('users.deleted_at');
                //     });
                // }

                // // $cumulative_revenue = $cumulative_revenue->distinct('billing_histories.created_at');
                // $cumulative_revenue = $cumulative_revenue->sum('billing_histories.price'); 
                // $cumulative_revenue = ($cumulative_revenue) ? General::decimalValues($cumulative_revenue, 2) : 0;

                // return $cumulative_revenue;
            });

        return $datatableData;
    }

   

    public static function insertDateValues($chartData=[], $maxKey=0){
        $dateArray = $chartData;
        for ($i=0; $i <= $maxKey; $i++) {
            $formatted_value = sprintf("%02d", $i+1);

            if (!array_key_exists($formatted_value, $dateArray)) {
                $dateArray[$formatted_value] = 0;
            }
        }        
        ksort($dateArray);
        return array_values($dateArray);
    }

    public function getLabels(){
        $month = date("m");
        $year = date("Y");
        $start_date = "01-".$month."-".$year;
        $start_time = strtotime($start_date);
        $end_time = strtotime("+1 month", $start_time);
        for($i=$start_time; $i<$end_time; $i+=86400)
        {
            $list[] = date('d', $i);
        }
        return $list;
    }


}
