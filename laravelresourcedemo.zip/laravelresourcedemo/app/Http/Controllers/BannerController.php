<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Libraries\General;
use App\Libraries\GUID;
use App\Libraries\CustomErrorHandler;

use App\Banner;
use App\BannerLink;
use App\WSErrorHandler;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Illuminate\Contracts\Routing\ResponseFactory;
use Yajra\DataTables\DataTablesServiceProvider;
use App\Http\Requests\Admin\BannerRequest;

use DB;
use Hash;
use Redirect;
use Validator;
use DataTables;


class BannerController extends Controller
{

    /**
     * Constructor
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        //$this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request  $request)
    {
        if($request->ajax()){
            $masterList = Banner::select(
                '*'
            );
             return Datatables::eloquent($masterList)
            ->editColumn('banner_image', function ($masterList) {
                $image_path = public_path('/upload/banner_image/'.$masterList->banner_image);
                if(file_exists($image_path) && isset($masterList->banner_image) && $masterList->banner_image !=""){
                    return '/upload/banner_image/'.$masterList->banner_image;
                }else{
                    return '/images/avatar5.png';
                }
            })
            ->editColumn('banner_description', function ($masterList) {
                if(isset($masterList->banner_description) && $masterList->banner_description !=""){
                    return html_entity_decode(strip_tags($masterList->banner_description));
                }else{
                    return '';
                }
            })
            ->make(true);
        }
        return View('admin.banner.banner_list');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Banner $banner)
    {
        $retData = array(
            'data' => $banner
        );
        return view('admin.banner.banner_add',$retData);

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(BannerRequest $request)
    {
        $requestData = $request->all();
        $authId = Auth::id();

        DB::beginTransaction();
        try {
                $bannerId = GUID::create_guid();
                if (isset($requestData['banner_image']) && $requestData['banner_image']) {
                    $fileData = General::fileUpload($requestData['banner_image'], "banner_image");
                    $requestData['banner_image'] = $fileData;
                }
                $requestData['banner_id'] = $bannerId;
                $requestData['created_by'] = $authId;
                
                
                Banner::create($requestData);
                if(isset($requestData) && !empty($requestData)){
                    BannerLink::insertORUpdateBannerList($authId,$bannerId,$requestData['hid_banner_length'],$requestData['banner']);
                }
                // if($bannerObj->save()){
                //         BannerLink::insertORUpdateBannerList($authId,$bannerId,$requestData['hid_banner_length'],$requestData['banner']);
                // }

                DB::commit();
                return redirect('/admin/banner')->with('success', 'Banner Added Successfully.');
        } catch (\Exception $e) {
            DB::rollback();
            CustomErrorHandler::APIServiceLog($e->getMessage(), "BannerController: store");
            return back()->with('error', 'Something Went Wrong.');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Banner  $banner
     * @return \Illuminate\Http\Response
     */
    public function show(Banner $banner)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Banner  $banner
     * @return \Illuminate\Http\Response
     */
    public function edit(Banner $banner)
    {
        if(!empty($banner)){
            $banner->banner_image = General::imageUrlPath('banner_image', $banner->banner_image, 1, 1, '', 'avatar5.png');
            $bannerLinkData = BannerLink::SELECT('*')->WHERE('banner_id',$banner->banner_id)->WHERENULL('deleted_at')->get();
        }
        $retData = array(
            'bannerLinkData' => $bannerLinkData,
            'data' => $banner
        );
        return view('admin.banner.banner_add',$retData);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Banner  $Banner
     * @return \Illuminate\Http\Response
     */
    public function update(BannerRequest $request, $bannerId)
    {
        $requestData = $request->all();
        $authId = Auth::id();
        DB::beginTransaction();
        try {
                $bannerObj = Banner::findOrFail($bannerId);
                if (isset($requestData['banner_image']) && $requestData['banner_image']) {
                    $fileData = General::fileUpload($requestData['banner_image'], "banner_image", $bannerObj->banner_image);
                    $requestData['banner_image'] = $fileData;
                }
                $requestData['updated_by'] = $authId;
                
               $bannerObj->update($requestData);
                if(isset($bannerObj) && !empty($bannerObj)){
                    BannerLink::insertORUpdateBannerList($authId,$bannerId,$requestData['hid_banner_length'],$requestData['banner']);
                }
                
            


                /* if($bannerObj->save()){
                    BannerLink::insertORUpdateBannerList($authId,$bannerId,$requestData['hid_banner_length'],$requestData['banner']);
                } */
                DB::commit();
                return redirect('/admin/banner')->with('success', 'Banner Updated Successfully.');
        } catch (\Exception $e) {
            DB::rollback();
            CustomErrorHandler::APIServiceLog($e->getMessage(), "BannerController: update");
            return back()->with('error', 'Something Went Wrong.');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Banner  $banner
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        DB::beginTransaction();
        try {
            Banner::destroy($id);
            BannerLink::where('banner_id',$id)->delete();
            DB::commit();
            return response()->json([
                'success' => true,
                'message'   => 'Banner deleted successfully.'
            ], 200);
        } catch (\Exception $e) {
            DB::rollback();
            CustomErrorHandler::APIServiceLog($e->getMessage(), "BannerController: destroy");
            return response()->json([
                'success' => false,
                'message'   => 'Something Went Wrong.'
            ], 200);
        }
    }

    
}

