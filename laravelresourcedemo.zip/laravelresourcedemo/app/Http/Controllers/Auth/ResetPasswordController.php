<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\ResetsPasswords;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Redirect;
use Validator;
use App\User;
use Hash;
use App\Libraries\Emailsend;
use App\Libraries\CustomErrorHandler;

class ResetPasswordController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset requests
    | and uses a simple trait to include this behavior. You're free to
    | explore this trait and override any methods you wish to tweak.
    |
    */

    //use ResetsPasswords;

    /**
     * Where to redirect users after resetting their password.
     *
     * @var string
     */
    protected $redirectTo = '/';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }


    public function showResetPasswordForm($token)
    {
        if (Auth::check()) {
            return redirect()->intended('/admin');
        } else {
            return \View::make('admin.auth.reset-password')->with('token', $token);
        }
    }

    public function postResetPassword(Request $request, $token)
    {

        $postData = $request->all();
        try {
            $rules = array(
                // 'email' => 'required|email',
                'password' => 'required|min:5|required_with:password_confirmation|same:password_confirmation',
                'password_confirmation' => 'required|min:5',
            );
            $messsages = array(
                'password.required' => 'Password field is required.',
                'password_confirmation.required' => 'Confirm password Field is required.'
            );
            $validator = Validator::make($postData, $rules, $messsages);

            if ($validator->fails()) {
                return back()->withInput($request->all())->withErrors($validator);
                /*return Redirect::to('admin/reset-password/'.$token)
                    ->withErrors($validator);*/

            } else {
                $userData = User::WHERE('token', $postData['token'])->first();
                if(isset($userData) && !empty($userData)) {
                    if (isset($postData['password']) && $postData['password']) {
                    $userData->password = Hash::make($postData['password']);
                    }
                    $userData->token = NULL;
                    $userData->save();

                    $mailTo['to'] = array(
                        array(
                            'email'=>$userData->email,
                            'display_name'=>$userData->name
                        )
                    );
                    $data = array(
                        'siteurl' => getenv('APP_URL'),
                        'mailcontent' => array(
                            'name'=> $userData->name,
                            'message'=> 'Password has been reseted sucessfully.',
                        )
                    );
                    $mailSubject = 'Reset Password - '.getenv("PROJECT_NAME");
                    $sendMail = Emailsend::sendEmail($mailTo, $mailSubject, 'emails.admin.update-password', $data);

                    if($sendMail){
                        return redirect('/admin/login')->with('success', 'Password has been reseted sucessfully!');

                        // return Redirect::route('admin.login')->with('success', 'Password has been reseted sucessfully!.');
                    } else {
                        return back()->with('error', 'Password has been reseted sucessfully!');
                        // return Redirect::back()->withErrors(['general_error' => 'Email not sent!']);
                        
                    }
                } else {
                    // return Redirect::back()->withErrors(['general_error' => 'Email not found!']);
                    return back()->with('error', 'Email not found!');
                }   
            
            }
        } catch (\Exception $e) {
            CustomErrorHandler::APIServiceLog($e->getMessage(), "ResetPasswordController: postResetPassword");
            return back()->with('error', 'Something Went Wrong.');
            // return [
            //     'success' => false,
            //     'message' => 'Something Went Wrong.',
            // ];
        }

    }
}
