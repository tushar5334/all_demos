<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Redirect;
use Validator;
use App\Libraries\CustomErrorHandler;
class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //$this->middleware('guest')->except('logout');
    }

    public function showLoginForm()
    {
        if (Auth::check()) {
            return redirect()->intended('/admin');
        } else {
            return \View::make('admin.auth.login');
        }
    }
    
    public function postLogin(Request $request)
    {

        $postData = $request->all();

        try {
            $rules = array(
                'email' => 'required|email',
                'password' => 'required|min:5',
            );
            $messsages = array(
                'email.required' => 'Username field is required.',
                'password.required' => 'Password Field is required.'
            );
            $validator = Validator::make($postData, $rules, $messsages);

            if ($validator->fails()) {
                return Redirect::to('admin/login')
                    ->withErrors($validator);
            } else {

                // create our user data for the authentication
                $userdata = array(
                    'email' => $postData['email'],
                    'password' => $postData['password'],
                    'status' => 1,
                );

                // attempt to do the login
                if (Auth::attempt($userdata)) {

                    //$userDetail = Auth::user();
                    //return redirect()->intended('admin/');
                    return redirect('admin/');

                } else {
                    //return Redirect::back()->withErrors(['login_error' => 'Username and password is not valid']);
                    return back()->with('error', 'Username or password is not valid.');
                }
            }
        } catch (\Exception $e) {
            // return [
            //     'success' => false,
            //     'message' => 'Something Went Wrong.',
            // ];
            CustomErrorHandler::APIServiceLog($e->getMessage(), "LoginController: postLogin");
            return back()->with('error', 'Something Went Wrong.');
        }

    }

    public function postLogout()
    {

        Auth::logout();
        //Cache::flush();
        //Cache::forget('all_topic_list');
        return redirect('admin/login');
    }
}
