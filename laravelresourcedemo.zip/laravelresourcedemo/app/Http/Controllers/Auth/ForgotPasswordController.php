<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\SendsPasswordResetEmails;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Redirect;
use Validator;
use App\User;
use App\Libraries\Emailsend;
use App\Libraries\General;
use App\Libraries\CustomErrorHandler;
class ForgotPasswordController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset emails and
    | includes a trait which assists in sending these notifications from
    | your application to your users. Feel free to explore this trait.
    |
    */

    //use SendsPasswordResetEmails;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    public function showFrogotPasswordForm()
    {
        if (Auth::check()) {
            return redirect()->intended('/admin');
        } else {
            return \View::make('admin.auth.forgot-password');
        }
    }


    public function postForgotPassword(Request $request)
    {

        $postData = $request->all();

        try {
            $rules = array(
                'email' => 'required|email',
            );
            
            $messsages = array(
                'email.required' => 'Email address field is required.'
            );

            $validator = Validator::make($postData, $rules, $messsages);

            if ($validator->fails()) {
                /*return Redirect::to('admin/')
                    ->withErrors($validator);*/
                    return Redirect::route('admin.forgot-password')
                    ->withErrors($validator);
                    //route('route.name', array('param1' => $param1,'param2' => $param2))
            } else {
                $userData = User::WHERE('email', $postData['email'])->first();

                if(isset($userData) && !empty($userData)) {
                    $autoResetToken = General::generate_token();
                    $userData->token = $autoResetToken;
                    $userData->save();

                    $mailTo['to'] = array(
                        array(
                            'email'=>$userData->email,
                            'display_name'=>$userData->name
                        )
                    );
                    $data = array(
                        'siteurl' => getenv('APP_URL'),
                        'mailcontent' => array(
                            'name'=> $userData->name,
                            'reset_url'=> url('/').'/admin/reset-password/'.$autoResetToken,
                            'message'=> 'You are receiving this email because we received a password reset request for your account.',
                        )
                    );
                    $mailSubject = 'Reset Password - '.getenv("PROJECT_NAME");
                    $sendMail = Emailsend::sendEmail($mailTo, $mailSubject, 'emails.admin.reset-password', $data);

                    if($sendMail){
                        return redirect('/admin/login')->with('success', 'Reset password link has been sent to your email address successfully!');

//                        return Redirect::route('admin.login')->with('success', 'Reset password link has been sent to your email address sucessfully!.');
                    } else {
//                        return Redirect::back()->withErrors(['general_error' => 'Email not sent!']);
                        return back()->with('error', 'Email not sent!');

                    }
                } else {
                    //return Redirect::back()->withErrors(['general_error' => 'Email not found!']);
                    return back()->with('error', 'Email not found!');

                }   
            
            }
        } catch (\Exception $e) {
            // return [
            //     'success' => false,
            //     'message' => 'Something Went Wrong.',
            // ];
            CustomErrorHandler::APIServiceLog($e->getMessage(), "ForgotPasswordController: postForgotPassword");
            return back()->with('error', 'Something Went Wrong.');

        }

    }
}
