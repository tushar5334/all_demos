<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\ResetsPasswords;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Redirect;
use Validator;
use App\User;
use Hash;
use App\Libraries\Emailsend;
use App\Libraries\CustomErrorHandler;

class SetPasswordController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Password Set Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password set requests
    | and uses a simple trait to include this behavior. You're free to
    | explore this trait and override any methods you wish to tweak.
    |
    */

    //use SetsPasswords;

    /**
     * Where to redirect users after setting their password.
     *
     * @var string
     */
    protected $redirectTo = '/';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }


    public function showSetPasswordForm($token)
    {
        if (Auth::check()) {
            return redirect()->intended('/admin');
        } else {
            return \View::make('admin.auth.set-password')->with('token', $token);
        }
    }

    public function postSetPassword(Request $request, $token)
    {

        $postData = $request->all();
        try {
            $rules = array(
                'password' => 'required|min:5|required_with:password_confirmation|same:password_confirmation',
                'password_confirmation' => 'required|min:5',
            );
            $messsages = array(
                'password.required' => 'Password field is required.',
                'password_confirmation.required' => 'Confirm password Field is required.'
            );
            $validator = Validator::make($postData, $rules, $messsages);

            if ($validator->fails()) {
                return back()->withInput($request->all())->withErrors($validator);
            } else {
                $userData = User::WHERE('token', $postData['token'])->first();
                if(isset($userData) && !empty($userData)) {
                    if (isset($postData['password']) && $postData['password']) {
                    $userData->password = Hash::make($postData['password']);
                    }
                    $userData->token = NULL;
                    $userData->save();

                    $mailTo['to'] = array(
                        array(
                            'email'=>$userData->email,
                            'display_name'=>$userData->name
                        )
                    );
                    $data = array(
                        'siteurl' => getenv('APP_URL'),
                        'mailcontent' => array(
                            'name'=> $userData->name,
                            'message'=> 'Congratulations, you have set up your password to access the Penrose Marketing Network. Login to get started.',
                        )
                    );
                    $mailSubject = 'Set Password - Penrose Marketing Network - '.getenv("PROJECT_NAME");
                    $sendMail = Emailsend::sendEmail($mailTo, $mailSubject, 'emails.admin.update-password', $data);

                    if($sendMail){
                        return redirect('/admin/login')->with('success', 'Password has been set sucessfully!');
                    } else {
                        return back()->with('error', 'Password has been seted sucessfully!');

                    }
                } else {
                    // return Redirect::back()->withErrors(['general_error' => 'Email not found!']);
                    return back()->with('error', 'Email not found!');
                }

            }
        } catch (\Exception $e) {
            CustomErrorHandler::APIServiceLog($e->getMessage(), "SetPasswordController: postSetPassword");
            return back()->with('error', 'Something Went Wrong.');
            // return [
            //     'success' => false,
            //     'message' => 'Something Went Wrong.',
            // ];
        }

    }
}
