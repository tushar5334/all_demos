<?php

namespace App\Http\Controllers;

use App\Tag;
use App\Libraries\General;
use App\Libraries\CustomErrorHandler;
use App\Http\Requests\Admin\TagRequest;
use Illuminate\Http\Request;

use Yajra\DataTables\DataTablesServiceProvider;

use DB;
use DataTables;
use Config;

class TagController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if($request->ajax()){
            return Datatables::of(Tag::query())->make(true);
        }
        return view('admin.tag.list');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.tag.add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(TagRequest $request)
    {        
        DB::beginTransaction();
        try {
            $requestData = $request->all();
            Tag::create($requestData);
            DB::commit();
            return redirect('/admin/tag')->with('success', 'Tag Added Successfully.');
        } catch(\Exception $e) {
            DB::rollback();
            CustomErrorHandler::APIServiceLog($e->getMessage(), "TagController: store");
            return back()->with('error', 'Something Went Wrong.');
        }       
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Tag  $tag
     * @return \Illuminate\Http\Response
     */
    public function show(Tag $tag)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Tag  $tag
     * @return \Illuminate\Http\Response
     */
    public function edit(Tag $tag)
    {          
        return view('admin.tag.add')->with('data', $tag);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Tag  $tag
     * @return \Illuminate\Http\Response
     */
    public function update(TagRequest $request, $tagId)
    {
        DB::beginTransaction();
        try {
            $postData = $request->all();
            $tagObj = Tag::findOrFail($tagId);
            $tagObj->update($postData);
            DB::commit();
            return redirect('/admin/tag')->with('success', 'Tag Updated Successfully.');         
        } catch(\Exception $e) {
            DB::rollback();
            CustomErrorHandler::APIServiceLog($e->getMessage(), "TagController: store");
            return back()->with('error', 'Something Went Wrong.');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Tag  $tag
     * @return \Illuminate\Http\Response
     */   
    public function destroy(Request $request, $id)
    {
        DB::beginTransaction();
        try {
            Tag::destroy($id);
            DB::commit();
            return response()->json([
                'success' => true,
                'message'   => 'Tag deleted successfully.'
            ], 200);
        } catch (\Exception $e) {
            DB::rollback();
            CustomErrorHandler::APIServiceLog($e->getMessage(), "TagController: destroy");
            return response()->json([
                'success' => false,
                'message'   => 'Something Went Wrong.'
            ], 200);
        }
    }

    
}
