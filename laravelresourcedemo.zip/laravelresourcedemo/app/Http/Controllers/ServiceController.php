<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Libraries\General;
use App\Libraries\GUID;
use App\Libraries\CustomErrorHandler;

use App\Service;
use App\WSErrorHandler;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Illuminate\Contracts\Routing\ResponseFactory;
use Yajra\DataTables\DataTablesServiceProvider;
use App\Http\Requests\Admin\ServiceRequest;

use DB;
use Hash;
use Redirect;
use Validator;
use DataTables;


class ServiceController extends Controller
{

    /**
     * Constructor
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        //$this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request  $request)
    {
         if($request->ajax()){
            $masterList = Service::select('*');
            return DataTables::eloquent($masterList)
            ->filterColumn('service_name', function($query, $keyword) {
                $query->whereRaw('tx_services.service_name LIKE ?', ["%{$keyword}%"]);
            })
            ->editColumn('service_description', function ($masterList) {
                if(isset($masterList->service_description) && $masterList->service_description !=""){
                    // return str_replace("&nbsp;", "", strip_tags($masterList->service_description));
                    return html_entity_decode(strip_tags($masterList->service_description));
                }else{
                    return '';
                }
            })
            ->editColumn('service_image', function ($masterList) {
                $icon_path = public_path('/upload/service_image/'.$masterList->service_image);
                if(file_exists($icon_path) && isset($masterList->service_image) && $masterList->service_image !=""){
                    return '/upload/service_image/'.$masterList->service_image;
                }else{
                    return '/images/NoImageAvailable.png';
                }
            })
        ->make(true);
        }
        return View('admin.service.service_list');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Service $service)
    {
        $retData = array(
            'data' => $service
        );
        return view('admin.service.service_add',$retData);

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ServiceRequest $request)
    {
        $requestData = $request->all();
        $authId = Auth::id();

        DB::beginTransaction();
        try {
            // $rules = array(
            //     'service_name' => 'required|unique:services,service_name,NULL,service_id',
            //     'service_description' => 'required'
            // );
            // $messsages = array(
            //     'service_name.required' => 'Service Name field is required.',
            //     'service_description.required' => 'Description field is required.'
            // );
            // $validator = Validator::make($requestData, $rules, $messsages);
            // if ($validator->fails()) {
            //     return back()->withInput($request->all())->withErrors($validator);
            // } else {

            //     $serviceId = GUID::create_guid();
            //     $serviceObj = new Service();
            //     $serviceObj->service_id = $serviceId;
            //     $serviceObj->created_by = $authId;
            //     $serviceObj->updated_by = $authId;
            //     $serviceObj->service_name = (isset($requestData['service_name']) && $requestData['service_name']) ? $requestData['service_name'] : NULL;
            //     if(isset($requestData['service_name']) && !empty($requestData['service_name']))
            //     {
            //         $service_slug = General::generateSlug($requestData['service_name']);
            //     }
            //     $serviceObj->service_slug = (isset($service_slug) && $service_slug) ? $service_slug : NULL;
            //     $serviceObj->service_description = (isset($requestData['service_description']) && $requestData['service_description']) ? $requestData['service_description'] : NULL;
            //     if (isset($requestData['service_image']) && $requestData['service_image']) {
            //         $iconFileData = General::fileUpload($requestData['service_image'], "service_image", $serviceObj->service_image);
            //         $serviceObj->service_image = $iconFileData;
            //     }
            //     $serviceObj->status =  $requestData['status'];
            

            //     if($serviceObj->save()){

            //     }

            //     DB::commit();
            //     return redirect('/admin/service')->with('success', 'Service Added Successfully.');
            // }
            if (isset($requestData['service_image']) && $requestData['service_image']) {
                    $iconFileData = General::fileUpload($requestData['service_image'], "service_image");
                    $requestData['service_image'] = $iconFileData;
                }
            $serviceId = GUID::create_guid();
            $requestData['service_id'] = $serviceId;
            $requestData['created_by'] = $authId;
            Service::create($requestData);
            DB::commit();
            return redirect('/admin/service')->with('success', 'Service Added Successfully.');
        } catch (\Exception $e) {
            DB::rollback();
            CustomErrorHandler::APIServiceLog($e->getMessage(), "ServiceController: store");
            return back()->with('error', 'Something Went Wrong.');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Service  $service
     * @return \Illuminate\Http\Response
     */
    public function show(Service $service)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Service  $service
     * @return \Illuminate\Http\Response
     */
    public function edit(Service $service)
    {        
        if(!empty($service)){
            $service->service_image = General::imageUrlPath('service_image', $service->service_image, 1, 1, '', 'images/NoImageAvailable.png');
        }
         $retData = array(
            'data' => $service
        );
        return view('admin.service.service_add',$retData);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Service  $service
     * @return \Illuminate\Http\Response
     */
    public function update(ServiceRequest $request, $serviceId)
    {
        $requestData = $request->all();
        $authId = Auth::id();
        DB::beginTransaction();
        try {

            // $rules = array(
            //     'service_name' => 'required|unique:services,service_name,'.$requestData['service_id'].',service_id',
            //     'service_description' => 'required'
            // );
            // $messsages = array(
            //     'service_name.required' => 'Service Name field is required.',
            //     'service_description.required' => 'Description field is required.'
            // );

            // $validator = Validator::make($requestData, $rules, $messsages);
            // if ($validator->fails()) {
            //     return back()->withInput($request->all())->withErrors($validator);
            // } else {
            //     $serviceObj = Service::findOrFail($serviceId);
            //     $serviceObj->updated_by = $authId;
            //     $serviceObj->service_name = (isset($requestData['service_name']) && $requestData['service_name']) ? $requestData['service_name'] : NULL;
            //     if(isset($requestData['service_name']) && !empty($requestData['service_name']))
            //     {
            //         $service_slug = General::generateSlug($requestData['service_name']);
            //     }
            //     $serviceObj->service_slug = (isset($service_slug) && $service_slug) ? $service_slug : NULL;
            //     $serviceObj->service_description = (isset($requestData['service_description']) && $requestData['service_description']) ? $requestData['service_description'] : NULL;
            //     if (isset($requestData['service_image']) && $requestData['service_image']) {
            //         $iconFileData = General::fileUpload($requestData['service_image'], "service_image", $serviceObj->service_image);
            //         $serviceObj->service_image = $iconFileData;
            //     }
            //     $serviceObj->status =  $requestData['status'];

            //     if($serviceObj->save()){

            //     }
            //     DB::commit();
            //     return redirect('/admin/service')->with('success', 'Service Updated Successfully.');
            // }
            $serviceObj = Service::findOrFail($serviceId);
            if (isset($requestData['service_image']) && $requestData['service_image']) {
                    $iconFileData = General::fileUpload($requestData['service_image'], "service_image", $serviceObj->service_image);
                   $requestData['service_image'] = $iconFileData;
                }
            $requestData['updated_by'] = $authId;
            $serviceObj->update($requestData);
            DB::commit();
            return redirect('/admin/service')->with('success', 'Service Updated Successfully.');

        } catch (\Exception $e) {
            DB::rollback();
            CustomErrorHandler::APIServiceLog($e->getMessage(), "ServiceController: update");
            return back()->with('error', 'Something Went Wrong.');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Service  $service
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        DB::beginTransaction();
        try {
            Service::destroy($id);
            DB::commit();
            return response()->json([
                'success' => true,
                'message'   => 'Service deleted successfully.'
            ], 200);
        } catch (\Exception $e) {
            DB::rollback();
            CustomErrorHandler::APIServiceLog($e->getMessage(), "ServiceController: destroy");
            return response()->json([
                'success' => false,
                'message'   => 'Something Went Wrong.'
            ], 200);
        }
    }

    /**
     * Get Datatable Listing Data.
     *
     * @return \Illuminate\Http\Response
     */
    // public function getDataTableList(Datatables $datatables)
    // {

    //     $masterList = Service::select('*');
    //     return DataTables::eloquent($masterList)
    //     ->filterColumn('service_name', function($query, $keyword) {
    //         $query->whereRaw('tx_services.service_name LIKE ?', ["%{$keyword}%"]);
    //     })
    //     ->editColumn('service_description', function ($masterList) {
    //         if(isset($masterList->service_description) && $masterList->service_description !=""){
    //             // return str_replace("&nbsp;", "", strip_tags($masterList->service_description));
    //             return html_entity_decode(strip_tags($masterList->service_description));
    //         }else{
    //             return '';
    //         }
    //     })
    //     ->editColumn('service_image', function ($masterList) {
    //         $icon_path = public_path('/upload/service_image/'.$masterList->service_image);
    //         if(file_exists($icon_path) && isset($masterList->service_image) && $masterList->service_image !=""){
    //             return '/upload/service_image/'.$masterList->service_image;
    //         }else{
    //             return '/images/NoImageAvailable.png';
    //         }
    //     })
    //    ->make(true);
    // }
}

