<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Libraries\General;
use App\Libraries\GUID;
use App\Libraries\CustomErrorHandler;

use App\Project;
use App\WSErrorHandler;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Illuminate\Contracts\Routing\ResponseFactory;
use Yajra\DataTables\DataTablesServiceProvider;
use App\Http\Requests\Admin\ProjectRequest;

use DB;
use Hash;
use Redirect;
use Validator;
use DataTables;


class ProjectController extends Controller
{

    /**
     * Constructor
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        //$this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request  $request)
    {
        if($request->ajax()){
            $masterList = Project::select(
                '*'
            );
             return Datatables::eloquent($masterList)
            ->editColumn('project_image', function ($masterList) {
                $image_path = public_path('/upload/project_image/'.$masterList->project_image);
                if(file_exists($image_path) && isset($masterList->project_image) && $masterList->project_image !=""){
                    return '/upload/project_image/'.$masterList->project_image;
                }else{
                    return '/images/avatar5.png';
                }
            })
            ->editColumn('project_description', function ($masterList) {
                if(isset($masterList->project_description) && $masterList->project_description !=""){
                    return html_entity_decode(strip_tags($masterList->project_description));
                }else{
                    return '';
                }
            })
            ->make(true);
        }
        return view('admin.project.project_list');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Project $project)
    {
        $retData = array(
            'data' => $project
        );
        return view('admin.project.project_add',$retData);

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ProjectRequest $request)
    {
        $requestData = $request->all();
        $authId = Auth::id();

        DB::beginTransaction();
        try {
            $projectId = GUID::create_guid();
            if (isset($requestData['project_image']) && $requestData['project_image']) {
                $fileData = General::fileUpload($requestData['project_image'], "project_image");
                $requestData['project_image'] = $fileData;
            }
            $requestData['project_id'] = $projectId;
            $requestData['created_by'] = $authId;
            
            Project::create($requestData);
            DB::commit();
                return redirect('/admin/project')->with('success', 'Project Added Successfully.');
        } catch (\Exception $e) {
            DB::rollback();
            CustomErrorHandler::APIServiceLog($e->getMessage(), "ProjectController: store");
            return back()->with('error', 'Something Went Wrong.');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Project  $project
     * @return \Illuminate\Http\Response
     */
    public function show(Project $project)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Project  $project
     * @return \Illuminate\Http\Response
     */
    public function edit(Project $project)
    {
        if(!empty($project)){
            $project->project_image = General::imageUrlPath('project_image', $project->project_image, 1, 1, '', 'avatar5.png');
        }
         $retData = array(
            'data' => $project
        );
        return view('admin.project.project_add',$retData);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Project  $project
     * @return \Illuminate\Http\Response
     */
    public function update(ProjectRequest $request, $projectId)
    {
        $requestData = $request->all();
        $authId = Auth::id();
        DB::beginTransaction();
        try {
            $projectObj = Project::findOrFail($projectId);
            if (isset($requestData['project_image']) && $requestData['project_image']) {
                $fileData = General::fileUpload($requestData['project_image'], "project_image", $projectObj->project_image);
                $requestData['project_image'] = $fileData;
            }
            $requestData['updated_by'] = $authId;
            $projectObj->update($requestData);
        
            DB::commit();
            return redirect('/admin/project')->with('success', 'Project Updated Successfully.');
        } catch (\Exception $e) {
            DB::rollback();
            CustomErrorHandler::APIServiceLog($e->getMessage(), "ProjectController: update");
            return back()->with('error', 'Something Went Wrong.');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Project  $project
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        DB::beginTransaction();
        try {
            Project::destroy($id);
            DB::commit();
            return response()->json([
                'success' => true,
                'message'   => 'Project deleted successfully.'
            ], 200);
        } catch (\Exception $e) {
            DB::rollback();
            CustomErrorHandler::APIServiceLog($e->getMessage(), "ProjectController: destroy");
            return response()->json([
                'success' => false,
                'message'   => 'Something Went Wrong.'
            ], 200);
        }
    }
}

