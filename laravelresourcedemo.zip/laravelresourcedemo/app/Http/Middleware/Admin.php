<?php

namespace App\Http\Middleware;

use Closure;
use Auth;

class Admin
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {   
        echo '<pre>';print_r(Auth::user());echo'</pre>';exit;
        if (Auth::user()->user_type == 'SuperAdmin' || Auth::user()->user_type=='Admin') {
            return $next($request);
        } else {
            return redirect('/admin/login');
        }
    }
}
