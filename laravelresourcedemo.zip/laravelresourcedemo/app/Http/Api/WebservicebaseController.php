<?php namespace App\Http\Controllers\Api;

/**
 * @uses Webservice Base Controller for common usage
 * @author Ashwin Vadgama <ashwinvadgama@gmail.com>
 * @return
 */

use App\Libraries\WebService;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;

use Tymon\JWTAuth\JWTAuth;
use Tymon\JWTAuth\Exceptions\TokenExpiredException;
use Tymon\JWTAuth\Exceptions\TokenInvalidException;
use Tymon\JWTAuth\Exceptions\JWTException;

use Auth;
use Lang;
use Storage;
use Config;
use Carbon;
use DB;

use App\Libraries\GUID;
use App\Libraries\General;

use App\User;
use App\AffiliateCredential;

//use Illuminate\Pagination\Paginator;

class WebservicebaseController extends Controller {

	private $WebService;
	private $jwtAuth;

	public function __construct($jwtAuth) {
		$this->WebService = new Webservice();
		$this->jwtAuth = $jwtAuth;
	}

	/**
     * @uses WebService: Login
     * @author Ashwin Vadgama <ashwinvadgama@gmail.com>
     * @return json
     */
	public function postLogin(){
		$result = $this->WebService->check_validation('login');
		if($result['status']){
            //$result = $this::CheckDeviceRegister();
            $post = Input::all();
            $data['email'] = $post['email'];
            $data['password'] = $post['password'];
            $data['user_status'] = "Active";
            $data['user_type'] = "Affiliate";
            $data['status'] = 1;
            if(Auth::once($data)){
                $userData = Auth::user();
                $user_id = Auth::id();
                $user = User::SELECT('user_id','email','name','user_status','status','user_type')->find($user_id);

                $AffiliateCredentialObj = AffiliateCredential::WHERE('affiliate_id','=',$user_id)->WHERE('status','=',1)->FIRST();
                if($AffiliateCredentialObj){

                    if($AffiliateCredentialObj->api_status == 1){
                        $userTokenData = array();
                        $userTokenData['user_id'] = $user_id;
                        $userTokenData['email'] = $userData->email;
                        $userTokenData['name'] = $userData->name;
                        $userTokenData['user_status'] = $userData->user_status;
                        $userTokenData['status'] = $userData->status;
                        $userTokenData['user_type'] = $userData->user_type;
                        $finaldata['token'] = $this->jwtAuth->fromUser($user);
                        $userData = $user->toArray();
                        $finaldata['userData'] = $userData;
                        $msg = Lang::get("ws.msg_login_success");
                        $result = $this->WebService->prepare_data(true,200,$msg,$finaldata);
                    }else{
                        $msg = Lang::get("ws.SOMETHING_WENT_WRONG");
                        $result = $this->WebService->prepare_data(false,401,$msg);
                    }
                }else{
                    $msg = Lang::get("ws.SOMETHING_WENT_WRONG");
                    $result = $this->WebService->prepare_data(false,401,$msg);
                }                
            }else{
                $msg = Lang::get("ws.msg_invalid_credential");
                $result = $this->WebService->prepare_data(false,401,$msg);
            }
		}
		return $this->WebService->output($result);
	}

 
    /**
     * @uses WebService: Check Device is register or not
     * @author Ashwin Vadgama <ashwinvadgama@gmail.com>
     * @return json
     */
    public function CheckDeviceRegister(){
        $post = Input::all();

        $versions = Device::CheckInitialData();

        if( ($versions['app_version'] != $post['app_version'] && isset($versions['force_download']) && $versions['force_download']==1) || ($versions['app_version'] < $post['app_version'])){
            $msg = Lang::get("ws.msg_app_version_not_match");

            $data['app_status']['current_version'] = $post['app_version'];
            $data['app_status']['latest_version'] = $versions['app_version'];
            $data['app_status']['update_link'] = $versions['update_link'];
            $data['app_status']['bundle_id'] = $versions['bundle_id'];
            $data['app_status']['ipa_filename'] = $versions['ipa_filename'];
            $result = $this->WebService->prepare_data(false,403,$msg,$data);
        }else{
            $data = array();
            $result = $this->CheckWebServiceApiVersion($versions);
            if($result['status'] == true){
                $result = $this->WebService->prepare_data(true,200,'',$data);
            }
        }
        return $result;
    }


    /**
     * @uses WebService: Check Webservice API version
     * @author Ashwin Vadgama <ashwinvadgama@gmail.com>
     * @return json
     */
    protected function CheckWebServiceApiVersion($versions){
        $post = Input::all();
        //$URI = Request::path();
        $URI = "";
        $RequstWebserviceVersion = @explode("/",$URI)[1];
        $RequstWebserviceVersionNumber = @substr($RequstWebserviceVersion,1);
        $RequiredWebserviceVersionNumber = @substr($versions['api_version'],1);
        $result['status'] = true;
        if($RequstWebserviceVersionNumber < $RequiredWebserviceVersionNumber &&  isset($versions['force_download']) && $versions['force_download']==1){
            $msg = Lang::get("ws.msg_api_version_not_match");
            $data['current_version'] = "v".$RequstWebserviceVersionNumber;
            $data['latest_version'] = "v".$RequiredWebserviceVersionNumber;
            $result = $this->WebService->prepare_data(false,403,$msg,$data);
        }
        return $result;
    }

    /**
     * @uses WebService: return current Webservice API version
     * @author Ashwin Vadgama <ashwinvadgama@gmail.com>
     * @return json
     */
    protected function ReturnWebServiceApiVersion(Request $request){
        $post = Input::all();
        $URI = $request->path();
        return $RequstWebserviceVersion = @explode("/",$URI)[1];
    }

}