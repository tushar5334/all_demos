<?php namespace App\Http\Controllers\Api\v1;

/**
 * @uses Webservice V1 Controller
 * @author Ashwin Vadgama <ashwinvadgama@gmail.com>
 * @return
 */

use Tymon\JWTAuth\JWTAuth;
use Tymon\JWTAuth\Exceptions\TokenExpiredException;
use Tymon\JWTAuth\Exceptions\TokenInvalidException;
use Tymon\JWTAuth\Exceptions\JWTException;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Api\WebservicebaseController;
use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;

use App\Libraries\WebService;
use App\Libraries\GUID;
use App\Libraries\General;
use App\Libraries\HashFunction;


use Auth;
use Lang;
use Config;
use DB;
use Validator;

/* Models */
use App\ApiLogs;
use App\User;
use App\AffiliateCredential;
use App\Subscription;
use App\SubscriptionHistory;
use App\SubscriptionStatus;
use App\Subscriber;

class WebserviceController extends WebservicebaseController {

	private $WebService;
	private $jwtAuth;

	public function __construct(JWTAuth $jwtAuth) {

		$this->WebService = new Webservice();
		$this->jwtAuth = $jwtAuth;
		parent::__construct($jwtAuth);
        $this->middleware('apijwtauth')->except(['postLogin']);
	}

	/**
     * @uses WebService: Check Version
     * @author Ashwin Vadgama <ashwinvadgama@gmail.com>
     * @return json
     */
	public function postCheckVersion(Request $request){
		$post = Input::all();
		$result = $this->WebService->check_validation('general-service-input');

		if($result['status']){
            $result['data']['update_available'] = false;
		}

		return $this->WebService->output($result);
	}


    /**
     * @uses WebService: Subscribe User
     * @author Ashwin Vadgama <ashwinvadgama@gmail.com>
     * @return json
     */
    public function postSubscribe(Request $request){
        $postData = Input::all();
        $result = $this->WebService->check_validation('subscribe');
        if($result['status']){

            try{
                $requestArr = array();
                $requestArr = $postData;

                $apiBaseURL = env('API_BASE_URL', null);
                $api_links = $apiBaseURL.'/subuser/';


                $rules=$messages=array();
                $post = $requestArr;                
                if (!(substr($post['msisdn'], 0, 1) === '0') || (substr($post['msisdn'], 0, 3) === '027')) {
                    $post['msisdn'] = "";
                    $rules = array(
                        'msisdn' => 'required',
                    );
                    $messages = array(
                        'msisdn.required' => 'Always pass the Mobile number of the subscriber with prefix 0 & without country code 27.',
                    );
                }
                $validator = Validator::make($post,$rules,$messages);
                if($validator->fails()) {
                    $msg = $validator->messages();
                    $result = $this->WebService->prepare_data(false,401,$msg);
                } else {

                    // Insert coutry code instead leading zero
                    if(isset($requestArr['msisdn']) && $requestArr['msisdn']){
                        $number = $requestArr['msisdn'];
                        $country_code = '27';
                        $requestArr['msisdn'] = substr_replace($number, $country_code, 0, ($number[0] == '0'));
                    }


                    $responseDataArr = ApiLogs::getApiResponse($api_links, $requestArr);
                    $responseDataArrJsonDecode = json_decode($responseDataArr, true);            

                    WebserviceController::storeResponseData($requestArr,$responseDataArr,$responseDataArrJsonDecode);

                    $data = $responseDataArrJsonDecode;
                    $msg = "API response successfully.";
                    $result = $this->WebService->prepare_data(true,200,$msg, $data);
                }

            } catch(\Exception $e) {
                $msg = Lang::get("ws.SOMETHING_WENT_WRONG");
                $result = $this->WebService->prepare_data(false,401,$msg);
            }

        }
        return $this->WebService->output($result);
    }


    /**
     * @uses WebService: UN-Subscribe User
     * @author Ashwin Vadgama <ashwinvadgama@gmail.com>
     * @return json
     */
    public function postUnSubscribe(Request $request){
        $postData = Input::all();
        $result = $this->WebService->check_validation('un-subscribe');
        if($result['status']){

            try{
                $requestArr = array();
                $requestArr = $postData;

                $apiBaseURL = env('API_BASE_URL', null);
                $api_links = $apiBaseURL.'/unsubuser/';
                
                $rules=$messages=array();
                $post = $requestArr;                
                if (!(substr($post['msisdn'], 0, 1) === '0') || (substr($post['msisdn'], 0, 3) === '027')) {
                    $post['msisdn'] = "";
                    $rules = array(
                        'msisdn' => 'required',
                    );
                    $messages = array(
                        'msisdn.required' => 'Always pass the Mobile number of the subscriber with prefix 0 & without country code 27.',
                    );
                }
                $validator = Validator::make($post,$rules,$messages);
                if($validator->fails()) {
                    $msg = $validator->messages();
                    $result = $this->WebService->prepare_data(false,401,$msg);
                } else {

                    // Insert coutry code instead leading zero
                    if(isset($requestArr['msisdn']) && $requestArr['msisdn']){
                        $number = $requestArr['msisdn'];
                        $country_code = '27';
                        $requestArr['msisdn'] = substr_replace($number, $country_code, 0, ($number[0] == '0'));
                    }
                    $authId = '';
                    if(isset($request->jwtUserData['JWTTokenData']) && count($request->jwtUserData['JWTTokenData'])>0){
                        $token_data = $request->jwtUserData['JWTTokenData'];
                        $authId = $token_data['user_id'];
                    }
                    
                    $isAvailableSubscription = true;
                    
                    $getSubscription = ($requestArr['msisdn']) ? Subscription::where('msisdn', $requestArr['msisdn'])->where('affiliate_id', $authId)->first() : '';
                    if(!isset($getSubscription) || empty($getSubscription)){
                        $isAvailableSubscription = false;
                    }
                    if($isAvailableSubscription){

                        $responseDataArr = ApiLogs::getApiResponse($api_links, $requestArr);
                        $responseDataArrJsonDecode = json_decode($responseDataArr, true);
                    
                        WebserviceController::storeResponseData($requestArr,$responseDataArr,$responseDataArrJsonDecode);

                        $data = $responseDataArrJsonDecode;
                        $msg = "API response successfully.";
                        $result = $this->WebService->prepare_data(true,200,$msg, $data);
                    } else {
                        $msg = Lang::get("ws.SOMETHING_WENT_WRONG");
                        $result = $this->WebService->prepare_data(false,401,$msg);
                    }
                }

            } catch(\Exception $e) {
                $msg = Lang::get("ws.SOMETHING_WENT_WRONG");
                $result = $this->WebService->prepare_data(false,401,$msg);
            }
        }
        return $this->WebService->output($result);
    }

    /**
     * @uses WebService: Check Status
     * @author Jashpalsinh Chauhan <jashpalsinh.chauhan@txtech.co>
     * @return json
     */
    public function postCheckStatus(Request $request){
        $postData = Input::all();
        $result = $this->WebService->check_validation('check-status');
        if($result['status']){

            try{
                $requestArr = array();
                $requestArr = $postData;

                $apiBaseURL = env('API_BASE_URL', null);
                $api_links = $apiBaseURL.'/CheckStatus/';


                $rules=$messages=array();
                $post = $requestArr;
                
                if (!(substr($post['msisdn'], 0, 1) === '0') || (substr($post['msisdn'], 0, 3) === '027')) {
                    $post['msisdn'] = "";
                    $rules = array(
                        'msisdn' => 'required',
                    );
                    $messages = array(
                        'msisdn.required' => 'Always pass the Mobile number of the subscriber with prefix 0 & without country code 27.',
                    );
                }
                $validator = Validator::make($post,$rules,$messages);
                if($validator->fails()) {
                    $msg = $validator->messages();
                    $result = $this->WebService->prepare_data(false,401,$msg);
                } else {
                    // Insert coutry code instead leading zero
                    if(isset($requestArr['msisdn']) && $requestArr['msisdn']){
                        $number = $requestArr['msisdn'];
                        $country_code = '27';
                        $requestArr['msisdn'] = substr_replace($number, $country_code, 0, ($number[0] == '0'));
                    }
                    $responseDataArr = ApiLogs::getApiResponse($api_links, $requestArr);
                    $responseDataArrJsonDecode = json_decode($responseDataArr, true);
                    
                    /* ******************************************************************
                    ** Insert subscription history data
                    ** ****************************************************************** */
                    // WebserviceController::storeResponseData($requestArr,$responseDataArr,$responseDataArrJsonDecode);
                    if(isset($requestArr['reqtype']) && $requestArr['reqtype'] == "CHECK"){
                        SubscriptionStatus::saveSubscriptionStatus($requestArr, $responseDataArrJsonDecode);
                    }                    

                    $data = $responseDataArrJsonDecode;
                    $msg = "API response successfully.";
                    $result = $this->WebService->prepare_data(true,200,$msg, $data);
                }

            } catch(\Exception $e) {
                $msg = Lang::get("ws.SOMETHING_WENT_WRONG");
                $result = $this->WebService->prepare_data(false,401,$msg);
            }
        }
        return $this->WebService->output($result);
    }

    
    /**
     * @uses WebService: Encrypt the post data
     * @author Ashwin Vadgama <ashwinvadgama@gmail.com>
     * @return json
     */
    public function postEncryptionString(Request $request){
        $post = Input::all();
        $result = $this->WebService->check_validation('encryption-string');
        if($result['status']){
            try{
                if(isset($request->jwtUserData['JWTTokenData']) && count($request->jwtUserData['JWTTokenData'])>0){
                    $token_data = $request->jwtUserData['JWTTokenData'];
                    $loggin_user_id = $token_data['user_id'];
                    $affiliateDetail = AffiliateCredential::WHERE('affiliate_id','=',$loggin_user_id)->FIRST();
                    if($affiliateDetail){
                      $api_secret_key = $affiliateDetail->api_secret_key;
                      $api_access_token = $affiliateDetail->api_access_token;
                      $api_salt = $affiliateDetail->api_salt;
                      $api_status = $affiliateDetail->api_status;
                        
                        if($api_secret_key != "" && $api_salt != ""){
                            $string = HashFunction::PrepareStringOfRequest($post['reqtype'],$post);
                            $encrypted = HashFunction::stringEncryption('encrypt', $string, $api_secret_key, $api_salt);
                            $data['encrypted_string'] = $encrypted;
                            $msg = "String encrypted successfully.";
                            $result = $this->WebService->prepare_data(true,200,$msg, $data);

                        }else{
                            $msg = Lang::get("ws.SOMETHING_WENT_WRONG");
                            $result = $this->WebService->prepare_data(false,401,$msg);    
                        }
                    }else{
                        $msg = Lang::get("ws.SOMETHING_WENT_WRONG");
                        $result = $this->WebService->prepare_data(false,401,$msg);
                    }
                }
            } catch(\Exception $e) {
                $msg = Lang::get("ws.SOMETHING_WENT_WRONG");
                $result = $this->WebService->prepare_data(false,401,$msg);
            }
        }
        return $this->WebService->output($result);
    }

    
    /**
     * @uses WebService: Store Response Data into other tables
     * @author Jashpalsinh Chauhan <jashpalsinh.chauhan@txtech.co>
     * @return json
     */
    public function storeResponseData($requestArr = array(),$responseDataArr = array(),$responseDataArrJsonDecode = array()){
        /* ******************************************************************
        ** Insert API logs data
        ** ****************************************************************** */
        $apiLogsObj = ApiLogs::saveApiLogs($requestArr, $responseDataArr);
    
        /* ******************************************************************
        ** Insert or update subscription data
        ** ****************************************************************** */
        $subscriptionObj = Subscription::saveSubscription($requestArr, $responseDataArrJsonDecode); 

        /* ******************************************************************
        ** Insert or update subscriber data
        ** ****************************************************************** */
        $responseStatus = '';
        if(isset($responseDataArrJsonDecode['response'])){
            $apiResponseData = (isset($responseDataArrJsonDecode)) ? $responseDataArrJsonDecode['response'] : '';
        }
        if(isset($responseDataArrJsonDecode['service'])){
            $apiResponseData = (isset($responseDataArrJsonDecode)) ? $responseDataArrJsonDecode['service'] : '';
        }
        if(isset($apiResponseData) && $apiResponseData){
            $responseStatus = (isset($apiResponseData['status'])) ? $apiResponseData['status'] : '';
        }
        if($responseStatus==0){
            $checkStatusArr = [
                'reqtype' => "CHECK",
                'msisdn' => $requestArr['msisdn'],
                "serviceid" => $requestArr['serviceid'],
                "scode" => $requestArr['scode'],
                "STATUS" => "ACTIVE"
            ];
            $apiBaseURL = env('API_BASE_URL', null);
            $checkResponseDataArr = ApiLogs::getApiResponse($apiBaseURL.'/CheckStatus/', $checkStatusArr);
            $checkResponseDataArrJsonDecode = json_decode($checkResponseDataArr, true);
            $subscriberObj = Subscriber::saveSubscriber($requestArr, $checkResponseDataArrJsonDecode);
        }

        /* ******************************************************************
        ** Insert subscription history data
        ** ****************************************************************** */
        $subscriptionHistoryObj = SubscriptionHistory::saveSubscriptionHistory($requestArr, $responseDataArrJsonDecode, $subscriptionObj->subscription_id, $apiLogsObj->api_log_id);

        /* ******************************************************************
        // ** Insert subscription status data
        // ** ****************************************************************** */
        // if(isset($requestArr['reqtype']) && $requestArr['reqtype'] == "CHECK"){
        //     SubscriptionStatus::saveSubscriptionStatus($requestArr, $responseDataArrJsonDecode, $subscriptionObj->subscription_id);                
        // }
    }
    
}