<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Input;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\ColumnFillable;
use DB;
use Config;

class Hiring extends Model
{

    protected $table = 'hirings';
    protected $primaryKey = 'hiring_id';
    public $incrementing = false;
    use SoftDeletes;
    use ColumnFillable;
    protected $dates = ['deleted_at'];

}