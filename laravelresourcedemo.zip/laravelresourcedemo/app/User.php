<?php
/**
 * @uses User Model
 * @author Ranjitsinh Bhalgariya <ranjit.bhalgariya@jini.guru>
 * @return 
 */

namespace App;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use App\Libraries\General;




class User extends Authenticatable 
{
    use Notifiable;


    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    protected $table = 'users';
    protected $primaryKey = 'user_id';
    public $incrementing = false;

   

    public static function getUserAutoSearchData($user_id='') {
        $limit = General::$ajaxSearchDataLimit;        
        $data =  User::SELECT(
            'users.user_id', 
            'users.user_id as id',  
            'users.name as text'
        );
        if($user_id){
            $data = $data->where('user_id', $user_id);
        }
        $data = $data->limit($limit)->GET()->toArray();
        return $data;
    }
}
