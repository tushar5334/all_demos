<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Input;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\ColumnFillable;
use DB;
use Config;

class Banner extends Model
{

    protected $table = 'banners';
    protected $primaryKey = 'banner_id';
    public $incrementing = false;
    use SoftDeletes;
    use ColumnFillable;
    protected $dates = ['deleted_at'];

}