<?php

namespace App\Exports;

use App\Subscriber;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithHeadings;

class SubscribersExport implements FromArray, ShouldAutoSize, WithHeadings
{

    protected $subscriberHeading;
    protected $subscriberData;
 
    public function __construct(array $subscriberHeading, array $subscriberData){
        $this->subscriberHeading = $subscriberHeading;       
        $this->subscriberData = $subscriberData;       
    }
    
    public function headings(): array
    {
        return $this->subscriberHeading;
    }

    public function array(): array
    {
        return $this->subscriberData;
    }
    
}
