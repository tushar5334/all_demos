<?php 
/**
 * @uses GUID Libraries
 * @author Ranjitsinh Bhalgariya <ranjit.bhalgariya@txtech.co>
 * @return 
 */

namespace App\Libraries;

use Illuminate\Contracts\Routing\ResponseFactory;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Http\Requests;
use Input;

class GUID {

    /**
     * @author Ranjitsinh Bhalgariya <ranjit.bhalgariya@txtech.co>
     * @uses Generate GUID
     * @return string
     */

    public static function create_guid()
    {
        $microTime = microtime();
        list($a_dec, $a_sec) = explode(" ", $microTime);

        $dec_hex = dechex($a_dec* 1000000);
        $sec_hex = dechex($a_sec);

        GUID::ensure_length($dec_hex, 5);
        GUID::ensure_length($sec_hex, 6);

        $guid = "";
        $guid .= $dec_hex;
        $guid .= GUID::create_guid_section(3);
        $guid .= '-';
        $guid .= GUID::create_guid_section(4);
        $guid .= '-';
        $guid .= GUID::create_guid_section(4);
        $guid .= '-';
        $guid .= GUID::create_guid_section(4);
        $guid .= '-';
        $guid .= $sec_hex;
        $guid .= GUID::create_guid_section(6);

        return $guid;

    }

    /**
     * @author Ranjitsinh Bhalgariya <ranjit.bhalgariya@txtech.co>
     * @uses Generate GUID
     * @return string
     */

    public static function create_guid_section($characters)
    {
        $return = "";
        for ($i=0; $i<$characters; $i++) {
            $return .= dechex(mt_rand(0,15));
        }

        return $return;
    }

   /**
     * @author Ranjitsinh Bhalgariya <ranjit.bhalgariya@txtech.co>
     * @uses Generate GUID
     * @return string
     */
   
    public static function ensure_length(&$string, $length)
    {
        $strlen = strlen($string);
        if ($strlen < $length) {
            $string = str_pad($string,$length,"0");
        } elseif ($strlen > $length) {
            $string = substr($string, 0, $length);
        }
    }

}
