<?php
/**
 * @uses General Functions
 * @author Ranjitsinh Bhalgariya <ranjit.bhalgariya@txtech.co>
 * @return
 */

namespace App\Libraries;

use File;
use Image;
use URL;

class HashFunction {

    /**
     * @author ashwin vadgama <ashwinvadgama.gmail.com>
     * @uses for checking hash 
     * @return string
     */
    public static function check_request_parameter($request, $api_secret_key="",$api_salt="") {
        $ReturnData = array();

        $request_parameter = $request->all();
        $request_header = $request->header();
        $x_signature = $request->header('x-signature');

        if(isset($x_signature) && $x_signature != "" && isset($request_parameter) && count($request_parameter)){
            
            //$encrypted = HashFunction::stringEncryption('encrypt', $string);
            //echo 'encrypted = '.$encrypted."\n\n";
            $decrypted = HashFunction::stringEncryption('decrypt', $x_signature, $api_secret_key, $api_salt);
            $request_array = @explode("&", $decrypted);
            $error = 0;
            $error_msg = array();
            $total_count = count($request_array);
            $total_count_array = array();
            foreach ($request_array as $key => $value) {
                $sub = @explode("=", $value);
                if(isset($request_parameter[$sub[0]]) && isset($sub[1])){
                    if($request_parameter[$sub[0]] == $sub[1]){
                        $total_count_array[] = 1;
                    }else{
                        $error=1;
                        $error_msg[$sub[0]] = $sub[0]." went wrong";
                    }
                }
            }
            
            if($error == 0 && $total_count == count($total_count_array)){
                $ReturnData['status'] = true;
                $ReturnData['status_code'] = 200;
                $ReturnData['message'] = "Decrypted successfully.";
            }else{                
                $ReturnData['status'] = false;
                $ReturnData['status_code'] = 401;
                $ReturnData['message'] = "Something went wrong.";
                //$ReturnData['error_message'] = $error_msg;
            }
        }else{
            //SECRET KEY NOT PASS MESSAGE
            $ReturnData['status'] = false;
            $ReturnData['status_code'] = 401;
            $ReturnData['message'] = "Something went wrong.";
        }
        return $ReturnData;
    }



    public static function stringEncryption( $action = 'encrypt', $string, $api_secret_key, $api_salt ) {
        
        //$secret_key = 'my_simple_secret_key';
        //$secret_iv = 'my_simple_secret_iv';

        $secret_key = $api_secret_key;
        $secret_iv = $api_salt;

        $output = false;
        $encrypt_method = "AES-256-CBC";
        $key = hash( 'sha256', $secret_key );
        $iv = substr( hash( 'sha256', $secret_iv ), 0, 16 );

        if( $action == 'encrypt' ) {
            $output = base64_encode( openssl_encrypt( $string, $encrypt_method, $key, 0, $iv ) );
        }
        else if( $action == 'decrypt' ){
            $output = openssl_decrypt( base64_decode( $string ), $encrypt_method, $key, 0, $iv );
        }

        return $output;
    }


    public static function PrepareStringOfRequest($type="SUB", $post=array()){
        $ReturnData = "";
        if($type == "SUB" || $type == "UNSUB"){
            $ReturnData .= "reqtype=".$post['reqtype']."&";
            $ReturnData .= "msisdn=".$post['msisdn']."&";
            $ReturnData .= "serviceid=".$post['serviceid']."&";
            $ReturnData .= "scode=".$post['scode']."&";
            $ReturnData .= "chnl=".$post['chnl'];
        }
        if($type == "CHECK"){           
            $ReturnData .= "reqtype=".$post['reqtype']."&";
            $ReturnData .= "msisdn=".$post['msisdn']."&";
            $ReturnData .= "serviceid=".$post['serviceid']."&";
            if(isset($post['scode']) && $post['scode'] != ""){
                $ReturnData .= "scode=".$post['scode']."&";
            }
            $ReturnData .= "STATUS=".$post['STATUS'];
        }
        return $ReturnData;
    }
    

   
}
