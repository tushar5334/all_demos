<?php namespace App\Libraries;

use App\Libraries\CustomErrorHandler;
use File;
use PDF;
use PDFMerger;
use URL;

class GeneratePdf  {

	public static function generateCoverPDF($pdfBodyData)
    {
        $cover = PDF::loadView('pdf.cover', $pdfBodyData);
        $cover = $cover->setPaper('a4');
        if(isset($pdfBodyData['orientation']) && $pdfBodyData['orientation']=='landscape') {
            $cover = $cover->setOrientation('landscape');
        }
        $cover = $cover->setOption('no-background', false);
        $cover = $cover->setOption('background', true);
        $cover = $cover->setOption('disable-javascript', true);
        $cover = $cover->setOption('print-media-type', false);
        $cover = $cover->setOption('margin-bottom', 0);
        $cover = $cover->setOption('margin-left', 0);
        $cover = $cover->setOption('margin-right', 0);
        $cover = $cover->setOption('margin-top', 0);
        $cover = $cover->save($pdfBodyData['storage_path'].'cover_'.$pdfBodyData['file_name']);
        return $pdfBodyData['storage_path'].'cover_'.$pdfBodyData['file_name'];

    }

    public static function generatePagePDF($pdfBodyData)
    {
        $cover = PDF::loadView($pdfBodyData['template'], $pdfBodyData['data']);
        $cover = $cover->setPaper('a4');
        if(isset($pdfBodyData['orientation']) && $pdfBodyData['orientation']=='landscape') {
            $cover = $cover->setOrientation('landscape');
        }
        $cover = $cover->setOption('margin-left','15');
        $cover = $cover->setOption('margin-right','15');
        $cover = $cover->setOption('margin-top','32');
        $cover = $cover->setOption('margin-bottom','15');
        $cover = $cover->setOption('header-html', $pdfBodyData['header']);
        $cover = $cover->setOption('footer-html', $pdfBodyData['footer']);
        $cover = $cover->save($pdfBodyData['storage_path'].$pdfBodyData['file_name']);
        return $pdfBodyData['storage_path'].$pdfBodyData['file_name'];

    }

    public static function generatePDFWithoutHeader($pdfBodyData)
    {
        $cover = PDF::loadView($pdfBodyData['template'], $pdfBodyData['data']);
        $cover = $cover->setPaper('a4');
        if(isset($pdfBodyData['orientation']) && $pdfBodyData['orientation']=='landscape') {
            $cover = $cover->setOrientation('landscape');
        }
        $cover = $cover->setOption('margin-left','2');
        $cover = $cover->setOption('margin-right','2');
        $cover = $cover->setOption('margin-top','5');
        $cover = $cover->setOption('margin-bottom','5');
        $cover = $cover->save($pdfBodyData['storage_path'].$pdfBodyData['file_name']);
        return $pdfBodyData['storage_path'].$pdfBodyData['file_name'];

    }


    public static function generatePDF($pdfConfigData=[])
    {

        // PDF File Template
        $pdfConfigData['pdf_template'] = (isset($pdfConfigData['pdf_template']) && !empty($pdfConfigData['pdf_template'])) ? $pdfConfigData['pdf_template'] : 'pdf.index';
        // Dynamic File Storage directory Name
        $pdfConfigData['storage_directory_name'] = (isset($pdfConfigData['storage_directory_name']) && !empty($pdfConfigData['storage_directory_name'])) ? $pdfConfigData['storage_directory_name'] : 'sub_folder';
        // PDF Storage Path
        $pdfConfigData['storage_path'] = (isset($pdfConfigData['storage_path']) && !empty($pdfConfigData['storage_path'])) ? $pdfConfigData['storage_path'] : '';
        // Default Generated File Name
        $pdfConfigData['filename'] = (isset($pdfConfigData['filename']) && !empty($pdfConfigData['filename'])) ? $pdfConfigData['filename'] : '';
        // Full layour with header and footer
        $pdfConfigData['full_layout'] = (isset($pdfConfigData['full_layout']) && $pdfConfigData['full_layout']) ? $pdfConfigData['full_layout'] : false;
        // Add Cover page when true
        $pdfConfigData['cover'] = (isset($pdfConfigData['cover']) && $pdfConfigData['cover']) ? $pdfConfigData['cover'] : false;
        // Post dynamic data in pdf pages
        $pdfConfigData['pdf_dynamic_data'] = (isset($pdfConfigData['pdf_dynamic_data']) && !empty($pdfConfigData['pdf_dynamic_data'])) ? $pdfConfigData['pdf_dynamic_data'] : '';
        // Post dynamic data in cover page
        $pdfConfigData['cover_data'] = (isset($pdfConfigData['cover_data']) && !empty($pdfConfigData['cover_data'])) ? $pdfConfigData['cover_data'] : '';
        // Post dynamic data in header
        $pdfConfigData['header_data'] = (isset($pdfConfigData['header_data']) && !empty($pdfConfigData['header_data'])) ? $pdfConfigData['header_data'] : '';
        
        // Generate PDF Name
        $randomFileName = GUID::create_guid();
        $generatedPdfName = (isset($pdfConfigData['filename']) && $pdfConfigData['filename']) ? $pdfConfigData['filename'] : $randomFileName.'.pdf';

        // Storage directory path
        $storageDirectoryName = (isset($pdfConfigData['storage_directory_name']) && $pdfConfigData['storage_directory_name']) ? storage_path('app/public/pdf/'.$pdfConfigData['storage_directory_name']) : storage_path('app/public/pdf');
        $exact_path = (isset($pdfConfigData['storage_path']) && $pdfConfigData['storage_path']) ? $pdfConfigData['storage_path'] : $storageDirectoryName;

        // File Full path
        $fullPath = $exact_path.'/'.$generatedPdfName;

        // Check file not exists
        if(!file_exists($fullPath)) {

            if(!File::exists($exact_path)) {
                File::makeDirectory($exact_path, 0777, true, true);
            }

            if(file_exists($fullPath)) {
                unlink($fullPath);
            }

            // PDF Page data
            $pdfData = [];
            $pdfData['data'] = (isset($pdfConfigData['pdf_dynamic_data']) && $pdfConfigData['pdf_dynamic_data']) ? $pdfConfigData['pdf_dynamic_data'] : '';
            //$saveTempPath = $exact_path.'/tmp_'.$randomFileName.'/';
            $saveTempPath = $exact_path.'/';
            $pdfBodyData = [
                'template' => $pdfConfigData['pdf_template'],
                'data'  => $pdfData,
                'storage_path'  =>  $saveTempPath,
                'file_name'  =>  $generatedPdfName,
                'orientation' => 'landscape'
            ];
            
            // PDF Cover
            if((isset($pdfConfigData['cover']) && $pdfConfigData['cover']) ){
                $pdfBodyData['cover_data'] = (isset($pdfConfigData['cover_data']) && $pdfConfigData['cover_data']) ? $pdfConfigData['cover_data'] : 'Cover Page';
                $coverHtml = view()->make('pdf.cover', $pdfBodyData)->render();
                $coverurl = GeneratePdf::generateCoverPDF($pdfBodyData);
            }

            // PDF Header and Footer
            if(isset($pdfConfigData['full_layout']) && $pdfConfigData['full_layout']==true ){
                $headerHtml = view()->make('pdf.header');                
                $headerHtml = $headerHtml->with('data', $pdfConfigData['header_data']);
                $headerHtml = $headerHtml->render();

                $footerHtml = view()->make('pdf.footer');              
                $footerHtml = $footerHtml->render();

                $pdfBodyData['header'] =  $headerHtml;
                $pdfBodyData['footer'] =  $footerHtml;             
                $url = GeneratePdf::generatePagePDF($pdfBodyData);
            } else {
                $url = GeneratePdf::generatePDFWithoutHeader($pdfBodyData);
            }

            // Merge PDF
            // $newpdf = new PDFMerger();
            // if(isset($pdfConfigData['cover']) && $pdfConfigData['cover']){
            //     $newpdf->addPDF($coverurl, '1');
            // }
            // if(isset($url) && $url){
            //     $newpdf->addPDF($url, 'all');
            // }
            // $newpdf->merge('file', $fullPath);

            // Delete temp path directory
            // File::deleteDirectory($saveTempPath);

        }

        return $fullPath;
    }
}
