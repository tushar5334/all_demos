<?php
namespace App\Libraries;

/**
 * @author Ashwin Vadgama <ashwinvadgama@gmail.com>
 * @uses This file Content Webservice Common Functions.
 * @return object
 */

use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Request;
use Response;

use App\Libraries\GUID;

use App\APILogs;



class WebService{

	protected function required_parameter(){
		$para = array();
		$input = Input::all();

/*		$para['custom']['aa'] = 'required';
		$para['custom']['a'] = 'required|boolean';
		$para['custom']['b'] = 'required|integer';
		$para['custom']['c'] = 'required|numeric';
		$para['custom']['d'] = 'required|alpha_num';
		$para['custom']['e'] = 'required|date_format:Y-m-d';
		$para['custom']['f'] = 'required|exists:locations,id';
		$para['custom']['g'] = 'required|exists:users,id,usertype,guide';

		//email => email address
		//boolean => only allow 0 or 1
		//integer => allow + or - in integer
		//numeric => allow + or - in numeric
		//alpha => only a to z allow
		//alpha_num => alpha numeric
		//date_format:format -> date_format:Y-m-d
		//exists:table,column
		//exists:table,column,add where condition
*/

		
		$para['login']['email'] = 'required';
		$para['login']['password'] = 'required';
		/*$para['login']['device_id'] = 'required';
		$para['login']['push_registration_id'] = 'required';
		$para['login']['app_version'] = 'required';
		$para['login']['device_type'] = 'required|in:ANDROID,IOS';
		$para['login']['os_version'] = 'required';
		$para['login']['build_version'] = 'required';
		$para['login']['request_date'] = 'required|date_format:Y-m-d H:i:s';*/

		$para['subscribe']['reqtype'] = 'required|in:SUB';
		$para['subscribe']['msisdn'] = 'required';
		$para['subscribe']['serviceid'] = 'required';
		$para['subscribe']['scode'] = 'required|numeric';
		$para['subscribe']['chnl'] = 'required';

		$para['un-subscribe']['reqtype'] = 'required|in:UNSUB';
		$para['un-subscribe']['msisdn'] = 'required';
		$para['un-subscribe']['serviceid'] = 'required';
		$para['un-subscribe']['scode'] = 'required|numeric';
		$para['un-subscribe']['chnl'] = 'required';

		$para['check-status']['reqtype'] = 'required|in:CHECK';
		$para['check-status']['msisdn'] = 'required';
		// $para['check-status']['serviceid'] = 'required';
		// $para['check-status']['scode'] = 'required|numeric';
		$para['check-status']['STATUS'] = 'required';

		$para['encryption-string']['reqtype'] = 'required|in:SUB,UNSUB,CHECK';
		$para['encryption-string']['msisdn'] = 'required';

		if(isset($input['reqtype']) && $input['reqtype'] === 'CHECK'){
			$para['encryption-string']['STATUS'] = 'required';
		}else{
			$para['encryption-string']['serviceid'] = 'required';
			$para['encryption-string']['scode'] = 'required|numeric';
			$para['encryption-string']['chnl'] = 'required';
		}
	
		/*$para['general-service-input']['device_id'] = 'required';
		$para['general-service-input']['push_registration_id'] = 'required';
		$para['general-service-input']['app_version'] = 'required';
		$para['general-service-input']['device_type'] = 'required|in:ANDROID,IOS';
		$para['general-service-input']['os_version'] = 'required';
		$para['general-service-input']['build_version'] = 'required';
		$para['general-service-input']['request_date'] = 'required|date_format:Y-m-d H:i:s';*/

		return $para;
	}

	protected function error_messages(){
		$error_msg = array();
		$error_msg['test'] = 'test.';
		return $error_msg;
	}

	protected function custom_validation(){
		Validator::extend('test', function($attribute, $value, $parameters)
        {
            return false;
        });
	}

	public function check_validation($service_type){
		$para = $this->required_parameter();
		$errormsg = $this->error_messages();
		$this->custom_validation();
 		$post = Input::all();
 		$post['custom'] = 1;

 		$post_keys = array();

 		$validator = Validator::make($post,$para[$service_type],$errormsg);

        if ($validator->fails()) {
        	$error = array();
        	$messages = $validator->errors();
        	foreach ($messages->all() as $key => $value) {
        		$error[] = $value;
        	}
			$errormsg = 'Error in fields.';
			$finaloutput = $this->prepare_data(false,401,$errormsg,'',$error);
	    }else{
	    	$finaloutput = $this->prepare_data(true,200);
	    }
	    return $finaloutput;
	}

	public function prepare_data($status=false,$statusCode=200, $msg="",$data=array(),$errorlist=array()){
		$dataready = array();
		$dataready['status'] = $status;
		$dataready['statusCode'] = $statusCode;
		if(isset($errorlist) && count($errorlist)>0){
			$dataready['message'] = $msg;
			$dataready['errorlist'] = $errorlist;
		}else{
			$dataready['message'] = $msg;
			if(isset($data) && count($data)>0){
				$dataready['data'] = $data;
			}/*else{
				//$dataready['message'] = $msg;
				$dataready['data'] = null;
			}*/
		}
		return $dataready;
	}

	public function output($result){
		//$this->StoreAPILOG($result);
		return response($result, $result['statusCode'])->header('Content-Type', "application/json");
	}

	public static function StoreAPILOG($result){
		$post = Input::all();
		$APILogs = new APILogs;
		$APILogs->log_id = GUID::create_guid();
		$APILogs->device_id = isset($post['device_id']) ? $post['device_id'] : "";
		$APILogs->push_registration_id = isset($post['push_registration_id']) ? $post['push_registration_id'] : "";
		$APILogs->app_version = isset($post['app_version']) ? $post['app_version'] : "";
		$APILogs->device_type = isset($post['device_type']) ? $post['device_type'] : "";
		$APILogs->os_version = isset($post['os_version']) ? $post['os_version'] : "";
		$APILogs->request_date = isset($post['request_date']) ? $post['request_date'] : "";
		$APILogs->request_parameter = json_encode($post);
		$APILogs->response_parameter = json_encode($result);
		$APILogs->message = isset($result['message']) ? $result['message'] : "";
		$APILogs->statusCode = $result['statusCode'];
		$APILogs->status = $result['status'];
		$APILogs->SAVE();
	}

	public static function GetCurrentApiVersionInfo(){
		$URI = Request::path();
        return $RequstWebserviceVersion = @explode("/",$URI)[1];
	}

}
