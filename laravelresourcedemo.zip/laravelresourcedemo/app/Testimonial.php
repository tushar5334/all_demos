<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Input;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\ColumnFillable;
use DB;
use Config;

class Testimonial extends Model
{

    protected $table = 'testimonials';
    protected $primaryKey = 'testimonial_id';
    public $incrementing = false;
    use SoftDeletes;
    use ColumnFillable;
    protected $dates = ['deleted_at'];

}