<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use App\Product;
use App\User;
class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        
        view()->composer(
            'admin.include.header', 
            function ($view) {
                //$productList = Product::getHeaderProductList();
                ///$usersList = User::getAffiliateList();
                $view;
            }
        );
    }
}
