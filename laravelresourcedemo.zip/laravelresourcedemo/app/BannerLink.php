<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Input;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Http\Requests\Admin\BannerLinkRequest;
use App\Traits\ColumnFillable;
use DB;
use Config;
use App\Libraries\GUID;

class BannerLink extends Model
{

    protected $table = 'banner_links';
    protected $primaryKey = 'banner_link_id';
    public $incrementing = false;
    use SoftDeletes;
    use ColumnFillable;
    protected $dates = ['deleted_at'];

    public static function insertORUpdateBannerList($logged_user_id="",$bannerID="",$hidBannerLength="",$bannerArray=[]){
    	if(!empty($bannerArray)){
    		$bannerIdArray = [];
	        for($i=0;$i<$hidBannerLength;$i++){	        	
	        	$post['banner_link_title'] = $bannerArray['banner_link_title'][$i];
                $post['banner_link_url'] = $bannerArray['banner_link_url'][$i];
               
                $bannerLinkObj = BannerLink::WHERE('banner_id',$bannerID);
                //$bannerLinkObj = BannerLink::WHERE('status','=',1);
                if(isset($post['banner_link_title']) && $post['banner_link_title'] != ""){
                    $bannerLinkObj = $bannerLinkObj->Where('banner_link_title','=',trim($post['banner_link_title']));
                }
                if(isset($post['banner_link_url']) && $post['banner_link_url'] != ""){
                    $bannerLinkObj = $bannerLinkObj->Where('banner_link_url','=',trim($post['banner_link_url']));
                }
                $bannerLinkObj = $bannerLinkObj->FIRST();
                //echo '<pre>';print_r($bannerLinkObj);echo'</pre>';exit;
                if(!empty($bannerLinkObj)){
                    $bannerIdArray[] = $bannerLinkObj->banner_link_id;
                }
                
                if(empty($bannerLinkObj))
                {
                    $banner_link_id = GUID::create_guid();
                    $post['banner_link_id'] = $banner_link_id;
                    $post['banner_id'] = $bannerID;
                    $post['created_by'] = $logged_user_id;
                    $post['updated_by'] = $logged_user_id;
                    BannerLink::create($post);
                    $bannerIdArray[] = $banner_link_id;
                } 
                else {
                    $post['updated_by'] = $logged_user_id;
                    $bannerLinkObj->update($post);
                }
	        	// if(empty($bannerLinkObj)){	        		
                //     $bannerLinkObj = new BannerLink();
                //     $banner_link_id = GUID::create_guid();
                //     $bannerLinkObj->banner_link_id =  $banner_link_id;
                //     $bannerIdArray[] = $banner_link_id;
	        	// }
	        	// $bannerLinkObj->banner_id = $bannerID;
	        	// $bannerLinkObj->banner_link_title = $post['banner_link_title'];
	        	// $bannerLinkObj->banner_link_url = $post['banner_link_url'];
	        	// $bannerLinkObj->created_by = $logged_user_id;
	        	// $bannerLinkObj->updated_by = $logged_user_id;
	        	// $bannerLinkObj->save();
            }
            if(!empty($bannerIdArray)){
	        	BannerLink::whereNotIn('banner_link_id', $bannerIdArray)->where('banner_id', $bannerID)->delete();
	        }
    	} else if(empty($bannerArray)) {
            BannerLink::where('banner_id', $bannerID)->delete();
        }
    }
}