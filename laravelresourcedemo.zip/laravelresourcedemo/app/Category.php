<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\ColumnFillable;

class Category extends Model{
    protected $table = 'categories';
    protected $primaryKey = 'category_id';
    public $incrementing = false;
    use SoftDeletes;
    use ColumnFillable;
    protected $dates = ['deleted_at'];
    // protected $fillable = ['category_id','parent_category_id','category_name','category_slug','category_level','category_description'];

    public static $categoryArray = [];

    public function parent(){
        return $this->hasMany(self::class);
    }

    public function children(){
        return $this->childrenCategory()->with('children');
    }

    public function childrenCategory() {
        return $this->hasMany(self::class, 'parent_category_id', 'category_id')->ORDERBY('created_at','ASC');
    }

    public static function getParentCategoryList(){
    	$categoryListObj = self::with('children')->where('status','1')->whereNull('parent_category_id')->get();
        $categoryList = self::buildTree($categoryListObj);
    	return $categoryList;
    }

    public static function buildTree($elements = array()) {
        foreach ($elements as $key => $value) {
            $finalCat = array(
                'category_id' => $value->category_id,
                'category_name' =>   $value->category_level > 0 ?  '|'.str_repeat("- ",$value->category_level) .' '. $value->category_name : $value->category_name,
            );
            self::$categoryArray[] = $finalCat;
            if(!empty($value->children)){
                self::buildTree($value->children);
            }
        }
        return self::$categoryArray;
    }
}
