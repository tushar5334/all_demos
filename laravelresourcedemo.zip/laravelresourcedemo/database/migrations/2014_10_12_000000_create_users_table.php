<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use App\Libraries\GUID;


class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->char('user_id', 36)->primary()->index();
            $table->string('name');
            $table->string('email',150)->unique()->index();
            $table->string('password');
            $table->string('user_code',50)->nullable();
            $table->string('profile_picture')->nullable();
            $table->enum('user_type', ['SuperAdmin', 'Admin', 'Affiliate'])->default('Affiliate')->index();
            $table->enum('user_status', ['Active', 'InActive'])->default('Active')->index();
            $table->rememberToken()->nullable();
            $table->tinyInteger('status')->default(1)->index()->comment = "0-InActive, 1-Active";
            $table->timestamps();
            $table->softDeletes();
        });      
        
        // Insert user
        DB::table('users')->insert(
            array(
                'user_id' => GUID::create_guid(),
                'name' => 'Super Admin',
                'email' => 'ashwin.vadgama@txtech.co',
                'password' => Hash::make('admin'),  
                'user_type' => 'SuperAdmin',         
                'user_status' => 'Active', 
                'created_at'    => Carbon::now(),
                'updated_at'    => Carbon::now()
            )
        );

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}