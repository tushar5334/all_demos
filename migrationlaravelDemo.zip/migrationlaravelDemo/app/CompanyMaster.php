<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\SoftDeletes;


class CompanyMaster extends Model
{
    use Notifiable;

    /**
    * The table associated with the model.
    *
    * @var string
    */
    protected $table = 'company_master';
    protected $primaryKey = 'company_id';

    public $incrementing = false;

    /* Customization start - ashwin for the revision class */
    use SoftDeletes;
    protected $dates = ['deleted_at'];
    /* Customization end - ashwin for the revision class */


    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [

    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [

    ];

    protected $casts = [
        'launch_date' => 'datetime:d/m/Y',
    ];

    //protected $appends = ['launch_date1'];

     /*public function getLaunchDate1Attribute() {
        //return $this->cat_name ." ".  $this->cat_slug;
        return  \Carbon\Carbon::parse($this->launch_date)->format('d/m/Y');
    }*/

    /*public function getLaunchDateAttribute($value) {
        //return  \Carbon\Carbon::parse($value)->format('d/m/Y');
    }*/

    public static function getCompanyDetail($userId="") {
        $userCompany = [];
        if(!empty($userId)) {
            $userCompany = CompanyMaster::select()->where('created_by', $userId)->where('status', 1)->get();
        }
        return $userCompany;
    }

    public function hasManyCompanyAddresses()
    {
        return $this->hasMany('App\CompanyAddresses','company_id', 'company_id');
    }  

}
