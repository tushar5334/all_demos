<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Http\Controllers\Controller;
use Illuminate\Contracts\Routing\ResponseFactory;
use Illuminate\Http\Response;

use App\Libraries\CustomErrorHandler;
use App\Libraries\General;
use App\Libraries\GUID;

use DB;
use Validator;

use App\CompanyMaster;
use App\CompanyAddresses;
use App\CompanyFinancials;
use App\CompanyEmpStrength;
use App\CompanyFundingRounds;
use App\CompanyTeamMembers;
use App\CompanyNewsLinks;

use App\OptionCateogry;
use App\CompanyTags;
use App\CompanyValuations;

use App\EventMaster;
use Carbon;
class AdminCompanyController extends Controller {

    private $res;

    public function __construct(ResponseFactory $responseFactory) {
        $this->res = $responseFactory;
    }

    /**
     * @uses Get List of Company
     *
     * @author Ghanshyam Tank
     *
     * @return json
     */
    public function getListOfCompany(Request $request){

        $jwtUserData = $request->jwtUserData;

        try {
            $postData = $request->all();

            $perPage = $request->get('rows', 10);
            $sortField = $request->get('sortField', 'company_master.created_at');
            $sortOrder = ($request->get('sortOrder')==1) ? 'ASC' : 'DESC';
            $globalFilter = $request->get('globalFilter');
            $offsetNumber = $request->get('first', 0);

            $companyData = CompanyMaster::SELECT(
                'company_master.company_id',
                'company_master.name',
                'company_master.launch_date',
                //'company_master.launch_year',
                'company_master.status',
                'company_master.website_url',
                'option_master.option'
            )->leftJoin('option_master', function($join)
            {
                $join->on('option_master.option_id', '=', 'company_master.company_type_id')
                ->where('option_master.status', 1)
                ->whereNull('option_master.deleted_at');
            });

            if(!empty($globalFilter)) {
                $companyData->where(function ($query) use ($globalFilter) {
                    $query->WHERE('company_master.name', 'LIKE', ["%{$globalFilter}%"]);
                });
            }

            $companyData = $companyData->orderby($sortField, $sortOrder)->paginate($perPage);


            return $this->res->json([
                'success'   =>  true,
                'message'   => "Company listed successfully.",
                'data'      => $companyData
            ], Response::HTTP_OK);

        } catch(\Exception $e) {
            CustomErrorHandler::APIServiceLog($e->getMessage(), "AdminPortalCompanyController: getListOfCompany");
            return [
                'success'   => false,
                'message'   => 'Something Went Wrong.'
            ];
        }
    }

    /**
     * @uses Get init data of Announced Deal
     *
     * @author Ghanshyam Tank
     *
     * @return json
     */
    public function getInitDataOfCompany(Request $request, $adId=""){

        $jwtUserData = $request->jwtUserData;

        try {

            $success = true;
            $message = 'data listed successfully.';

            $categoryList = ['tags_type','tags_client_focus','tags_industries'];

            $companyFinalData['companyInitData'] = OptionCateogry::getCategoryOptions($categoryList);

            return $this->res->json([
                'success'   =>  $success,
                'message'   => $message,
                'data'      => $companyFinalData
            ], Response::HTTP_OK);

        } catch(\Exception $e) {
            CustomErrorHandler::APIServiceLog($e->getMessage(), "FrontAnnouncedDealController: getInitDataOfAnnouncedDeal");
            return [
                'success'   => false,
                'message'   => 'Something Went Wrong.'
            ];
        }
    }

    /**
     * @uses Fetch Company Data for Update company
     *
     * @author Ghanshyam Tank
     *
     * @return json
     */
    public function getUpdateDataOfCompany(Request $request, $companyId=""){
        $jwtUserData = $request->jwtUserData;

        try {

            $companyFinalData = [];
            if(!empty($companyId)) {

                $companyUpdateData = CompanyMaster::Select('*')->with('hasManyCompanyAddresses')->find($companyId);
                if(isset($companyUpdateData->logo) && $companyUpdateData->logo) {
                    $imageUrlPath = General::imageUrlPath('company_logo', $companyUpdateData->logo, 1);
                    $companyUpdateData->downloadFileSrc = $imageUrlPath;
                }
                $companyFinalData['companyUpdateData'] = $companyUpdateData;
            }

            return $this->res->json([
                'success'   =>  true,
                'message'   => "Company detail fetched successfully.",
                'data'      => $companyFinalData
            ], Response::HTTP_OK);
        } catch(\Exception $e) {
            CustomErrorHandler::APIServiceLog($e->getMessage(), "AdminPortalCompanyController: getUpdateDataOfCompany");
            return [
                'success'   => false,
                'message'   => 'Something Went Wrong.'
            ];
        }
    }


    /**
     * @uses Delete company
     *
     * @author Ghanshyam Tank
     *
     * @return json
     */
    public function deleteCompany(Request $request, $companyId){

        try {
            $companyObj = CompanyMaster::find($companyId);
            if(isset($companyObj->company_id) && !empty($companyObj->company_id)) {
                $companyObj->delete();
                return $this->res->json([
                    'success'   =>  true,
                    'message'   => "Company deleted successfully.",
                ], Response::HTTP_OK);
            } else {
                return $this->res->json([
                    'success'   =>  false,
                    'message'   => "There is no company available.",
                ], Response::HTTP_OK);
            }

        } catch(\Exception $e) {
            CustomErrorHandler::APIServiceLog($e->getMessage(), "AdminPortalCompanyController: deleteCompany");
            return [
                'success'   => false,
                'message'   => 'Something Went Wrong.'
            ];
        }
    }

    /**
     * @uses Store Company Data
     *
     * @author Ghanshyam Tank
     *
     * @return json
     */
    public function storeCompanyData(Request $request){
        try {

            $jwtUserData = $request->jwtUserData;
            $postData = $request->all();

            $currentUserId = (isset($jwtUserData->user_id) && !empty($jwtUserData->user_id)) ? $jwtUserData->user_id : '';

            $rules=$messages=array();
            if(isset($postData['section_type']) && $postData['section_type'] == 'general_info') {
                $rules = array(
                    'name' => 'required',
                    'growth_stage' => 'required',
                    'company_status' => 'required',
                    'launch_date' => 'required',
                );
                $messages = [
                    'name.required' => 'The company name field is required.',
                    'growth_stage.required' => 'The growth stage field is required.',
                    'company_status.required' => 'The company status field is required.',
                    'launch_date.required' => 'The launch date field is required.',
                ];

                $sizeInKB = '2048';
                if(isset($postData['fileList']) && !empty($postData['fileList'])) {
                    $rules['fileList'] = 'image|mimes:jpeg,png,jpg,gif,svg|max:'.$sizeInKB;
                    $messages['fileList.image'] = 'The file must be an image.';
                    $messages['fileList.mimes'] = 'The file must be a file of type: jpeg, png, jpg, gif, svg.';
                    $messages['fileList.max'] = 'The file may not be greater than '.$sizeInKB.' kilobytes.';
                }
            }
            else if(isset($postData['section_type']) && $postData['section_type'] == 'address_section') {
                $rules = array(
                    'addresses.*.formated_address' => 'required',
                );
                $messages = [
                    'addresses.*.formated_address.required' => 'The formated address field is required.',
                ];
            }
            else if(isset($postData['section_type']) && $postData['section_type'] == 'analytics_links_section') {
                 $rules = array(
                    'website_url' => 'url',
                    'linkedin_url' => 'url',
                    'twitter_url' => 'url',
                    'facebook_url' => 'url',
                    'itunes_url' => 'url',
                    'googleplay_url' => 'url',
                );
                $messages = [
                    'website_url.url' => 'Please enter valid website url.',
                    'linkedin_url.url' => 'Please enter valid linkedin url.',
                    'twitter_url.url' => 'Please enter valid twitter url.',
                    'facebook_url.url' => 'Please enter valid facebook url.',
                    'itunes_url.url' => 'Please enter valid itunes url.',
                    'googleplay_url.url' => 'Please enter valid googleplay url.',
                ];
            }
            $validator = Validator::make($postData, $rules, $messages);
            if ($validator->fails()) {
                return $this->res->json([
                    'success' => false,
                    'message' => $validator->messages()
                ]);
            } else {
                $isNewCompany = 0;
                $companyId = $request->get('company_id');
                //$companyId = 'd8b0a24c-0d6c-ab37-5f70-5e215ebf199d';
                if(isset($postData['section_type']) && $postData['section_type'] == 'general_info') {
                    $launch_date = (!empty($request->get('launch_date'))) ? Carbon\Carbon::createFromFormat('d/m/Y', $request->get('launch_date'))->toDateString() : NULL;
                    // (1) ---------------- Store Company details - START ----------------
                    $companyObj = CompanyMaster::find($companyId);
                    if(!$companyObj) {
                        $isNewCompany = 1;
                        $companyId = GUID::create_guid();
                        $companyObj = new CompanyMaster();
                        $companyObj->company_id = $companyId;
                    }

                    $companyObj->name = $request->get('name');
                    $companyObj->tag_line = $request->get('tag_line');
                    $companyObj->growth_stage = $request->get('growth_stage');
                    $companyObj->company_status = $request->get('company_status');
                    $companyObj->launch_date = $launch_date;
                    if(isset($postData['fileList']) && $postData['fileList']){
                        $FileData =  General::fileUpload($postData['fileList'], "company_logo", $companyObj->logo);
                        $companyObj->logo = $FileData;
                    }
                    $companyObj->save();

                    // (1) ---------------- Store Company details - END ----------------
                }
                else if(isset($postData['section_type']) && $postData['section_type'] == 'analytics_links_section') {
                    $companyObj = CompanyMaster::find($companyId);
                    $companyObj->website_url = $request->get('website_url');
                    $companyObj->linkedin_url = $request->get('linkedin_url');
                    $companyObj->twitter_url = $request->get('twitter_url');
                    $companyObj->facebook_url = $request->get('facebook_url');
                    $companyObj->itunes_url = $request->get('itunes_url');
                    $companyObj->googleplay_url = $request->get('googleplay_url');
                    $companyObj->save();
                }
                else if(isset($postData['section_type']) && $postData['section_type'] == 'address_section') {
                    $inputAddresses = $request->get('addresses', []);
                    if(!empty($inputAddresses)) {
                        self::insertUpdateCompanyAddress($isNewCompany, $inputAddresses, $companyId, $currentUserId );
                    }
                }

                return $this->res->json([
                    'success'   =>  true,
                    'data'   =>  ['company_id'=>$companyId],
                    'message'   => "Company saved successfully.",
                ], Response::HTTP_OK);
            }
        } catch(\Exception $e) {
            CustomErrorHandler::APIServiceLog($e->getMessage(), "AdminPortalCompanyController: storeCompanyData");
            return [
                'success'   => false,
                'message'   => 'Something Went Wrong.'
            ];
        }
    }

    public function getMasterEventList(Request $request, $searchString="") {
        // $jwtUserData = $request->jwtUserData;
        try {

            $eventData = EventMaster::SELECT('*')
            ->where('event_master.status', 1)
            ->where(function($query) use ($searchString){
                $query->where('event_master.event_name', 'LIKE', "%$searchString%");
            })->get();

            return $this->res->json([
                'success'   =>  true,
                'data' => $eventData
            ], Response::HTTP_OK);
        } catch(\Exception $e) {
            CustomErrorHandler::APIServiceLog($e->getMessage(), "AdminPortalCompanyController: getMasterEventList");
            DB::rollback();
            return [
                'success'   => false,
                'message'   => 'Something Went Wrong.'
            ];
        }
    }

    public static function insertUpdateCompanyAddress($isNewCompany=true, $inputAddresses=[], $companyId, $currentUserId="" ) {

        if(!$isNewCompany) {
            $addressIds = @array_filter(array_unique(array_column($inputAddresses, 'address_id')));
            CompanyAddresses::whereNotIn('address_id', $addressIds)->where('company_id', $companyId)->delete();
        }

        foreach ($inputAddresses as $addresskey => $addressValue) {

            $companyAddressesObj = "";
            if (isset($addressValue['address_id']) && !empty($addressValue['address_id'])) {
                $companyAddressesObj = CompanyAddresses::find($addressValue['address_id']);
            }
            if (empty($companyAddressesObj)) {
                $companyAddressesObj = new CompanyAddresses();
                $companyAddressesObj->address_id = GUID::create_guid();
                $companyAddressesObj->company_id = $companyId;
                $companyAddressesObj->created_by = $currentUserId;
            }

            $companyAddressesObj->formated_address = $addressValue['formated_address'];
            $companyAddressesObj->is_hq = $addressValue['is_hq'];
            $companyAddressesObj->is_founding_location = $addressValue['is_founding_location'];
            $companyAddressesObj->updated_by = $currentUserId;
            $companyAddressesObj->save();
        }
    }
}
