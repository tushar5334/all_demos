<?php

namespace App\Http\Controllers\Front;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Http\Controllers\Controller;
use Illuminate\Contracts\Routing\ResponseFactory;
use Illuminate\Http\Response;

use App\Libraries\CustomErrorHandler;
use App\Libraries\General;
use App\Libraries\GUID;
use App\OptionCateogry;
use App\DealMaster;
use App\DealCoInvestors;
use App\CategoryAnswers;
use App\User;
use DB;
use Carbon;
use Validator;

class FrontAnnouncedDealController extends Controller {

    private $res;

    public function __construct(ResponseFactory $responseFactory) {
        $this->res = $responseFactory;
    }

    /**
     * @uses Get List of Announced Deal
     *
     * @author Ghanshyam Tank
     *
     * @return json
     */
    public function getListOfAnnouncedDeal(Request $request){

        $jwtUserData = $request->jwtUserData;
       try {
            $postData = $request->all();
            $customParam = reset($postData['customParam']);
            $customParam['category'] = (isset($customParam['category'])) ? array_column($customParam['category'], 'option'):[];
            $customParam['deal_status'] =(isset($customParam['deal_status']))  ? array_column($customParam['deal_status'], 'option') : [];
            $customParam['custom_filter'] =(isset($customParam['custom_filter']))  ? $customParam['custom_filter'] : [];
            $customParam['field_list']=['deal_master.deal_unique_id','deal_master.is_target_uk_based','deal_master.deal_name_from_article','deal_master.deal_variety'];
            $perPage = $request->get('rows', 1);
            $sortField = $request->get('sortField', 'deal_master.created_at');
            $sortOrder = ($request->get('sortOrder')==1) ? 'ASC' : 'DESC';
            $globalFilter = $request->get('globalFilter');
            $offsetNumber = $request->get('first', 0);
            $dealMasterData = DealMaster::SELECT(
                'deal_master.deal_id',
                'deal_master.deal_unique_id',
                'deal_master.announcing_deal_type',
                'deal_master.deal_status',
                'deal_master.is_target_uk_based',
                'deal_master.deal_name_from_article',
                'deal_master.deal_variety'
            )
            ->where('deal_master.status', 1);
            if(!empty($globalFilter)) {
                $dealMasterData->where(function ($query) use ($globalFilter) {
                    $query->WHERE('deal_master.deal_unique_id', 'LIKE', ["%{$globalFilter}%"]);
                });
            }

            if(isset($customParam['category']) || isset($customParam['deal_status']) || isset($customParam['custom_filter'])){
               $dealMasterData = $dealMasterData->where(function ($query) use ($customParam) {
                    if(count($customParam['category']) > 0){
                        $query->WhereIn('deal_master.deal_type', $customParam['category']);
                    }
                    if(count($customParam['deal_status']) > 0){
                        $query->orWhereIn('deal_master.deal_status', $customParam['deal_status']);
                    }

                    if(count($customParam['custom_filter']) > 0){
                        foreach ($customParam['custom_filter'] as $fKey => $custom_filter_value) {
                            foreach ($customParam['field_list'] as $fieldName) {
                                $query->orWhere($fieldName, 'LIKE', "%".$custom_filter_value."%");
                            }
                        }
                    }
                });
            }

            $dealMasterData = $dealMasterData->orderby($sortField, $sortOrder)->paginate($perPage);
            return $this->res->json([
                'success'   =>  true,
                'message'   => "data listed successfully.",
                'data'      => $dealMasterData
            ], Response::HTTP_OK);

        } catch(\Exception $e) {
            CustomErrorHandler::APIServiceLog($e->getMessage(), "FrontAnnouncedDealController: getListOfAnnouncedDeal");
            return [
                'success'   => false,
                'message'   => 'Something Went Wrong.'
            ];
        }
    }

    /**
     * @uses Get Store Announced Deal Data
     *
     * @author Ghanshyam Tank
     *
     * @return json
     */
    public function storeAnnouncedDealData(Request $request){

        $jwtUserData = $request->jwtUserData;
        $postData = $request->all();
        try {

            $deal_unique_id_unique_rule = (!empty($request->get('deal_id')))
            ?'unique:deal_master,deal_unique_id,'.$request->get('deal_id').',deal_id,deleted_at,NULL'
            :'unique:deal_master,deal_unique_id,null,deal_id,deleted_at,NULL';

            $rules = array(
                'deal_unique_id' => 'required|'.$deal_unique_id_unique_rule,
                'source' => 'required',
                'buy_side_firm_gp' => 'required',
                'target_firm_name' => 'required'
            );

            $messages = [
                'deal_unique_id.required' => 'The DealID field is required.',
                'deal_unique_id.unique' => 'The DealID field is already exists.',
                'source.required' => 'The source field is required.',
                'buy_side_firm_gp.required' => 'The buy-side firm gp field is required.',
                'target_firm_name.required' => 'The target firm name field is required.'
            ];

            $validator = Validator::make($postData, $rules, $messages);
            if ($validator->fails()) {
                return $this->res->json([
                    'success' => false,
                    'message' => $validator->messages()
                ]);
            } else {

                $isNewDeal = 0;
                $map_type = 'announced-deals';
                $currentUserId = isset($jwtUserData->user_id) && !empty($jwtUserData->user_id) ? $jwtUserData->user_id : '';
                $deal_id = $request->get('deal_id');
                $dealMasterObj = DealMaster::find($deal_id);
                if(!$dealMasterObj) {
                    $isNewDeal = 1;
                    $deal_id = GUID::create_guid();
                    $dealMasterObj = new DealMaster();
                    $dealMasterObj->deal_id = $deal_id;
                    $dealMasterObj->deal_unique_id = $request->get('deal_unique_id');
                }


                $dealMasterObj->last_verified_date = (!empty($request->get('last_verified_date'))) ? Carbon\Carbon::createFromFormat('d/m/Y', $request->get('last_verified_date'))->toDateString() : '';

                $dealMasterObj->date_news_article = (!empty($request->get('date_news_article'))) ? Carbon\Carbon::createFromFormat('d/m/Y', $request->get('date_news_article'))->toDateString() : '';


                $dealMasterObj->source = $request->get('source');
                $dealMasterObj->announcing_deal_type = $request->get('announcing_deal_type');
                $dealMasterObj->deal_status = $request->get('deal_status');
                $dealMasterObj->is_target_uk_based = $request->get('is_target_uk_based');
                $dealMasterObj->deal_name_from_article = $request->get('deal_name_from_article');
                $dealMasterObj->deal_variety = $request->get('deal_variety');
                $dealMasterObj->deal_area = $request->get('deal_area');
                $dealMasterObj->deal_type = $request->get('deal_type');
                $dealMasterObj->deal_sub_type = $request->get('deal_sub_type');
                $dealMasterObj->deal_rationale = $request->get('deal_rationale');
                $dealMasterObj->deal_value = $request->get('deal_value');
                $dealMasterObj->deal_value_currency = $request->get('deal_value_currency');
                $dealMasterObj->buy_side_firm_gp = $request->get('buy_side_firm_gp');
                $dealMasterObj->buy_side_partner_lead = $request->get('buy_side_partner_lead');
                $dealMasterObj->buy_side_advisiors = $request->get('buy_side_advisiors');
                $dealMasterObj->sell_side_firm = $request->get('sell_side_firm');
                $dealMasterObj->sell_side_partner_lead = $request->get('sell_side_partner_lead');
                $dealMasterObj->sell_side_advisiors = $request->get('sell_side_advisiors');
                $dealMasterObj->target_firm_name = $request->get('target_firm_name');
                $dealMasterObj->target_firm_hq_location = $request->get('target_firm_hq_location');
                $dealMasterObj->target_firm_industry_article = $request->get('target_firm_industry_article');
                $dealMasterObj->target_cust_focus_model = $request->get('target_cust_focus_model');
                $dealMasterObj->target_firm_home_page = $request->get('target_firm_home_page');
                $dealMasterObj->target_firm_linkedin_info = $request->get('target_firm_linkedin_info');
                $dealMasterObj->google_result_for_deal = $request->get('google_result_for_deal');
                $dealMasterObj->other_links_to_deal = $request->get('other_links_to_deal');
                $dealMasterObj->regulatory_issues = $request->get('regulatory_issues');
                $dealMasterObj->created_by = $currentUserId;
                $dealMasterObj->updated_by = $currentUserId;
                $dealMasterObj->save();


                // (1) ************** Store Target Firm Industry - START **************
                CategoryAnswers::deleteAndStoreCategoryAnswer($deal_id, $map_type, 4, $request->get('target_firm_industry_ftse', []), $isNewDeal);
                // (1) ---------------- Store Store Target Firm Industry - END ----------------

                // (2) ************** Store Target Firm Sub-Industry - START **************
                CategoryAnswers::deleteAndStoreCategoryAnswer($deal_id, $map_type, 5, $request->get('target_firm_sub_industry_ftse', []), $isNewDeal);
                // (2) ---------------- Store Target Firm Sub-Industry - END ----------------

                // (3) ************** Store Target Firm Tags - START **************
                CategoryAnswers::deleteAndStoreCategoryAnswer($deal_id, $map_type, 6, $request->get('target_firm_tags', []), $isNewDeal);
                // (3) ---------------- Store Target Firm Tags - END ----------------

                // (4) ************** Store Target Revenue Model - START **************
                CategoryAnswers::deleteAndStoreCategoryAnswer($deal_id, $map_type, 7, $request->get('target_revenue_model', []), $isNewDeal);
                // (4) ---------------- Store Target Revenue Model - END ----------------

                // (5) ************** Store Other Unsuccessful Bidder - START **************
                CategoryAnswers::deleteAndStoreCategoryAnswer($deal_id, $map_type, 8, $request->get('unsuccessful_bidder', []), $isNewDeal);
                // (5) ---------------- Store Other Unsuccessful Bidder - END ----------------

                // (6) ************** Store co-investors - START **************

                $co_investors = $request->get('co_investors', []);
                if(!$isNewDeal) {
                    $ciIDs = @array_filter(array_unique(array_column($co_investors, 'user_id')));
                    DealCoInvestors::whereNotIn('investor_id', $ciIDs)->where('deal_id', $deal_id)->delete();
                }

                foreach ($co_investors as $ci_key => $ci_val) {
                    $ciObj = "";
                    if (isset($ci_val['user_id']) && !empty($ci_val['user_id'])) {
                        $ciObj = DealCoInvestors::where('investor_id', $ci_val['user_id'])->where('deal_id', $deal_id)->first();
                    }
                    if (empty($ciObj)) {
                        $ciObj = new DealCoInvestors();
                        $ciObj->deal_co_investors_id = GUID::create_guid();
                        $ciObj->deal_id = $deal_id;
                    }
                        $ciObj->investor_id = $ci_val['user_id'];
                        $ciObj->save();
                }

                // (6) ---------------- Store co-investors - END ----------------

                return $this->res->json([
                    'success'   =>  true,
                    'message'   => "data listed successfully.",
                    'data'      => []
                ], Response::HTTP_OK);
            }

        } catch(\Exception $e) {
            CustomErrorHandler::APIServiceLog($e->getMessage(), "FrontAnnouncedDealController: storeAnnouncedDealData");
            return [
                'success'   => false,
                'message'   => 'Something Went Wrong.'
            ];
        }
    }

    /**
     * @uses Get init data of Announced Deal
     *
     * @author Ghanshyam Tank
     *
     * @return json
     */
    public function getInitDataOfAnnouncedDeal(Request $request, $adId=""){

        $jwtUserData = $request->jwtUserData;

        try {

            $success = true;
            $message = 'data listed successfully.';

            $categoryList = ['deal_type','deal_sub_type','deal_value_currency','target_firm_industrytransformed_into_ftse','target_firm_sub_industryftse','target_firm_tags','target_revenue_model','other_unsuccessful_bidderinvestor_firm'];

            $announceDealFinalData['announcedDealInitData'] = OptionCateogry::getCategoryOptions($categoryList);


            $coInvestorsList = array();
            $coInvestorsList = User::SELECT('user_id','full_name')->get()->toArray();
            $announceDealFinalData['announcedDealInitData']['coInvestorList'] = $coInvestorsList;


            if(!empty($adId)) {
                $selectedCoInvestorsList = User::SELECT('user_id','full_name')
                ->leftjoin('deal_co_investors','investor_id','user_id')
                ->where('deal_id',$adId)
                ->whereNull('deal_co_investors.deleted_at')
                ->get()->toArray();

                $announcedDealUpdateData = DealMaster::select(
                    '*',
                    DB::RAW('IF(last_verified_date!="" AND last_verified_date!="0000-00-00", DATE_FORMAT(last_verified_date, "%d/%m/%Y"), "") as last_verified_date'),
                    DB::RAW('IF(date_news_article!="" AND date_news_article!="0000-00-00", DATE_FORMAT(date_news_article, "%d/%m/%Y"), "") as date_news_article')
                    )->find($adId);

                if(isset($announcedDealUpdateData) && !empty($announcedDealUpdateData)){
                    $categoryAnswerList = OptionCateogry::getCategoryOptionAnswers($adId, 'announced-deals', $categoryList);

                    $announcedDealUpdateData->co_investors = $selectedCoInvestorsList;

                    $announcedDealUpdateData->target_firm_industry_ftse = isset($categoryAnswerList['target_firm_industrytransformed_into_ftse']) ? $categoryAnswerList['target_firm_industrytransformed_into_ftse'] : [];
                    $announcedDealUpdateData->target_firm_sub_industry_ftse = isset($categoryAnswerList['target_firm_sub_industryftse']) ? $categoryAnswerList['target_firm_sub_industryftse'] : [];
                    $announcedDealUpdateData->target_firm_tags = isset($categoryAnswerList['target_firm_tags']) ? $categoryAnswerList['target_firm_tags'] : [];
                    $announcedDealUpdateData->target_revenue_model = isset($categoryAnswerList['target_revenue_model']) ? $categoryAnswerList['target_revenue_model'] : [];
                    $announcedDealUpdateData->unsuccessful_bidder = isset($categoryAnswerList['other_unsuccessful_bidderinvestor_firm']) ? $categoryAnswerList['other_unsuccessful_bidderinvestor_firm'] : [];

                    $announceDealFinalData['announcedDealUpdateData'] = $announcedDealUpdateData;
                } else {
                    $success = false;
                    $message = 'No data found!';
                }


            } else {
                $announceDealFinalData['deal_unique_id'] = DealMaster::createDealUniqueId();
            }

            return $this->res->json([
                'success'   =>  $success,
                'message'   => $message,
                'data'      => $announceDealFinalData
            ], Response::HTTP_OK);

        } catch(\Exception $e) {
            CustomErrorHandler::APIServiceLog($e->getMessage(), "FrontAnnouncedDealController: getInitDataOfAnnouncedDeal");
            return [
                'success'   => false,
                'message'   => 'Something Went Wrong.'
            ];
        }
    }


    /**
     * @uses Get init data of Announced Deal
     *
     * @author Ghanshyam Tank
     *
     * @return json
     */
    public function getInitDataOfAnnouncedDealListPage(Request $request, $adId=""){

        $jwtUserData = $request->jwtUserData;

        try {

            $success = true;
            $message = 'data listed successfully.';

            $categoryList = ['deal_type'];

            $announceDealFinalData['announcedDealInitData'] = OptionCateogry::getCategoryOptions($categoryList);

            return $this->res->json([
                'success'   =>  $success,
                'message'   => $message,
                'data'      => $announceDealFinalData
            ], Response::HTTP_OK);

        } catch(\Exception $e) {
            CustomErrorHandler::APIServiceLog($e->getMessage(), "FrontAnnouncedDealController: getInitDataOfAnnouncedDealListPage");
            return [
                'success'   => false,
                'message'   => 'Something Went Wrong.'
            ];
        }
    }


    /**
     * @uses delete Announced Deal
     *
     * @author Ghanshyam Tank
     *
     * @return json
     */
    public function deleteAnnouncedDeal(Request $request, $adId=""){

        $jwtUserData = $request->jwtUserData;

        try {
            $dealObj = DealMaster::find($adId);
            if(isset($dealObj->deal_id) && !empty($dealObj->deal_id)) {
                $dealObj->delete();
                return $this->res->json([
                    'success'   =>  true,
                    'message'   => "Deal deleted successfully.",
                ], Response::HTTP_OK);
            } else {
                return $this->res->json([
                    'success'   =>  false,
                    'message'   => "There is no deal available.",
                ], Response::HTTP_OK);
            }

        } catch(\Exception $e) {
            CustomErrorHandler::APIServiceLog($e->getMessage(), "FrontAnnouncedDealController: deleteAnnouncedDeal");
            return [
                'success'   => false,
                'message'   => 'Something Went Wrong.'
            ];
        }
    }


    /**
     * @uses Get init data of Announced Deal
     *
     * @author Ghanshyam Tank
     *
     * @return json
     */
    public function getViewDetailOfAnnouncedDeal(Request $request, $adId=""){

        $jwtUserData = $request->jwtUserData;

        try {

            $announceDealFinalData = array();

            $categoryList = ['deal_type','deal_sub_type','deal_value_currency','target_firm_industrytransformed_into_ftse','target_firm_sub_industryftse','target_firm_tags','target_revenue_model','other_unsuccessful_bidderinvestor_firm'];


            if(!empty($adId)) {
                $selectedCoInvestorsList = User::SELECT('user_id','full_name')
                ->leftjoin('deal_co_investors','investor_id','user_id')
                ->where('deal_id',$adId)
                ->whereNull('deal_co_investors.deleted_at')
                ->get()->toArray();

                $announcedDealUpdateData = DealMaster::select(
                    '*',
                    DB::RAW('IF(last_verified_date!="" AND last_verified_date!="0000-00-00", DATE_FORMAT(last_verified_date, "%d/%m/%Y"), "") as last_verified_date'),
                    DB::RAW('IF(date_news_article!="" AND date_news_article!="0000-00-00", DATE_FORMAT(date_news_article, "%d/%m/%Y"), "") as date_news_article')
                    )->find($adId);

                $categoryAnswerList = OptionCateogry::getCategoryOptionAnswers($adId, 'announced-deals', $categoryList);
                if(isset($announcedDealUpdateData) && !empty($announcedDealUpdateData)){
                    $announcedDealUpdateData->co_investors = $selectedCoInvestorsList;
                    $announcedDealUpdateData->target_firm_industry_ftse = $categoryAnswerList['target_firm_industrytransformed_into_ftse'];
                    $announcedDealUpdateData->target_firm_sub_industry_ftse = $categoryAnswerList['target_firm_sub_industryftse'];
                    $announcedDealUpdateData->target_firm_tags = $categoryAnswerList['target_firm_tags'];
                    $announcedDealUpdateData->target_revenue_model = $categoryAnswerList['target_revenue_model'];
                    $announcedDealUpdateData->unsuccessful_bidder = $categoryAnswerList['other_unsuccessful_bidderinvestor_firm'];
                }

                $announceDealFinalData['announcedDealUpdateData'] = $announcedDealUpdateData;

                return $this->res->json([
                    'success'   =>  true,
                    'message'   => "data listed successfully.",
                    'data'      => $announceDealFinalData
                ], Response::HTTP_OK);
            } else {
                return $this->res->json([
                    'success'   =>  false,
                    'message'   => "There is no record available.",
                    'data'      => []
                ], Response::HTTP_OK);
            }


        } catch(\Exception $e) {
            CustomErrorHandler::APIServiceLog($e->getMessage(), "FrontAnnouncedDealController: getViewDetailOfAnnouncedDeal");
            return [
                'success'   => false,
                'message'   => 'Something Went Wrong.'
            ];
        }
    }



}
