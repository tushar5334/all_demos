<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\SoftDeletes;


class OptionCateogry extends Model
{
    use Notifiable;

    /**
    * The table associated with the model.
    *
    * @var string
    */
    protected $table = 'option_cateogry';
    protected $primaryKey = 'cat_id';

    public $incrementing = false;

    /* Customization start - ashwin for the revision class */
    use SoftDeletes;
    protected $dates = ['deleted_at'];
    /* Customization end - ashwin for the revision class */


    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [

    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [

    ];

    /*protected $appends = ['test_name'];

    public function getTestNameAttribute() {
        //return $this->cat_name ." ".  $this->cat_slug;
        return "{$this->cat_name} {$this->cat_slug}";
    }*/

    public function OptionList()
    {
        return $this->hasMany('App\OptionMaster','cat_id', 'cat_id')
                    ->SELECT(array(
                        'option_id',
                        'cat_id',
                        'option',
                        'option_image',
                        'option_remark',
                        'display_order',
                        'status'
                    ))
                    ->WHERE('status',1)
                    ->WHERENULL('deleted_at')
                    ->ORDERBY('display_order');
    }

    public function OptionAnswerList()
    {
        return $this->hasMany('App\CategoryAnswers','cat_id', 'cat_id');
    }

    public function CompanyTagOptionList()
    {
        return $this->hasMany('App\CompanyTags','option_cat_id', 'cat_id');
    }

    /**
     * @uses Get option list based on array of category slug
     * @author Ghanshyam Tank
     * @return json
        //OptionCateogry::getCategoryOptions(['what_best_describes_you','currency']);
     */
    public static function getCategoryOptions($category_slugs=[]){
        $ReturnData = array();
        if(isset($category_slugs) && count($category_slugs) > 0){
            $optionData = OptionCateogry::SELECT()
            ->WHERE('option_cateogry.status',1)
            ->WHEREIN('option_cateogry.cat_slug',$category_slugs)
            ->WITH('OptionList')
            ->ORDERBY('display_order')
            ->GET()->toArray();

            foreach ($optionData as $key => $value) {
                $ReturnData[$value['cat_slug']] = $value;
            }

        }
        return $ReturnData;
    }


    /**
     * @uses Get option list based on array of category slug
     * @author Ghanshyam Tank
     * @return json
        //OptionCateogry::getCategoryOptions(['what_best_describes_you','currency']);
     */
    public static function getCategoryOptionAnswers($mapId='', $map_type='announced-deals', $category_slugs=[]){
        $ReturnData = array();
        if(isset($category_slugs) && count($category_slugs) > 0){
            $optionData = OptionCateogry::SELECT()
            ->WHERE('option_cateogry.status',1)
            ->WHEREIN('option_cateogry.cat_slug',$category_slugs)
            ->WITH(['OptionAnswerList'=>function($q) use ($mapId, $map_type){
                $q->SELECT(
                        'category_answers.cat_answer_id',
                        'category_answers.option_id',
                        'option_master.cat_id',
                        'option_master.option'
                    )->leftjoin('option_master', 'option_master.option_id', 'category_answers.option_id')
                    ->where('category_answers.map_id', $mapId)
                    ->where('category_answers.map_type', $map_type)
                    ;
                }])
            ->ORDERBY('display_order')
            ->GET()->toArray();

            foreach ($optionData as $key => $value) {
                $ReturnData[$value['cat_slug']] = isset($value['option_answer_list']) ? $value['option_answer_list'] : [];
            }

        }
        return $ReturnData;
    }


    /**
     * @uses Get option list based on array of category slug
     * @author Ghanshyam Tank
     * @return json
        //OptionCateogry::getCategoryOptions(['what_best_describes_you','currency']);
     */
    public static function getCompanyTagOption($mapId='', $category_slugs=[]){

        $ReturnData = array();
        if(isset($category_slugs) && count($category_slugs) > 0){
            $optionData = OptionCateogry::SELECT()
            ->WHERE('option_cateogry.status',1)
            ->WHEREIN('option_cateogry.cat_slug',$category_slugs)
            ->WITH(['CompanyTagOptionList'=>function($q) use ($mapId){
                $q->SELECT('company_tags.tag_id',
                        'company_tags.option_cat_id',
                        'company_tags.option_id',
                        'option_master.option',
                        'option_master.cat_id',
                        'option_master.option_image',
                        'option_master.option_remark',
                        'option_master.display_order',
                        'option_master.status'
                        )
                    ->leftjoin('option_master', 'option_master.option_id', 'company_tags.option_id')
                    ->where('company_tags.company_id', $mapId);
            }])
            ->ORDERBY('display_order')
            ->GET()->toArray();
            foreach ($optionData as $key => $value) {
                if(isset($value['company_tag_option_list'])) {
                    if(count($value['company_tag_option_list']) > 0){
                        foreach ($value['company_tag_option_list'] as $CTOLkey => $CTOLvalue) {
                            unset($value['company_tag_option_list'][$CTOLkey]['option_cat_id']);
                            unset($value['company_tag_option_list'][$CTOLkey]['tag_id']);
                        }
                    }
                } else {
                    [];
                }
                $ReturnData[$value['cat_slug']] = $value['company_tag_option_list'];
            }

        }
        return $ReturnData;
    }

}
