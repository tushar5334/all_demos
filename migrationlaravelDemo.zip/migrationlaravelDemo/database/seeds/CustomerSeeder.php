<?php

use Illuminate\Database\Seeder;
use App\Customer;
class CustomerSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
       /* for ($i=0; $i <10 ; $i++) {
        	$cutomer = new Customer;
        	$cutomer->name ="Panny";
        	$cutomer->address ="US";
        	$cutomer->mobile_number =rand(10000, 399999);
        	$cutomer->type =rand(0, 1);
        	$cutomer->save();
        }*/

        factory(Customer::class,10)->create();
    }
}
