<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Customer;
use Faker\Generator as Faker;

$factory->define(Customer::class, function (Faker $faker) {
    return [
		'name' =>$faker->name,
		'address' =>$faker->country,
		//'mobile_number' =>$faker->phoneNumber, //number as a string
		//'mobile_number' =>numberBetween(1000000, 3434343),
		'mobile_number' =>rand(1000000, 3434343),
		//'age' =>numberBetween(15, 50),
		//'type' =>numberBetween(0, 1)
		'type' =>rand(0, 1)
    ];
});
